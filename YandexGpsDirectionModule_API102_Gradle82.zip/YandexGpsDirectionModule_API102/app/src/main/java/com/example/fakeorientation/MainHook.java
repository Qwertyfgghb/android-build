package com.example.fakeorientation;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;

import java.lang.reflect.Method;

import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedInterface;

public final class MainHook extends XposedModule {
    private static final String TAG = "YandexGpsDirection";
    private static final String TARGET_PACKAGE = "ru.yandex.yandexmaps";
    private static final String SERVICE_PACKAGE = "own.moderpach.extinguish";
    private static final String SERVICE_CLASS =
            "own.moderpach.extinguish.service.ExtinguishService";

    private static final float SCREEN_OFF_SPEED_KMH = 5.0f;
    private static final float SCREEN_ON_SPEED_KMH = 20.0f;
    private static final Object LOCK = new Object();

    private static Location lastLocation;
    private static float fakeAzimuth;
    private static int screenState = -1;
    private static boolean listenerStarted;

    @Override
    public void onModuleLoaded(ModuleLoadedParam param) {
        log(Log.INFO, TAG, "Module loaded in process " + param.getProcessName());
    }

    @Override
    public void onPackageLoaded(PackageLoadedParam param) {
        if (!TARGET_PACKAGE.equals(param.getPackageName())) return;

        log(Log.INFO, TAG, "Target package loaded");
        try {
            Method onCreate = android.app.Application.class.getDeclaredMethod("onCreate");
            hook(onCreate).setExceptionMode(XposedInterface.ExceptionMode.PROTECTIVE)
                    .intercept(chain -> {
                        Object result = chain.proceed();
                        Context context = (Context) chain.getThisObject();
                        startLocationListener(context);
                        installLocationHooks();
                        return result;
                    });
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook Application.onCreate: " + Log.getStackTraceString(t));
        }
    }

    private static void startLocationListener(Context context) {
        synchronized (LOCK) {
            if (listenerStarted) return;
            listenerStarted = true;
        }

        try {
            LocationManager manager =
                    (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
            if (manager == null) {
                logStatic(Log.WARN, "LocationManager unavailable");
                return;
            }

            LocationListener listener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    updateLocation(context, location);
                }
                @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) {}
            };

            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500L, 0f, listener);
            logStatic(Log.INFO, "GPS listener registered");
        } catch (Throwable t) {
            logStatic(Log.ERROR, "GPS listener failed: " + Log.getStackTraceString(t));
        }
    }

    private static void updateLocation(Context context, Location location) {
        if (location == null) return;

        synchronized (LOCK) {
            if (lastLocation != null && lastLocation.distanceTo(location) >= 1.0f) {
                fakeAzimuth = calculateBearing(lastLocation, location);
            }
            lastLocation = new Location(location);
        }

        if (location.hasSpeed()) {
            float speedKmh = location.getSpeed() * 3.6f;
            if (speedKmh < SCREEN_OFF_SPEED_KMH) {
                setScreen(context, 0);
            } else if (speedKmh >= SCREEN_ON_SPEED_KMH) {
                setScreen(context, 1);
            }
        }
    }

    private static float calculateBearing(Location from, Location to) {
        double lat1 = Math.toRadians(from.getLatitude());
        double lon1 = Math.toRadians(from.getLongitude());
        double lat2 = Math.toRadians(to.getLatitude());
        double lon2 = Math.toRadians(to.getLongitude());
        double dLon = lon2 - lon1;
        double y = Math.sin(dLon) * Math.cos(lat2);
        double x = Math.cos(lat1) * Math.sin(lat2)
                - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
        double bearing = Math.toDegrees(Math.atan2(y, x));
        if (bearing < 0) bearing += 360.0;
        return (float) bearing;
    }

    private void installLocationHooks() {
        try {
            Method getBearing = Location.class.getDeclaredMethod("getBearing");
            hook(getBearing).setExceptionMode(XposedInterface.ExceptionMode.PROTECTIVE)
                    .intercept(chain -> {
                        synchronized (LOCK) {
                            if (lastLocation == null) return chain.proceed();
                            return fakeAzimuth;
                        }
                    });

            Method hasBearing = Location.class.getDeclaredMethod("hasBearing");
            hook(hasBearing).setExceptionMode(XposedInterface.ExceptionMode.PROTECTIVE)
                    .intercept(chain -> {
                        synchronized (LOCK) {
                            return lastLocation != null;
                        }
                    });
            log(Log.INFO, TAG, "Location bearing hooks installed");
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook Location methods: " + Log.getStackTraceString(t));
        }
    }

    private static void setScreen(Context context, int state) {
        synchronized (LOCK) {
            if (screenState == state) return;
            try {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(SERVICE_PACKAGE, SERVICE_CLASS));
                intent.putExtra("screen", state);
                context.startService(intent);
                screenState = state;
                logStatic(Log.INFO, "Requested screen=" + state);
            } catch (Throwable t) {
                logStatic(Log.ERROR, "Screen service call failed: " + Log.getStackTraceString(t));
            }
        }
    }

    private static void logStatic(int priority, String message) {
        // Android logcat remains available from the target process.
        Log.println(priority, TAG, message);
    }
}
