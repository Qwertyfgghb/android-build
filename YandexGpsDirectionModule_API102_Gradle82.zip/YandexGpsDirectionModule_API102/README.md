# Yandex GPS Direction — libxposed API 102

Experimental module targeting Yandex Maps (`ru.yandex.yandexmaps`), migrated to modern `io.github.libxposed` API 102.

## Build compatibility
- Gradle 8.2
- Android Gradle Plugin 8.2.2
- JDK 17
- Android compile SDK 34
- `io.github.libxposed:api:102.0.0-SNAPSHOT` (preview snapshot)

The GitHub Actions workflow explicitly installs Gradle 8.2.

## Build on GitHub
Upload the project files to a GitHub repository, open Actions, and run **Build LSPosed API 102 module**. Download the `yandex-gps-direction-api102-debug` artifact.

## Current experimental behavior
- Computes movement bearing from successive GPS coordinates.
- Hooks Android `Location.getBearing()` and `Location.hasBearing()` in Yandex Maps.
- Requests `own.moderpach.extinguish/.service.ExtinguishService` with extra `screen=0` below 5 km/h and `screen=1` at 20 km/h or above. Between those thresholds it preserves the previous state.

## Important
- API 102 is a preview/snapshot and may change.
- The target device's LSPosed build must support modern libxposed API 102.
- The external `ExtinguishService` must be installed and permit cross-app service starts. A successful `startService()` return does not guarantee the screen changed.
- Hooking Android `Location` may not affect Yandex Maps' displayed direction if it uses a separate internal heading pipeline.
- This source has not been built in this environment; check GitHub Actions output and send any compiler error for correction.
