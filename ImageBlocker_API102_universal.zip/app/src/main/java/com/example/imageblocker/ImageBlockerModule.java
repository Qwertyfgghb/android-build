package com.example.imageblocker;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.Log;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import io.github.libxposed.api.XposedModule;

/**
 * Image display blocker for modern libxposed API 102.
 * Covers common ImageView paths used by Glide/Picasso/Coil, WebView network
 * images, and common Compose BitmapPainter/VectorPainter paths.
 * Library internals vary by version, so this is broad coverage, not a guarantee
 * that every custom renderer or network request is blocked.
 */
public final class ImageBlockerModule extends XposedModule {
    private static final String TAG = "ImageBlocker";
    private static final Set<String> HOOKED = ConcurrentHashMap.newKeySet();

    public ImageBlockerModule() { super(); }

    @Override
    public void onModuleLoaded(ModuleLoadedParam param) {
        log(Log.INFO, TAG, "ImageBlocker API 102 initialized");
    }

    @Override
    public void onPackageLoaded(PackageLoadedParam param) {
        String pkg = param.getPackageName();
        if (pkg == null || pkg.equals("com.example.imageblocker")) return;

        hookImageViewSetter("setImageBitmap", Bitmap.class);
        hookImageViewSetter("setImageDrawable", Drawable.class);
        hookImageViewSetter("setImageURI", Uri.class);
        hookImageViewSetter("setImageResource", int.class);
        hookVideoSurfaceVisibility();
        hookWebView();
        hookComposePainters(param.getDefaultClassLoader());
        log(Log.INFO, TAG, "HOOKS_READY package=" + pkg
                + " imageView=true videoSurface=true webView=true compose=best-effort");
    }

    private void hookImageViewSetter(String name, Class<?> argType) {
        try {
            Method method = ImageView.class.getDeclaredMethod(name, argType);
            installSkipHook(method, "ImageView#" + name);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook ImageView." + name, t);
        }
    }

    /**
     * Hide common Android video rendering surfaces without pausing the player.
     * Audio is not touched by this hook. This covers SurfaceView/TextureView based
     * players (including many VideoView/ExoPlayer configurations), but not every
     * custom OpenGL/native renderer.
     */
    private void hookVideoSurfaceVisibility() {
        try {
            Method method = View.class.getDeclaredMethod("setVisibility", int.class);
            String key = "View#setVisibility(video-surface)";
            if (!HOOKED.add(key)) return;
            hook(method).intercept(chain -> {
                Object target = chain.getThisObject();
                Object value = chain.getArg(0);
                if ((target instanceof SurfaceView || target instanceof TextureView)
                        && value instanceof Integer
                        && ((Integer) value) == View.VISIBLE) {
                    String type = target instanceof SurfaceView ? "SurfaceView" : "TextureView";
                    log(Log.INFO, TAG, "VIDEO_FRAME_BLOCKED type=" + type
                            + " method=View#setVisibility; audio playback not modified");
                    // Re-enter once with INVISIBLE; that call proceeds normally.
                    ((View) target).setVisibility(View.INVISIBLE);
                    return null;
                }
                return chain.proceed();
            });
            log(Log.INFO, TAG, "HOOK_INSTALLED " + key);

            // Many players create an already-visible SurfaceView/TextureView and never
            // call setVisibility(VISIBLE). Hide the surface when it is attached instead.
            Method attached = View.class.getDeclaredMethod("onAttachedToWindow");
            String attachKey = "View#onAttachedToWindow(video-surface)";
            if (HOOKED.add(attachKey)) {
                hook(attached).intercept(chain -> {
                    Object result = chain.proceed();
                    Object target = chain.getThisObject();
                    if (target instanceof SurfaceView || target instanceof TextureView) {
                        String type = target instanceof SurfaceView ? "SurfaceView" : "TextureView";
                        View view = (View) target;
                        if (view.getVisibility() != View.INVISIBLE && view.getVisibility() != View.GONE) {
                            view.setVisibility(View.INVISIBLE);
                            log(Log.INFO, TAG, "VIDEO_FRAME_BLOCKED type=" + type
                                    + " method=View#onAttachedToWindow; audio playback not modified");
                        }
                    }
                    return result;
                });
                log(Log.INFO, TAG, "HOOK_INSTALLED " + attachKey);
            }
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "HOOK_ERROR video-surface", t);
        }
    }

    private void hookWebView() {
        try {
            Method getSettings = WebView.class.getDeclaredMethod("getSettings");
            String key = "WebView#getSettings";
            if (HOOKED.add(key)) {
                hook(getSettings).intercept(chain -> {
                    Object result = chain.proceed();
                    if (result instanceof WebSettings) {
                        WebSettings settings = (WebSettings) result;
                        // The public WebSettings#setBlockNetworkImage method is abstract
                        // on Android; hook the concrete runtime implementation instead.
                        hookConcreteWebSettings(result.getClass());
                        try {
                            settings.setBlockNetworkImage(true);
                            log(Log.INFO, TAG, "NETWORK_IMAGE_BLOCKED surface=WebView mode=block-network-images");
                        } catch (Throwable t) {
                            log(Log.ERROR, TAG, "Could not block WebView images", t);
                        }
                    }
                    return result;
                });
                log(Log.INFO, TAG, "HOOK_INSTALLED " + key);
            }
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to install WebView getSettings hook", t);
        }
    }

    private void hookConcreteWebSettings(Class<?> runtimeClass) {
        try {
            Class<?> current = runtimeClass;
            Method concreteMethod = null;
            while (current != null && current != Object.class) {
                try {
                    Method candidate = current.getDeclaredMethod("setBlockNetworkImage", boolean.class);
                    if (!Modifier.isAbstract(candidate.getModifiers())) {
                        concreteMethod = candidate;
                        break;
                    }
                } catch (NoSuchMethodException ignored) {
                    // Check the superclass; framework implementations can inherit it.
                }
                current = current.getSuperclass();
            }
            if (concreteMethod == null) {
                log(Log.WARN, TAG, "No concrete setBlockNetworkImage implementation found for "
                        + runtimeClass.getName() + "; will still set block flag through normal API");
                return;
            }

            final Method hookedMethod = concreteMethod;
            String key = hookedMethod.getDeclaringClass().getName() + "#setBlockNetworkImage";
            if (!HOOKED.add(key)) return;
            hook(hookedMethod).intercept(chain -> {
                Object arg = chain.getArg(0);
                if (Boolean.FALSE.equals(arg)) {
                    log(Log.INFO, TAG, "WEBVIEW_IMAGE_SETTING_BLOCKED attempted=false implementation="
                            + hookedMethod.getDeclaringClass().getName());
                    return null;
                }
                return chain.proceed();
            });
            log(Log.INFO, TAG, "HOOK_INSTALLED " + key);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook concrete WebSettings implementation for "
                    + runtimeClass.getName(), t);
        }
    }

    private void hookComposePainters(ClassLoader classLoader) {
        if (classLoader == null) return;
        hookComposePainter(classLoader, "androidx.compose.ui.graphics.painter.BitmapPainter");
        hookComposePainter(classLoader, "androidx.compose.ui.graphics.painter.VectorPainter");
    }

    private void hookComposePainter(ClassLoader classLoader, String className) {
        try {
            Class<?> painterClass = Class.forName(className, false, classLoader);
            int count = 0;
            for (Method method : painterClass.getDeclaredMethods()) {
                if (method.getName().equals("onDraw") && !Modifier.isAbstract(method.getModifiers())) {
                    installSkipHook(method, className + "#onDraw");
                    count++;
                }
            }
            if (count == 0) log(Log.INFO, TAG, "No onDraw method found: " + className);
        } catch (ClassNotFoundException e) {
            log(Log.DEBUG, TAG, "Compose painter not present: " + className);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook Compose painter: " + className, t);
        }
    }

    private void installSkipHook(Method method, String key) {
        if (!HOOKED.add(key)) return;
        try {
            hook(method).intercept(chain -> {
                log(Log.INFO, TAG, "IMAGE_BLOCKED method=" + key);
                return null;
            });
            log(Log.INFO, TAG, "HOOK_INSTALLED " + key);
        } catch (Throwable t) {
            HOOKED.remove(key);
            log(Log.ERROR, TAG, "Failed to hook: " + key, t);
        }
    }
}
