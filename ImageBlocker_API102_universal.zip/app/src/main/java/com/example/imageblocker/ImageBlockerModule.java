package com.example.imageblocker;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.Log;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import io.github.libxposed.api.XposedModule;

/**
 * Image display blocker for modern libxposed API 102.
 * Covers common ImageView paths used by Glide/Picasso/Coil, WebView network
 * images, and common Compose BitmapPainter/VectorPainter paths.
 * Library internals vary by version, so this is broad coverage, not a guarantee
 * that every custom renderer or network request is blocked.
 */
public final class ImageBlockerModule extends XposedModule {
    private static final String TAG = "ImageBlocker";
    private static final Set<String> HOOKED = ConcurrentHashMap.newKeySet();
    private static final Set<String> TRACK_LOGGED = ConcurrentHashMap.newKeySet();
    private static final ThreadLocal<Boolean> APPLYING_TRACK_POLICY = ThreadLocal.withInitial(() -> false);

    public ImageBlockerModule() { super(); }

    @Override
    public void onModuleLoaded(ModuleLoadedParam param) {
        log(Log.INFO, TAG, "ImageBlocker API 102 initialized");
    }

    @Override
    public void onPackageLoaded(PackageLoadedParam param) {
        String pkg = param.getPackageName();
        if (pkg == null || pkg.equals("com.example.imageblocker")) return;

        hookImageViewSetter("setImageBitmap", Bitmap.class);
        hookImageViewSetter("setImageDrawable", Drawable.class);
        hookImageViewSetter("setImageURI", Uri.class);
        hookImageViewSetter("setImageResource", int.class);
        hookVideoSurfaceVisibility();
        hookWebView();
        hookComposePainters(param.getDefaultClassLoader());
        hookAutomaticVideoTrackDiscovery(param.getDefaultClassLoader());
        log(Log.INFO, TAG, "HOOKS_READY package=" + pkg
                + " imageView=true videoSurface=true webView=true compose=best-effort videoTrackAutoDiscovery=true");
    }

    /**
     * Best-effort automatic discovery of common ExoPlayer/Media3 track selectors.
     * It does not depend on one fixed obfuscated app class name: it observes classes
     * loaded by the target app and looks for the track-selection API by method shape.
     * When a supported selector exposes setTrackTypeDisabled(2, true), the video track
     * is disabled while audio remains selected. Unknown/custom players fall back to
     * hiding the output surface only.
     */
    private void hookAutomaticVideoTrackDiscovery(ClassLoader appLoader) {
        try {
            Method loadClass = ClassLoader.class.getDeclaredMethod("loadClass", String.class);
            String key = "ClassLoader#loadClass(video-track-discovery)";
            if (HOOKED.add(key)) {
                hook(loadClass).intercept(chain -> {
                    Object loaded = chain.proceed();
                    if (loaded instanceof Class<?>) {
                        discoverVideoTrackApi((Class<?>) loaded);
                    }
                    return loaded;
                });
                log(Log.INFO, TAG, "HOOK_INSTALLED " + key);
            }
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "HOOK_ERROR video-track-discovery-loader", t);
        }

        // Also inspect the usual APIs immediately in case the app loaded them before this hook.
        if (appLoader != null) {
            String[] likelyApis = new String[] {
                    "androidx.media3.exoplayer.ExoPlayer",
                    "androidx.media3.exoplayer.ExoPlayerImpl",
                    "androidx.media3.common.Player",
                    "androidx.media3.common.TrackSelectionParameters",
                    "androidx.media3.exoplayer.trackselection.DefaultTrackSelector",
                    "com.google.android.exoplayer2.ExoPlayer",
                    "com.google.android.exoplayer2.ExoPlayerImpl",
                    "com.google.android.exoplayer2.Player",
                    "com.google.android.exoplayer2.trackselection.DefaultTrackSelector"
            };
            for (String name : likelyApis) {
                try { discoverVideoTrackApi(Class.forName(name, false, appLoader)); }
                catch (Throwable ignored) { /* Library is not present in this app. */ }
            }
        }
    }

    private void discoverVideoTrackApi(Class<?> loadedClass) {
        if (loadedClass == null) return;
        String className = loadedClass.getName();
        String lower = className.toLowerCase(Locale.ROOT);
        if (!(lower.contains("exoplayer") || lower.contains("media3")
                || lower.contains("trackselector") || lower.contains("baseplayer"))) return;

        Class<?> current = loadedClass;
        while (current != null && current != Object.class) {
            for (Method method : current.getDeclaredMethods()) {
                String name = method.getName();
                if (Modifier.isAbstract(method.getModifiers()) || Modifier.isStatic(method.getModifiers())) continue;
                if (!(name.equals("setTrackSelectionParameters") || name.equals("setParameters"))) continue;
                if (method.getParameterTypes().length != 1) continue;
                String paramName = method.getParameterTypes()[0].getName().toLowerCase(Locale.ROOT);
                if (!(paramName.contains("trackselectionparameters") || paramName.endsWith("$parameters")
                        || paramName.contains("defaulttrackselector"))) continue;
                final String ownerClassName = current.getName();
                final String hookedSetterName = name;
                String key = ownerClassName + "#" + name + "(auto-video-track)";
                if (!HOOKED.add(key)) continue;
                try {
                    hook(method).intercept(chain -> {
                        Object result = chain.proceed();
                        if (!Boolean.TRUE.equals(APPLYING_TRACK_POLICY.get())) {
                            enforceVideoTrackDisabled(chain.getThisObject(), hookedSetterName, ownerClassName);
                        }
                        return result;
                    });
                    log(Log.INFO, TAG, "HOOK_INSTALLED " + key);
                } catch (Throwable t) {
                    HOOKED.remove(key);
                    log(Log.WARN, TAG, "VIDEO_TRACK_HOOK_UNAVAILABLE class=" + ownerClassName
                            + " method=" + name + " error=" + t.getClass().getSimpleName());
                }
            }
            current = current.getSuperclass();
        }
    }

    private void enforceVideoTrackDisabled(Object playerOrSelector, String setterName, String ownerName) {
        if (playerOrSelector == null || Boolean.TRUE.equals(APPLYING_TRACK_POLICY.get())) return;
        APPLYING_TRACK_POLICY.set(true);
        try {
            String getterName = setterName.equals("setTrackSelectionParameters")
                    ? "getTrackSelectionParameters" : "getParameters";
            Method getter = findNoArgMethod(playerOrSelector.getClass(), getterName);
            if (getter == null) return;
            Object parameters = getter.invoke(playerOrSelector);
            if (parameters == null) return;
            Method buildUpon = findNoArgMethod(parameters.getClass(), "buildUpon");
            if (buildUpon == null) return;
            Object builder = buildUpon.invoke(parameters);
            if (builder == null) return;
            Method disable = findTrackTypeDisabledMethod(builder.getClass());
            if (disable == null) {
                if (TRACK_LOGGED.add(ownerName)) {
                    log(Log.INFO, TAG, "VIDEO_TRACK_AUTO_DISCOVERY_UNSUPPORTED class=" + ownerName
                            + " reason=no-setTrackTypeDisabled; keeping surface-hide fallback");
                }
                return;
            }
            disable.invoke(builder, 2, true); // C.TRACK_TYPE_VIDEO in ExoPlayer/Media3.
            Method build = findNoArgMethod(builder.getClass(), "build");
            if (build == null) return;
            Object newParameters = build.invoke(builder);
            Method setter = findCompatibleSetter(playerOrSelector.getClass(), setterName,
                    newParameters.getClass());
            if (setter == null) return;
            setter.invoke(playerOrSelector, newParameters);
            if (TRACK_LOGGED.add(ownerName)) {
                log(Log.INFO, TAG, "VIDEO_TRACK_DISABLED player=" + ownerName
                        + " mode=track-selection audio=preserved");
            }
        } catch (Throwable t) {
            if (TRACK_LOGGED.add(ownerName + "#error")) {
                log(Log.WARN, TAG, "VIDEO_TRACK_DISABLE_FAILED player=" + ownerName
                        + " error=" + t.getClass().getSimpleName());
            }
        } finally {
            APPLYING_TRACK_POLICY.set(false);
        }
    }

    private Method findNoArgMethod(Class<?> type, String name) {
        Class<?> current = type;
        while (current != null && current != Object.class) {
            try {
                Method method = current.getDeclaredMethod(name);
                if (!Modifier.isAbstract(method.getModifiers())) {
                    method.setAccessible(true);
                    return method;
                }
            } catch (Throwable ignored) { }
            current = current.getSuperclass();
        }
        return null;
    }

    private Method findTrackTypeDisabledMethod(Class<?> builderClass) {
        Class<?> current = builderClass;
        while (current != null && current != Object.class) {
            for (Method method : current.getDeclaredMethods()) {
                Class<?>[] p = method.getParameterTypes();
                if (method.getName().equals("setTrackTypeDisabled") && p.length == 2
                        && (p[0] == int.class || p[0] == Integer.class)
                        && (p[1] == boolean.class || p[1] == Boolean.class)
                        && !Modifier.isAbstract(method.getModifiers())) {
                    try { method.setAccessible(true); } catch (Throwable ignored) { }
                    return method;
                }
            }
            current = current.getSuperclass();
        }
        return null;
    }

    private Method findCompatibleSetter(Class<?> type, String name, Class<?> parameterType) {
        Class<?> current = type;
        while (current != null && current != Object.class) {
            for (Method method : current.getDeclaredMethods()) {
                if (method.getName().equals(name) && method.getParameterTypes().length == 1
                        && method.getParameterTypes()[0].isAssignableFrom(parameterType)
                        && !Modifier.isAbstract(method.getModifiers())) {
                    try { method.setAccessible(true); } catch (Throwable ignored) { }
                    return method;
                }
            }
            current = current.getSuperclass();
        }
        return null;
    }

    private void hookImageViewSetter(String name, Class<?> argType) {
        try {
            Method method = ImageView.class.getDeclaredMethod(name, argType);
            installSkipHook(method, "ImageView#" + name);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook ImageView." + name, t);
        }
    }

    /**
     * Hide common Android video rendering surfaces without pausing the player.
     * Audio is not touched by this hook. This covers SurfaceView/TextureView based
     * players (including many VideoView/ExoPlayer configurations), but not every
     * custom OpenGL/native renderer.
     */
    private void hookVideoSurfaceVisibility() {
        try {
            Method method = View.class.getDeclaredMethod("setVisibility", int.class);
            String key = "View#setVisibility(video-surface)";
            if (!HOOKED.add(key)) return;
            hook(method).intercept(chain -> {
                Object target = chain.getThisObject();
                Object value = chain.getArg(0);
                if ((target instanceof SurfaceView || target instanceof TextureView)
                        && value instanceof Integer
                        && ((Integer) value) == View.VISIBLE) {
                    String type = target instanceof SurfaceView ? "SurfaceView" : "TextureView";
                    log(Log.INFO, TAG, "VIDEO_FRAME_BLOCKED type=" + type
                            + " method=View#setVisibility; audio playback not modified");
                    // Re-enter once with INVISIBLE; that call proceeds normally.
                    ((View) target).setVisibility(View.INVISIBLE);
                    return null;
                }
                return chain.proceed();
            });
            log(Log.INFO, TAG, "HOOK_INSTALLED " + key);

            // Many players create an already-visible SurfaceView/TextureView and never
            // call setVisibility(VISIBLE). Hide the surface when it is attached instead.
            Method attached = View.class.getDeclaredMethod("onAttachedToWindow");
            String attachKey = "View#onAttachedToWindow(video-surface)";
            if (HOOKED.add(attachKey)) {
                hook(attached).intercept(chain -> {
                    Object result = chain.proceed();
                    Object target = chain.getThisObject();
                    if (target instanceof SurfaceView || target instanceof TextureView) {
                        String type = target instanceof SurfaceView ? "SurfaceView" : "TextureView";
                        View view = (View) target;
                        if (view.getVisibility() != View.INVISIBLE && view.getVisibility() != View.GONE) {
                            view.setVisibility(View.INVISIBLE);
                            log(Log.INFO, TAG, "VIDEO_FRAME_BLOCKED type=" + type
                                    + " method=View#onAttachedToWindow; audio playback not modified");
                        }
                    }
                    return result;
                });
                log(Log.INFO, TAG, "HOOK_INSTALLED " + attachKey);
            }
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "HOOK_ERROR video-surface", t);
        }
    }

    private void hookWebView() {
        try {
            Method getSettings = WebView.class.getDeclaredMethod("getSettings");
            String key = "WebView#getSettings";
            if (HOOKED.add(key)) {
                hook(getSettings).intercept(chain -> {
                    Object result = chain.proceed();
                    if (result instanceof WebSettings) {
                        WebSettings settings = (WebSettings) result;
                        // The public WebSettings#setBlockNetworkImage method is abstract
                        // on Android; hook the concrete runtime implementation instead.
                        hookConcreteWebSettings(result.getClass());
                        try {
                            settings.setBlockNetworkImage(true);
                            log(Log.INFO, TAG, "NETWORK_IMAGE_BLOCKED surface=WebView mode=block-network-images");
                        } catch (Throwable t) {
                            log(Log.ERROR, TAG, "Could not block WebView images", t);
                        }
                    }
                    return result;
                });
                log(Log.INFO, TAG, "HOOK_INSTALLED " + key);
            }
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to install WebView getSettings hook", t);
        }
    }

    private void hookConcreteWebSettings(Class<?> runtimeClass) {
        try {
            Class<?> current = runtimeClass;
            Method concreteMethod = null;
            while (current != null && current != Object.class) {
                try {
                    Method candidate = current.getDeclaredMethod("setBlockNetworkImage", boolean.class);
                    if (!Modifier.isAbstract(candidate.getModifiers())) {
                        concreteMethod = candidate;
                        break;
                    }
                } catch (NoSuchMethodException ignored) {
                    // Check the superclass; framework implementations can inherit it.
                }
                current = current.getSuperclass();
            }
            if (concreteMethod == null) {
                log(Log.WARN, TAG, "No concrete setBlockNetworkImage implementation found for "
                        + runtimeClass.getName() + "; will still set block flag through normal API");
                return;
            }

            final Method hookedMethod = concreteMethod;
            String key = hookedMethod.getDeclaringClass().getName() + "#setBlockNetworkImage";
            if (!HOOKED.add(key)) return;
            hook(hookedMethod).intercept(chain -> {
                Object arg = chain.getArg(0);
                if (Boolean.FALSE.equals(arg)) {
                    log(Log.INFO, TAG, "WEBVIEW_IMAGE_SETTING_BLOCKED attempted=false implementation="
                            + hookedMethod.getDeclaringClass().getName());
                    return null;
                }
                return chain.proceed();
            });
            log(Log.INFO, TAG, "HOOK_INSTALLED " + key);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook concrete WebSettings implementation for "
                    + runtimeClass.getName(), t);
        }
    }

    private void hookComposePainters(ClassLoader classLoader) {
        if (classLoader == null) return;
        hookComposePainter(classLoader, "androidx.compose.ui.graphics.painter.BitmapPainter");
        hookComposePainter(classLoader, "androidx.compose.ui.graphics.painter.VectorPainter");
    }

    private void hookComposePainter(ClassLoader classLoader, String className) {
        try {
            Class<?> painterClass = Class.forName(className, false, classLoader);
            int count = 0;
            for (Method method : painterClass.getDeclaredMethods()) {
                if (method.getName().equals("onDraw") && !Modifier.isAbstract(method.getModifiers())) {
                    installSkipHook(method, className + "#onDraw");
                    count++;
                }
            }
            if (count == 0) log(Log.INFO, TAG, "No onDraw method found: " + className);
        } catch (ClassNotFoundException e) {
            log(Log.DEBUG, TAG, "Compose painter not present: " + className);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook Compose painter: " + className, t);
        }
    }

    private void installSkipHook(Method method, String key) {
        if (!HOOKED.add(key)) return;
        try {
            hook(method).intercept(chain -> {
                log(Log.INFO, TAG, "IMAGE_BLOCKED method=" + key);
                return null;
            });
            log(Log.INFO, TAG, "HOOK_INSTALLED " + key);
        } catch (Throwable t) {
            HOOKED.remove(key);
            log(Log.ERROR, TAG, "Failed to hook: " + key, t);
        }
    }
}
