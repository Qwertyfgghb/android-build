package com.example.imageblocker;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import io.github.libxposed.api.XposedModule;

/**
 * ImageBlocker Universal prototype for modern libxposed API 102.
 * Runs inside each package enabled in LSPosed Scope. It blocks common display
 * setters and attempts to stop image requests made through known library APIs.
 * It cannot universally intercept arbitrary native/custom networking.
 */
public final class ImageBlockerModule extends XposedModule {
    private static final String TAG = "ImageBlocker";
    private static final Set<String> HOOKED = ConcurrentHashMap.newKeySet();

    private static final String[][] LIBRARY_CLASSES = new String[][] {
        {"Glide", "com.bumptech.glide.RequestBuilder"},
        {"Picasso", "com.squareup.picasso.RequestCreator"},
        {"Coil 2", "coil.ImageViewKt"},
        {"Coil 3", "coil3.ImageViewKt"}
    };

    public ImageBlockerModule() { super(); }

    @Override
    public void onModuleLoaded(ModuleLoadedParam param) {
        log(Log.INFO, TAG, "ImageBlocker Universal API 102 initialized");
        log(Log.INFO, TAG, "Enable this module for every desired app in LSPosed Scope; global Scope is managed by LSPosed, not by the module itself.");
    }

    @Override
    public void onPackageLoaded(PackageLoadedParam param) {
        String pkg = param.getPackageName();
        if (pkg == null || pkg.equals("com.example.imageblocker")) return;

        ClassLoader loader = param.getDefaultClassLoader();
        log(Log.INFO, TAG, "Package loaded: " + pkg + "; scanning image APIs");

        // Common Android view assignment paths used by many image libraries.
        hookImageViewSetter("setImageBitmap", Bitmap.class);
        hookImageViewSetter("setImageDrawable", Drawable.class);
        hookImageViewSetter("setImageURI", Uri.class);
        hookImageViewSetter("setImageResource", int.class);

        // Network-saving hooks for common image-library entry points.
        scanLibrary(loader, "Glide", "com.bumptech.glide.RequestBuilder", "into");
        scanLibrary(loader, "Picasso", "com.squareup.picasso.RequestCreator", "into");
        scanLibrary(loader, "Coil 2", "coil.ImageViewKt", "load");
        scanLibrary(loader, "Coil 3", "coil3.ImageViewKt", "load");

        // WebView: block remote network images without disabling text/page content.
        hookWebView();

        // Compose painter draw methods when present in this app's classloader.
        hookComposePainters(loader);
        log(Log.INFO, TAG, "ImageBlocker scan finished for package: " + pkg);
    }

    private void hookImageViewSetter(String name, Class<?> argType) {
        try {
            Method method = ImageView.class.getDeclaredMethod(name, argType);
            installSkipHook(method, "Android ImageView#" + name, false);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook ImageView." + name, t);
        }
    }

    private void scanLibrary(ClassLoader loader, String label, String className, String methodName) {
        if (loader == null) return;
        try {
            Class<?> cls = Class.forName(className, false, loader);
            int found = 0;
            for (Method method : cls.getDeclaredMethods()) {
                if (!method.getName().equals(methodName)) continue;
                boolean hasImageView = false;
                for (Class<?> type : method.getParameterTypes()) {
                    if (ImageView.class.isAssignableFrom(type)) {
                        hasImageView = true;
                        break;
                    }
                }
                if (!hasImageView) continue;
                // Coil's ImageView.load extension and Glide/Picasso into(ImageView).
                // Skipping this entry point can avoid starting the image request.
                installSkipHook(method, label + "#" + method.getName(), true);
                found++;
            }
            if (found == 0) {
                log(Log.INFO, TAG, label + " detected, but no compatible " + methodName + "(ImageView) entry point found");
            } else {
                log(Log.INFO, TAG, label + " detected; image request hook candidates=" + found);
            }
        } catch (ClassNotFoundException e) {
            log(Log.DEBUG, TAG, label + " not present in this app");
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Library scan failed: " + label, t);
        }
    }

    private void hookWebView() {
        try {
            Method getSettings = WebView.class.getDeclaredMethod("getSettings");
            String key = "Android WebView#getSettings";
            if (HOOKED.add(key)) {
                hook(getSettings).intercept(chain -> {
                    Object result = chain.proceed();
                    if (result instanceof WebSettings) {
                        try {
                            ((WebSettings) result).setBlockNetworkImage(true);
                            log(Log.INFO, TAG, "WebView remote images blocked");
                        } catch (Throwable t) {
                            log(Log.ERROR, TAG, "Could not block WebView images", t);
                        }
                    }
                    return result;
                });
                log(Log.INFO, TAG, "Hook installed: " + key);
            }

            Method setBlock = WebSettings.class.getDeclaredMethod("setBlockNetworkImage", boolean.class);
            String setKey = "Android WebSettings#setBlockNetworkImage";
            if (HOOKED.add(setKey)) {
                hook(setBlock).intercept(chain -> {
                    Object arg = chain.getArg(0);
                    if (Boolean.FALSE.equals(arg)) {
                        log(Log.INFO, TAG, "Ignored app attempt to re-enable WebView network images");
                        return null;
                    }
                    return chain.proceed();
                });
                log(Log.INFO, TAG, "Hook installed: " + setKey);
            }
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to install WebView hooks", t);
        }
    }

    private void hookComposePainters(ClassLoader classLoader) {
        hookComposePainter(classLoader, "androidx.compose.ui.graphics.painter.BitmapPainter");
        hookComposePainter(classLoader, "androidx.compose.ui.graphics.painter.VectorPainter");
    }

    private void hookComposePainter(ClassLoader classLoader, String className) {
        if (classLoader == null) return;
        try {
            Class<?> painterClass = Class.forName(className, false, classLoader);
            int count = 0;
            for (Method method : painterClass.getDeclaredMethods()) {
                if (method.getName().equals("onDraw") && !Modifier.isAbstract(method.getModifiers())) {
                    installSkipHook(method, className + "#onDraw", false);
                    count++;
                }
            }
            if (count == 0) log(Log.INFO, TAG, "Compose painter class found but no onDraw hook candidate: " + className);
            else log(Log.INFO, TAG, "Compose painter hook candidates=" + count + " for " + className);
        } catch (ClassNotFoundException e) {
            log(Log.DEBUG, TAG, "Compose painter not present: " + className);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook Compose painter: " + className, t);
        }
    }

    private void installSkipHook(Method method, String label, boolean requestEntry) {
        String key = method.toGenericString();
        if (!HOOKED.add(key)) return;
        try {
            hook(method).intercept(chain -> {
                if (requestEntry) {
                    log(Log.INFO, TAG, "Blocked image request via " + label);
                } else {
                    log(Log.DEBUG, TAG, "Blocked image display via " + label);
                }
                Class<?> returnType = method.getReturnType();
                if (returnType == void.class) return null;
                if (ImageView.class.isAssignableFrom(returnType)) {
                    for (int i = 0; i < method.getParameterTypes().length; i++) {
                        Object arg = chain.getArg(i);
                        if (arg instanceof ImageView) return arg;
                    }
                }
                if (!returnType.isPrimitive()) return null;
                if (returnType == boolean.class) return false;
                if (returnType == char.class) return '\0';
                if (returnType == byte.class) return (byte) 0;
                if (returnType == short.class) return (short) 0;
                if (returnType == int.class) return 0;
                if (returnType == long.class) return 0L;
                if (returnType == float.class) return 0f;
                if (returnType == double.class) return 0d;
                return null;
            });
            log(Log.INFO, TAG, "Hook installed: " + label + " -> " + method.getName());
        } catch (Throwable t) {
            HOOKED.remove(key);
            log(Log.ERROR, TAG, "Failed to hook: " + label + " / " + method, t);
        }
    }
}
