package com.virtual.app.proxy;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.content.Intent;
import android.os.Bundle;

/**
 * Real Android entry point.  The target Activity is delegated to separately
 * after this proxy has been attached by ActivityThread.
 */
public class ProxyActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        ProxyInstrumentation.dispatchCreate(this, savedInstanceState);
    }

    @Override
    protected void onStart() {
        super.onStart();
        ProxyInstrumentation.dispatchStart(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ProxyInstrumentation.dispatchResume(this);
    }

    @Override
    protected void onPause() {
        ProxyInstrumentation.dispatchPause(this);
        super.onPause();
    }

    @Override
    protected void onStop() {
        ProxyInstrumentation.dispatchStop(this);
        super.onStop();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        ProxyInstrumentation.dispatchSaveInstanceState(this, outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        ProxyInstrumentation.dispatchNewIntent(this, intent);
    }

    @Override
    protected void onDestroy() {
        ProxyInstrumentation.dispatchDestroy(this);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (!ProxyInstrumentation.dispatchBackPressed(this)) {
            super.onBackPressed();
        }
    }
}
