# Devil virtual launch

This build adds a root-free in-process proxy runtime:
- ProxyActivity is the manifest entry point for virtual launches.
- ProxyInstrumentation replaces the proxy Activity instance with the target Activity loaded from the installed source APK.
- Target Application is created when declared by the source APK.
- Screen ON policy is selected by the cloned package and applied before target Activity creation.

This is an in-process virtualization foundation. Apps that depend on isolated Linux UID/process, privileged services, split APKs, or advanced Android framework APIs may still require additional compatibility hooks.
