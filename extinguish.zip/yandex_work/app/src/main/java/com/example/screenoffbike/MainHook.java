package com.example.screenoffbike;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "ScreenOffBike";

    // ==== Пороги скорости ====
    private static final float SLOW_SPEED_KMH = 12f;
    private static final float FAST_SPEED_KMH = 18f;

    // ==== Значения для Extinguish ====
    private static final int SCREEN_SLOW = 1; // медленно -> экран ВКЛ
    private static final int SCREEN_FAST = 0; // быстро  -> экран ВЫКЛ

    // ==== Тайминги ====
    private static final long POLL_MS        = 2000L;
    private static final long AM_THROTTLE_MS = 3000L;
    private static final long STALE_MS       = 5000L;

    // ==== Состояние ====
    private static volatile int    currentState = -1;
    private static volatile long   lastAmTime   = 0L;
    private static volatile double prevLat  = Double.NaN;
    private static volatile double prevLon  = Double.NaN;
    private static volatile long   prevTime = 0L;

    private static volatile Handler handler = null;
    private static volatile boolean started = false;

    // ==================================================================
    // Entry
    // ==================================================================

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps")
                && !lpparam.packageName.contains("yandexnavi")) return;

        XposedBridge.log(TAG + ": hooked in " + lpparam.packageName);
        ensureStarted();
    }

    // ==================================================================
    // Polling
    // ==================================================================

    private static synchronized void ensureStarted() {
        if (started) return;
        started = true;
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(pollRunnable, POLL_MS);
    }

    private static final Runnable pollRunnable = new Runnable() {
        @Override public void run() {
            try { poll(); } catch (Throwable t) {
                XposedBridge.log(TAG + ": poll error: " + t);
            }
            if (handler != null) handler.postDelayed(this, POLL_MS);
        }
    };

    private static void poll() {
        Context ctx = getAppContext();
        if (ctx == null) return;

        LocationManager lm =
                (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return;

        Location loc = null;
        try {
            loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (loc == null) loc = lm.getLastKnownLocation("fused");
            if (loc == null) loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        } catch (Throwable t) {
            return;
        }
        if (loc == null) return;

        long now = loc.getTime();
        if (now == 0L) now = System.currentTimeMillis();

        double lat = loc.getLatitude();
        double lon = loc.getLongitude();

        if (Double.isNaN(prevLat)) {
            prevLat = lat; prevLon = lon; prevTime = now;
            return;
        }

        long dtMs = now - prevTime;
        if (dtMs <= 0 || dtMs > STALE_MS) {
            prevLat = lat; prevLon = lon; prevTime = now;
            return;
        }

        double dLat = lat - prevLat;
        double dLon = lon - prevLon;
        double latM = dLat * 111320.0;
        double lonM = dLon * 111320.0 * Math.cos(Math.toRadians(lat));
        double distM = Math.hypot(latM, lonM);
        double speedKmh = (distM / (dtMs / 1000.0)) * 3.6;

        prevLat = lat; prevLon = lon; prevTime = now;

        updateState(speedKmh);
    }

    /** Context получаем через ActivityThread — AndroidAppHelper недоступен в api:82. */
    private static Context getAppContext() {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object app = XposedHelpers.callStaticMethod(at, "currentApplication");
            return (app instanceof Context) ? (Context) app : null;
        } catch (Throwable t) {
            return null;
        }
    }

    // ==================================================================
    // Логика
    // ==================================================================

    private static void updateState(double speedKmh) {
        int desired = currentState;

        if (speedKmh < SLOW_SPEED_KMH) {
            desired = SCREEN_SLOW;
        } else if (speedKmh > FAST_SPEED_KMH) {
            desired = SCREEN_FAST;
        }

        if (desired == -1 || desired == currentState) return;

        long now = System.currentTimeMillis();
        if (now - lastAmTime < AM_THROTTLE_MS) return;

        lastAmTime = now;
        currentState = desired;

        XposedBridge.log(TAG + ": speed=" + String.format("%.1f", speedKmh)
                + " км/ч -> screen=" + desired);

        sendAmCommand(desired);
    }

    // ==================================================================
    // am-вызов
    // ==================================================================

    private static void sendAmCommand(int screenValue) {
        String cmd =
                "am startservice -n own.moderpach.extinguish/.service.ExtinguishService "
                        + "--ei screen " + screenValue;
        try {
            Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": am fail: " + t);
        }
    }
}