package com.example.screenonspoof;

import android.app.Activity;
import android.app.Instrumentation;
import android.app.KeyguardManager;
import android.content.Intent;
import android.os.PowerManager;
import android.os.SystemClock;
import android.view.Display;
import android.view.Window;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * ScreenOnSpoof v5.
 *
 * Important: this version deliberately does NOT hook ActivityThread directly.
 * ActivityThread is an internal Android class and is not part of the normal
 * compile SDK API. v5 uses public SDK classes plus XposedHelpers only.
 *
 * The module also writes diagnostic messages to the Xposed/LSPosed log so we
 * can see which lifecycle callback happens when the physical screen is turned off.
 */
public class ScreenOnSpoofHook implements IXposedHookLoadPackage {
    private static final String TAG = "ScreenOnSpoof";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (lp == null || lp.packageName == null) return;

        log("START package=" + lp.packageName + " pid=" + android.os.Process.myPid());

        hookPower();
        hookDisplay();
        hookKeyguard();
        hookActivityLifecycleDiagnostics();
        hookWindowFocusDiagnostics();
        hookScreenBroadcastDiagnostics();
    }

    private void hookPower() {
        bool(PowerManager.class, "isInteractive", true);
        bool(PowerManager.class, "isScreenOn", true);
        bool(PowerManager.class, "isDeviceIdleMode", false);
        bool(PowerManager.class, "isLightDeviceIdleMode", false);
        bool(PowerManager.class, "isLowPowerStandbyEnabled", false);
        bool(PowerManager.class, "isExemptFromLowPowerStandby", true);
    }

    private void hookDisplay() {
        try {
            XposedHelpers.findAndHookMethod(Display.class, "getState", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    Object old = p.getResult();
                    p.setResult(Display.STATE_ON);
                    log("Display.getState old=" + old + " -> ON");
                }
            });
        } catch (Throwable t) { logError("Display.getState", t); }

        bool(Display.class, "isValid", true);
    }

    private void hookKeyguard() {
        bool(KeyguardManager.class, "isKeyguardLocked", false);
        bool(KeyguardManager.class, "isKeyguardSecure", false);
        bool(KeyguardManager.class, "inKeyguardRestrictedInputMode", false);
    }

    /**
     * Instrumentation is a public SDK class and is a safer diagnostic point
     * than importing the hidden ActivityThread class.
     *
     * We ONLY log pause/stop here. We intentionally do not cancel them yet.
     * That prevents the module from breaking the app lifecycle while we identify
     * the actual reason the timer stops.
     */
    private void hookActivityLifecycleDiagnostics() {
        try {
            XposedHelpers.findAndHookMethod(Instrumentation.class, "callActivityOnPause",
                    Activity.class, new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    Activity a = (Activity) p.args[0];
                    log("CALL_ACTIVITY_ON_PAUSE " + activityName(a));
                }
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    log("RETURN_ACTIVITY_ON_PAUSE");
                }
            });
        } catch (Throwable t) { logError("Instrumentation.callActivityOnPause", t); }

        try {
            XposedHelpers.findAndHookMethod(Instrumentation.class, "callActivityOnStop",
                    Activity.class, new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    Activity a = (Activity) p.args[0];
                    log("CALL_ACTIVITY_ON_STOP " + activityName(a));
                }
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    log("RETURN_ACTIVITY_ON_STOP");
                }
            });
        } catch (Throwable t) { logError("Instrumentation.callActivityOnStop", t); }

        // Also log base callbacks when they are reached. We do not alter them.
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onPause", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Activity.onPause " + activityName((Activity) p.thisObject));
                }
            });
        } catch (Throwable t) { logError("Activity.onPause", t); }

        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onStop", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Activity.onStop " + activityName((Activity) p.thisObject));
                }
            });
        } catch (Throwable t) { logError("Activity.onStop", t); }
    }

    private void hookWindowFocusDiagnostics() {
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onWindowFocusChanged", boolean.class,
                    new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Activity.onWindowFocusChanged focus=" + p.args[0]
                            + " " + activityName((Activity) p.thisObject));
                }
            });
        } catch (Throwable t) { logError("Activity.onWindowFocusChanged", t); }

        try {
            XposedHelpers.findAndHookMethod(Window.class, "onWindowFocusChanged", boolean.class,
                    new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Window.onWindowFocusChanged focus=" + p.args[0]);
                }
            });
        } catch (Throwable t) { logError("Window.onWindowFocusChanged", t); }
    }

    /**
     * Do not rewrite Intent.getAction(). That would corrupt unrelated intents.
     * Instead log screen broadcasts at the receiver boundary when available.
     */
    private void hookScreenBroadcastDiagnostics() {
        try {
            XposedHelpers.findAndHookMethod("android.content.ContextWrapper", null,
                    "sendBroadcast", Intent.class, new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    Intent i = (Intent) p.args[0];
                    if (i != null && (Intent.ACTION_SCREEN_OFF.equals(i.getAction())
                            || Intent.ACTION_SCREEN_ON.equals(i.getAction()))) {
                        log("sendBroadcast action=" + i.getAction());
                    }
                }
            });
        } catch (Throwable t) { logError("ContextWrapper.sendBroadcast", t); }
    }

    private String activityName(Activity a) {
        if (a == null) return "<null>";
        return a.getClass().getName();
    }

    private void bool(Class<?> c, String name, final boolean value) {
        try {
            XposedHelpers.findAndHookMethod(c, name, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    p.setResult(value);
                }
            });
        } catch (Throwable t) {
            logError(c.getName() + "." + name, t);
        }
    }

    private void log(String msg) {
        XposedBridge.log(TAG + " [" + SystemClock.uptimeMillis() + "]: " + msg);
    }

    private void logError(String where, Throwable t) {
        XposedBridge.log(TAG + " ERROR " + where + ": " + t);
    }
}
