ScreenOnSpoof v5

LSPosed module for the selected app scope.

What it spoofs:
- PowerManager.isInteractive() -> true
- PowerManager.isScreenOn() -> true
- Doze/Light Doze/Low Power Standby -> false
- Display.getState() -> STATE_ON
- Display.isValid() -> true
- Keyguard state -> unlocked

v5 intentionally does NOT cancel Activity pause/stop. It logs lifecycle events instead.
This is diagnostic: after turning the physical screen off, inspect LSPosed/Xposed log
for CALL_ACTIVITY_ON_PAUSE, CALL_ACTIVITY_ON_STOP, focus changes, and Display calls.

api-82.jar is bundled locally at app/libs/api-82.jar and is compileOnly.
No network download of the Xposed API is required.
