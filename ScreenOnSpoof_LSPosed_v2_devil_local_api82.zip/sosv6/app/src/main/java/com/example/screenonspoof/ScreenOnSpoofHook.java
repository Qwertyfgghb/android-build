package com.example.screenonspoof;

import android.app.Activity;
import android.app.Instrumentation;
import android.app.KeyguardManager;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.PowerManager;
import android.os.SystemClock;
import android.view.Display;
import android.view.Window;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** ScreenOnSpoof v6: state spoofing plus diagnostic callbacks. */
public class ScreenOnSpoofHook implements IXposedHookLoadPackage {
    private static final String TAG = "ScreenOnSpoof";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (lp == null || lp.packageName == null) return;
        log("START package=" + lp.packageName + " pid=" + android.os.Process.myPid());
        hookPower();
        hookDisplay();
        hookKeyguard();
        hookActivityLifecycleDiagnostics();
        hookWindowFocusDiagnostics();
        hookScreenBroadcastDiagnostics();
    }

    private void hookPower() {
        boolWithLog(PowerManager.class, "isInteractive", true);
        boolWithLog(PowerManager.class, "isScreenOn", true);
        boolWithLog(PowerManager.class, "isDeviceIdleMode", false);
        boolWithLog(PowerManager.class, "isLightDeviceIdleMode", false);
        boolWithLog(PowerManager.class, "isLowPowerStandbyEnabled", false);
        boolWithLog(PowerManager.class, "isExemptFromLowPowerStandby", true);
    }

    private void hookDisplay() {
        try {
            XposedHelpers.findAndHookMethod(Display.class, "getState", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    Object old = p.getResult();
                    p.setResult(Display.STATE_ON);
                    log("Display.getState old=" + old + " -> ON");
                }
            });
        } catch (Throwable t) { logError("Display.getState", t); }
        boolWithLog(Display.class, "isValid", true);
    }

    private void hookKeyguard() {
        boolWithLog(KeyguardManager.class, "isKeyguardLocked", false);
        boolWithLog(KeyguardManager.class, "isKeyguardSecure", false);
        boolWithLog(KeyguardManager.class, "inKeyguardRestrictedInputMode", false);
    }

    private void hookActivityLifecycleDiagnostics() {
        try {
            XposedHelpers.findAndHookMethod(Instrumentation.class, "callActivityOnPause",
                    Activity.class, new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("CALL_ACTIVITY_ON_PAUSE " + activityName((Activity) p.args[0]));
                }
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    log("RETURN_ACTIVITY_ON_PAUSE");
                }
            });
        } catch (Throwable t) { logError("Instrumentation.callActivityOnPause", t); }

        try {
            XposedHelpers.findAndHookMethod(Instrumentation.class, "callActivityOnStop",
                    Activity.class, new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("CALL_ACTIVITY_ON_STOP " + activityName((Activity) p.args[0]));
                }
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    log("RETURN_ACTIVITY_ON_STOP");
                }
            });
        } catch (Throwable t) { logError("Instrumentation.callActivityOnStop", t); }

        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onPause", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Activity.onPause " + activityName((Activity) p.thisObject));
                }
            });
        } catch (Throwable t) { logError("Activity.onPause", t); }

        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onStop", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Activity.onStop " + activityName((Activity) p.thisObject));
                }
            });
        } catch (Throwable t) { logError("Activity.onStop", t); }

        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onTrimMemory", int.class,
                    new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Activity.onTrimMemory level=" + p.args[0] + " " + activityName((Activity) p.thisObject));
                }
            });
        } catch (Throwable t) { logError("Activity.onTrimMemory", t); }
    }

    private void hookWindowFocusDiagnostics() {
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onWindowFocusChanged", boolean.class,
                    new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Activity.onWindowFocusChanged focus=" + p.args[0]
                            + " " + activityName((Activity) p.thisObject));
                }
            });
        } catch (Throwable t) { logError("Activity.onWindowFocusChanged", t); }

        try {
            XposedHelpers.findAndHookMethod(Window.class, "onWindowFocusChanged", boolean.class,
                    new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Window.onWindowFocusChanged focus=" + p.args[0]);
                }
            });
        } catch (Throwable t) { logError("Window.onWindowFocusChanged", t); }

        try {
            XposedHelpers.findAndHookMethod(Window.class, "isActive", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    log("Window.isActive=" + p.getResult());
                }
            });
        } catch (Throwable t) { logError("Window.isActive", t); }
    }

    private void hookScreenBroadcastDiagnostics() {
        try {
            XposedHelpers.findAndHookMethod(ContextWrapper.class, "sendBroadcast",
                    Intent.class, new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    Intent i = (Intent) p.args[0];
                    if (i != null && (Intent.ACTION_SCREEN_OFF.equals(i.getAction())
                            || Intent.ACTION_SCREEN_ON.equals(i.getAction()))) {
                        log("ContextWrapper.sendBroadcast action=" + i.getAction());
                    }
                }
            });
        } catch (Throwable t) { logError("ContextWrapper.sendBroadcast", t); }
    }

    private void boolWithLog(Class<?> c, String name, final boolean value) {
        try {
            XposedHelpers.findAndHookMethod(c, name, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    Object old = p.getResult();
                    p.setResult(value);
                    log(c.getSimpleName() + "." + name + " old=" + old + " -> " + value);
                }
            });
        } catch (Throwable t) { logError(c.getName() + "." + name, t); }
    }

    private String activityName(Activity a) {
        return a == null ? "<null>" : a.getClass().getName();
    }

    private void log(String msg) {
        XposedBridge.log(TAG + " [" + SystemClock.uptimeMillis() + "]: " + msg);
    }

    private void logError(String where, Throwable t) {
        XposedBridge.log(TAG + " ERROR " + where + ": " + t);
    }
}
