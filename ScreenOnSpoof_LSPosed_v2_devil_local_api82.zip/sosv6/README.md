# ScreenOnSpoof v6

LSPosed diagnostic build. Uses the local `app/libs/api-82.jar` via `compileOnly files('libs/api-82.jar')`; no API JAR download is needed.

Hooks screen/power state methods and logs Activity lifecycle, focus, memory trim, and screen broadcast send attempts to the LSPosed log with the `ScreenOnSpoof` prefix. This version is diagnostic: it does not suppress lifecycle callbacks and cannot guarantee that an app timer continues.

Build with the supplied `/devil` GitHub Actions workflow.
