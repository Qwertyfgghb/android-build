# Screen On Spoof — LSPosed legacy API 82

This project is prepared for the `/devil - Build APK` GitHub Actions workflow.

## Local API

The project intentionally uses:

```gradle
compileOnly files('libs/api-82.jar')
```

and contains `app/libs/api-82.jar` inside the ZIP. GitHub Actions does not need to download the Xposed API dependency.

The bundled `api-82.jar` is a small compile-time compatibility stub containing the legacy Xposed classes used by this project. The actual Xposed/LSPosed implementation is supplied by the framework at runtime and is therefore not packaged into the APK.

## LSPosed

Enable the module and select the applications in its Scope. The module hooks common app-visible power/display state APIs:

- `PowerManager.isInteractive()` → `true`
- `PowerManager.isScreenOn()` → `true`
- `PowerManager.isDeviceIdleMode()` → `false` when available
- `PowerManager.isLightDeviceIdleMode()` → `false` when available
- `PowerManager.isLowPowerStandbyEnabled()` → `false` when available
- `Display.getState()` → `Display.STATE_ON`
- `Display.isValid()` → `true`

This does not physically turn on the display.
