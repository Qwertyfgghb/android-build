# ScreenOnSpoof v7

LSPosed module intended for IZI (`com.veon.iziy`) on Android 11. The module only hooks that package. It spoofs a small set of screen/power state methods and requests a `PARTIAL_WAKE_LOCK` after an IZI Activity is created, to help the CPU continue running with the display off.

## Important limitations
- A wake lock does not keep the screen on and does not prevent `Activity.onPause()`/`onStop()`.
- If IZI's timer is tied to visible UI callbacks, this module cannot guarantee it continues updating while the screen is off.
- The wake lock is held while the target process remains alive; this can increase battery drain. Force-stop IZI or disable the module to release it.
- This version intentionally omits the methods that produced `NoSuchMethodError` in the supplied log (`isLowPowerStandbyEnabled`, `isExemptFromLowPowerStandby`, and `Window.onWindowFocusChanged`).

## Build
The local `app/libs/api-82.jar` is included. No API JAR download is needed. Build with the existing `/devil` GitHub Actions workflow (Java 17 / Gradle 8.2). ZIP root contains `app/`, `settings.gradle`, and `build.gradle`.

## Test
1. Build and install the APK.
2. Enable ScreenOnSpoof in LSPosed and select **only IZI**.
3. Force-stop IZI, reopen it, start the timer, and turn the screen off with the power button.
4. After testing, inspect LSPosed logs for `PARTIAL_WAKE_LOCK acquired`, `Activity.onPause`, and `Activity.onStop`.
