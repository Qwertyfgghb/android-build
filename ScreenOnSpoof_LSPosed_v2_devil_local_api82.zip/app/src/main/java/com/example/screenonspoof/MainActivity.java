package com.example.screenonspoof;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        t.setPadding(32, 32, 32, 32);
        t.setText("Screen On Spoof v7\n\nTarget: IZI (com.veon.iziy).\n\nHooks screen-state methods and acquires a PARTIAL_WAKE_LOCK when an IZI Activity is created. This can help keep CPU work running with the display off, but cannot force IZI to continue UI-bound timers or override every Android/vendor background restriction.\n\nEnable this module in LSPosed for IZI only, then force-stop and reopen IZI.");
        setContentView(t);
    }
}
