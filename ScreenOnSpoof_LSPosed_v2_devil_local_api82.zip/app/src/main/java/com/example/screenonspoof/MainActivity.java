package com.example.screenonspoof;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        t.setPadding(32, 32, 32, 32);
        t.setText("Screen On Spoof\n\nLSPosed module.\n\nEnable the module in LSPosed and select the applications where you want the physical screen-off state to be reported as ON/interactive.\n\nThe module changes app-visible state only; it does not turn on the display.");
        setContentView(t);
    }
}
