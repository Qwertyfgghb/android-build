package com.example.screenonspoof;

import android.app.Activity;
import android.app.ActivityThread;
import android.app.KeyguardManager;
import android.content.Intent;
import android.os.PowerManager;
import android.view.Display;
import android.view.Window;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** Screen state spoofing for the selected application. */
public class ScreenOnSpoofHook implements IXposedHookLoadPackage {
    private static final String TAG = "ScreenOnSpoof";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (lp == null || lp.packageName == null) return;
        hookPower();
        hookDisplay();
        hookKeyguard();
        hookActivityThreadLifecycle();
        hookActivityCallbacks();
        hookWindowFocus();
        hookIntentScreenOff();
    }

    private void hookPower() {
        bool(PowerManager.class, "isInteractive", true);
        bool(PowerManager.class, "isScreenOn", true);
        bool(PowerManager.class, "isDeviceIdleMode", false);
        bool(PowerManager.class, "isLightDeviceIdleMode", false);
        bool(PowerManager.class, "isLowPowerStandbyEnabled", false);
        bool(PowerManager.class, "isExemptFromLowPowerStandby", true);
    }

    private void hookDisplay() {
        try {
            XposedHelpers.findAndHookMethod(Display.class, "getState", new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam p) { p.setResult(Display.STATE_ON); }
            });
        } catch (Throwable t) { log("Display.getState", t); }
        bool(Display.class, "isValid", true);
    }

    private void hookKeyguard() {
        bool(KeyguardManager.class, "isKeyguardLocked", false);
        bool(KeyguardManager.class, "isKeyguardSecure", false);
        bool(KeyguardManager.class, "inKeyguardRestrictedInputMode", false);
    }

    /*
     * Hook ActivityThread rather than only Activity.onPause/onStop.
     * Apps normally override onPause/onStop, so hooking the base Activity
     * method alone does NOT intercept their overrides.
     */
    private void hookActivityThreadLifecycle() {
        try {
            Class<?> at = ActivityThread.class;
            XposedBridge.hookAllMethods(at, "performPauseActivity", new XC_MethodHook() {
                protected void beforeHookedMethod(MethodHookParam p) {
                    // Keep the Activity in the resumed path from the app's point of view.
                    // Do not invoke the framework pause operation.
                    if (p.getResult() == null) p.setResult(null);
                }
            });
        } catch (Throwable t) { log("ActivityThread.performPauseActivity", t); }

        try {
            Class<?> at = ActivityThread.class;
            XposedBridge.hookAllMethods(at, "performStopActivity", new XC_MethodHook() {
                protected void beforeHookedMethod(MethodHookParam p) {
                    // Most Android releases return boolean here; null is safe for void only,
                    // so only short-circuit known non-void methods with false.
                    Method m = p.method;
                    if (m.getReturnType() == boolean.class) p.setResult(false);
                    else if (m.getReturnType() == void.class) p.setResult(null);
                }
            });
        } catch (Throwable t) { log("ActivityThread.performStopActivity", t); }
    }

    private void hookActivityCallbacks() {
        // Base callbacks help for Activities that do not override them.
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onWindowFocusChanged", boolean.class,
                    new XC_MethodHook() {
                        protected void beforeHookedMethod(MethodHookParam p) { p.args[0] = true; }
                    });
        } catch (Throwable t) { log("Activity.onWindowFocusChanged", t); }
    }

    private void hookWindowFocus() {
        try {
            XposedHelpers.findAndHookMethod(Window.class, "onWindowFocusChanged", boolean.class,
                    new XC_MethodHook() {
                        protected void beforeHookedMethod(MethodHookParam p) { p.args[0] = true; }
                    });
        } catch (Throwable t) { log("Window.onWindowFocusChanged", t); }
    }

    /* Hide ACTION_SCREEN_OFF from dynamic receivers where possible. */
    private void hookIntentScreenOff() {
        try {
            XposedHelpers.findAndHookMethod(Intent.class, "getAction", new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam p) {
                    Object r = p.getResult();
                    if (Intent.ACTION_SCREEN_OFF.equals(r)) p.setResult(null);
                }
            });
        } catch (Throwable t) { log("Intent.getAction", t); }
    }

    private void bool(Class<?> c, String name, final boolean value) {
        try {
            XposedHelpers.findAndHookMethod(c, name, new XC_MethodHook() {
                protected void afterHookedMethod(MethodHookParam p) { p.setResult(value); }
            });
        } catch (Throwable ignored) { }
    }

    private void log(String where, Throwable t) {
        XposedBridge.log(TAG + ": " + where + ": " + t);
    }
}
