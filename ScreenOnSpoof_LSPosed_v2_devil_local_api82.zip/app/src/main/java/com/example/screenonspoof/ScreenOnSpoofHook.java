package com.example.screenonspoof;

import android.app.Activity;
import android.os.PowerManager;
import android.view.Display;
import android.view.Window;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Makes the hooked application see an interactive display even when the real
 * panel is off. It also suppresses common Activity callbacks that applications
 * use to pause timers when the screen is turned off.
 */
public class ScreenOnSpoofHook implements IXposedHookLoadPackage {
    private static final String TAG = "ScreenOnSpoof";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (lpparam == null || lpparam.packageName == null) return;

        hookPowerManager();
        hookDisplay();
        hookActivityLifecycle();
        hookWindowFocus();
    }

    private void hookPowerManager() {
        hookBoolean(PowerManager.class, "isInteractive", true);
        hookBoolean(PowerManager.class, "isScreenOn", true);
        hookBooleanIfPresent(PowerManager.class, "isDeviceIdleMode", false);
        hookBooleanIfPresent(PowerManager.class, "isLightDeviceIdleMode", false);
        hookBooleanIfPresent(PowerManager.class, "isLowPowerStandbyEnabled", false);
        hookBooleanIfPresent(PowerManager.class, "isExemptFromLowPowerStandby", true);
    }

    private void hookDisplay() {
        try {
            XposedHelpers.findAndHookMethod(Display.class, "getState", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    p.setResult(Display.STATE_ON);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Display.getState: " + t);
        }

        hookBooleanIfPresent(Display.class, "isValid", true);
    }

    private void hookActivityLifecycle() {
        // Many timers are stopped by the application's own onPause/onStop.
        // Skip the app callback while allowing the framework to continue its
        // internal lifecycle bookkeeping.
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onPause", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    p.setResult(null);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Activity.onPause: " + t);
        }

        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onStop", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    p.setResult(null);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Activity.onStop: " + t);
        }

        // Prevent apps from explicitly treating the loss of focus as a reason
        // to pause their timer. This does not keep the physical display on.
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onWindowFocusChanged", boolean.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam p) {
                            p.args[0] = true;
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Activity.onWindowFocusChanged: " + t);
        }
    }

    private void hookWindowFocus() {
        try {
            XposedHelpers.findAndHookMethod(Window.class, "onWindowFocusChanged", boolean.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam p) {
                            p.args[0] = true;
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Window.onWindowFocusChanged: " + t);
        }
    }

    private void hookBoolean(Class<?> clazz, String method, final boolean value) {
        try {
            XposedHelpers.findAndHookMethod(clazz, method, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    p.setResult(value);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": " + method + ": " + t);
        }
    }

    private void hookBooleanIfPresent(Class<?> clazz, String method, final boolean value) {
        try {
            XposedHelpers.findAndHookMethod(clazz, method, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    p.setResult(value);
                }
            });
        } catch (NoSuchMethodError | NoSuchMethodException ignored) {
            // API not available on this Android version.
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": optional " + method + ": " + t);
        }
    }
}
