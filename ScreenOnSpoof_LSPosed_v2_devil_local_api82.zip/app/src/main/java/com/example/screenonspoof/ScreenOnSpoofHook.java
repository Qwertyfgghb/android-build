package com.example.screenonspoof;

import android.app.Activity;
import android.os.PowerManager;
import android.os.SystemClock;
import android.view.Display;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** ScreenOnSpoof v7: target-only state hooks and a partial CPU wake lock. */
public class ScreenOnSpoofHook implements IXposedHookLoadPackage {
    private static final String TAG = "ScreenOnSpoof";
    private static final String TARGET = "com.veon.iziy";
    private static PowerManager.WakeLock wakeLock;

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (lp == null || !TARGET.equals(lp.packageName)) return;
        log("START target=" + lp.packageName + " pid=" + android.os.Process.myPid());
        hookPowerState();
        hookDisplayState();
        hookActivityDiagnosticsAndWakeLock();
    }

    private void hookPowerState() {
        hookBoolean(PowerManager.class, "isInteractive", true);
        hookBoolean(PowerManager.class, "isScreenOn", true);
        hookBoolean(PowerManager.class, "isDeviceIdleMode", false);
        hookBoolean(PowerManager.class, "isLightDeviceIdleMode", false);
    }

    private void hookDisplayState() {
        try {
            XposedHelpers.findAndHookMethod(Display.class, "getState", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    Object old = p.getResult();
                    p.setResult(Display.STATE_ON);
                    log("Display.getState old=" + old + " -> ON");
                }
            });
        } catch (Throwable t) { logError("Display.getState", t); }
        hookBoolean(Display.class, "isValid", true);
    }

    private void hookActivityDiagnosticsAndWakeLock() {
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onCreate", android.os.Bundle.class,
                    new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    Activity a = (Activity) p.thisObject;
                    log("Activity.onCreate " + activityName(a));
                    acquireCpuWakeLock(a);
                }
            });
        } catch (Throwable t) { logError("Activity.onCreate", t); }

        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onPause", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Activity.onPause " + activityName((Activity) p.thisObject));
                }
            });
        } catch (Throwable t) { logError("Activity.onPause", t); }

        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onStop", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Activity.onStop " + activityName((Activity) p.thisObject));
                }
            });
        } catch (Throwable t) { logError("Activity.onStop", t); }

        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onTrimMemory", int.class,
                    new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Activity.onTrimMemory level=" + p.args[0] + " " + activityName((Activity) p.thisObject));
                }
            });
        } catch (Throwable t) { logError("Activity.onTrimMemory", t); }

        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onWindowFocusChanged", boolean.class,
                    new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    log("Activity.onWindowFocusChanged focus=" + p.args[0]
                            + " " + activityName((Activity) p.thisObject));
                }
            });
        } catch (Throwable t) { logError("Activity.onWindowFocusChanged", t); }
    }

    private synchronized void acquireCpuWakeLock(Activity a) {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                log("PARTIAL_WAKE_LOCK already held");
                return;
            }
            PowerManager pm = (PowerManager) a.getApplicationContext().getSystemService("power");
            if (pm == null) { log("PowerManager unavailable; cannot acquire wake lock"); return; }
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ScreenOnSpoof:IZI");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire();
            log("PARTIAL_WAKE_LOCK acquired (held while this target process remains alive)");
        } catch (Throwable t) { logError("PARTIAL_WAKE_LOCK.acquire", t); }
    }

    private void hookBoolean(Class<?> c, String name, final boolean value) {
        try {
            XposedHelpers.findAndHookMethod(c, name, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    Object old = p.getResult();
                    p.setResult(value);
                    log(c.getSimpleName() + "." + name + " old=" + old + " -> " + value);
                }
            });
        } catch (Throwable t) { logError(c.getName() + "." + name, t); }
    }

    private String activityName(Activity a) { return a == null ? "<null>" : a.getClass().getName(); }
    private void log(String msg) { XposedBridge.log(TAG + " [" + SystemClock.uptimeMillis() + "]: " + msg); }
    private void logError(String where, Throwable t) { XposedBridge.log(TAG + " ERROR " + where + ": " + t); }
}
