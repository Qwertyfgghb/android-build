package com.example.screenonspoof;

import android.os.PowerManager;
import android.view.Display;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Screen/interactive-state spoof for the selected LSPosed app scope.
 *
 * The real panel can be OFF. Inside the hooked application, common Android
 * APIs report that the device/display is interactive and not idle.
 */
public class ScreenOnSpoofHook implements IXposedHookLoadPackage {
    private static final String TAG = "ScreenOnSpoof";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (lpparam == null || lpparam.packageName == null) return;

        hookPowerManager();
        hookDisplay();
    }

    private void hookPowerManager() {
        hookBoolean(PowerManager.class, "isInteractive", true);
        hookBoolean(PowerManager.class, "isScreenOn", true);
        hookBooleanIfPresent(PowerManager.class, "isDeviceIdleMode", false);
        hookBooleanIfPresent(PowerManager.class, "isLightDeviceIdleMode", false);
        hookBooleanIfPresent(PowerManager.class, "isLowPowerStandbyEnabled", false);
        hookBooleanIfPresent(PowerManager.class, "isExemptFromLowPowerStandby", true);
    }

    private void hookDisplay() {
        try {
            XposedHelpers.findAndHookMethod(Display.class, "getState",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(Display.STATE_ON);
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Display.getState: " + t);
        }

        // Some applications use these convenience methods instead of getState().
        hookBooleanIfPresent(Display.class, "isValid", true);
        hookBooleanIfPresent(Display.class, "isHdr", false);
    }

    private void hookBoolean(Class<?> clazz, String method, final boolean value) {
        try {
            XposedHelpers.findAndHookMethod(clazz, method,
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(value);
                        }
                    });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": " + method + ": " + t);
        }
    }

    private void hookBooleanIfPresent(Class<?> clazz, String method, final boolean value) {
        try {
            XposedHelpers.findAndHookMethod(clazz, method,
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(value);
                        }
                    });
        } catch (NoSuchMethodError | NoSuchMethodException ignored) {
            // API not available on this Android version.
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": optional " + method + ": " + t);
        }
    }
}
