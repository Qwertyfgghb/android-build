package com.example.fakeorientation;

import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "YandexGpsDirection";
    private static final String YANDEX_MAPS_PACKAGE = "ru.yandex.yandexmaps";

    private static final String SERVICE_PACKAGE = "own.moderpach.extinguish";
    private static final String SERVICE_CLASS =
            "own.moderpach.extinguish.service.ExtinguishService";

    // Screen turns off below 5 km/h and turns on at 20 km/h or faster.
    private static final float SCREEN_OFF_SPEED_KMH = 5.0f;
    private static final float SCREEN_ON_SPEED_KMH = 20.0f;

    private static final Object LOCK = new Object();
    private static Location lastLocation;
    private static float fakeAzimuth = 0f;
    private static int screenState = -1;
    private static boolean listenerStarted = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!YANDEX_MAPS_PACKAGE.equals(lpparam.packageName)) return;

        XposedBridge.log(TAG + ": loaded in " + lpparam.packageName);

        XposedHelpers.findAndHookMethod(
                Application.class,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        Context context = (Context) param.thisObject;
                        startLocationListener(context);
                        hookLocationBearing();
                    }
                }
        );
    }

    private static void startLocationListener(Context context) {
        synchronized (LOCK) {
            if (listenerStarted) return;
            listenerStarted = true;
        }

        try {
            LocationManager locationManager =
                    (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
            if (locationManager == null) {
                XposedBridge.log(TAG + ": LocationManager unavailable");
                return;
            }

            LocationListener listener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    updateLocation(context, location);
                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {}

                @Override
                public void onProviderEnabled(String provider) {}

                @Override
                public void onProviderDisabled(String provider) {}
            };

            // Runs inside Yandex Maps' process and uses its granted location permissions.
            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    500L,
                    0.0f,
                    listener
            );
            XposedBridge.log(TAG + ": GPS listener registered");
        } catch (SecurityException e) {
            XposedBridge.log(TAG + ": location permission denied: " + Log.getStackTraceString(e));
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": could not register GPS listener: " + Log.getStackTraceString(t));
        }
    }

    private static void updateLocation(Context context, Location location) {
        if (location == null) return;

        synchronized (LOCK) {
            if (lastLocation != null) {
                float distance = lastLocation.distanceTo(location);
                // Avoid noisy headings while stationary or when GPS points barely move.
                if (distance >= 1.0f) {
                    fakeAzimuth = calculateBearing(lastLocation, location);
                }
            }
            lastLocation = new Location(location);
        }

        if (location.hasSpeed()) {
            float speedKmh = location.getSpeed() * 3.6f;
            if (speedKmh < SCREEN_OFF_SPEED_KMH) {
                setScreen(context, 0);
            } else if (speedKmh >= SCREEN_ON_SPEED_KMH) {
                setScreen(context, 1);
            }
            // Between 5 and 20 km/h, preserve the previous screen state.
        }
    }

    private static float calculateBearing(Location from, Location to) {
        double lat1 = Math.toRadians(from.getLatitude());
        double lon1 = Math.toRadians(from.getLongitude());
        double lat2 = Math.toRadians(to.getLatitude());
        double lon2 = Math.toRadians(to.getLongitude());
        double dLon = lon2 - lon1;

        double y = Math.sin(dLon) * Math.cos(lat2);
        double x = Math.cos(lat1) * Math.sin(lat2)
                - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);

        double bearing = Math.toDegrees(Math.atan2(y, x));
        if (bearing < 0) bearing += 360.0;
        return (float) bearing;
    }

    private static void hookLocationBearing() {
        XposedHelpers.findAndHookMethod(
                Location.class,
                "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        synchronized (LOCK) {
                            param.setResult(fakeAzimuth);
                        }
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class,
                "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        synchronized (LOCK) {
                            // Do not claim a bearing before two usable GPS points exist.
                            param.setResult(lastLocation != null);
                        }
                    }
                }
        );
    }

    private static void setScreen(Context context, int state) {
        synchronized (LOCK) {
            if (screenState == state) return;

            try {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName(SERVICE_PACKAGE, SERVICE_CLASS));
                intent.putExtra("screen", state);
                context.startService(intent);
                screenState = state;
                XposedBridge.log(TAG + ": requested screen=" + state);
            } catch (Throwable t) {
                XposedBridge.log(TAG + ": screen service call failed: "
                        + Log.getStackTraceString(t));
            }
        }
    }
}
