# Yandex GPS Direction Module

An experimental LSPosed/Xposed module targeting **Yandex Maps** (`ru.yandex.yandexmaps`).

## What it currently does

- Registers a GPS location listener inside the Yandex Maps process.
- Calculates a movement bearing from successive GPS coordinates.
- Hooks `Location.getBearing()` and `Location.hasBearing()` in that process.
- Requests the external `ExtinguishService` to turn the screen off below **5 km/h** and on at **20 km/h or above**. Between 5 and 20 km/h, it keeps the previous state.

## Build on GitHub

1. Create a new GitHub repository and upload these files.
2. Open **Actions** and run **Build LSPosed module**, or push a commit.
3. Download the `yandex-gps-direction-debug` artifact from the workflow run.

The workflow builds `app-debug.apk`; it is not a release-signed APK.

## Install and test

1. Install the APK.
2. Enable it in LSPosed and select Yandex Maps.
3. Reboot or restart Yandex Maps.
4. Check LSPosed logs / logcat for the tag `YandexGpsDirection`.

## Important limitations

- The package name is assumed to be `ru.yandex.yandexmaps`; verify the installed Yandex Maps package if the hook does not activate.
- This is a first test build. Yandex Maps may use its own internal heading/orientation pipeline, so hooking Android's `Location` methods may not change the arrow as expected.
- `ExtinguishService` must exist on the device and allow this app process to start it. If Android blocks the service call or the service is not exported, screen control will fail. The code logs failures, but a successful `startService()` call does not prove that the screen actually changed.
- Screen-off threshold is currently 5 km/h. GPS speed may be absent or noisy, and the module leaves the screen state unchanged when speed is unavailable.
- The module does not request or bypass Android permissions. Yandex Maps must have location permission and GPS must be available.
