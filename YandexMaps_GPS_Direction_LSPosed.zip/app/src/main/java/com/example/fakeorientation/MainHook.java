package com.example.fakeorientation;

import android.content.Context;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    private static volatile float fakeAzimuth = 0f;
    private static volatile Location lastLocation;
    private static volatile boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"ru.yandex.yandexmaps".equals(lpparam.packageName)) return;

        XposedHelpers.findAndHookMethod(
            "android.app.Application", lpparam.classLoader, "onCreate",
            new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    synchronized (MainHook.class) {
                        if (started) return;
                        started = true;
                    }
                    try {
                        startLocation((Context) param.thisObject);
                    } catch (Throwable t) {
                        XposedBridge.log("FakeOrientation: start location failed: " + t);
                    }
                }
            }
        );

        XposedHelpers.findAndHookMethod(Location.class, "getBearing",
            new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    param.setResult(fakeAzimuth);
                }
            });

        XposedHelpers.findAndHookMethod(Location.class, "hasBearing",
            new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    param.setResult(true);
                }
            });

        // getOrientation is static: its returned array is the orientation result.
        try {
            XposedHelpers.findAndHookMethod(
                SensorManager.class, "getOrientation", float[].class, float[].class,
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam param) {
                        Object result = param.getResult();
                        if (result instanceof float[]) {
                            float[] orientation = (float[]) result;
                            if (orientation.length > 0) {
                                orientation[0] = (float) Math.toRadians(fakeAzimuth);
                                param.setResult(orientation);
                            }
                        }
                    }
                });
        } catch (Throwable t) {
            XposedBridge.log("FakeOrientation: orientation hook unavailable: " + t);
        }
    }

    private static void startLocation(Context context) {
        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return;

        LocationListener listener = new LocationListener() {
            @Override public void onLocationChanged(Location location) {
                updateFromLocation(location);
            }
            @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
            @Override public void onProviderEnabled(String provider) {}
            @Override public void onProviderDisabled(String provider) {}
        };

        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 1f, listener);
            Location current = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (current != null) updateFromLocation(current);
        } catch (SecurityException e) {
            XposedBridge.log("FakeOrientation: location permission unavailable: " + e);
        } catch (Throwable t) {
            XposedBridge.log("FakeOrientation: GPS updates failed: " + t);
        }
    }

    private static void updateFromLocation(Location location) {
        if (location == null) return;
        Location previous = lastLocation;
        // Update course only when the device has actually moved far enough to reduce GPS jitter.
        if (previous != null && location.distanceTo(previous) >= 2.0f
                && (!location.hasSpeed() || location.getSpeed() >= 1.0f)) {
            double lat1 = Math.toRadians(previous.getLatitude());
            double lon1 = Math.toRadians(previous.getLongitude());
            double lat2 = Math.toRadians(location.getLatitude());
            double lon2 = Math.toRadians(location.getLongitude());
            double dLon = lon2 - lon1;
            double y = Math.sin(dLon) * Math.cos(lat2);
            double x = Math.cos(lat1) * Math.sin(lat2)
                - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
            double bearing = Math.toDegrees(Math.atan2(y, x));
            if (bearing < 0) bearing += 360.0;
            fakeAzimuth = (float) bearing;
        }
        lastLocation = new Location(location);
    }
}
