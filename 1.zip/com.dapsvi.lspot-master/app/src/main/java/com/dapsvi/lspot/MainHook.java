package com.dapsvi.lspot;

import android.util.Log;
import java.lang.reflect.Method;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "LSpot";
    private static final String[] TARGETS = {"com.veon.izi", "com.veon.iziyyyyy"};
    private static final String BLOCKED_STR = "api.izi.me/auth/my-number";

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
        boolean isTarget = false;
        for (String t : TARGETS) {
            if (t.equals(lpparam.packageName)) isTarget = true;
        }
        if (!isTarget) return;

        XposedBridge.log(TAG + ": Loading for " + lpparam.packageName + " (PID: " + android.os.Process.myPid() + ")");

        // 1. Хук на обфусцированный OkHttpClient (dU.B)
        try {
            Class<?> clientClass = XposedHelpers.findClass("dU.B", lpparam.classLoader);
            if (clientClass != null) {
                XposedBridge.log(TAG + ": FOUND obfuscated OkHttpClient (dU.B)!");
                hookAllMethodsInClient(clientClass);
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": dU.B NOT FOUND directly. Will wait for ClassLoader.");
        }

        // 2. Хук на ClassLoader (если dU.B загрузится позже)
        try {
            XposedHelpers.findAndHookMethod(ClassLoader.class, "loadClass", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    String className = (String) param.args[0];
                    if ("dU.B".equals(className)) {
                        XposedBridge.log(TAG + ": Catching dU.B via ClassLoader!");
                        hookAllMethodsInClient((Class<?>) param.getResult());
                    }
                }
            });
        } catch (Throwable ignored) {}
    }

    // Перехватываем ВСЕ методы внутри dU.B
    private void hookAllMethodsInClient(Class<?> clientClass) {
        for (Method method : clientClass.getDeclaredMethods()) {
            try {
                XposedBridge.hookMethod(method, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        for (int i = 0; i < param.args.length; i++) {
                            Object arg = param.args[i];
                            if (arg == null) continue;
                            
                            try {
                                // Пытаемся вытащить URL из аргумента (объект Request)
                                Object urlObj = XposedHelpers.callMethod(arg, "url");
                                if (urlObj != null) {
                                    String url = urlObj.toString();
                                    if (url.contains(BLOCKED_STR)) {
                                        XposedBridge.log(TAG + " [!] BLOCKED (dU.B): " + url);
                                        
                                        // ВМЕСТО ИСКЛЮЧЕНИЯ: подменяем URL на несуществующий
                                        Object newRequest = replaceUrlInRequest(arg, "http://127.0.0.1:1/blocked");
                                        if (newRequest != null) {
                                            param.args[i] = newRequest;
                                            XposedBridge.log(TAG + " [!] URL REWRITTEN TO DEAD ENDPOINT");
                                        }
                                    }
                                }
                            } catch (Throwable ignored) {}
                        }
                    }
                });
            } catch (Throwable ignored) {}
        }
        XposedBridge.log(TAG + ": Hooked all methods in " + clientClass.getName());
    }

    // Утилита для подмены URL в обфусцированном Request
    private Object replaceUrlInRequest(Object request, String newUrl) {
        try {
            // 1. Ищем метод newBuilder() (возвращает Builder)
            Method newBuilderMethod = null;
            for (Method m : request.getClass().getDeclaredMethods()) {
                if (m.getParameterCount() == 0 && m.getReturnType().getName().contains("Builder")) {
                    newBuilderMethod = m; break;
                }
            }
            if (newBuilderMethod == null) return null;
            
            Object builder = newBuilderMethod.invoke(request);
            Class<?> builderClass = builder.getClass();
            
            // 2. Ищем метод url(String)
            Method urlMethod = null;
            for (Method m : builderClass.getDeclaredMethods()) {
                if (m.getParameterCount() == 1 && m.getParameterTypes()[0] == String.class) {
                    urlMethod = m; break;
                }
            }
            if (urlMethod == null) return null;
            
            // 3. Ищем метод build() (возвращает Request)
            Method buildMethod = null;
            for (Method m : builderClass.getDeclaredMethods()) {
                if (m.getParameterCount() == 0 && m.getReturnType() == request.getClass()) {
                    buildMethod = m; break;
                }
            }
            if (buildMethod == null) return null;
            
            // 4. Выполняем подмену
            urlMethod.invoke(builder, newUrl);
            return buildMethod.invoke(builder);
        } catch (Throwable t) {
            XposedBridge.log(TAG + " Failed to rewrite URL: " + t.getMessage());
            return null;
        }
    }
}