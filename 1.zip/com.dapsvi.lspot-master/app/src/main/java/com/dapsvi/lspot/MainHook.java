package com.dapsvi.lspot;

import android.util.Log;
import java.io.IOException;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "LSpot";
    private static final String[] TARGETS = {"com.veon.izi", "com.veon.iziyyyyy"};
    private static final String BLOCKED_STR = "api.izi.me/auth/my-number";

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
        boolean isTarget = false;
        for (String t : TARGETS) {
            if (t.equals(lpparam.packageName)) isTarget = true;
        }
        if (!isTarget) return;

        XposedBridge.log(TAG + ": Loading for " + lpparam.packageName + " (PID: " + android.os.Process.myPid() + ")");

        // 1. Попытка найти OkHttp сразу
        try {
            Class<?> clientClass = XposedHelpers.findClass("okhttp3.OkHttpClient", lpparam.classLoader);
            XposedBridge.log(TAG + ": OkHttpClient FOUND directly!");
            hookOkHttpClient(clientClass, lpparam.classLoader);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": OkHttpClient NOT FOUND directly. Waiting for ClassLoader...");
        }

        // 2. Хук на ClassLoader + динамический поиск
        try {
            XposedHelpers.findAndHookMethod(ClassLoader.class, "loadClass", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    String className = (String) param.args[0];
                    if (className == null) return;

                    // Логируем все, что связано с сетью
                    if (className.contains("okhttp") || className.contains("retrofit") || className.contains("cronet") || className.contains("volley")) {
                        XposedBridge.log(TAG + " -> Class loaded: " + className);
                    }

                    Class<?> clazz = (Class<?>) param.getResult();
                    if (clazz != null) {
                        checkAndHookNetworkClasses(clazz, lpparam.classLoader);
                    }
                }
            });
            XposedBridge.log(TAG + ": ClassLoader hook installed successfully");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook ClassLoader: " + t.getMessage());
        }

        // 3. Хук на java.net.URL
        try {
            XposedBridge.hookAllConstructors(java.net.URL.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    if (param.args.length >= 1 && param.args[0] instanceof String) {
                        String url = (String) param.args[0];
                        if (url.contains(BLOCKED_STR)) {
                            XposedBridge.log(TAG + " [!] BLOCKED (java.net.URL): " + url);
                            param.args[0] = "http://127.0.0.1/blocked";
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": java.net.URL hook installed");
        } catch (Throwable ignored) {}

        // 4. Хук на HttpURLConnection
        try {
            XposedHelpers.findAndHookMethod("java.net.HttpURLConnection", lpparam.classLoader, "connect", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    Object urlObj = XposedHelpers.getObjectField(param.thisObject, "url");
                    if (urlObj != null) {
                        String url = urlObj.toString();
                        if (url.contains(BLOCKED_STR)) {
                            XposedBridge.log(TAG + " [!] BLOCKED (HttpURLConnection): " + url);
                            throw new IOException("Blocked by LSpot");
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": HttpURLConnection hook installed");
        } catch (Throwable ignored) {}
    }

    private void checkAndHookNetworkClasses(Class<?> clazz, ClassLoader cl) {
        try {
            // Проверяем, является ли класс наследником OkHttpClient
            Class<?> okhttpClientClass = XposedHelpers.findClassIfExists("okhttp3.OkHttpClient", cl);
            if (okhttpClientClass != null && okhttpClientClass.isAssignableFrom(clazz) && !clazz.equals(okhttpClientClass)) {
                XposedBridge.log(TAG + ": Found OkHttpClient subclass: " + clazz.getName());
                hookOkHttpClient(clazz, cl);
            }

            // Проверяем, реализует ли класс okhttp3.Call
            Class<?> callClass = XposedHelpers.findClassIfExists("okhttp3.Call", cl);
            if (callClass != null && callClass.isAssignableFrom(clazz) && !clazz.isInterface()) {
                XposedBridge.log(TAG + ": Found Call implementation: " + clazz.getName());
                hookCallInterface(clazz);
            }
        } catch (Throwable ignored) {}
    }

    private void hookOkHttpClient(Class<?> clientClass, ClassLoader cl) {
        try {
            Class<?> requestClass = cl.loadClass("okhttp3.Request");
            XposedHelpers.findAndHookMethod(clientClass, "newCall", requestClass, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    Object request = param.args[0];
                    Object urlObj = XposedHelpers.callMethod(request, "url");
                    if (urlObj != null) {
                        String url = urlObj.toString();
                        if (url.contains(BLOCKED_STR)) {
                            XposedBridge.log(TAG + " [!] BLOCKED (OkHttpClient): " + url);
                            throw new IOException("Blocked by LSpot");
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": Hooked " + clientClass.getName() + ".newCall SUCCESSFULLY");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook " + clientClass.getName() + ".newCall: " + t.getMessage());
        }
    }

    private void hookCallInterface(Class<?> callClass) {
        try {
            XposedBridge.hookAllMethods(callClass, "execute", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    Object request = XposedHelpers.callMethod(param.thisObject, "request");
                    Object urlObj = XposedHelpers.callMethod(request, "url");
                    if (urlObj != null) {
                        String url = urlObj.toString();
                        if (url.contains(BLOCKED_STR)) {
                            XposedBridge.log(TAG + " [!] BLOCKED (Call.execute): " + url);
                            throw new IOException("Blocked by LSpot");
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": Hooked Call implementation " + callClass.getName());
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook Call implementation " + callClass.getName() + ": " + t.getMessage());
        }
    }
}