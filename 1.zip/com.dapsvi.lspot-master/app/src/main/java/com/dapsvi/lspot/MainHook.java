package com.dapsvi.lspot;

import android.util.Log;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "LSpot";
    private static final String[] TARGETS = {"com.veon.izi", "com.veon.iziyyyyy"};

    // Блокируем только этот URL
    private static final Pattern[] BLOCKED_PATTERNS = {
        Pattern.compile("https://api\\.izi\\.me/auth/my-number.*"),
    };

    private static boolean isTarget(String pkg) {
        for (String t : TARGETS) {
            if (t.equals(pkg)) return true;
        }
        return false;
    }

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
        if (!isTarget(lpparam.packageName)) return;

        XposedBridge.log(TAG + ": Loading for " + lpparam.packageName);

        // Хукаем загрузчик классов, чтобы поймать OkHttp, когда приложение его загрузит
        try {
            XposedHelpers.findAndHookMethod(ClassLoader.class, "loadClass", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    String className = (String) param.args[0];
                    Class<?> clazz = (Class<?>) param.getResult();

                    if (clazz == null) return;

                    // Как только загрузился OkHttpClient — вешаем на него хук
                    if (className.equals("okhttp3.OkHttpClient")) {
                        hookOkHttpClient(clazz, clazz.getClassLoader());
                    }
                    // Ловим внутренний класс OkHttp для надежности
                    else if (className.equals("okhttp3.internal.http.RealInterceptorChain")) {
                        hookRealInterceptorChain(clazz, clazz.getClassLoader());
                    }
                }
            });
            XposedBridge.log(TAG + ": ClassLoader hook installed (waiting for OkHttp)");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": ClassLoader hook failed: " + t.getMessage());
        }

        // Резервный метод (для HttpURLConnection)
        try {
            Class<?> urlClass = lpparam.classLoader.loadClass("java.net.URL");
            Method hookConstructors = XposedBridge.class.getMethod("hookAllConstructors", Class.class, XC_MethodHook.class);
            hookConstructors.invoke(null, urlClass, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    if (param.args.length >= 1 && param.args[0] instanceof String) {
                        String str = (String) param.args[0];
                        for (Pattern p : BLOCKED_PATTERNS) {
                            if (p.matcher(str).matches()) {
                                Log.i(TAG, "Blocked (URL): " + str);
                                // Перенаправляем на несуществующий адрес, чтобы вызвать ошибку
                                param.args[0] = "http://127.0.0.1/blocked";
                                break;
                            }
                        }
                    }
                }
            });
        } catch (Throwable ignored) {}
    }

    // ── Перехват OkHttpClient ──
    private void hookOkHttpClient(Class<?> clientClass, ClassLoader cl) {
        try {
            Class<?> requestClass = cl.loadClass("okhttp3.Request");
            XposedHelpers.findAndHookMethod(clientClass, "newCall", requestClass, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    Object request = param.args[0];
                    if (request == null) return;
                    
                    Method urlMethod = request.getClass().getMethod("url");
                    Object httpUrl = urlMethod.invoke(request);
                    String url = httpUrl.toString();

                    for (Pattern p : BLOCKED_PATTERNS) {
                        if (p.matcher(url).matches()) {
                            Log.i(TAG, "Blocked (OkHttp): " + url);
                            // Выбрасываем ошибку, чтобы приложение думало, что нет сети
                            throw new IOException("Blocked by LSpot");
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": Hooked OkHttpClient.newCall successfully");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook OkHttpClient: " + t.getMessage());
        }
    }

    // ── Перехват внутренностей OkHttp (надежный fallback) ──
    private void hookRealInterceptorChain(Class<?> ricClass, ClassLoader cl) {
        try {
            Class<?> requestClass = cl.loadClass("okhttp3.Request");
            String ricMethod = null;
            for (Method m : ricClass.getDeclaredMethods()) {
                if (m.getParameterCount() == 1 && m.getParameterTypes()[0].equals(requestClass) 
                        && m.getReturnType().getName().equals("okhttp3.Response")) {
                    ricMethod = m.getName();
                    break;
                }
            }
            if (ricMethod != null) {
                XposedHelpers.findAndHookMethod(ricClass, ricMethod, requestClass, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        Object request = param.args[0];
                        Method urlMethod = request.getClass().getMethod("url");
                        Object httpUrl = urlMethod.invoke(request);
                        String url = httpUrl.toString();

                        for (Pattern p : BLOCKED_PATTERNS) {
                            if (p.matcher(url).matches()) {
                                Log.i(TAG, "Blocked (RIC): " + url);
                                param.setResult(emptyResponse(request, cl));
                                return;
                            }
                        }
                    }
                });
                XposedBridge.log(TAG + ": Hooked RealInterceptorChain successfully");
            }
        } catch (Throwable ignored) {}
    }

    private static Object emptyResponse(Object request, ClassLoader cl) throws Exception {
        Class<?> respBuilderClass = cl.loadClass("okhttp3.Response$Builder");
        Class<?> protocolClass = cl.loadClass("okhttp3.Protocol");
        Class<?> bodyClass = cl.loadClass("okhttp3.ResponseBody");

        Object http11 = protocolClass.getField("HTTP_1_1").get(null);
        Object builder = respBuilderClass.getDeclaredConstructor().newInstance();

        respBuilderClass.getMethod("request", request.getClass()).invoke(builder, request);
        respBuilderClass.getMethod("protocol", protocolClass).invoke(builder, http11);
        respBuilderClass.getMethod("code", int.class).invoke(builder, 200);
        respBuilderClass.getMethod("message", String.class).invoke(builder, "OK");
        respBuilderClass.getMethod("body", bodyClass).invoke(builder,
            bodyClass.getMethod("create", cl.loadClass("okhttp3.MediaType"), byte[].class)
                .invoke(null, (Object) null, new byte[0]));

        return respBuilderClass.getMethod("build").invoke(builder);
    }
}