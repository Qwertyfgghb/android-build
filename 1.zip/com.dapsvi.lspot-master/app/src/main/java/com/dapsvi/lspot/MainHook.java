package com.dapsvi.lspot;

import android.util.Log;
import java.io.IOException;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "LSpot";
    private static final String[] TARGETS = {"com.veon.izi", "com.veon.iziyyyyy"};
    private static final String BLOCKED_STR = "api.izi.me/auth/my-number";

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
        boolean isTarget = false;
        for (String t : TARGETS) {
            if (t.equals(lpparam.packageName)) isTarget = true;
        }
        if (!isTarget) return;

        XposedBridge.log(TAG + ": ===================================");
        XposedBridge.log(TAG + ": Loading for " + lpparam.packageName + " (PID: " + android.os.Process.myPid() + ")");

        // 1. Пытаемся найти OkHttp напрямую
        boolean okhttpFound = false;
        try {
            Class<?> clientClass = XposedHelpers.findClass("okhttp3.OkHttpClient", lpparam.classLoader);
            XposedBridge.log(TAG + ": OkHttpClient FOUND directly!");
            hookOkHttpClient(clientClass, lpparam.classLoader);
            okhttpFound = true;
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": OkHttpClient NOT FOUND directly.");
        }

        // 2. Хук на ClassLoader (ловит классы, если они грузятся позже)
        try {
            XposedHelpers.findAndHookMethod(ClassLoader.class, "loadClass", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    String className = (String) param.args[0];
                    if (className == null) return;

                    // Логируем вообще все классы, где есть "ok" или "http"
                    if (className.toLowerCase().contains("okhttp") || className.toLowerCase().contains("cronet")) {
                        XposedBridge.log(TAG + " -> Class loaded: " + className);
                    }

                    if (className.equals("okhttp3.OkHttpClient")) {
                        hookOkHttpClient((Class<?>) param.getResult(), lpparam.classLoader);
                    }
                    // Ловим Request.Builder
                    if (className.equals("okhttp3.Request$Builder")) {
                        hookRequestBuilder((Class<?>) param.getResult());
                    }
                }
            });
            XposedBridge.log(TAG + ": ClassLoader hook installed successfully");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook ClassLoader: " + t.getMessage());
        }

        // 3. Хук на java.net.URL (для HttpURLConnection)
        try {
            XposedBridge.hookAllConstructors(java.net.URL.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    if (param.args.length >= 1 && param.args[0] instanceof String) {
                        String url = (String) param.args[0];
                        if (url.contains(BLOCKED_STR)) {
                            XposedBridge.log(TAG + " [!] BLOCKED (java.net.URL): " + url);
                            param.args[0] = "http://127.0.0.1/blocked";
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": java.net.URL hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook URL: " + t.getMessage());
        }
    }

    // Перехват OkHttpClient.newCall
    private void hookOkHttpClient(Class<?> clientClass, ClassLoader cl) {
        try {
            Class<?> requestClass = cl.loadClass("okhttp3.Request");
            XposedHelpers.findAndHookMethod(clientClass, "newCall", requestClass, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    Object request = param.args[0];
                    Object urlObj = XposedHelpers.callMethod(request, "url");
                    if (urlObj != null) {
                        String url = urlObj.toString();
                        if (url.contains(BLOCKED_STR)) {
                            XposedBridge.log(TAG + " [!] BLOCKED (OkHttpClient.newCall): " + url);
                            throw new IOException("Blocked by LSpot");
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": Hooked OkHttpClient.newCall SUCCESSFULLY");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook OkHttpClient.newCall: " + t.getMessage());
        }
    }

    // Перехват OkHttp Request.Builder.build()
    private void hookRequestBuilder(Class<?> builderClass) {
        try {
            XposedHelpers.findAndHookMethod(builderClass, "build", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    Object builder = param.thisObject;
                    // В OkHttp URL хранится в поле "url"
                    Object urlObj = XposedHelpers.getObjectField(builder, "url");
                    if (urlObj != null) {
                        String url = urlObj.toString();
                        if (url.contains(BLOCKED_STR)) {
                            XposedBridge.log(TAG + " [!] BLOCKED (Request.Builder): " + url);
                            throw new IOException("Blocked by LSpot");
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": Hooked Request.Builder.build SUCCESSFULLY");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook Request.Builder: " + t.getMessage());
        }
    }
}