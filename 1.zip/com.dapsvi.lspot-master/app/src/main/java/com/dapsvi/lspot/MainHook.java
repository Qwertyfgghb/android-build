package com.dapsvi.lspot;

import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.regex.Pattern;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "LSpot";
    private static final String[] TARGETS = {"com.veon.izi", "com.veon.iziyyyyy"};

    // Ищем этот URL
    private static final Pattern BLOCKED_PATTERN = Pattern.compile("https://api\\.izi\\.me/auth/my-number.*");

    private static boolean isTarget(String pkg) {
        for (String t : TARGETS) {
            if (t.equals(pkg)) return true;
        }
        return false;
    }

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
        if (!isTarget(lpparam.packageName)) return;

        XposedBridge.log(TAG + ": Loading for " + lpparam.packageName + " (PID: " + android.os.Process.myPid() + ")");

        // 1. Пытаемся навесить хуки напрямую, если OkHttp уже в памяти
        hookOkHttpDirectly(lpparam);

        // 2. Ждем загрузки классов через ClassLoader (на случай, если загрузится позже)
        try {
            XposedHelpers.findAndHookMethod(ClassLoader.class, "loadClass", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    String className = (String) param.args[0];
                    Class<?> clazz = (Class<?>) param.getResult();
                    if (clazz == null) return;

                    if (className.startsWith("okhttp3.")) {
                        XposedBridge.log(TAG + ": OkHttp class loaded: " + className);
                    }
                    
                    // Если загрузился класс, который нам нужен — вешаем хук
                    if ("okhttp3.RealCall".equals(className) || "okhttp3.OkHttpClient".equals(className)) {
                        hookOkHttpClasses(clazz.getClassLoader());
                    }
                }
            });
        } catch (Throwable ignored) {}

        // 3. Хук на java.net.URL (на всякий случай)
        try {
            Method hookConstructors = XposedBridge.class.getMethod("hookAllConstructors", Class.class, XC_MethodHook.class);
            hookConstructors.invoke(null, java.net.URL.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    if (param.args.length >= 1 && param.args[0] instanceof String) {
                        String str = (String) param.args[0];
                        if (BLOCKED_PATTERN.matcher(str).matches()) {
                            Log.i(TAG, "Blocked (java.net.URL): " + str);
                            param.args[0] = "http://127.0.0.1/blocked";
                        }
                    }
                }
            });
        } catch (Throwable ignored) {}
    }

    private void hookOkHttpDirectly(LoadPackageParam lpparam) {
        try {
            Class<?> realCallClass = lpparam.classLoader.loadClass("okhttp3.RealCall");
            hookRealCall(realCallClass);
        } catch (Throwable ignored) {}

        try {
            Class<?> httpUrlClass = lpparam.classLoader.loadClass("okhttp3.HttpUrl");
            hookHttpUrl(httpUrlClass);
        } catch (Throwable ignored) {}
    }

    private void hookOkHttpClasses(ClassLoader cl) {
        try {
            Class<?> realCallClass = cl.loadClass("okhttp3.RealCall");
            hookRealCall(realCallClass);
        } catch (Throwable ignored) {}

        try {
            Class<?> httpUrlClass = cl.loadClass("okhttp3.HttpUrl");
            hookHttpUrl(httpUrlClass);
        } catch (Throwable ignored) {}
    }

    // Перехватываем выполнение запроса (самый надежный способ)
    private void hookRealCall(Class<?> realCallClass) {
        try {
            XposedHelpers.findAndHookMethod(realCallClass, "execute", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    checkAndBlock(param);
                }
            });
            XposedHelpers.findAndHookMethod(realCallClass, "enqueue", Class.forName("okhttp3.Callback"), new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    checkAndBlock(param);
                }
            });
            XposedBridge.log(TAG + ": Hooked RealCall (execute/enqueue)");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook RealCall: " + t.getMessage());
        }
    }

    // Перехватываем парсинг URL
    private void hookHttpUrl(Class<?> httpUrlClass) {
        try {
            XposedHelpers.findAndHookMethod(httpUrlClass, "get", String.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    String url = (String) param.args[0];
                    if (url != null && BLOCKED_PATTERN.matcher(url).matches()) {
                        Log.i(TAG, "Blocked (HttpUrl.get): " + url);
                        throw new IOException("Blocked by LSpot");
                    }
                }
            });
            XposedBridge.log(TAG + ": Hooked HttpUrl.get");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook HttpUrl: " + t.getMessage());
        }
    }

    private void checkAndBlock(XC_MethodHook.MethodHookParam param) throws IOException {
        try {
            // Получаем Request из RealCall
            Object request = XposedHelpers.getObjectField(param.thisObject, "originalRequest");
            if (request == null) return;
            
            Object httpUrl = XposedHelpers.callMethod(request, "url");
            if (httpUrl != null) {
                String url = httpUrl.toString();
                if (BLOCKED_PATTERN.matcher(url).matches()) {
                    Log.i(TAG, "Blocked (RealCall): " + url);
                    throw new IOException("Blocked by LSpot");
                }
            }
        } catch (IOException e) {
            throw e; // Пробрасываем ошибку блокировки
        } catch (Throwable ignored) {}
    }
}