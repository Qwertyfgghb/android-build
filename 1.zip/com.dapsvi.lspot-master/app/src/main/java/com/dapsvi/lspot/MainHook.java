package com.dapsvi.lspot;

import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Method;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "LSpot";
    private static final String[] TARGETS = {"com.veon.izi", "com.veon.iziyyyyy"};
    private static final String BLOCKED_STR = "api.izi.me/auth/my-number";

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
        boolean isTarget = false;
        for (String t : TARGETS) {
            if (t.equals(lpparam.packageName)) isTarget = true;
        }
        if (!isTarget) return;

        XposedBridge.log(TAG + ": Loading for " + lpparam.packageName + " (PID: " + android.os.Process.myPid() + ")");

        // 1. Хук на обфусцированный OkHttpClient (dU.B)
        try {
            Class<?> clientClass = XposedHelpers.findClass("dU.B", lpparam.classLoader);
            if (clientClass != null) {
                XposedBridge.log(TAG + ": FOUND obfuscated OkHttpClient (dU.B)!");
                hookAllMethodsInClient(clientClass);
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": dU.B NOT FOUND directly. Will wait for ClassLoader.");
        }

        // 2. Хук на ClassLoader (если dU.B загрузится позже)
        try {
            XposedHelpers.findAndHookMethod(ClassLoader.class, "loadClass", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    String className = (String) param.args[0];
                    if ("dU.B".equals(className)) {
                        XposedBridge.log(TAG + ": Catching dU.B via ClassLoader!");
                        hookAllMethodsInClient((Class<?>) param.getResult());
                    }
                }
            });
        } catch (Throwable ignored) {}

        // 3. Резервный хук на URLConnection
        try {
            XposedHelpers.findAndHookMethod("java.net.URLConnection", lpparam.classLoader, "connect", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    java.net.URL url = ((java.net.URLConnection) param.thisObject).getURL();
                    if (url.toString().contains(BLOCKED_STR)) {
                        XposedBridge.log(TAG + " [!] BLOCKED (URLConnection): " + url);
                        throw new IOException("Blocked by LSpot");
                    }
                }
            });
        } catch (Throwable ignored) {}
    }

    // Перехватываем ВСЕ методы внутри dU.B
    private void hookAllMethodsInClient(Class<?> clientClass) {
        for (Method method : clientClass.getDeclaredMethods()) {
            try {
                XposedBridge.hookMethod(method, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        // Проверяем все аргументы метода
                        for (Object arg : param.args) {
                            if (arg == null) continue;
                            
                            // Пытаемся вытащить URL из аргумента (это объект Request)
                            try {
                                // Ищем метод url()
                                Object urlObj = XposedHelpers.callMethod(arg, "url");
                                if (urlObj != null) {
                                    String url = urlObj.toString();
                                    if (url.contains(BLOCKED_STR)) {
                                        XposedBridge.log(TAG + " [!] BLOCKED (dU.B): " + url);
                                        throw new IOException("Blocked by LSpot");
                                    }
                                }
                            } catch (IOException io) {
                                // ВАЖНО: пробрасываем наше исключение блокировки наверх!
                                throw io; 
                            } catch (Throwable e) {
                                // Если метода url() нет или произошла другая ошибка,
                                // проверяем сам объект (вдруг это просто строка)
                                if (arg instanceof String && ((String) arg).contains(BLOCKED_STR)) {
                                    XposedBridge.log(TAG + " [!] BLOCKED (dU.B String): " + arg);
                                    throw new IOException("Blocked by LSpot");
                                }
                            }
                        }
                    }
                });
            } catch (Throwable ignored) {}
        }
        XposedBridge.log(TAG + ": Hooked all methods in " + clientClass.getName());
    }
}