package com.dapsvi.lspot;

import android.util.Log;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "LSpot";
    private static final String[] TARGETS = {"com.veon.izi", "com.veon.iziyyyyy"};

    private static final Pattern[] BLOCKED_PATTERNS = {
        Pattern.compile("https://api\\.izi\\.me/auth/my-number.*"),
    };

    private static boolean isTarget(String pkg) {
        for (String t : TARGETS) {
            if (t.equals(pkg)) return true;
        }
        return false;
    }

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
        if (!isTarget(lpparam.packageName)) return;

        XposedBridge.log(TAG + ": Loading for " + lpparam.packageName);

        // 1. Пытаемся перехватить OkHttp сразу
        try {
            Class<?> builderClass = lpparam.classLoader.loadClass("okhttp3.Request$Builder");
            hookRequestBuilder(builderClass);
        } catch (Throwable ignored) {
            // OkHttp еще не загружен, ждем ClassLoader
        }

        // 2. Хук на загрузчик классов
        try {
            XposedHelpers.findAndHookMethod(ClassLoader.class, "loadClass", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    String className = (String) param.args[0];
                    Class<?> clazz = (Class<?>) param.getResult();
                    if (clazz == null) return;

                    // Логируем загрузку сетевых классов
                    if (className.startsWith("okhttp3.")) {
                        XposedBridge.log(TAG + ": OkHttp class loaded: " + className);
                    }

                    if (className.equals("okhttp3.OkHttpClient")) {
                        hookOkHttpClient(clazz, clazz.getClassLoader());
                    } else if (className.equals("okhttp3.Request$Builder")) {
                        hookRequestBuilder(clazz);
                    }
                }
            });
            XposedBridge.log(TAG + ": ClassLoader hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": ClassLoader hook failed: " + t.getMessage());
        }

        // 3. Резервный метод (java.net.URL)
        try {
            Class<?> urlClass = lpparam.classLoader.loadClass("java.net.URL");
            Method hookConstructors = XposedBridge.class.getMethod("hookAllConstructors", Class.class, XC_MethodHook.class);
            hookConstructors.invoke(null, urlClass, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    if (param.args.length >= 1 && param.args[0] instanceof String) {
                        String str = (String) param.args[0];
                        for (Pattern p : BLOCKED_PATTERNS) {
                            if (p.matcher(str).matches()) {
                                Log.i(TAG, "Blocked (URL): " + str);
                                param.args[0] = "http://127.0.0.1/blocked";
                                break;
                            }
                        }
                    }
                }
            });
        } catch (Throwable ignored) {}
    }

    // Перехват OkHttpClient.newCall
    private void hookOkHttpClient(Class<?> clientClass, ClassLoader cl) {
        try {
            Class<?> requestClass = cl.loadClass("okhttp3.Request");
            XposedHelpers.findAndHookMethod(clientClass, "newCall", requestClass, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    Object request = param.args[0];
                    if (request == null) return;
                    
                    Method urlMethod = request.getClass().getMethod("url");
                    Object httpUrl = urlMethod.invoke(request);
                    String url = httpUrl.toString();

                    for (Pattern p : BLOCKED_PATTERNS) {
                        if (p.matcher(url).matches()) {
                            Log.i(TAG, "Blocked (OkHttpClient): " + url);
                            throw new IOException("Blocked by LSpot");
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": Hooked OkHttpClient.newCall successfully");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook OkHttpClient: " + t.getMessage());
        }
    }

    // Перехват Request.Builder (ловит URL до отправки)
    private void hookRequestBuilder(Class<?> builderClass) {
        try {
            XposedHelpers.findAndHookMethod(builderClass, "build", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    Object builder = param.thisObject;
                    // В OkHttp 4.x URL хранится в поле "url"
                    Object urlObj = XposedHelpers.getObjectField(builder, "url");
                    if (urlObj != null) {
                        String url = urlObj.toString();
                        for (Pattern p : BLOCKED_PATTERNS) {
                            if (p.matcher(url).matches()) {
                                Log.i(TAG, "Blocked (Request.Builder): " + url);
                                throw new IOException("Blocked by LSpot");
                            }
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": Hooked Request.Builder.build successfully");
        } catch (Throwable t) {
            // XposedBridge.log(TAG + ": Failed to hook Request.Builder: " + t.getMessage());
        }
    }
}