package com.dapsvi.lspot;

import android.util.Log;
import java.io.IOException;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "LSpot";
    private static final String[] TARGETS = {"com.veon.izi", "com.veon.iziyyyyy"};
    // Ищем вхождение этой строки в URL
    private static final String BLOCKED_STR = "api.izi.me/auth/my-number";

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
        boolean isTarget = false;
        for (String t : TARGETS) {
            if (t.equals(lpparam.packageName)) isTarget = true;
        }
        if (!isTarget) return;

        XposedBridge.log(TAG + ": ===================================");
        XposedBridge.log(TAG + ": Loading for " + lpparam.packageName + " (PID: " + android.os.Process.myPid() + ")");

        // 1. Пытаемся повесить хук напрямую (если OkHttp уже в памяти)
        try {
            Class<?> clientClass = XposedHelpers.findClass("okhttp3.OkHttpClient", lpparam.classLoader);
            XposedBridge.log(TAG + ": OkHttpClient FOUND directly!");
            hookOkHttpClient(clientClass, lpparam.classLoader);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": OkHttpClient NOT FOUND directly. Waiting for ClassLoader...");
        }

        // 2. Вешаем хук на ClassLoader, чтобы поймать OkHttp, когда он загрузится
        try {
            XposedHelpers.findAndHookMethod(ClassLoader.class, "loadClass", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    String className = (String) param.args[0];
                    if (className == null) return;

                    // Логируем ВСЕ классы, связанные с сетью или okhttp
                    if (className.toLowerCase().contains("okhttp") || className.toLowerCase().contains("cronet")) {
                        XposedBridge.log(TAG + " -> Class loaded: " + className);
                    }

                    if (className.equals("okhttp3.OkHttpClient")) {
                        XposedBridge.log(TAG + ": Catching OkHttpClient via ClassLoader!");
                        hookOkHttpClient((Class<?>) param.getResult(), lpparam.classLoader);
                    }
                }
            });
            XposedBridge.log(TAG + ": ClassLoader hook installed successfully");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook ClassLoader: " + t.getMessage());
        }

        // 3. Хук на java.net.URL (для HttpURLConnection)
        try {
            XposedBridge.hookAllConstructors(java.net.URL.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    if (param.args.length >= 1 && param.args[0] instanceof String) {
                        String url = (String) param.args[0];
                        if (url.contains(BLOCKED_STR)) {
                            XposedBridge.log(TAG + " [!] BLOCKED (java.net.URL): " + url);
                            param.args[0] = "http://127.0.0.1/blocked";
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": java.net.URL hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook URL: " + t.getMessage());
        }
    }

    private void hookOkHttpClient(Class<?> clientClass, ClassLoader cl) {
        try {
            Class<?> requestClass = cl.loadClass("okhttp3.Request");
            XposedHelpers.findAndHookMethod(clientClass, "newCall", requestClass, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    Object request = param.args[0];
                    Object urlObj = XposedHelpers.callMethod(request, "url");
                    if (urlObj != null) {
                        String url = urlObj.toString();
                        if (url.contains(BLOCKED_STR)) {
                            XposedBridge.log(TAG + " [!] BLOCKED (OkHttpClient): " + url);
                            throw new IOException("Blocked by LSpot");
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": Hooked OkHttpClient.newCall SUCCESSFULLY");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": Failed to hook OkHttpClient.newCall: " + t.getMessage());
        }
    }
}