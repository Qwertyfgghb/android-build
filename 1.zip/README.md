# Radio Recorder v10

- reconnect without restarting the current track
- first-track skip is OFF by default and survives reconnects
- real bitrate used for post-roll duration
- scheduled stop waits for the current metadata track to finish and post-roll, without starting the next track
- multiple independent schedules per station
- schedule can target an artist/metadata value learned from the metadata database
- metadata database stores StreamTitle and artist history
- recordings can be filtered by station and artist
- built-in player uses MediaStore file descriptors and excludes pending files
- manual Stop immediately deletes unfinished writers
