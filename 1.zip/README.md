# Radio Recorder — Android Studio

Параметры записи в этой версии установлены ТОЧНО:

- `RING_BUFFER_SECONDS = 8.0`
- `OVERLAP_SECONDS = 1.0`
- `POSTROLL_SECONDS = 7.0`

Дополнительно:
- поток: `https://play.pro`
- bitrate: 192 kbps
- `icy-metaint`: читается из HTTP-заголовка, при отсутствии используется 16000
- первый `StreamTitle` только запоминается и не сохраняется
- при следующем изменении StreamTitle предыдущий трек получает 7 секунд post-roll
- новый трек получает 1 секунду аудио из ring buffer
- старые треки могут одновременно находиться в post-roll
- имена: `Исполнитель - Название.mp3`, затем `(2)`, `(3)` и т.д.
- дата/время в имени файла не добавляются
- сохранение: `Music/Radio` через MediaStore
- запись работает в Foreground Service с WakeLock

## Сборка

Откройте папку проекта в Android Studio с Gradle/AGP 8.2.2 и соберите APK:
`Build -> Build APK(s)`

Минимальная версия Android: 6.0 (API 23).
Target SDK: 34.
Java: 11.
