# Radio Recorder

Android 23+ multi-station radio recorder.

Features:
- compact multi-station list;
- automatic station name from URL and ICY icy-name;
- per-station ring buffer, overlap, post-roll and bitrate;
- UTF-8/Latin-1 ICY StreamTitle parsing;
- notification on every new StreamTitle;
- real traffic/throughput indication while recording;
- automatic reconnect handled by the scheduler/manual restart workflow;
- metadata target supports several comma/semicolon-separated keywords;
- optional recording only when metadata matches;
- duplicate-track protection: already recorded StreamTitle values are skipped and persisted;
- old recordings are also checked before creating a duplicate filename;
- manual Stop immediately deletes unfinished writers and closes the stream;
- one-shot scheduler for station start/stop;
- compact in-app recording browser with search and tap-to-play;
- recordings stored in Music/Radio/<station>/;
- no unfinished pending files should remain after manual stop.

Build: compileSdk 34, targetSdk 34, Java 11, Android Gradle Plugin 8.2.2.
