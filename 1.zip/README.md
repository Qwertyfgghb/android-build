# Radio Recorder — multi-station

- Multiple radio stations can record simultaneously.
- Every station has its own name, URL, ring buffer, overlap, post-roll and bitrate.
- Station parameters are edited with the ✎ button on that station.
- Normal track change uses that station's `POSTROLL` value.
- Manual Stop uses `POSTROLL + 3 seconds` for that station.
- Manual Stop does not delete the current track: it finishes the current recording with the stop post-roll, then closes the file.
- Stop commands use `startService()` rather than `startForegroundService()` so Android does not throw the foreground-service-start timeout when stopping.
- Each station has its own status showing the current track and post-roll state.
- Files are saved under `Music/Radio/<station>/`.
- First StreamTitle is remembered and is not saved as a track; recording starts at the next title change with ring-buffer overlap.
- Multiple old tracks can be in post-roll simultaneously.
