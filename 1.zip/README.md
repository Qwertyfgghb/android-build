# /devil — VirtualSpace + screen-state policy

This repository is a modified copy of the uploaded VirtualSpace source.

## What was added

For every cloned package, Clone Details now has:

**Devil — Screen state**
- `Keep screen state ON`

The setting is stored per package.

The decision API is:

`com.devil.DevilScreenServicePolicy`

It provides:
- `isInteractive(...)`
- `isScreenOn(...)`
- `displayState(...)`

When enabled, the policy returns:
- `isInteractive = true`
- `isScreenOn = true`
- `Display.STATE_ON = 2`

## Important limitation of this uploaded upstream revision

The supplied VirtualSpace source is itself a skeleton in several places:
- `ServiceBroker.getService()` returns null.
- `HookManager.hookMethod()` only logs a registration.
- `BinderHook` does not replace the framework service binder.
- native hook functions are placeholders.
- the supplied dispatch/loader code does not create a complete independent application process.

Therefore this build contains the **complete Devil policy and UI**, but it does NOT falsely claim that an arbitrary third-party app is already receiving the fake PowerManager result. The service-proxy layer must actually invoke `DevilScreenServicePolicy` inside the virtual app's system-service path.

To make the switch effective for arbitrary apps, the next implementation step is a genuine virtual process/context layer or bytecode/runtime hook that routes `PowerManager` and `Display` calls through this policy.

## Build

The project already contains the upstream Gradle wrapper. On GitHub Actions:

`./gradlew assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Android

The uploaded source declares:
- minSdk 28
- targetSdk 34
- compileSdk 34

This means the current project is not automatically an Android 16-complete implementation merely because the VirtualSpace project description may mention newer Android releases.
