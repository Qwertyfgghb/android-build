package com.djay.touchmenot;

import android.app.KeyguardManager;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.widget.Toast;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class VolPwrBlocker implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // Модуль активен для SystemUI и android
        if (!"com.android.systemui".equals(lpparam.packageName) &&
            !"android".equals(lpparam.packageName)) return;

        Logger.hookSuccess("VolPwrBlocker:init");

        hookPowerKey(lpparam);
    }

    private void hookPowerKey(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> pwm = XposedHelpers.findClass(
                "com.android.server.policy.PhoneWindowManager",
                lpparam.classLoader
            );

            XposedHelpers.findAndHookMethod(pwm, "interceptKeyBeforeQueueing",
                KeyEvent.class, int.class, boolean.class, new XC_MethodHook() {

                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        KeyEvent event = (KeyEvent) param.args[0];
                        if (event == null) return;

                        int keyCode = event.getKeyCode();
                        int action = event.getAction();

                        Context ctx = getContext(param.thisObject);
                        if (ctx == null) return;

                        KeyguardManager km = (KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
                        if (km == null || !km.isKeyguardLocked()) return;

                        // Перехватываем PowerKey при нажатии
                        if (keyCode == KeyEvent.KEYCODE_POWER && action == KeyEvent.ACTION_DOWN) {
                            // Максимально блокируем стандартное поведение PowerKey
                            param.setResult(0);

                            // Кастомное действие: Toast + вибрация
                            showFeedback(ctx, "PowerKey intercepted!");

                            Logger.blocked("PowerKey", "intercepted");
                        }
                    }
                });

            Logger.hookSuccess("interceptKeyBeforeQueueing hooked");

        } catch (Throwable t) {
            Logger.hookFail("hookPowerKey", t.getMessage());
        }
    }

    private Context getContext(Object obj) {
        try {
            Object ctx = XposedHelpers.getObjectField(obj, "mContext");
            if (ctx instanceof Context) return (Context) ctx;
        } catch (Throwable ignored) {}
        return null;
    }

    private void showFeedback(Context ctx, String message) {
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show();
                Vibrator vib = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
                if (vib != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vib.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        vib.vibrate(50);
                    }
                }
            } catch (Throwable ignored) {}
        });
    }
}