package com.djay.touchmenot;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class VolPwrBlocker implements IXposedHookLoadPackage {

    private static boolean isPowerKeyHeld = false;
    private static boolean isVolumeUpKeyHeld = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // Подключаемся ко всем системным процессам, где есть PhoneWindowManager
        String pkg = lpparam.packageName;
        if (!"android".equals(pkg) && !"system_server".equals(pkg)) return;

        XposedBridge.log("VolPwrBlocker:init for package: " + pkg);

        hookPowerMenu(lpparam);
        hookKeyCombination(lpparam);
    }

    private void hookPowerMenu(final XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> pwm = lpparam.classLoader.loadClass("com.android.server.policy.PhoneWindowManager");
            XposedHelpers.findAndHookMethod(pwm, "showGlobalActions", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    try {
                        Context ctx = getContextFromObject(param.thisObject);
                        if (ctx == null) return;

                        KeyguardManager km = (KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
                        if (km != null && km.isKeyguardLocked()) {
                            param.setResult(null); // блокируем PowerMenu
                            XposedBridge.log("VolPwrBlocker: PowerMenu blocked (keyguard locked)");
                            dispatchFeedback(ctx, "Разблокируйте устройство, чтобы использовать PowerMenu");
                        }
                    } catch (Throwable t) {
                        XposedBridge.log("VolPwrBlocker#showGlobalActions error: " + t);
                    }
                }
            });
            XposedBridge.log("VolPwrBlocker: hooked showGlobalActions successfully");
        } catch (Throwable t) {
            XposedBridge.log("VolPwrBlocker: failed to hook showGlobalActions: " + t);
        }
    }

    private void hookKeyCombination(final XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> pwm = lpparam.classLoader.loadClass("com.android.server.policy.PhoneWindowManager");
            XposedHelpers.findAndHookMethod(pwm, "interceptKeyBeforeQueueing", KeyEvent.class, int.class, boolean.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    try {
                        KeyEvent event = (KeyEvent) param.args[0];
                        if (event == null) return;
                        if (!isLocked(param.thisObject)) return;

                        int keyCode = event.getKeyCode();

                        if (event.getAction() == KeyEvent.ACTION_DOWN) {
                            if (keyCode == KeyEvent.KEYCODE_POWER) isPowerKeyHeld = true;
                            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) isVolumeUpKeyHeld = true;

                            if (isPowerKeyHeld && isVolumeUpKeyHeld) {
                                param.setResult(0); // блокируем комбинацию
                                XposedBridge.log("VolPwrBlocker: Power+VolUp blocked");

                                Context ctx = getContextFromObject(param.thisObject);
                                if (ctx != null) {
                                    KeyguardManager km = (KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
                                    if (km != null) {
                                        Intent i = km.createConfirmDeviceCredentialIntent(null, null);
                                        if (i != null) {
                                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                            ctx.startActivity(i);
                                        }
                                    }
                                }
                            }
                        } else if (event.getAction() == KeyEvent.ACTION_UP) {
                            if (keyCode == KeyEvent.KEYCODE_POWER) isPowerKeyHeld = false;
                            if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) isVolumeUpKeyHeld = false;
                        }

                    } catch (Throwable t) {
                        XposedBridge.log("VolPwrBlocker#interceptKeyBeforeQueueing error: " + t);
                    }
                }
            });
            XposedBridge.log("VolPwrBlocker: hooked interceptKeyBeforeQueueing successfully");
        } catch (Throwable t) {
            XposedBridge.log("VolPwrBlocker: failed to hook interceptKeyBeforeQueueing: " + t);
        }
    }

    private boolean isLocked(Object obj) {
        try {
            Context ctx = getContextFromObject(obj);
            if (ctx == null) return false;
            KeyguardManager km = (KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
            return km != null && km.isKeyguardLocked();
        } catch (Throwable t) {
            XposedBridge.log("VolPwrBlocker#isLocked error: " + t);
            return false;
        }
    }

    private Context getContextFromObject(Object obj) {
        if (obj == null) return null;
        try {
            String[] fields = new String[]{"mContext", "context", "mContextImpl"};
            for (String f : fields) {
                try {
                    Field field = obj.getClass().getDeclaredField(f);
                    field.setAccessible(true);
                    Object v = field.get(obj);
                    if (v instanceof Context) return (Context) v;
                } catch (Throwable ignored) {}
            }
            try {
                Method gm = obj.getClass().getMethod("getContext");
                Object r = gm.invoke(obj);
                if (r instanceof Context) return (Context) r;
            } catch (Throwable ignored) {}
        } catch (Throwable t) {
            XposedBridge.log("VolPwrBlocker#getContextFromObject error: " + t);
        }
        return null;
    }

    private void dispatchFeedback(Context ctx, String message) {
        if (ctx == null) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            try {
                Toast.makeText(ctx, message != null ? message : "Доступ заблокирован", Toast.LENGTH_SHORT).show();
                Vibrator vib = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
                if (vib != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vib.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        vib.vibrate(50);
                    }
                }
            } catch (Throwable t) {
                XposedBridge.log("VolPwrBlocker#dispatchFeedback error: " + t);
            }
        });
    }
}