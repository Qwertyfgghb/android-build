package com.djay.touchmenot;

import android.app.KeyguardManager;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.widget.Toast;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class VolPwrBlocker implements IXposedHookLoadPackage {

    private static boolean isPowerHeld = false;
    private static boolean isVolUpHeld = false;
    private static boolean isVolDownHeld = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // Подключаемся только к SystemUI и android
        if (!"com.android.systemui".equals(lpparam.packageName) &&
            !"android".equals(lpparam.packageName)) return;

        Logger.hookSuccess("VolPwrBlocker:init");

        hookPowerMenu(lpparam);
        hookKeyCombination(lpparam);
    }

    private void hookPowerMenu(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> pwm = XposedHelpers.findClass(
                "com.android.server.policy.PhoneWindowManager",
                lpparam.classLoader
            );

            XposedHelpers.findAndHookMethod(pwm, "showGlobalActions", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                    Context ctx = getContext(param.thisObject);
                    if (ctx == null) return;

                    KeyguardManager km = (KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
                    if (km != null && km.isKeyguardLocked()) {
                        param.setResult(null); // блокируем меню
                        showFeedback(ctx, "PowerMenu blocked while locked");
                        Logger.blocked("showGlobalActions", "keyguard_locked");
                    }
                }
            });

            Logger.hookSuccess("showGlobalActions hooked");
        } catch (Throwable t) {
            Logger.hookFail("hookPowerMenu", t.getMessage());
        }
    }

    private void hookKeyCombination(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> pwm = XposedHelpers.findClass(
                "com.android.server.policy.PhoneWindowManager",
                lpparam.classLoader
            );

            XposedHelpers.findAndHookMethod(pwm, "interceptKeyBeforeQueueing",
                KeyEvent.class, int.class, boolean.class, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        KeyEvent event = (KeyEvent) param.args[0];
                        if (event == null) return;

                        Context ctx = getContext(param.thisObject);
                        if (ctx == null) return;

                        KeyguardManager km = (KeyguardManager) ctx.getSystemService(Context.KEYGUARD_SERVICE);
                        if (km == null || !km.isKeyguardLocked()) return;

                        int key = event.getKeyCode();

                        if (event.getAction() == KeyEvent.ACTION_DOWN) {
                            if (key == KeyEvent.KEYCODE_POWER) isPowerHeld = true;
                            if (key == KeyEvent.KEYCODE_VOLUME_UP) isVolUpHeld = true;
                            if (key == KeyEvent.KEYCODE_VOLUME_DOWN) isVolDownHeld = true;

                            // Комбинации
                            if (isPowerHeld && (isVolUpHeld || isVolDownHeld)) {
                                param.setResult(0); // блокируем
                                showFeedback(ctx, "Power+Volume blocked!");
                                Logger.blocked("Power+Vol", "keyguard_locked");
                            }
                        } else if (event.getAction() == KeyEvent.ACTION_UP) {
                            if (key == KeyEvent.KEYCODE_POWER) isPowerHeld = false;
                            if (key == KeyEvent.KEYCODE_VOLUME_UP) isVolUpHeld = false;
                            if (key == KeyEvent.KEYCODE_VOLUME_DOWN) isVolDownHeld = false;
                        }
                    }
                }
            );

            Logger.hookSuccess("interceptKeyBeforeQueueing hooked");
        } catch (Throwable t) {
            Logger.hookFail("hookKeyCombination", t.getMessage());
        }
    }

    private Context getContext(Object obj) {
        try {
            Object ctx = XposedHelpers.getObjectField(obj, "mContext");
            if (ctx instanceof Context) return (Context) ctx;
        } catch (Throwable ignored) {}
        return null;
    }

    private void showFeedback(Context ctx, String message) {
        new Handler(Looper.getMainLooper()).post(() -> {
            Toast.makeText(ctx, message, Toast.LENGTH_SHORT).show();
            try {
                Vibrator vib = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
                if (vib != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vib.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));
                    } else {
                        vib.vibrate(50);
                    }
                }
            } catch (Throwable ignored) {}
        });
    }
}