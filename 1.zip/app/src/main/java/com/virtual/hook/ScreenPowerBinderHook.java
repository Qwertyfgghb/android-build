package com.virtual.hook;

import android.content.Context;
import android.os.IBinder;
import android.os.Parcel;
import android.util.Log;

import com.devil.ScreenStatePolicy;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Map;

/**
 * Per-virtual-app power-service proxy.
 *
 * It does not wake the physical display. It changes the reply returned to
 * the virtual process for IPowerManager.isInteractive().
 */
public final class ScreenPowerBinderHook {
    private static final String TAG = "DevilScreenPower";
    private static final int FIRST_CALL_TRANSACTION = 1;
    private static volatile String activePackage;
    private static volatile boolean installed;

    private ScreenPowerBinderHook() {}

    public static synchronized boolean install(Context context) {
        if (installed) return true;
        try {
            Class<?> sm = Class.forName("android.os.ServiceManager");
            Field cacheField = sm.getDeclaredField("sCache");
            cacheField.setAccessible(true);
            Object cacheObject = cacheField.get(null);
            if (!(cacheObject instanceof Map)) {
                Log.w(TAG, "ServiceManager.sCache is not a Map");
                return false;
            }

            @SuppressWarnings("unchecked")
            Map<String, IBinder> cache = (Map<String, IBinder>) cacheObject;
            IBinder original = cache.get("power");
            if (original == null) {
                Method getService = sm.getDeclaredMethod("getService", String.class);
                getService.setAccessible(true);
                original = (IBinder) getService.invoke(null, "power");
            }
            if (original == null) {
                Log.w(TAG, "Power service is unavailable");
                return false;
            }

            final IBinder originalBinder = original;
            final int isInteractiveCode = findIsInteractiveCode();
            if (isInteractiveCode < 0) {
                Log.w(TAG, "Could not find IPowerManager.isInteractive transaction code");
                return false;
            }

            IBinder proxy = (IBinder) Proxy.newProxyInstance(
                    IBinder.class.getClassLoader(),
                    new Class<?>[]{IBinder.class},
                    new InvocationHandler() {
                        @Override
                        public Object invoke(Object proxyObject, Method method, Object[] args) throws Throwable {
                            if ("transact".equals(method.getName())
                                    && args != null && args.length >= 4
                                    && args[0] instanceof Integer
                                    && ((Integer) args[0]) == isInteractiveCode
                                    && args[2] instanceof Parcel) {
                                Parcel reply = (Parcel) args[2];
                                boolean result = originalBinder.transact(
                                        (Integer) args[0],
                                        (Parcel) args[1],
                                        reply,
                                        (Integer) args[3]);
                                if (result && shouldForceInteractive(context)) {
                                    forceBooleanReply(reply);
                                }
                                return result;
                            }
                            return method.invoke(originalBinder, args);
                        }
                    });

            cache.put("power", proxy);
            installed = true;
            Log.i(TAG, "Power service proxy installed; isInteractive transaction=" + isInteractiveCode);
            return true;
        } catch (Throwable e) {
            Log.e(TAG, "Failed to install power service proxy", e);
            return false;
        }
    }

    public static void setActivePackage(String packageName) {
        activePackage = packageName;
        Log.i(TAG, "Active virtual package: " + packageName);
    }

    public static String getActivePackage() {
        return activePackage;
    }

    private static boolean shouldForceInteractive(Context context) {
        String pkg = activePackage;
        return pkg != null && ScreenStatePolicy.isEnabled(context, pkg);
    }

    private static void forceBooleanReply(Parcel reply) {
        try {
            // IPowerManager boolean results are marshalled as an int after
            // the standard Binder exception header.
            reply.setDataPosition(0);
            reply.readException();
            reply.setDataPosition(0);
            reply.writeNoException();
            reply.writeInt(1);
            reply.setDataPosition(0);
        } catch (Throwable e) {
            Log.w(TAG, "Could not rewrite isInteractive reply", e);
        }
    }

    private static int findIsInteractiveCode() {
        try {
            Class<?> stub = Class.forName("android.os.IPowerManager$Stub");
            Field field = stub.getDeclaredField("TRANSACTION_isInteractive");
            field.setAccessible(true);
            return field.getInt(null);
        } catch (Throwable ignored) {
            // Android releases where the generated constant is hidden or
            // renamed. Known legacy ordering is kept as a fallback.
            return FIRST_CALL_TRANSACTION + 11;
        }
    }
}
