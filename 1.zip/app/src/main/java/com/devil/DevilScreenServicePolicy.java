package com.devil;

import android.content.Context;

/**
 * Central screen-state decision point.
 *
 * IMPORTANT: this class does not alter Android's global display state.
 * It is meant to be called by the virtualization service proxy when a
 * virtual application's PowerManager/Display service is being served.
 */
public final class DevilScreenServicePolicy {
    private DevilScreenServicePolicy() {}

    public static boolean isInteractive(Context host, String virtualPackage,
                                        boolean realValue) {
        return ScreenStatePolicy.isEnabled(host, virtualPackage)
                ? DevilScreenState.INTERACTIVE : realValue;
    }

    public static boolean isScreenOn(Context host, String virtualPackage,
                                     boolean realValue) {
        return ScreenStatePolicy.isEnabled(host, virtualPackage)
                ? DevilScreenState.SCREEN_ON : realValue;
    }

    public static int displayState(Context host, String virtualPackage,
                                   int realState) {
        return ScreenStatePolicy.isEnabled(host, virtualPackage)
                ? DevilScreenState.DISPLAY_STATE : realState;
    }
}
