package com.devil;

/**
 * Values a virtual app should observe when the Devil screen policy is enabled.
 */
public final class DevilScreenState {
    private DevilScreenState() {}

    public static final boolean INTERACTIVE = true;
    public static final boolean SCREEN_ON = true;
    // android.view.Display.STATE_ON
    public static final int DISPLAY_STATE = 2;
}
