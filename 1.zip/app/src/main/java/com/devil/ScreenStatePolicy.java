package com.devil;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/**
 * Persistent per-package policy used by the Devil virtualization layer.
 */
public final class ScreenStatePolicy {
    private static final String PREFS = "devil_prefs";
    private static final String KEY_FORCE = "force_interactive";

    private ScreenStatePolicy() {}

    public static boolean isEnabled(Context context, String packageName) {
        if (packageName == null || packageName.isEmpty()) return false;
        return prefs(context).getStringSet(KEY_FORCE, new HashSet<String>())
                .contains(packageName);
    }

    public static boolean hasAnyEnabled(Context context) {
        return !prefs(context).getStringSet(KEY_FORCE, new HashSet<String>()).isEmpty();
    }

    public static void setEnabled(Context context, String packageName, boolean enabled) {
        if (packageName == null || packageName.isEmpty()) return;
        SharedPreferences p = prefs(context);
        Set<String> set = new HashSet<>(p.getStringSet(KEY_FORCE, new HashSet<String>()));
        if (enabled) set.add(packageName); else set.remove(packageName);
        p.edit().putStringSet(KEY_FORCE, set).apply();
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
