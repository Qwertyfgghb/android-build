package com.example.ytmusicblock;

import android.util.Log;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class Blocker implements IXposedHookLoadPackage {

    private static final String TAG = "YTMusicBlocker";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("com.google.android.youtube")) return;

        Log.i(TAG, "YouTube ReVanced загружен, включаем блокировку музыки");

        try {
            // Хук на метод, который получает PlayerResponse или VideoMetadata
            XposedHelpers.findAndHookMethod(
                    "com.google.android.apps.youtube.app.player.PlayerController", // класс ReVanced
                    lpparam.classLoader,
                    "onVideoPrepared", // метод, когда видео готово
                    Object.class, // объект PlayerResponse или Video
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            Object playerResponse = param.args[0];

                            // Получаем categoryId из объекта
                            String categoryId = (String) XposedHelpers.getObjectField(playerResponse, "categoryId");

                            if ("10".equals(categoryId)) { // 10 = музыка
                                Log.i(TAG, "Заблокирована музыка!");
                                param.setResult(null); // блокируем воспроизведение
                            }
                        }
                    }
            );
        } catch (Throwable t) {
            Log.e(TAG, "Ошибка хука", t);
        }
    }
}