package com.example.ytmusicblock;

import android.util.Log;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class Blocker implements IXposedHookLoadPackage {

    private static final String TAG = "YTMusicBlocker";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("com.google.android.youtube")) return;

        Log.i(TAG, "YouTube ReVanced загружен, включаем блокировку музыки");

        try {
            XposedHelpers.findAndHookMethod(
                    "com.google.android.apps.youtube.app.player.PlayerController",
                    lpparam.classLoader,
                    "onVideoPrepared",
                    Object.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            Object playerResponse = param.args[0];

                            try {
                                String categoryId = (String) XposedHelpers.getObjectField(playerResponse, "categoryId");

                                Log.i(TAG, "Video categoryId: " + categoryId);

                                if ("10".equals(categoryId)) {
                                    Log.i(TAG, "Заблокирована музыка!");
                                    param.setResult(null);
                                }
                            } catch (Throwable t) {
                                Log.e(TAG, "Ошибка при проверке categoryId", t);
                            }
                        }
                    }
            );
        } catch (Throwable t) {
            Log.e(TAG, "Ошибка хука PlayerController", t);
        }
    }
}