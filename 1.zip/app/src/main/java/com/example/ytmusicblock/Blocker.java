package com.example.ytmusicblock;

import android.util.Log;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class Blocker implements IXposedHookLoadPackage {

    private static final String TAG = "YTMusicBlocker";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // Хук только для основного пакета YouTube ReVanced
        if (!lpparam.packageName.equals("com.google.android.youtube")) return;

        Log.i(TAG, "YTMusicBlocker: пакет загружен - начинаем перехват методов");

        // Перебор всех классов в ClassLoader
        ClassLoader cl = lpparam.classLoader;

        try {
            // Пример универсального хука
            // Ловим все методы с одним параметром Object (обычно video / player response)
            XposedHelpers.findAndHookMethod(
                    "com.google.android.apps.youtube.app.player.PlayerController",
                    cl,
                    "onVideoPrepared",
                    Object.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            Object videoObj = param.args[0];
                            if (videoObj == null) return;

                            // Пытаемся получить поле categoryId
                            try {
                                String categoryId = (String) XposedHelpers.getObjectField(videoObj, "categoryId");
                                Log.i(TAG, "Video categoryId: " + categoryId);

                                // Блокировка музыки
                                if ("10".equals(categoryId)) {
                                    Log.i(TAG, "YTMusicBlocker: заблокирована музыка!");
                                    param.setResult(null); // блокируем воспроизведение
                                }
                            } catch (NoSuchFieldError e) {
                                Log.i(TAG, "YTMusicBlocker: categoryId не найден, метод вызван");
                            } catch (Throwable t) {
                                Log.e(TAG, "YTMusicBlocker: ошибка при чтении categoryId", t);
                            }
                        }
                    }
            );
        } catch (Throwable t) {
            Log.e(TAG, "YTMusicBlocker: универсальный хук не применился", t);
        }
    }
}