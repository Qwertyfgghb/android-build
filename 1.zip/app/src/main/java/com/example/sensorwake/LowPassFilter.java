package com.example.sensorwake;

public class LowPassFilter {
    private float alpha;

    public LowPassFilter(float alpha) {
        this.alpha = alpha;
    }

    // Сглаживание одного значения
    public float filter(float input, float lastOutput) {
        return lastOutput + alpha * (input - lastOutput);
    }

    // Сглаживание массива (например, трехосевой сенсор)
    public float[] filter(float[] input, float[] lastOutput) {
        if (lastOutput == null || lastOutput.length != input.length) {
            lastOutput = new float[input.length];
            System.arraycopy(input, 0, lastOutput, 0, input.length);
            return lastOutput;
        }
        for (int i = 0; i < input.length; i++) {
            lastOutput[i] = lastOutput[i] + alpha * (input[i] - lastOutput[i]);
        }
        return lastOutput;
    }
}