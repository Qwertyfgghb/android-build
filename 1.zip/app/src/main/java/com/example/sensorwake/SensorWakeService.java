package com.example.sensorwake;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import static de.robv.android.xposed.XposedHelpers.*;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;

public class SensorWakeModule implements IXposedHookLoadPackage {

    // Укажи пакет, для которого работает модуль
    private static final String TARGET_PACKAGE = "ru.yandex.yandexmaps";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals(TARGET_PACKAGE)) return;

        hookMethod(lpparam);
    }

    private void hookMethod(XC_LoadPackage.LoadPackageParam lpparam) {
        // Хуким Context.getSystemService, чтобы "разбудить" сенсоры
        findAndHookMethod(Context.class, "getSystemService", String.class, (param) -> {
            if (param.args[0].equals(Context.SENSOR_SERVICE)) {
                SensorManager sensorManager = (SensorManager) param.getResult();
                if (sensorManager != null) {
                    Utils.activateAllSensors(sensorManager);
                }
            }
        });
    }
}