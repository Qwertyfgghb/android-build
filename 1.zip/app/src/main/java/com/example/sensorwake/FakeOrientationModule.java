package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class FakeOrientationModule implements IXposedHookLoadPackage, SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor gyroscope;

    private float[] gravity = new float[3];
    private float[] rotation = new float[3];
    private float azimuth = 0f; // текущее направление телефона
    private Context appContext;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // Фильтруем только нужное приложение
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return;

        // Получаем контекст приложения
        try {
            appContext = (Context) appContext = AndroidAppHelper.currentApplication();;
        } catch (Exception e) {
            appContext = null;
        }

        if (appContext == null) {
            Log.e("FakeOrientation", "Context is null!");
            return;
        } else {
            Log.i("FakeOrientation", "Module initialized with context!");
        }

        // Получаем менеджер сенсоров
        sensorManager = (SensorManager) appContext.getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager == null) {
            Log.e("FakeOrientation", "SensorManager is null!");
            return;
        }

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

        if (accelerometer != null)
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
        if (gyroscope != null)
            sensorManager.registerListener(this, gyroscope, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            System.arraycopy(event.values, 0, gravity, 0, 3);
        } else if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
            rotation[0] += event.values[0];
            rotation[1] += event.values[1];
            rotation[2] += event.values[2];
        }

        // Азимут телефона — поворот вокруг оси Z
        azimuth = rotation[2];

        // Логируем для проверки
        Log.i("FakeOrientation", "Phone azimuth: " + azimuth);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Не нужно для текущей цели
    }
}