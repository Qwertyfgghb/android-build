package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.View;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class FullCompassAutoDetectModule implements IXposedHookLoadPackage {

    private float[] gravity = new float[3];
    private float[] geomagnetic = new float[3];
    private float currentAzimuth = 0f;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return;

        // Хук на attachBaseContext, чтобы получить Context приложения
        XposedHelpers.findAndHookMethod(
                "ru.yandex.yandexmaps.MainActivity",
                lpparam.classLoader,
                "attachBaseContext",
                Context.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        final Context context = (Context) param.args[0];
                        startCompass(context, lpparam.classLoader);
                    }
                }
        );
    }

    private void startCompass(Context context, ClassLoader classLoader) {
        SensorManager sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager == null) return;

        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        Sensor magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        SensorEventListener listener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                    System.arraycopy(event.values, 0, gravity, 0, 3);
                } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                    System.arraycopy(event.values, 0, geomagnetic, 0, 3);
                }

                float R[] = new float[9];
                float I[] = new float[9];
                if (SensorManager.getRotationMatrix(R, I, gravity, geomagnetic)) {
                    float orientation[] = new float[3];
                    SensorManager.getOrientation(R, orientation);
                    float azimuth = (float) Math.toDegrees(orientation[0]);
                    if (azimuth < 0) azimuth += 360;

                    currentAzimuth += (azimuth - currentAzimuth) * 0.1f; // плавное обновление

                    // Авто-детект стрелки компаса
                    try {
                        Class<?> compassClass = detectCompassClass(classLoader);
                        if (compassClass != null) {
                            Method updateMethod = findAzimuthMethod(compassClass);
                            if (updateMethod != null) {
                                updateMethod.setAccessible(true);
                                XposedHelpers.callStaticMethod(compassClass, updateMethod.getName(), currentAzimuth);
                            }
                        }
                    } catch (Throwable ignored) {}
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {}
        };

        sensorManager.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_UI);
        sensorManager.registerListener(listener, magnetometer, SensorManager.SENSOR_DELAY_UI);
    }

    // Перебор всех классов, ищем View с полем типа float/azimuth
    private Class<?> detectCompassClass(ClassLoader classLoader) {
        try {
            for (String name : XposedHelpers.findClass("java.lang.ClassLoader", classLoader).getClass().getClasses()) {
                try {
                    Class<?> cls = Class.forName(name, false, classLoader);
                    if (View.class.isAssignableFrom(cls)) {
                        for (Field f : cls.getDeclaredFields()) {
                            if (f.getType() == float.class || f.getType() == double.class) {
                                return cls; // первый подходящий View
                            }
                        }
                    }
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        return null;
    }

    // Находим метод, который принимает float/double (azimuth)
    private Method findAzimuthMethod(Class<?> cls) {
        for (Method m : cls.getDeclaredMethods()) {
            if (m.getParameterTypes().length == 1 &&
                (m.getParameterTypes()[0] == float.class || m.getParameterTypes()[0] == double.class)) {
                return m;
            }
        }
        return null;
    }
}