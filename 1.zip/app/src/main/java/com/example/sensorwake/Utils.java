package com.example.sensorwake;

public class LowPassFilter {
    private float alpha;
    private float last = -1;

    public LowPassFilter(float alpha) {
        this.alpha = alpha;
    }

    public float apply(float value) {
        if (last < 0) {
            last = value;
            return value;
        }
        last = last + alpha * (value - last);
        return last;
    }
}