package com.example.sensorwake;

import android.app.ActivityThread;
import android.content.Context;

public class Utils {
    public static Context getAppContext(ClassLoader cl) {
        try {
            Object activityThread = ActivityThread.currentActivityThread();
            if (activityThread != null) {
                return (Context) activityThread.getSystemContext();
            }
        } catch (Throwable t) {}
        return null;
    }
}