package com.example.sensorwake;

import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

public class Utils {

    public static void activateAllSensors(SensorManager sensorManager) {
        SensorEventListener dummyListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(android.hardware.SensorEvent event) {}
            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {}
        };

        for (Sensor sensor : sensorManager.getSensorList(Sensor.TYPE_ALL)) {
            // Зарегистрировать сенсор с минимальной частотой
            sensorManager.registerListener(dummyListener, sensor, SensorManager.SENSOR_DELAY_FASTEST);
        }
    }
}