package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;

public class FullCompassModule implements IXposedHookLoadPackage {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor magnetometer;

    private float[] gravity;
    private float[] geomagnetic;
    private float currentAzimuth = 0f;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // Ограничение на конкретное приложение (Яндекс.Карты)
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) {
            return;
        }

        XposedBridge.log("FullCompassModule loaded for: " + lpparam.packageName);

        // Получаем контекст через Application класса
        lpparam.appInfo.loadLabel(lpparam.classLoader); // Просто для инициализации

        // Хук на onCreate приложения
        try {
            Class<?> appClass = Class.forName(lpparam.appInfo.className, true, lpparam.classLoader);
            XposedBridge.hookAllMethods(appClass, "onCreate", new de.robv.android.xposed.XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Context context = (Context) param.thisObject;
                    startSensors(context);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("Compass init error: " + t.getMessage());
        }
    }

    private void startSensors(Context context) {
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager == null) {
            XposedBridge.log("SensorManager not found!");
            return;
        }

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        if (accelerometer == null || magnetometer == null) {
            XposedBridge.log("Compass sensors not available!");
            return;
        }

        sensorManager.registerListener(sensorListener, accelerometer, SensorManager.SENSOR_DELAY_UI);
        sensorManager.registerListener(sensorListener, magnetometer, SensorManager.SENSOR_DELAY_UI);

        XposedBridge.log("Compass sensors registered!");
    }

    private final SensorEventListener sensorListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
                gravity = event.values.clone();
            if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
                geomagnetic = event.values.clone();

            if (gravity != null && geomagnetic != null) {
                float R[] = new float[9];
                float I[] = new float[9];
                if (SensorManager.getRotationMatrix(R, I, gravity, geomagnetic)) {
                    float orientation[] = new float[3];
                    SensorManager.getOrientation(R, orientation);
                    currentAzimuth = (float) Math.toDegrees(orientation[0]);
                    if (currentAzimuth < 0) {
                        currentAzimuth += 360;
                    }
                    XposedBridge.log("Compass azimuth: " + currentAzimuth);
                }
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {}
    };
}