package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class FullCompassModule implements IXposedHookLoadPackage, SensorEventListener {

    private Context appContext;
    private SensorManager sensorManager;
    private Sensor magnetometer;
    private Sensor accelerometer;

    private float[] gravity;
    private float[] geomagnetic;
    private float azimuth;

    private LowPassFilter filter = new LowPassFilter(0.1f); // сглаживание

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        // Проверяем целевой пакет
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return;

        try {
            // Получаем контекст приложения
            appContext = (Context) lpparam.appContext; // если lpparam.appContext == null, нужен AndroidAppHelper.currentApplication()
            if (appContext == null) return;

            sensorManager = (SensorManager) appContext.getSystemService(Context.SENSOR_SERVICE);
            magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

            sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI);
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);

        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            gravity = filter.filter(event.values.clone(), gravity);
        } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            geomagnetic = filter.filter(event.values.clone(), geomagnetic);
        }

        if (gravity != null && geomagnetic != null) {
            float[] R = new float[9];
            float[] I = new float[9];
            if (SensorManager.getRotationMatrix(R, I, gravity, geomagnetic)) {
                float[] orientation = new float[3];
                SensorManager.getOrientation(R, orientation);
                azimuth = (float) Math.toDegrees(orientation[0]);
                if (azimuth < 0) azimuth += 360;

                // Лог для отладки
                System.out.println("Compass azimuth: " + azimuth);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}
}