package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class FullCompassModule implements IXposedHookLoadPackage, SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor magnetometer;
    private float[] gravity = new float[3];
    private float[] geomagnetic = new float[3];
    private Context appContext;
    private LowPassFilter filter = new LowPassFilter(0.2f); // сглаживание азимута

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return;

        try {
            // Получаем контекст приложения через Xposed
            Class<?> activityThread = Class.forName("android.app.ActivityThread");
            appContext = (Context) activityThread.getMethod("currentApplication").invoke(null);

            if (appContext == null) {
                Log.e("FullCompassModule", "Context is null!");
                return;
            }

            Log.i("FullCompassModule", "FullCompassModule initialized with context!");

            sensorManager = (SensorManager) appContext.getSystemService(Context.SENSOR_SERVICE);
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
            sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI);

        } catch (Exception e) {
            Log.e("FullCompassModule", "Error init module", e);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            System.arraycopy(event.values, 0, gravity, 0, event.values.length);
        }
        if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            System.arraycopy(event.values, 0, geomagnetic, 0, event.values.length);
        }

        if (gravity != null && geomagnetic != null) {
            float R[] = new float[9];
            float I[] = new float[9];
            boolean success = SensorManager.getRotationMatrix(R, I, gravity, geomagnetic);
            if (success) {
                float orientation[] = new float[3];
                SensorManager.getOrientation(R, orientation);
                float azimuth = (float) Math.toDegrees(orientation[0]);
                if (azimuth < 0) azimuth += 360;

                // сглаживание
                float smoothAzimuth = filter.apply(azimuth);

                // Логируем азимут — можно использовать для передачи в Yandex Maps
                Log.i("FullCompassModule", "Compass azimuth: " + smoothAzimuth);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {}

}