package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.android.AndroidAppHelper;

public class FullCompassModule implements IXposedHookLoadPackage, SensorEventListener {

    private Context context;
    private SensorManager sensorManager;
    private Sensor rotationSensor;

    private float[] rotationMatrix = new float[9];
    private float[] orientationAngles = new float[3];

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        XposedBridge.log("FullCompassModule: handleLoadPackage for " + lpparam.packageName);
        initSensorWhenContextReady();
    }

    private void initSensorWhenContextReady() {
        new Thread(() -> {
            // Ждём, пока контекст станет доступен
            Context appContext = null;
            while (appContext == null) {
                appContext = AndroidAppHelper.currentApplication();
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ignored) {}
            }

            context = appContext;
            XposedBridge.log("FullCompassModule initialized with context!");

            sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
            if (sensorManager == null) {
                XposedBridge.log("SensorManager not available!");
                return;
            }

            rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
            if (rotationSensor == null) {
                XposedBridge.log("Rotation vector sensor not available!");
                return;
            }

            sensorManager.registerListener(
                    this,
                    rotationSensor,
                    SensorManager.SENSOR_DELAY_UI,
                    new Handler(Looper.getMainLooper())
            );
        }).start();
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values);
            SensorManager.getOrientation(rotationMatrix, orientationAngles);

            // Азимут в градусах
            float azimuth = (float) Math.toDegrees(orientationAngles[0]);
            if (azimuth < 0) {
                azimuth += 360;
            }

            XposedBridge.log("Compass azimuth: " + azimuth);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Пока ничего не делаем
    }
}