package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;

public class FullCompassModule implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // Подключаемся только к Яндекс.Картам
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return;

        XposedBridge.log("FullCompassModule loaded for: " + lpparam.packageName);

        // Получаем context приложения
        Class<?> activityThread = Class.forName("android.app.ActivityThread");
        Object app = activityThread.getMethod("currentApplication").invoke(null);
        Context context = (Context) app;

        SensorManager sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        Sensor rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);

        if (rotationSensor == null) {
            XposedBridge.log("Rotation Vector Sensor not available!");
            return;
        }

        sensorManager.registerListener(new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                float[] rotationMatrix = new float[9];
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values);

                float[] orientation = new float[3];
                SensorManager.getOrientation(rotationMatrix, orientation);

                float azimuth = (float) Math.toDegrees(orientation[0]);
                if (azimuth < 0) azimuth += 360;

                XposedBridge.log("Compass azimuth: " + azimuth);
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) { }
        }, rotationSensor, SensorManager.SENSOR_DELAY_UI);

        XposedBridge.log("FullCompassModule initialized successfully!");
    }
}