package com.example.sensorwake;

import de.robv.android.xposed.XposedHelpers;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class FullCompassModule implements IXposedHookLoadPackage, SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor magnetometer;

    private float[] gravity;
    private float[] geomagnetic;
    private float currentAzimuth = 0f;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        XposedBridge.log("FullCompassModule loaded for: " + lpparam.packageName);

        // Проверяем, что это нужное приложение (например, Яндекс.Карты)
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return;

        try {
            Context context = (Context) XposedHelpers.callMethod(
                    lpparam.classLoader.loadClass("android.app.ActivityThread"),
                    "currentApplication"
            );

            sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

            // Регистрируем слушателей сенсоров
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
            sensorManager.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_UI);

            XposedBridge.log("Compass sensors registered successfully.");

        } catch (Throwable t) {
            XposedBridge.log("FullCompassModule initialization error: " + t);
        }
    }

    // ---------------- SENSOR EVENT ----------------
    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            gravity = event.values.clone();
        } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
            geomagnetic = event.values.clone();
        }

        if (gravity != null && geomagnetic != null) {
            float R[] = new float[9];
            float I[] = new float[9];
            boolean success = SensorManager.getRotationMatrix(R, I, gravity, geomagnetic);
            if (success) {
                float orientation[] = new float[3];
                SensorManager.getOrientation(R, orientation);
                float azimuth = (float) Math.toDegrees(orientation[0]);
                azimuth = (azimuth + 360) % 360;

                // Плавное обновление азимута
                currentAzimuth = currentAzimuth + 0.1f * (azimuth - currentAzimuth);

                XposedBridge.log("Compass azimuth: " + currentAzimuth);
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Можно логировать, если нужно
    }
}