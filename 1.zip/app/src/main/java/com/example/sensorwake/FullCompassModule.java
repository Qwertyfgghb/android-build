package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.SensorEvent;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XC_MethodHook;

public class FullCompassModule implements IXposedHookLoadPackage {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor magnetometer;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // Подключаемся только к Яндекс.Картам
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) {
            return;
        }

        XposedBridge.log("FullCompassModule loaded for: " + lpparam.packageName);

        try {
            // Получаем класс Application и хук на onCreate
            Class<?> appClass = Class.forName(lpparam.appInfo.className, true, lpparam.classLoader);
            XposedBridge.hookAllMethods(appClass, "onCreate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Context context = (Context) param.thisObject;
                    startSensors(context);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("Compass init error: " + t.getMessage());
        }
    }

    private void startSensors(Context context) {
        try {
            sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

            sensorManager.registerListener(sensorListener, accelerometer, SensorManager.SENSOR_DELAY_UI);
            sensorManager.registerListener(sensorListener, magnetometer, SensorManager.SENSOR_DELAY_UI);

            XposedBridge.log("Compass sensors started");
        } catch (Exception e) {
            XposedBridge.log("Failed to start sensors: " + e.getMessage());
        }
    }

    private final SensorEventListener sensorListener = new SensorEventListener() {
        float[] gravity;
        float[] geomagnetic;

        @Override
        public void onSensorChanged(SensorEvent event) {
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                gravity = event.values.clone();
            } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                geomagnetic = event.values.clone();
            }

            if (gravity != null && geomagnetic != null) {
                float[] R = new float[9];
                float[] I = new float[9];

                if (SensorManager.getRotationMatrix(R, I, gravity, geomagnetic)) {
                    float[] orientation = new float[3];
                    SensorManager.getOrientation(R, orientation);
                    float azimuth = (float) Math.toDegrees(orientation[0]);
                    XposedBridge.log("Compass azimuth: " + azimuth);
                }
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
            // Ничего не делаем
        }
    };
}