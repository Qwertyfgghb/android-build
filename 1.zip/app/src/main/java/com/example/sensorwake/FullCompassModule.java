package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class FakeOrientationModule implements IXposedHookLoadPackage, SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private float[] gravity = new float[3];
    private float[] orientation = new float[3]; // yaw, pitch, roll

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return;

        // Получаем контекст приложения
        Context context = lpparam.appInfo != null ? lpparam.appInfo.loadLabel(lpparam.classLoader).getClass().getClassLoader().getClass().getClassLoader() : null;
        if (context == null) return;

        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager == null) return;

        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() != Sensor.TYPE_ACCELEROMETER) return;

        // Фильтр для сглаживания (простая версия)
        final float alpha = 0.8f;
        gravity[0] = alpha * gravity[0] + (1 - alpha) * event.values[0];
        gravity[1] = alpha * gravity[1] + (1 - alpha) * event.values[1];
        gravity[2] = alpha * gravity[2] + (1 - alpha) * event.values[2];

        // Вычисляем ориентацию устройства
        float norm = (float) Math.sqrt(gravity[0]*gravity[0] + gravity[1]*gravity[1] + gravity[2]*gravity[2]);
        if (norm == 0) return;
        float x = gravity[0]/norm;
        float y = gravity[1]/norm;
        float z = gravity[2]/norm;

        orientation[0] = (float) Math.atan2(y, x); // yaw (направление «влево-вправо»)
        orientation[1] = (float) Math.atan2(-z, Math.sqrt(x*x + y*y)); // pitch
        orientation[2] = 0; // roll можно игнорировать
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    // Функция для получения «фейковой» ориентации телефона
    public float[] getPhoneOrientation() {
        return orientation.clone();
    }
}