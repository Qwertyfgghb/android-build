package com.example.sensorwake;

import android.app.AndroidAppHelper;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;

public class FullCompassModule implements IXposedHookLoadPackage, SensorEventListener {

    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private float[] rotationMatrix = new float[9];
    private float[] orientation = new float[3];
    private float lastAzimuth = -1;
    private Context context;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        // Берём безопасный контекст приложения через AndroidAppHelper
        context = AndroidAppHelper.currentApplication();
        if (context == null) {
            XposedBridge.log("FullCompassModule: Context is null!");
            return;
        }

        XposedBridge.log("FullCompassModule initialized with context!");

        // Инициализация сенсора на главном потоке
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (sensorManager == null) {
            XposedBridge.log("FullCompassModule: SensorManager not available!");
            return;
        }

        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if (rotationSensor == null) {
            XposedBridge.log("FullCompassModule: Rotation vector sensor not available!");
            return;
        }

        // Регистрируем слушателя на главном Looper
        sensorManager.registerListener(
                this,
                rotationSensor,
                SensorManager.SENSOR_DELAY_UI,
                new Handler(Looper.getMainLooper())
        );
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() != Sensor.TYPE_ROTATION_VECTOR) return;

        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values);
        SensorManager.getOrientation(rotationMatrix, orientation);

        // Азимут в градусах
        float azimuth = (float) Math.toDegrees(orientation[0]);
        if (azimuth < 0) azimuth += 360;

        // Логируем все изменения
        if (lastAzimuth != azimuth) {
            lastAzimuth = azimuth;
            XposedBridge.log("Compass azimuth: " + azimuth);
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Можно логировать, если нужно
    }
}