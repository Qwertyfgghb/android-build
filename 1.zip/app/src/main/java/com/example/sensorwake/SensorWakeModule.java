package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.XC_MethodHook;

public class SensorWakeModule implements IXposedHookLoadPackage {

    // Укажи пакет приложения, для которого активируем сенсоры
    private static final String TARGET_PACKAGE = "ru.yandex.yandexmaps";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        if (!lpparam.packageName.equals(TARGET_PACKAGE)) return;

        // Хук getSystemService, чтобы разбудить сенсоры
        XposedHelpers.findAndHookMethod(
            Context.class,
            "getSystemService",
            String.class,
            new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {

                    String serviceName = (String) param.args[0];
                    Object result = param.getResult();

                    if (serviceName.equals(Context.SENSOR_SERVICE) && result instanceof SensorManager) {
                        SensorManager sm = (SensorManager) result;

                        // Разбудим стандартные сенсоры
                        wakeSensor(sm, Sensor.TYPE_ACCELEROMETER);
                        wakeSensor(sm, Sensor.TYPE_GYROSCOPE);
                        wakeSensor(sm, Sensor.TYPE_MAGNETIC_FIELD);
                    }
                }
            }
        );
    }

    // Функция для регистрации слушателя и разбудить сенсор
    private void wakeSensor(SensorManager sm, int sensorType) {
        Sensor sensor = sm.getDefaultSensor(sensorType);
        if (sensor != null) {
            sm.registerListener(new DummySensorListener(), sensor, SensorManager.SENSOR_DELAY_FASTEST);
        }
    }

    // Пустой слушатель для поддержания сенсора активным
    private static class DummySensorListener implements android.hardware.SensorEventListener {
        @Override
        public void onSensorChanged(android.hardware.SensorEvent event) { }
        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) { }
    }
}