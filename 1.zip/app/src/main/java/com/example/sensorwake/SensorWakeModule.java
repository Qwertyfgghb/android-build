package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class SensorWakeModule implements IXposedHookLoadPackage {

    private float currentAzimuth = 0f;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        // Ограничиваем на конкретное приложение, например Яндекс.Карты
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return;

        try {
            Context context = (Context) XposedHelpers.callMethod(
                    lpparam.appInfo, "loadLabel", lpparam.classLoader
            ); // для UI или HookContext

            if (context == null) return;

            SensorManager sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
            Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            Sensor magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
            Sensor gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

            SensorEventListener sensorListener = new SensorEventListener() {
                float[] gravity;
                float[] geomagnetic;
                float[] gyroValues;

                @Override
                public void onSensorChanged(SensorEvent event) {
                    switch (event.sensor.getType()) {
                        case Sensor.TYPE_ACCELEROMETER:
                            gravity = event.values.clone();
                            break;
                        case Sensor.TYPE_MAGNETIC_FIELD:
                            geomagnetic = event.values.clone();
                            break;
                        case Sensor.TYPE_GYROSCOPE:
                            gyroValues = event.values.clone();
                            break;
                    }

                    if (gravity != null && geomagnetic != null) {
                        float R[] = new float[9];
                        float I[] = new float[9];
                        if (SensorManager.getRotationMatrix(R, I, gravity, geomagnetic)) {
                            float orientation[] = new float[3];
                            SensorManager.getOrientation(R, orientation);
                            float azimuth = (float) Math.toDegrees(orientation[0]);
                            azimuth = (azimuth + 360) % 360;

                            updateCompass(azimuth);
                        }
                    }
                }

                @Override
                public void onAccuracyChanged(Sensor sensor, int accuracy) {}
            };

            sensorManager.registerListener(sensorListener, accelerometer, SensorManager.SENSOR_DELAY_UI);
            sensorManager.registerListener(sensorListener, magnetometer, SensorManager.SENSOR_DELAY_UI);
            sensorManager.registerListener(sensorListener, gyroscope, SensorManager.SENSOR_DELAY_UI);

        } catch (Throwable t) {
            XposedBridge.log("SensorWakeModule error: " + t);
        }
    }

    private void updateCompass(float azimuth) {
        // плавное приближение к новой позиции
        currentAzimuth = currentAzimuth + 0.1f * ((azimuth - currentAzimuth + 540) % 360 - 180);
        // здесь можно передавать значение в UI Яндекс.Карт или другой интерфейс
        XposedBridge.log("Compass azimuth: " + currentAzimuth);
    }
}