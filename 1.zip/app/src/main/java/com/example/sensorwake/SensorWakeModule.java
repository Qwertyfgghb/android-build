package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.util.Log;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_LoadPackage;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_MethodHook;

public class SensorWakeModule implements IXposedHookLoadPackage {

    private static final String TAG = "SensorWakeModule";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // Хук на ContextImpl.getSystemService, чтобы получить доступ к SensorManager
        XposedHelpers.findAndHookMethod(
                "android.app.ContextImpl",   // конкретная реализация Context
                lpparam.classLoader,
                "getSystemService",
                String.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        String name = (String) param.args[0];
                        if (Context.SENSOR_SERVICE.equals(name)) {
                            SensorManager sm = (SensorManager) param.getResult();
                            if (sm != null) {
                                wakeAllSensors(sm);
                            }
                        }
                    }
                }
        );
    }

    private void wakeAllSensors(SensorManager sm) {
        try {
            for (Sensor sensor : sm.getSensorList(Sensor.TYPE_ALL)) {
                Log.i(TAG, "Found sensor: " + sensor.getName() + " | type=" + sensor.getType());
                
                // Регистрируем простой слушатель на все сенсоры
                sm.registerListener((s, event) -> {
                    // Ничего не делаем, просто держим сенсор активным
                }, sensor, SensorManager.SENSOR_DELAY_NORMAL);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error waking sensors: ", e);
        }
    }
}