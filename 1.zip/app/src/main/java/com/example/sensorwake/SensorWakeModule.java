package com.example.sensorhook;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class FullCompassModule implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return;

        XposedBridge.log("FullCompassModule: Hooking Yandex Maps");

        XposedHelpers.findAndHookMethod(
            SensorManager.class,
            "registerListener",
            SensorEventListener.class,
            Sensor.class,
            int.class,
            new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    Sensor sensor = (Sensor) param.args[1];
                    SensorEventListener listener = (SensorEventListener) param.args[0];

                    if (sensor.getType() == Sensor.TYPE_ACCELEROMETER ||
                        sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD ||
                        sensor.getType() == Sensor.TYPE_GYROSCOPE) {

                        XposedBridge.log("FullCompassModule: Intercepting sensor " + sensor.getType());

                        Context context = (Context) XposedHelpers.getObjectField(param.thisObject, "mContext");
                        SensorManager sm = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);

                        Sensor accelerometer = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
                        Sensor magnetometer  = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
                        Sensor gyroscope     = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);

                        Handler handler = new Handler(Looper.getMainLooper());

                        SensorEventListener realListener = new SensorEventListener() {
                            float[] gravity = new float[3];
                            float[] geomagnetic = new float[3];
                            float azimuthSmoothed = 0;
                            float gyroAzimuth = 0;
                            long lastTimestamp = 0;

                            @Override
                            public void onSensorChanged(SensorEvent event) {
                                switch (event.sensor.getType()) {
                                    case Sensor.TYPE_ACCELEROMETER:
                                        gravity = event.values.clone();
                                        break;
                                    case Sensor.TYPE_MAGNETIC_FIELD:
                                        geomagnetic = event.values.clone();
                                        break;
                                    case Sensor.TYPE_GYROSCOPE:
                                        if (lastTimestamp != 0) {
                                            float dt = (event.timestamp - lastTimestamp) * 1e-9f;
                                            gyroAzimuth += event.values[2] * dt * (180f / (float)Math.PI);
                                        }
                                        lastTimestamp = event.timestamp;
                                        break;
                                }

                                float[] R = new float[9];
                                float[] I = new float[9];

                                boolean success = SensorManager.getRotationMatrix(R, I, gravity, geomagnetic);
                                if (success) {
                                    float[] orientation = new float[3];
                                    SensorManager.getOrientation(R, orientation);
                                    float azimuth = (float) Math.toDegrees(orientation[0]);
                                    if (azimuth < 0) azimuth += 360;

                                    // объединяем гироскоп и магнитометр
                                    float combinedAzimuth = 0.95f * azimuth + 0.05f * gyroAzimuth;

                                    // сглаживание
                                    azimuthSmoothed = azimuthSmoothed * 0.85f + combinedAzimuth * 0.15f;

                                    // создаём поддельный SensorEvent
                                    SensorEvent fakeEvent = XposedHelpers.newInstance(SensorEvent.class, 3);
                                    XposedHelpers.setObjectField(fakeEvent, "values", new float[]{azimuthSmoothed, 0f, 0f});

                                    handler.post(() -> listener.onSensorChanged(fakeEvent));
                                }
                            }

                            @Override
                            public void onAccuracyChanged(Sensor sensor, int accuracy) {}
                        };

                        sm.registerListener(realListener, accelerometer, SensorManager.SENSOR_DELAY_GAME);
                        sm.registerListener(realListener, magnetometer, SensorManager.SENSOR_DELAY_GAME);
                        sm.registerListener(realListener, gyroscope, SensorManager.SENSOR_DELAY_GAME);
                    }
                }
            }
        );
    }
}