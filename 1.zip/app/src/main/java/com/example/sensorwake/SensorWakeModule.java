package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class SensorWakeModule implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return; // только Яндекс карты

        final Context appContext = Utils.getAppContext(lpparam.classLoader);
        if (appContext == null) return;

        SensorManager sm = (SensorManager) appContext.getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) return;

        // Подписываемся на все сенсоры
        for (Sensor sensor : sm.getSensorList(Sensor.TYPE_ALL)) {
            sm.registerListener(new SensorEventListener() {
                @Override
                public void onSensorChanged(SensorEvent event) {
                    // можно логировать event.values, если нужно
                }
                @Override
                public void onAccuracyChanged(Sensor sensor, int accuracy) {}
            }, sensor, SensorManager.SENSOR_DELAY_FASTEST);
        }
    }
}