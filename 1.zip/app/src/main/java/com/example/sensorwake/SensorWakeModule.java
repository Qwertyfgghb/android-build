package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.PowerManager;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class SensorWakeModule implements IXposedHookLoadPackage {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor magnetometer;
    private SensorEventListener sensorListener;
    private PowerManager.WakeLock wakeLock;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) {
            return; // Модуль активен только для Яндекс.Карт
        }

        Context context = lpparam.appInfo != null ? lpparam.appInfo.loadLabel(lpparam.classLoader) : null;
        if (context == null) {
            context = getSystemContext(); // Если нужно, свой метод через ActivityThread
        }

        // Получаем SensorManager
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        // Создаем слушатель сенсоров
        sensorListener = new SensorEventListener() {
            float[] gravity;
            float[] geomagnetic;

            @Override
            public void onSensorChanged(SensorEvent event) {
                if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                    gravity = event.values.clone();
                } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                    geomagnetic = event.values.clone();
                }

                if (gravity != null && geomagnetic != null) {
                    float R[] = new float[9];
                    float I[] = new float[9];
                    if (SensorManager.getRotationMatrix(R, I, gravity, geomagnetic)) {
                        float orientation[] = new float[3];
                        SensorManager.getOrientation(R, orientation);
                        float azimuth = (float) Math.toDegrees(orientation[0]);
                        // azimuth — это направление стрелки компаса
                        // Можно передавать его в Яндекс.Карты через API, если нужно
                    }
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) { }
        };

        // Регистрируем сенсоры
        sensorManager.registerListener(sensorListener, accelerometer, SensorManager.SENSOR_DELAY_UI);
        sensorManager.registerListener(sensorListener, magnetometer, SensorManager.SENSOR_DELAY_UI);

        // Wakelock, чтобы сенсоры работали при заблокированном экране
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SensorWakeModule::WakeLock");
        wakeLock.acquire();
    }

    // Необходимо реализовать корректный метод получения systemContext, если context null
    private Context getSystemContext() {
        try {
            Class<?> activityThread = Class.forName("android.app.ActivityThread");
            Object thread = activityThread.getMethod("currentActivityThread").invoke(null);
            return (Context) activityThread.getMethod("getSystemContext").invoke(thread);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}