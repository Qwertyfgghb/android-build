package com.example.sensorwake;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class SensorWakeModule implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // Активируем только для целевого пакета, чтобы не хукать все
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return;

        // Получаем контекст приложения
        Context context = (Context) lpparam.classLoader
                .loadClass("android.app.Application")
                .getDeclaredConstructor()
                .newInstance();

        SensorManager sm = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) return;

        // Регистрируем слушатель на все сенсоры
        for (Sensor sensor : sm.getSensorList(Sensor.TYPE_ALL)) {
            sm.registerListener(new SensorEventListener() {
                @Override
                public void onSensorChanged(SensorEvent event) {
                    // Здесь можно обработать данные сенсора
                }

                @Override
                public void onAccuracyChanged(Sensor sensor, int accuracy) {}
            }, sensor, SensorManager.SENSOR_DELAY_FASTEST);
        }
    }
}