package com.example.radiorecorder;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class MetadataDbHelper extends SQLiteOpenHelper {
    private static final String DB="radio_metadata.db";
    public MetadataDbHelper(Context c){super(c,DB,null,1);}
    @Override public void onCreate(SQLiteDatabase db){db.execSQL("CREATE TABLE tracks(id INTEGER PRIMARY KEY AUTOINCREMENT,station_id INTEGER,station TEXT,title TEXT,artist TEXT,seen_at INTEGER)");db.execSQL("CREATE INDEX idx_artist ON tracks(artist)");db.execSQL("CREATE INDEX idx_title ON tracks(title)");}
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV){}
    public synchronized void add(int stationId,String station,String title){if(title==null||title.trim().isEmpty())return;String t=title.trim();String artist="";int p=t.indexOf(" - ");if(p>0)artist=t.substring(0,p).trim();SQLiteDatabase db=getWritableDatabase();ContentValues v=new ContentValues();v.put("station_id",stationId);v.put("station",station);v.put("title",t);v.put("artist",artist);v.put("seen_at",System.currentTimeMillis());db.insert("tracks",null,v);}
    public ArrayList<String> artists(int stationId){ArrayList<String>a=new ArrayList<>();SQLiteDatabase db=getReadableDatabase();Cursor c=db.rawQuery("SELECT artist,MAX(seen_at) FROM tracks WHERE station_id=? AND artist<>'' GROUP BY artist ORDER BY MAX(seen_at) DESC",new String[]{String.valueOf(stationId)});try{while(c.moveToNext())a.add(c.getString(0));}finally{c.close();}return a;}
    public ArrayList<String> titles(int stationId){ArrayList<String>a=new ArrayList<>();SQLiteDatabase db=getReadableDatabase();Cursor c=db.rawQuery("SELECT title,MAX(seen_at) FROM tracks WHERE station_id=? GROUP BY title ORDER BY MAX(seen_at) DESC",new String[]{String.valueOf(stationId)});try{while(c.moveToNext())a.add(c.getString(0));}finally{c.close();}return a;}
    public ArrayList<String> allArtists(){ArrayList<String>a=new ArrayList<>();SQLiteDatabase db=getReadableDatabase();Cursor c=db.rawQuery("SELECT artist,MAX(seen_at) FROM tracks WHERE artist<>'' GROUP BY artist ORDER BY MAX(seen_at) DESC",null);try{while(c.moveToNext())a.add(c.getString(0));}finally{c.close();}return a;}
}
