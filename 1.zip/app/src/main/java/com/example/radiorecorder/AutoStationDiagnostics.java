package com.example.radiorecorder;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.*;
import java.net.*;
import java.nio.charset.Charset;
import java.util.*;

/** Generic one-time stream diagnostics. No provider/API is hard-coded here. */
public final class AutoStationDiagnostics {
    public static final class Profile {
        public int httpCode;
        public String contentType="";
        public String icyName="";
        public String icyBitrate="";
        public int icyMetaInt=0;
        public String metadataKey="";
        public String metadataEncoding="";
        public String sampleTitle="";
        public boolean hasMetadata;
        public String rawHeaders="";
    }
    public interface Callback { void done(Profile p, String error); }
    private AutoStationDiagnostics() {}

    public static void runAsync(final String url, final Callback cb) {
        new Thread(() -> {
            Profile p=null; String err=null;
            try { p=diagnose(url); } catch(Exception e) { err=e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage()); }
            final Profile fp=p; final String fe=err;
            android.os.Handler h=new android.os.Handler(android.os.Looper.getMainLooper());
            h.post(() -> cb.done(fp,fe));
        }, "RadioAutoDiagnostic").start();
    }

    public static Profile diagnose(String u) throws Exception {
        Profile p=new Profile();
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(9000); c.setRequestProperty("Icy-MetaData","1");
        c.setRequestProperty("User-Agent","RadioRecorder-Diagnostic/2.0"); c.setRequestProperty("Connection","close");
        c.connect(); p.httpCode=c.getResponseCode();
        p.contentType=nvl(c.getContentType()); p.icyName=nvl(c.getHeaderField("icy-name"));
        p.icyBitrate=nvl(c.getHeaderField("icy-br")); p.icyMetaInt=parseInt(c.getHeaderField("icy-metaint"),0);
        StringBuilder hs=new StringBuilder(); Map<String,List<String>> h=c.getHeaderFields();
        if(h!=null) for(Map.Entry<String,List<String>> e:h.entrySet()) if(e.getKey()!=null) hs.append(e.getKey()).append(": ").append(e.getValue()).append('\n');
        p.rawHeaders=hs.toString();
        if(p.httpCode<200||p.httpCode>=400) throw new IOException("HTTP "+p.httpCode);
        if(p.icyMetaInt>0) {
            InputStream in=new BufferedInputStream(c.getInputStream());
            byte[] audio=new byte[Math.min(p.icyMetaInt,65536)];
            for(int block=0;block<12;block++) {
                readFully(in,audio,audio.length); if(audio.length<p.icyMetaInt) { byte[] rest=new byte[p.icyMetaInt-audio.length]; readFully(in,rest,rest.length); }
                int len=in.read(); if(len<0) break; int mlen=len*16;
                if(mlen>0) {
                    byte[] m=new byte[mlen]; readFully(in,m,mlen);
                    String[] enc={"UTF-8","windows-1251","ISO-8859-1"};
                    for(String encName:enc) {
                        String raw=new String(trimZeros(m),Charset.forName(encName));
                        String title=extractTitle(raw);
                        if(title!=null&&!title.trim().isEmpty()&&!raw.contains("\uFFFD")) {
                            p.hasMetadata=true; p.metadataEncoding=encName; p.sampleTitle=clean(title); p.metadataKey=findKey(raw); break;
                        }
                    }
                    if(p.hasMetadata) break;
                }
            }
            in.close();
        }
        c.disconnect(); return p;
    }

    public static void save(Context ctx,int stationId,Profile p) {
        if(p==null)return; SharedPreferences sp=ctx.getSharedPreferences("radio_prefs",Context.MODE_PRIVATE);
        sp.edit().putInt("station_diag_http_"+stationId,p.httpCode)
          .putString("station_diag_content_type_"+stationId,p.contentType)
          .putString("station_diag_icy_name_"+stationId,p.icyName)
          .putString("station_diag_icy_br_"+stationId,p.icyBitrate)
          .putInt("station_diag_metaint_"+stationId,p.icyMetaInt)
          .putBoolean("station_diag_has_metadata_"+stationId,p.hasMetadata)
          .putString("station_diag_meta_key_"+stationId,p.metadataKey)
          .putString("station_diag_encoding_"+stationId,p.metadataEncoding)
          .putString("station_diag_sample_"+stationId,p.sampleTitle)
          .putString("station_diag_headers_"+stationId,p.rawHeaders).apply();
    }

    public static String describe(Profile p) {
        if(p==null)return "Диагностика не выполнена";
        return "HTTP "+p.httpCode+"\nContent-Type: "+p.contentType+"\nicy-name: "+p.icyName+"\nicy-br: "+p.icyBitrate+"\nicy-metaint: "+p.icyMetaInt+"\nMetadata: "+(p.hasMetadata?"да":"нет")+"\nПоле: "+p.metadataKey+"\nКодировка: "+p.metadataEncoding+"\nПример: "+p.sampleTitle;
    }

    private static String findKey(String s){String l=s.toLowerCase(Locale.ROOT);String[] k={"streamtitle","stream-title","icy-title","icytitle","currenttitle","current_title","tracktitle","track_title","songtitle","song_title","title"};int best=-1;String out="";for(String x:k){int i=l.indexOf(x);if(i>=0&&(best<0||i<best)){best=i;out=x;}}return out;}
    public static String extractTitle(String s){
        if(s==null)return null; String l=s.toLowerCase(Locale.ROOT);
        String[] keys={"streamtitle","stream-title","icy-title","icytitle","currenttitle","current_title","tracktitle","track_title","songtitle","song_title","title"};
        int best=-1;String key=null;for(String k:keys){int i=l.indexOf(k);if(i>=0&&(best<0||i<best)){best=i;key=k;}}
        if(best>=0){int i=best+key.length();while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;if(i<s.length()&&(s.charAt(i)=='='||s.charAt(i)==':'))i++;while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;if(i<s.length()){char q=s.charAt(i);if(q=='\''||q=='\"'){int e=s.indexOf(q,i+1);if(e>i)return clean(s.substring(i+1,e));}int e=s.indexOf(';',i);return clean(s.substring(i,e<0?s.length():e));}}
        // JSON/XML-like metadata fallback.
        String[] marks={"\"title\"", "\"song\"", "<title>", "<song>"};
        for(String m:marks){int i=l.indexOf(m.toLowerCase(Locale.ROOT));if(i>=0){int a=s.indexOf(':',i+m.length());if(a<0)a=s.indexOf('>',i+m.length());if(a>=0){a++;while(a<s.length()&&Character.isWhitespace(s.charAt(a)))a++;int e=s.indexOf('"',a);if(e<0)e=s.indexOf('<',a);if(e> a)return clean(s.substring(a,e));}}}
        return null;
    }
    private static String clean(String s){return s==null?null:s.replace("\u0000","").replaceAll("\\s+"," ").replace("&apos;","'").replace("&quot;","\"").replace("&amp;","&").trim();}
    private static byte[] trimZeros(byte[] b){int n=b.length;while(n>0&&(b[n-1]==0||b[n-1]==' '))n--;return Arrays.copyOf(b,n);}
    private static void readFully(InputStream in,byte[] b,int n)throws IOException{int o=0;while(o<n){int x=in.read(b,o,n-o);if(x<0)throw new EOFException();o+=x;}}
    private static int parseInt(String s,int d){try{return Integer.parseInt(s.trim());}catch(Exception e){return d;}}
    private static String nvl(String s){return s==null?"":s;}
}
