package com.example.radiorecorder;
/** Deprecated: the recorder is provider-agnostic and no longer probes a fixed API. */
@Deprecated public final class ApiFinder {
    private ApiFinder() {}
    public interface Callback { void done(String apiUrl); }
    public static void findAsync(String streamUrl, Callback cb) {
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> cb.done(null));
    }
    public static String find(String streamUrl) { return null; }
}
