package com.example.radiorecorder;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.util.*;

/** Finds an IZI radio station API by matching the station stream_url. */
public final class ApiFinder {
    private ApiFinder() {}
    public interface Callback { void done(String apiUrl); }

    public static void findAsync(final String streamUrl, final Callback cb) {
        new Thread(() -> {
            String result = find(streamUrl);
            new Handler(Looper.getMainLooper()).post(() -> cb.done(result));
        }, "ApiFinder").start();
    }

    public static String find(String streamUrl) {
        if (streamUrl == null || streamUrl.trim().isEmpty()) return null;
        String wanted = normalizeUrl(streamUrl);
        // First and preferred source: the station collection endpoint itself.
        // We deliberately check this endpoint before language-specific variants.
        String[] endpoints = {
                "https://play.prod.iziyo.xyz/api/v1.0/radio/stations/",
                "https://play.prod.iziyo.xyz/api/v1.0/radio/stations/?lang=ru",
                "https://play.prod.iziyo.xyz/api/v1.0/radio/stations/?lang=kk"
        };
        for (String endpoint : endpoints) {
            try {
                String json = get(endpoint);
                String id = null;
                try { id = findIdByStream(new JSONArray(json), wanted); } catch (Exception ignored) {}
                if (id == null) {
                    try { id = findIdByStream(new JSONObject(json), wanted); } catch (Exception ignored) {}
                }
                if (id != null) return stationApi(id, "ru");
            } catch (Exception ignored) {}
        }
        return null;
    }

    private static String stationApi(String id, String lang) {
        return "https://play.prod.iziyo.xyz/api/v1.0/radio/stations/" + id + "/?lang=" + lang;
    }

    private static String findIdByStream(JSONArray a, String wanted) {
        for (int i=0;i<a.length();i++) {
            Object o=a.opt(i);
            String id=findIdByStream(o,wanted);
            if(id!=null)return id;
        }
        return null;
    }

    private static String findIdByStream(Object value, String wanted) {
        if(value instanceof JSONObject){
            JSONObject o=(JSONObject)value;
            String stream=o.optString("stream_url","");
            String id=o.optString("id","");
            if(!stream.isEmpty() && !id.isEmpty() && sameUrl(stream,wanted)) return id;
            JSONArray names=o.names();
            if(names!=null) for(int i=0;i<names.length();i++){
                Object child=o.opt(names.optString(i));
                String r=findIdByStream(child,wanted); if(r!=null)return r;
            }
        } else if(value instanceof JSONArray) {
            return findIdByStream((JSONArray)value,wanted);
        }
        return null;
    }

    private static boolean sameUrl(String a,String b){
        return normalizeUrl(a).equals(normalizeUrl(b));
    }
    private static String normalizeUrl(String s){
        String x=s.trim();
        while(x.endsWith("/"))x=x.substring(0,x.length()-1);
        return x.toLowerCase(Locale.ROOT);
    }

    private static String get(String url) throws Exception {
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setConnectTimeout(5000);c.setReadTimeout(7000);c.setRequestMethod("GET");
        c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","RadioRecorder/11");
        int code=c.getResponseCode();
        InputStream in=code>=200&&code<400?c.getInputStream():c.getErrorStream();
        if(in==null)throw new IOException("HTTP "+code);
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;
        while((n=in.read(b))!=-1)out.write(b,0,n);in.close();c.disconnect();
        if(code<200||code>=400)throw new IOException("HTTP "+code);
        return out.toString("UTF-8");
    }
}
