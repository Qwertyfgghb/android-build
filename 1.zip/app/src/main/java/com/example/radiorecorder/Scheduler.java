package com.example.radiorecorder;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class Scheduler {
    private Scheduler() {}
    private static int requestCode(int id,String action){return id*10+(ScheduleReceiver.ACTION_START.equals(action)?1:2);}
    public static void schedule(Context c,int id,long when,String action){
        if(when<=System.currentTimeMillis()) return;
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am==null)return;
        Intent i=new Intent(c,ScheduleReceiver.class);i.setAction(action);i.putExtra("station_id",id);
        PendingIntent pi=PendingIntent.getBroadcast(c,requestCode(id,action),i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        if(Build.VERSION.SDK_INT>=31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        else if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);
        else am.set(AlarmManager.RTC_WAKEUP,when,pi);
    }
    public static void cancel(Context c,int id,String action){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am==null)return;
        Intent i=new Intent(c,ScheduleReceiver.class);i.setAction(action);i.putExtra("station_id",id);
        PendingIntent pi=PendingIntent.getBroadcast(c,requestCode(id,action),i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        am.cancel(pi);pi.cancel();
    }
}
