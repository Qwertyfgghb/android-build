package com.example.radiorecorder;
import android.app.*;import android.content.*;import android.os.Build;
public final class Scheduler{
 private Scheduler(){}
 private static int requestCode(int station,int sid,String action){return station*100000+sid*10+(ScheduleReceiver.ACTION_START.equals(action)?1:2);}
 public static void schedule(Context c,int station,int sid,long when,String action){if(when<=System.currentTimeMillis())return;AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am==null)return;Intent i=new Intent(c,ScheduleReceiver.class).setAction(action).putExtra("station_id",station).putExtra("schedule_id",sid);PendingIntent pi=PendingIntent.getBroadcast(c,requestCode(station,sid,action),i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));if(Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);else if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);else am.set(AlarmManager.RTC_WAKEUP,when,pi);}
 public static void cancel(Context c,int station,int sid,String action){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am==null)return;Intent i=new Intent(c,ScheduleReceiver.class).setAction(action).putExtra("station_id",station).putExtra("schedule_id",sid);PendingIntent pi=PendingIntent.getBroadcast(c,requestCode(station,sid,action),i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));am.cancel(pi);pi.cancel();}
}
