package com.example.radiorecorder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import java.util.Calendar;

public class ScheduleReceiver extends BroadcastReceiver {
    public static final String ACTION_START="com.example.radiorecorder.SCHEDULE_START";
    public static final String ACTION_STOP="com.example.radiorecorder.SCHEDULE_STOP";
    @Override public void onReceive(Context context, Intent intent) {
        if(Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())){restore(context);return;}
        SharedPreferences p=context.getSharedPreferences("radio_prefs",Context.MODE_PRIVATE);
        int id=intent.getIntExtra("station_id",-1);if(id<0)return;
        String url=p.getString("station_url_"+id,"");if(url.isEmpty())return;
        String name=p.getString("station_name_"+id,url);
        Intent s=new Intent(context,RadioService.class).putExtra("station_id",id).putExtra("station_name",name).putExtra("station_url",url);
        if(ACTION_START.equals(intent.getAction())){
            s.setAction(RadioService.ACTION_START_STATION);if(Build.VERSION.SDK_INT>=26)context.startForegroundService(s);else context.startService(s);
            rescheduleNext(context,id,ACTION_START,p.getLong("schedule_start_"+id,0));
        }else if(ACTION_STOP.equals(intent.getAction())){
            s.setAction(RadioService.ACTION_STOP_STATION);context.startService(s);
            rescheduleNext(context,id,ACTION_STOP,p.getLong("schedule_stop_"+id,0));
        }
    }
    static void rescheduleNext(Context c,int id,String action,long old){
        SharedPreferences p=c.getSharedPreferences("radio_prefs",Context.MODE_PRIVATE);String rep=p.getString("schedule_repeat_"+id,"once");
        if("once".equals(rep)||old<=0)return;Calendar x=Calendar.getInstance();x.setTimeInMillis(old);Calendar now=Calendar.getInstance();
        if("daily".equals(rep))x.add(Calendar.DAY_OF_YEAR,1);else x.add(Calendar.WEEK_OF_YEAR,1);
        while(x.getTimeInMillis()<=now.getTimeInMillis()){if("daily".equals(rep))x.add(Calendar.DAY_OF_YEAR,1);else x.add(Calendar.WEEK_OF_YEAR,1);}
        p.edit().putLong(action.equals(ACTION_START)?"schedule_start_"+id:"schedule_stop_"+id,x.getTimeInMillis()).apply();
        Scheduler.schedule(c,id,x.getTimeInMillis(),action);
    }
    private void restore(Context c){SharedPreferences p=c.getSharedPreferences("radio_prefs",Context.MODE_PRIVATE);int n=p.getInt("station_count",0);long now=System.currentTimeMillis();for(int i=0;i<n;i++){long a=p.getLong("schedule_start_"+i,0),b=p.getLong("schedule_stop_"+i,0);if(a>now)Scheduler.schedule(c,i,a,ACTION_START);else if("daily".equals(p.getString("schedule_repeat_"+i,"once"))||"weekly".equals(p.getString("schedule_repeat_"+i,"once")))rescheduleNext(c,i,ACTION_START,a);if(b>now)Scheduler.schedule(c,i,b,ACTION_STOP);else if("daily".equals(p.getString("schedule_repeat_"+i,"once"))||"weekly".equals(p.getString("schedule_repeat_"+i,"once")))rescheduleNext(c,i,ACTION_STOP,b);}}
}
