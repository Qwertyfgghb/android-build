package com.example.radiorecorder;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.Charset;
import java.util.*;

/** Диагностика потока: показывает ICY-заголовки и реальные metadata-блоки. */
public class DiagnosticActivity extends Activity {
    private EditText url;
    private TextView out;
    private Button test, add;
    private volatile boolean running;
    private Thread worker;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,14,18,10);
        TextView h=new TextView(this); h.setText("🔎 Диагностика радиопотока"); h.setTextSize(22); h.setGravity(17); root.addView(h);
        url=new EditText(this); url.setHint("Вставьте URL потока, например http://.../radio.aac"); url.setSingleLine(true); root.addView(url);
        LinearLayout bs=new LinearLayout(this);
        test=new Button(this); test.setText("Проверить поток"); add=new Button(this); add.setText("Добавить в рекордер"); add.setEnabled(false);
        bs.addView(test,new LinearLayout.LayoutParams(0,-2,1)); bs.addView(add,new LinearLayout.LayoutParams(0,-2,1)); root.addView(bs);
        TextView hint=new TextView(this); hint.setText("Проверка читает только небольшой объём данных и показывает Content-Type, icy-метаинтервал и фактические metadata. Полная запись не выполняется."); hint.setTextSize(12); root.addView(hint);
        ScrollView sc=new ScrollView(this); out=new TextView(this); out.setTextIsSelectable(true); out.setTextSize(13); out.setPadding(4,10,4,10); sc.addView(out); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        Button close=new Button(this); close.setText("Назад"); root.addView(close);
        setContentView(root);
        test.setOnClickListener(v->startTest());
        add.setOnClickListener(v->saveStation());
        close.setOnClickListener(v->finish());
    }

    private void startTest(){
        final String u=url.getText().toString().trim();
        if(u.isEmpty()){url.setError("Введите URL");return;}
        stopTest(); running=true; add.setEnabled(false); out.setText("Подключение...\n");
        worker=new Thread(()->diagnose(u),"radio-diagnostic"); worker.start();
    }

    private void diagnose(String u){
        HttpURLConnection c=null;
        try{
            URL x=new URL(u); c=(HttpURLConnection)x.openConnection();
            c.setConnectTimeout(8000); c.setReadTimeout(8000); c.setRequestProperty("Icy-MetaData","1"); c.setRequestProperty("User-Agent","RadioRecorder-Diagnostic/1.0"); c.setRequestProperty("Connection","close"); c.connect();
            StringBuilder s=new StringBuilder(); s.append("HTTP ").append(c.getResponseCode()).append("\n");
            s.append("Content-Type: ").append(c.getContentType()).append("\n");
            s.append("Content-Length: ").append(c.getContentLengthLong()).append("\n");
            Map<String,List<String>> hs=c.getHeaderFields();
            if(hs!=null) for(Map.Entry<String,List<String>> e:hs.entrySet()) if(e.getKey()!=null) s.append(e.getKey()).append(": ").append(e.getValue()).append("\n");
            final int meta=parseInt(c.getHeaderField("icy-metaint"),0); s.append("\nicy-metaint: ").append(meta).append("\n");
            final String br=c.getHeaderField("icy-br"); s.append("icy-br: ").append(br).append("\n");
            post(s.toString());
            if(meta<=0){post("\nStreamTitle не обнаружен в ICY-заголовках. Поток может быть без ICY metadata или использовать другой механизм метаданных.\n"); return;}
            InputStream in=new BufferedInputStream(c.getInputStream()); byte[] audio=new byte[Math.min(meta,65536)]; int blocks=0; long audioBytes=0;
            while(running && blocks<12){readFully(in,audio,meta); audioBytes+=meta; int len=in.read(); if(len<0)break; int mlen=len*16; if(mlen>0){byte[] m=new byte[mlen];readFully(in,m,mlen);String raw=decodeMetadata(m);post("\nMETADATA #"+(++blocks)+" ("+mlen+" bytes):\n"+raw);String title=extractTitle(raw);if(title!=null)post("  → распознано название: "+title+"\n");} else {post("\nMETADATA #"+(++blocks)+": пустой блок\n");}}
            post("\nПроверка завершена. Прочитано аудио-байт: "+audioBytes+".\n");
            ui(()->add.setEnabled(true));
        }catch(Exception e){post("\nОШИБКА: "+e.getClass().getSimpleName()+": "+e.getMessage()+"\n");}
        finally{if(c!=null)c.disconnect();running=false;}
    }

    private String decodeMetadata(byte[] b){
        int n=b.length; while(n>0 && (b[n-1]==0 || b[n-1]==' '))n--;
        String[] cs={"UTF-8","windows-1251","ISO-8859-1"};
        for(String z:cs)try{String s=new String(b,0,n,Charset.forName(z));if(!s.contains("\uFFFD"))return s;}catch(Exception ignored){}
        return new String(b,0,n,Charset.forName("ISO-8859-1"));
    }
    private String extractTitle(String s){
        String l=s.toLowerCase(Locale.ROOT);String[] keys={"streamtitle","stream-title","icy-title","icytitle","currenttitle","tracktitle","songtitle","title"};
        int p=-1;String key=null;for(String k:keys){int q=l.indexOf(k);if(q>=0&&(p<0||q<p)){p=q;key=k;}}
        if(p<0)return null;int i=p+key.length();while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;if(i<s.length()&&(s.charAt(i)=='='||s.charAt(i)==':'))i++;while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;if(i>=s.length())return null;
        char q=s.charAt(i);if(q=='\''||q=='\"'){int e=s.indexOf(q,i+1);return e>i?s.substring(i+1,e).trim():null;}int e=s.indexOf(';',i);return (e<0?s.substring(i):s.substring(i,e)).trim();
    }
    private void saveStation(){
        String u=url.getText().toString().trim();if(u.isEmpty())return;SharedPreferences p=getSharedPreferences("radio_prefs",MODE_PRIVATE);int n=p.getInt("station_count",0);String name=u;try{URI x=new URI(u);if(x.getHost()!=null)name=x.getHost();}catch(Exception ignored){}
        SharedPreferences.Editor e=p.edit();e.putString("station_url_"+n,u);e.putString("station_name_"+n,name);e.putBoolean("auto_name_"+n,true);e.putBoolean("station_skip_first_"+n,true);e.putBoolean("station_skip_duplicates_"+n,true);e.putBoolean("station_use_metadata_"+n,true);e.putBoolean("station_use_silence_"+n,false);e.putInt("station_count",n+1);e.apply();AutoStationDiagnostics.runAsync(u,(profile,error)->{if(profile!=null){AutoStationDiagnostics.save(this,n,profile);if(profile.icyName!=null&&!profile.icyName.trim().isEmpty())p.edit().putString("station_name_"+n,profile.icyName.trim()).apply();}Toast.makeText(this,"Станция добавлена"+(error==null?" и проверена":"; диагностика не удалась, но запись доступна"),Toast.LENGTH_SHORT).show();});add.setEnabled(false);
    }
    private void readFully(InputStream in,byte[] b,int n)throws IOException{int off=0;while(off<n){int x=in.read(b,off,n-off);if(x<0)throw new EOFException();off+=x;}}
    private int parseInt(String s,int d){try{return Integer.parseInt(s.trim());}catch(Exception e){return d;}}
    private void post(String s){ui(()->out.append(s));}
    private void ui(Runnable r){runOnUiThread(r);}
    private void stopTest(){running=false;if(worker!=null){try{worker.interrupt();}catch(Exception ignored){}worker=null;}}
    @Override protected void onDestroy(){stopTest();super.onDestroy();}
}
