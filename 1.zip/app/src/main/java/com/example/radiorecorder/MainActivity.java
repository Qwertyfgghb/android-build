package com.example.radiorecorder;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final String PREFS="radio_prefs";
    private SharedPreferences prefs;
    private LinearLayout stationContainer;
    private TextView emptyText;
    private final Map<Integer,TextView> statusViews=new HashMap<>();
    private final Map<Integer,String> statusTexts=new HashMap<>();

    private final BroadcastReceiver statusReceiver=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){
            int id=i.getIntExtra("station_id",-1);
            TextView v=statusViews.get(id);
            String st=i.getStringExtra("status"); String tr=i.getStringExtra("track");
            String text=(st==null?"":st)+(tr==null||tr.isEmpty()?"":"\nТрек: "+tr);
            statusTexts.put(id,text);
            if(v!=null)v.setText(text);
        }
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b); prefs=getSharedPreferences(PREFS,MODE_PRIVATE); buildUi();
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);
    }

    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,24,24,24);
        TextView title=new TextView(this);title.setText("Radio Recorder");title.setTextSize(24);title.setGravity(Gravity.CENTER);root.addView(title,new LinearLayout.LayoutParams(-1,-2));

        Button add=new Button(this);add.setText("+ Добавить радио");root.addView(add,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout all=new LinearLayout(this);all.setOrientation(LinearLayout.HORIZONTAL);
        Button startAll=new Button(this);startAll.setText("▶ Запустить все");Button stopAll=new Button(this);stopAll.setText("■ Остановить все");
        all.addView(startAll,new LinearLayout.LayoutParams(0,-2,1));all.addView(stopAll,new LinearLayout.LayoutParams(0,-2,1));root.addView(all);

        ScrollView scroll=new ScrollView(this);stationContainer=new LinearLayout(this);stationContainer.setOrientation(LinearLayout.VERTICAL);scroll.addView(stationContainer);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        emptyText=new TextView(this);emptyText.setText("Радиостанций пока нет.\nНажмите «Добавить радио».");emptyText.setTextSize(17);emptyText.setPadding(8,32,8,32);
        setContentView(root);

        add.setOnClickListener(v->stationDialog(-1));
        startAll.setOnClickListener(v->{for(Station s:stations())sendStation(RadioService.ACTION_START_STATION,s);});
        stopAll.setOnClickListener(v->sendSimple(RadioService.ACTION_STOP_ALL));
        refreshStations();
    }

    @Override protected void onResume(){super.onResume();if(stationContainer!=null)refreshStations();}
    @Override protected void onStart(){super.onStart();IntentFilter f=new IntentFilter(RadioService.ACTION_STATUS);if(Build.VERSION.SDK_INT>=33)registerReceiver(statusReceiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(statusReceiver,f);}
    @Override protected void onStop(){try{unregisterReceiver(statusReceiver);}catch(Exception ignored){}super.onStop();}

    private List<Station> stations(){
        int n=prefs.getInt("station_count",0);List<Station> list=new ArrayList<>();
        for(int i=0;i<n;i++){String name=prefs.getString("station_name_"+i,"");String url=prefs.getString("station_url_"+i,"");if(!name.isEmpty()&&!url.isEmpty())list.add(new Station(i,name,url));}
        return list;
    }

    private void refreshStations(){
        stationContainer.removeAllViews();statusViews.clear();List<Station> list=stations();
        if(list.isEmpty()){stationContainer.addView(emptyText);return;}
        for(Station s:list)addStationView(s);
    }

    private void addStationView(Station s){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(16,12,16,12);
        TextView name=new TextView(this);name.setText(s.name);name.setTextSize(20);card.addView(name);
        TextView url=new TextView(this);url.setText(s.url);url.setTextSize(12);card.addView(url);
        TextView params=new TextView(this);params.setText(parameterSummary(s.index));params.setTextSize(12);params.setPadding(0,6,0,2);card.addView(params);
        TextView status=new TextView(this);status.setText(statusTexts.containsKey(s.index)?statusTexts.get(s.index):"Остановлено");status.setTextSize(14);status.setPadding(0,8,0,8);card.addView(status);statusViews.put(s.index,status);
        LinearLayout buttons=new LinearLayout(this);buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button start=new Button(this);start.setText("▶");Button stop=new Button(this);stop.setText("■");Button edit=new Button(this);edit.setText("✎");Button del=new Button(this);del.setText("🗑");
        buttons.addView(start,new LinearLayout.LayoutParams(0,-2,1));buttons.addView(stop,new LinearLayout.LayoutParams(0,-2,1));buttons.addView(edit,new LinearLayout.LayoutParams(0,-2,1));buttons.addView(del,new LinearLayout.LayoutParams(0,-2,1));card.addView(buttons);stationContainer.addView(card);
        start.setOnClickListener(v->sendStation(RadioService.ACTION_START_STATION,s));
        stop.setOnClickListener(v->sendStation(RadioService.ACTION_STOP_STATION,s));
        edit.setOnClickListener(v->stationDialog(s.index));
        del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Удалить радио?").setMessage(s.name).setPositiveButton("Удалить",(d,w)->deleteStation(s.index)).setNegativeButton("Отмена",null).show());
    }

    private String parameterSummary(int i){
        return "Буфер: "+prefs.getString("station_ring_seconds_"+i,"8.0")+" с | Overlap: "+prefs.getString("station_overlap_seconds_"+i,"1.0")+" с | Post-roll: "+prefs.getString("station_postroll_seconds_"+i,"7.0")+" с | Bitrate: "+prefs.getString("station_bitrate_kbps_"+i,"192")+" кбит/с";
    }

    private EditText field(LinearLayout box,String hint,String value,boolean decimal){
        EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setSingleLine(true);e.setInputType(decimal?InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL:InputType.TYPE_CLASS_NUMBER);box.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;
    }

    private String defaultStationName(int index){
        if(index>=0 && index<26) return "Радио "+(char)('A'+index);
        return "Радио "+(index+1);
    }

    private void stationDialog(int index){
        boolean edit=index>=0;
        ScrollView scroll=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(40,0,40,0);scroll.addView(box);
        EditText name=field(box,"Название радиостанции",edit?prefs.getString("station_name_"+index,""):defaultStationName(prefs.getInt("station_count",0)),false);
        EditText url=field(box,"URL потока",edit?prefs.getString("station_url_"+index,""):"",false);url.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        field(box,"Кольцевой буфер, секунд",edit?prefs.getString("station_ring_seconds_"+index,"8.0"):"8.0",true);
        EditText overlap=field(box,"Overlap, секунд",edit?prefs.getString("station_overlap_seconds_"+index,"1.0"):"1.0",true);
        EditText post=field(box,"Post-roll при смене трека, секунд",edit?prefs.getString("station_postroll_seconds_"+index,"7.0"):"7.0",true);
        EditText bitrate=field(box,"Битрейт, кбит/с",edit?prefs.getString("station_bitrate_kbps_"+index,"192"):"192",false);
        TextView note=new TextView(this);note.setText("При ручном «Стоп» поток продолжается до следующей смены названия трека, затем используется обычный Post-roll этой станции.");note.setPadding(0,12,0,8);box.addView(note);
        EditText ring=(EditText)box.getChildAt(2);

        new AlertDialog.Builder(this).setTitle(edit?"Радио и параметры станции":"Добавить радио и параметры").setView(scroll)
            .setPositiveButton("Сохранить",(d,w)->{
                String n=name.getText().toString().trim(),u=url.getText().toString().trim();
                if(n.isEmpty()||u.isEmpty())return;
                try{
                    double rv=Double.parseDouble(ring.getText().toString());double ov=Double.parseDouble(overlap.getText().toString());double pv=Double.parseDouble(post.getText().toString());int bv=Integer.parseInt(bitrate.getText().toString());
                    if(rv<=0||ov<0||pv<0||bv<=0)throw new Exception();
                    int i=edit?index:prefs.getInt("station_count",0);SharedPreferences.Editor e=prefs.edit();
                    e.putString("station_name_"+i,n).putString("station_url_"+i,u).putString("station_ring_seconds_"+i,String.valueOf(rv)).putString("station_overlap_seconds_"+i,String.valueOf(ov)).putString("station_postroll_seconds_"+i,String.valueOf(pv)).putString("station_bitrate_kbps_"+i,String.valueOf(bv));
                    if(!edit)e.putInt("station_count",i+1);e.apply();refreshStations();
                }catch(Exception ex){Toast.makeText(this,"Проверьте параметры станции",Toast.LENGTH_LONG).show();}
            }).setNegativeButton("Отмена",null).show();
    }

    private void deleteStation(int index){
        int n=prefs.getInt("station_count",0);SharedPreferences.Editor e=prefs.edit();
        for(int i=index;i<n-1;i++){
            e.putString("station_name_"+i,prefs.getString("station_name_"+(i+1),""));e.putString("station_url_"+i,prefs.getString("station_url_"+(i+1),""));
            e.putString("station_ring_seconds_"+i,prefs.getString("station_ring_seconds_"+(i+1),"8.0"));e.putString("station_overlap_seconds_"+i,prefs.getString("station_overlap_seconds_"+(i+1),"1.0"));e.putString("station_postroll_seconds_"+i,prefs.getString("station_postroll_seconds_"+(i+1),"7.0"));e.putString("station_bitrate_kbps_"+i,prefs.getString("station_bitrate_kbps_"+(i+1),"192"));
        }
        int last=Math.max(0,n-1);e.remove("station_name_"+last).remove("station_url_"+last).remove("station_ring_seconds_"+last).remove("station_overlap_seconds_"+last).remove("station_postroll_seconds_"+last).remove("station_bitrate_kbps_"+last).putInt("station_count",last).apply();
        statusTexts.remove(index);refreshStations();
    }

    private void sendStation(String action,Station s){
        Intent i=new Intent(this,RadioService.class);i.setAction(action);i.putExtra("station_id",s.index);i.putExtra("station_name",s.name);i.putExtra("station_url",s.url);
        if(Build.VERSION.SDK_INT>=26){if(RadioService.ACTION_START_STATION.equals(action))startForegroundService(i);else startService(i);}else startService(i);
    }
    private void sendSimple(String action){Intent i=new Intent(this,RadioService.class);i.setAction(action);if(Build.VERSION.SDK_INT>=26){if(RadioService.ACTION_START_STATION.equals(action))startForegroundService(i);else startService(i);}else startService(i);}
    private static class Station{int index;String name,url;Station(int i,String n,String u){index=i;name=n;url=u;}}
}
