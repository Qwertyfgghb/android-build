package com.example.radiorecorder;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final String PREFS="radio_prefs";
    private SharedPreferences prefs;
    private LinearLayout stationContainer;
    private TextView emptyText;
    private final Map<Integer,TextView> statusViews=new HashMap<>();
    private final Map<Integer,TextView> nameViews=new HashMap<>();
    private final Map<Integer,String> statusTexts=new HashMap<>();
    private final SimpleDateFormat df=new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault());

    private final BroadcastReceiver statusReceiver=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){
            int id=i.getIntExtra("station_id",-1);
            TextView v=statusViews.get(id);
            TextView nv=nameViews.get(id);
            String st=i.getStringExtra("status"); String tr=i.getStringExtra("track");
            String autoName=i.getStringExtra("station_name");
            if(nv!=null && autoName!=null && !autoName.isEmpty()) nv.setText(autoName);
            String text=(st==null?"":st)+(tr==null||tr.isEmpty()?"":"\n♫ "+tr);
            statusTexts.put(id,text);
            if(v!=null)v.setText(text);
        }
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b); prefs=getSharedPreferences(PREFS,MODE_PRIVATE); migrateDefaults(); buildUi();
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);
    }

    private void migrateDefaults(){if(!prefs.getBoolean("first_skip_migration_v10",false)){SharedPreferences.Editor e=prefs.edit();int n=prefs.getInt("station_count",0);for(int i=0;i<n;i++)e.putBoolean("station_skip_first_"+i,true);e.putBoolean("first_skip_migration_v10",true);e.apply();}}

    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(18,14,18,10);
        TextView title=new TextView(this);title.setText("Radio Recorder");title.setTextSize(23);title.setGravity(Gravity.CENTER);root.addView(title,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);
        Button add=new Button(this);add.setText("+ Радио");Button recordings=new Button(this);recordings.setText("Записи");Button scheduleAll=new Button(this);scheduleAll.setText("Планировщик");
        top.addView(add,new LinearLayout.LayoutParams(0,-2,1));top.addView(recordings,new LinearLayout.LayoutParams(0,-2,1));top.addView(scheduleAll,new LinearLayout.LayoutParams(0,-2,1));root.addView(top);
        LinearLayout all=new LinearLayout(this);all.setOrientation(LinearLayout.HORIZONTAL);
        Button startAll=new Button(this);startAll.setText("▶ Все");Button stopAll=new Button(this);stopAll.setText("■ Все");
        all.addView(startAll,new LinearLayout.LayoutParams(0,-2,1));all.addView(stopAll,new LinearLayout.LayoutParams(0,-2,1));root.addView(all);

        ScrollView scroll=new ScrollView(this);stationContainer=new LinearLayout(this);stationContainer.setOrientation(LinearLayout.VERTICAL);scroll.addView(stationContainer);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        emptyText=new TextView(this);emptyText.setText("Радиостанций пока нет.\nНажмите «+ Радио».");emptyText.setTextSize(17);emptyText.setPadding(8,28,8,28);
        setContentView(root);

        add.setOnClickListener(v->stationDialog(-1));
        recordings.setOnClickListener(v->startActivity(new Intent(this,RecordingsActivity.class)));
        startAll.setOnClickListener(v->{for(Station s:stations())sendStation(RadioService.ACTION_START_STATION,s);});
        stopAll.setOnClickListener(v->sendSimple(RadioService.ACTION_STOP_ALL));
        scheduleAll.setOnClickListener(v->startActivity(new Intent(this,PlannerActivity.class)));
        refreshStations();
    }

    @Override protected void onResume(){super.onResume();if(stationContainer!=null)refreshStations();}
    @Override protected void onStart(){super.onStart();IntentFilter f=new IntentFilter(RadioService.ACTION_STATUS);if(Build.VERSION.SDK_INT>=33)registerReceiver(statusReceiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(statusReceiver,f);}
    @Override protected void onStop(){try{unregisterReceiver(statusReceiver);}catch(Exception ignored){}super.onStop();}

    private List<Station> stations(){
        int n=prefs.getInt("station_count",0);List<Station> list=new ArrayList<>();
        for(int i=0;i<n;i++){String name=prefs.getString("station_name_"+i,"");String url=prefs.getString("station_url_"+i,"");if(!url.isEmpty())list.add(new Station(i,name.isEmpty()?urlName(url):name,url));}
        return list;
    }

    private void refreshStations(){
        stationContainer.removeAllViews();statusViews.clear();nameViews.clear();List<Station> list=stations();
        if(list.isEmpty()){stationContainer.addView(emptyText);return;}
        for(Station s:list)addStationView(s);
    }

    private void addStationView(Station s){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(10,9,10,9);
        LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.HORIZONTAL);
        TextView name=new TextView(this);String groupLabel=prefs.getString("station_group_"+s.index,"");boolean fav=prefs.getBoolean("station_favorite_"+s.index,false);name.setText((fav?"⭐ ":"")+s.name+(groupLabel.isEmpty()?"":"  · "+groupLabel));name.setTextSize(19);name.setSingleLine(true);head.addView(name,new LinearLayout.LayoutParams(0,-2,1));nameViews.put(s.index,name);
        Button more=new Button(this);more.setText("⋮");head.addView(more,new LinearLayout.LayoutParams(48,-2));row.addView(head);
        TextView status=new TextView(this);status.setText(statusTexts.containsKey(s.index)?statusTexts.get(s.index):"Остановлено");status.setTextSize(13);status.setPadding(2,3,2,5);row.addView(status);statusViews.put(s.index,status);
        String sch=scheduleSummary(s.index);if(!sch.isEmpty()){TextView sv=new TextView(this);sv.setText(sch);sv.setTextSize(11);row.addView(sv);}
        LinearLayout buttons=new LinearLayout(this);buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button start=new Button(this);start.setText("▶ Запись");Button stop=new Button(this);stop.setText("■ Стоп");
        buttons.addView(start,new LinearLayout.LayoutParams(0,-2,1));buttons.addView(stop,new LinearLayout.LayoutParams(0,-2,1));row.addView(buttons);
        stationContainer.addView(row);
        start.setOnClickListener(v->sendStation(RadioService.ACTION_START_STATION,s));
        stop.setOnClickListener(v->sendStation(RadioService.ACTION_STOP_STATION,s));
        more.setOnClickListener(v->{PopupMenu pm=new PopupMenu(this,more);pm.getMenu().add("Настройки радио");pm.getMenu().add("Планировщик");pm.getMenu().add("Удалить");pm.setOnMenuItemClickListener(mi->{String x=mi.getTitle().toString();if(x.startsWith("Настройки"))stationDialog(s.index);else if(x.startsWith("Планировщик")){Intent pi=new Intent(this,PlannerActivity.class);pi.putExtra("station_id",s.index);startActivity(pi);}else deleteConfirm(s.index);return true;});pm.show();});
    }

    private String scheduleSummary(int i){
        ArrayList<ScheduleStore.Item> a=ScheduleStore.load(prefs,i);int active=0;for(ScheduleStore.Item x:a)if(x.enabled)active++;return active==0?"":"Планировщиков: "+active;
    }

    private EditText field(LinearLayout box,String hint,String value,int type){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setSingleLine(true);e.setInputType(type);box.addView(e,new LinearLayout.LayoutParams(-1,-2));return e;}
    private String defaultStationName(int index){return urlName("http://radio-"+(index+1)+"/");}
    private String urlName(String u){try{URI x=new URI(u);String h=x.getHost();if(h!=null&&!h.isEmpty()){if(h.startsWith("www."))h=h.substring(4);return h;}String p=x.getPath();if(p!=null&&!p.isEmpty())return p.substring(p.lastIndexOf('/')+1); }catch(Exception ignored){}return "Радио";}

    private void stationDialog(int index){
        boolean edit=index>=0;ScrollView scroll=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(28,0,28,0);scroll.addView(box);
        String oldUrl=edit?prefs.getString("station_url_"+index,""):"";
        EditText url=field(box,"URL потока",oldUrl,InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        EditText name=field(box,"Название (можно оставить пустым для авто)",edit?prefs.getString("station_name_"+index,""):"",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        CheckBox auto=new CheckBox(this);auto.setText("Автоматически брать название из ссылки/icy-name");auto.setChecked(edit?prefs.getBoolean("auto_name_"+index,true):true);box.addView(auto);
        EditText ring=field(box,"Кольцевой буфер, секунд",edit?prefs.getString("station_ring_seconds_"+index,"8.0"):"8.0",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText overlap=field(box,"Overlap, секунд",edit?prefs.getString("station_overlap_seconds_"+index,"1.0"):"1.0",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText post=field(box,"Post-roll при смене трека, секунд",edit?prefs.getString("station_postroll_seconds_"+index,"7.0"):"7.0",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText bitrate=field(box,"Битрейт, кбит/с",edit?prefs.getString("station_bitrate_kbps_"+index,"192"):"192",InputType.TYPE_CLASS_NUMBER);
        EditText target=field(box,"Метаданные: слова через запятую (необязательно)",edit?prefs.getString("station_meta_target_"+index,""):"",InputType.TYPE_CLASS_TEXT);
        Spinner metaMode=new Spinner(this); String[] modes={"Совпадение: любое слово","Совпадение: все слова","Совпадение: точное название"}; ArrayAdapter<String> ma=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,modes);ma.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);metaMode.setAdapter(ma); String mm=edit?prefs.getString("station_meta_mode_"+index,"contains"):"contains";metaMode.setSelection("all".equals(mm)?1:("exact".equals(mm)?2:0));box.addView(metaMode);
        EditText group=field(box,"Группа станции (необязательно)",edit?prefs.getString("station_group_"+index,""):"",InputType.TYPE_CLASS_TEXT);
        CheckBox favorite=new CheckBox(this);favorite.setText("⭐ Избранная станция");favorite.setChecked(edit?prefs.getBoolean("station_favorite_"+index,false):false);box.addView(favorite);
        CheckBox dateFolders=new CheckBox(this);dateFolders.setText("Создавать отдельную папку по дате");dateFolders.setChecked(edit&&prefs.getBoolean("station_date_folders_"+index,false));box.addView(dateFolders);
        CheckBox skipDup=new CheckBox(this);skipDup.setText("Не записывать один и тот же трек повторно");skipDup.setChecked(edit?prefs.getBoolean("station_skip_duplicates_"+index,true):true);box.addView(skipDup);
        CheckBox skipFirst=new CheckBox(this);skipFirst.setText("Не записывать первый трек после подключения");skipFirst.setChecked(edit?prefs.getBoolean("station_skip_first_"+index,true):true);box.addView(skipFirst);
        TextView note=new TextView(this);note.setText("Если поле метаданных заполнено, запись начинается при совпадении StreamTitle и прекращается при уходе на другой трек с обычным post-roll.");note.setPadding(0,10,0,8);box.addView(note);
        new AlertDialog.Builder(this).setTitle(edit?"Настройки радио":"Добавить радио").setView(scroll).setPositiveButton("Сохранить",(d,w)->{
            String u=url.getText().toString().trim();String n=name.getText().toString().trim();if(u.isEmpty()){Toast.makeText(this,"Введите URL потока",Toast.LENGTH_LONG).show();return;}
            if(n.isEmpty()&& !auto.isChecked())n=urlName(u);if(n.isEmpty())n=urlName(u);
            try{double rv=Double.parseDouble(ring.getText().toString());double ov=Double.parseDouble(overlap.getText().toString());double pv=Double.parseDouble(post.getText().toString());int bv=Integer.parseInt(bitrate.getText().toString());if(rv<=0||ov<0||pv<0||bv<=0)throw new Exception();int i=edit?index:prefs.getInt("station_count",0);SharedPreferences.Editor e=prefs.edit();e.putString("station_name_"+i,n).putString("station_url_"+i,u).putBoolean("auto_name_"+i,auto.isChecked()).putString("station_ring_seconds_"+i,String.valueOf(rv)).putString("station_overlap_seconds_"+i,String.valueOf(ov)).putString("station_postroll_seconds_"+i,String.valueOf(pv)).putString("station_bitrate_kbps_"+i,String.valueOf(bv)).putString("station_meta_target_"+i,target.getText().toString().trim()).putString("station_meta_mode_"+i,metaMode.getSelectedItemPosition()==1?"all":(metaMode.getSelectedItemPosition()==2?"exact":"contains")).putString("station_group_"+i,group.getText().toString().trim()).putBoolean("station_favorite_"+i,favorite.isChecked()).putBoolean("station_date_folders_"+i,dateFolders.isChecked()).putBoolean("station_skip_duplicates_"+i,skipDup.isChecked()).putBoolean("station_skip_first_"+i,skipFirst.isChecked());if(!edit)e.putInt("station_count",i+1);e.apply();refreshStations();}catch(Exception ex){Toast.makeText(this,"Проверьте параметры станции",Toast.LENGTH_LONG).show();}
        }).setNegativeButton("Отмена",null).show();
    }

    private void deleteConfirm(int index){new AlertDialog.Builder(this).setTitle("Удалить радио?").setMessage(prefs.getString("station_name_"+index,urlName(prefs.getString("station_url_"+index,"")))).setPositiveButton("Удалить",(d,w)->deleteStation(index)).setNegativeButton("Отмена",null).show();}
    private void deleteStation(int index){
        sendStopIfRunning(index);int n=prefs.getInt("station_count",0);
        for(int i=0;i<n;i++){for(ScheduleStore.Item q:ScheduleStore.load(prefs,i)){Scheduler.cancel(this,i,q.id,ScheduleReceiver.ACTION_START);Scheduler.cancel(this,i,q.id,ScheduleReceiver.ACTION_STOP);}}
        SharedPreferences.Editor e=prefs.edit();
        for(int i=index;i<n-1;i++)copyStation(e,i,i+1);
        int last=Math.max(0,n-1);removeStationKeys(e,last);e.putInt("station_count",last).apply();
        for(int i=0;i<last;i++)for(ScheduleStore.Item q:ScheduleStore.load(prefs,i)){if(q.start>System.currentTimeMillis())Scheduler.schedule(this,i,q.id,q.start,ScheduleReceiver.ACTION_START);if(q.stop>System.currentTimeMillis())Scheduler.schedule(this,i,q.id,q.stop,ScheduleReceiver.ACTION_STOP);}
        statusTexts.remove(index);refreshStations();
    }
    private void copyStation(SharedPreferences.Editor e,int to,int from){String[] ks={"station_name_","station_url_","station_ring_seconds_","station_overlap_seconds_","station_postroll_seconds_","station_bitrate_kbps_","station_meta_target_","station_meta_mode_","station_group_"};for(String k:ks)e.putString(k+to,prefs.getString(k+from,""));e.putBoolean("station_skip_duplicates_"+to,prefs.getBoolean("station_skip_duplicates_"+from,true));e.putBoolean("station_skip_first_"+to,prefs.getBoolean("station_skip_first_"+from,true));e.putBoolean("station_favorite_"+to,prefs.getBoolean("station_favorite_"+from,false));e.putBoolean("station_date_folders_"+to,prefs.getBoolean("station_date_folders_"+from,false));e.putStringSet("recorded_titles_"+to,new HashSet<>(prefs.getStringSet("recorded_titles_"+from,Collections.emptySet())));e.putBoolean("auto_name_"+to,prefs.getBoolean("auto_name_"+from,true));e.putString("schedules_"+to,prefs.getString("schedules_"+from,""));}
    private void removeStationKeys(SharedPreferences.Editor e,int i){for(String k:new String[]{"station_name_","station_url_","station_ring_seconds_","station_overlap_seconds_","station_postroll_seconds_","station_bitrate_kbps_","station_meta_target_","station_meta_mode_","station_group_"})e.remove(k+i);e.remove("station_skip_duplicates_"+i);e.remove("station_skip_first_"+i);e.remove("station_favorite_"+i);e.remove("station_date_folders_"+i);e.remove("recorded_titles_"+i);e.remove("auto_name_"+i);e.remove("schedules_"+i);}
    private void sendStopIfRunning(int id){Intent i=new Intent(this,RadioService.class);i.setAction(RadioService.ACTION_STOP_STATION);i.putExtra("station_id",id);startService(i);for(ScheduleStore.Item q:ScheduleStore.load(prefs,id)){Scheduler.cancel(this,id,q.id,ScheduleReceiver.ACTION_START);Scheduler.cancel(this,id,q.id,ScheduleReceiver.ACTION_STOP);}}

    private void sendStation(String action,Station s){Intent i=new Intent(this,RadioService.class);i.setAction(action);i.putExtra("station_id",s.index).putExtra("station_name",s.name).putExtra("station_url",s.url);if(Build.VERSION.SDK_INT>=26){if(RadioService.ACTION_START_STATION.equals(action))startForegroundService(i);else startService(i);}else startService(i);}
    private void sendSimple(String action){Intent i=new Intent(this,RadioService.class);i.setAction(action);if(Build.VERSION.SDK_INT>=26)startService(i);else startService(i);}
    private static class Station{int index;String name,url;Station(int i,String n,String u){index=i;name=n;url=u;}}
}
