package com.example.radiorecorder;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.app.AlertDialog;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String PREFS = "radio_prefs";
    private SharedPreferences prefs;
    private LinearLayout stationContainer;
    private TextView emptyText;
    private final java.util.Map<Integer, TextView> statusViews = new java.util.HashMap<>();
    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override public void onReceive(android.content.Context c, Intent i) {
            int id=i.getIntExtra("station_id",-1);
            TextView v=statusViews.get(id);
            if(v!=null){ String st=i.getStringExtra("status"); String tr=i.getStringExtra("track"); v.setText((st==null?"":st)+(tr==null||tr.isEmpty()?"":"\n"+tr)); }
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24);

        TextView title = new TextView(this);
        title.setText("Radio Recorder"); title.setTextSize(24); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL);
        Button add = new Button(this); add.setText("+ Добавить радио");
        Button settings = new Button(this); settings.setText("⚙ Настройки");
        top.addView(add, new LinearLayout.LayoutParams(0,-2,1));
        top.addView(settings, new LinearLayout.LayoutParams(0,-2,1));
        root.addView(top);

        LinearLayout all = new LinearLayout(this); all.setOrientation(LinearLayout.HORIZONTAL);
        Button startAll = new Button(this); startAll.setText("▶ Запустить все");
        Button stopAll = new Button(this); stopAll.setText("■ Остановить все");
        all.addView(startAll, new LinearLayout.LayoutParams(0,-2,1));
        all.addView(stopAll, new LinearLayout.LayoutParams(0,-2,1));
        root.addView(all);

        ScrollView scroll = new ScrollView(this);
        stationContainer = new LinearLayout(this); stationContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(stationContainer); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        emptyText = new TextView(this); emptyText.setText("Радиостанций пока нет.\nНажмите «Добавить радио»."); emptyText.setTextSize(17); emptyText.setPadding(8,32,8,32);
        stationContainer.addView(emptyText);
        setContentView(root);

        add.setOnClickListener(v -> stationDialog(-1));
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        startAll.setOnClickListener(v -> { for (Station s: stations()) sendStation(RadioService.ACTION_START_STATION,s); });
        stopAll.setOnClickListener(v -> sendSimple(RadioService.ACTION_STOP_ALL));
        refreshStations();
    }

    @Override protected void onResume(){ super.onResume(); if(stationContainer!=null) refreshStations(); }
    @Override protected void onStart(){ super.onStart(); registerReceiver(statusReceiver,new IntentFilter(RadioService.ACTION_STATUS)); }
    @Override protected void onStop(){ try{unregisterReceiver(statusReceiver);}catch(Exception ignored){} super.onStop(); }

    private List<Station> stations(){
        int n=prefs.getInt("station_count",0); List<Station> list=new ArrayList<>();
        for(int i=0;i<n;i++) { String name=prefs.getString("station_name_"+i,""); String url=prefs.getString("station_url_"+i,""); if(!name.isEmpty()&&!url.isEmpty()) list.add(new Station(i,name,url)); }
        return list;
    }

    private void refreshStations(){
        stationContainer.removeAllViews(); statusViews.clear(); List<Station> list=stations();
        if(list.isEmpty()){ stationContainer.addView(emptyText); return; }
        for(Station s:list) addStationView(s);
    }

    private void addStationView(Station s){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(16,12,16,12);
        TextView name=new TextView(this); name.setText(s.name); name.setTextSize(20); card.addView(name);
        TextView url=new TextView(this); url.setText(s.url); url.setTextSize(12); card.addView(url);
        TextView status=new TextView(this); status.setText("Остановлено"); status.setTextSize(14); status.setPadding(0,8,0,8); card.addView(status); statusViews.put(s.index,status);
        LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button start=new Button(this); start.setText("▶"); Button stop=new Button(this); stop.setText("■"); Button edit=new Button(this); edit.setText("✎"); Button del=new Button(this); del.setText("🗑");
        buttons.addView(start,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(stop,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(edit,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(del,new LinearLayout.LayoutParams(0,-2,1));
        card.addView(buttons); stationContainer.addView(card);
        start.setOnClickListener(v->sendStation(RadioService.ACTION_START_STATION,s));
        stop.setOnClickListener(v->sendStation(RadioService.ACTION_STOP_STATION,s));
        edit.setOnClickListener(v->stationDialog(s.index));
        del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Удалить радио?").setMessage(s.name).setPositiveButton("Удалить",(d,w)->deleteStation(s.index)).setNegativeButton("Отмена",null).show());
    }

    private void stationDialog(int index){
        boolean edit=index>=0; EditText name=new EditText(this); name.setHint("Название"); EditText url=new EditText(this); url.setHint("URL потока"); url.setSingleLine(true);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(40,0,40,0); box.addView(name); box.addView(url);
        if(edit){name.setText(prefs.getString("station_name_"+index,"")); url.setText(prefs.getString("station_url_"+index,""));}
        new AlertDialog.Builder(this).setTitle(edit?"Изменить радио":"Добавить радио").setView(box).setPositiveButton("Сохранить",(d,w)->{String n=name.getText().toString().trim();String u=url.getText().toString().trim();if(n.isEmpty()||u.isEmpty())return; if(edit){prefs.edit().putString("station_name_"+index,n).putString("station_url_"+index,u).apply();}else{int c=prefs.getInt("station_count",0);prefs.edit().putString("station_name_"+c,n).putString("station_url_"+c,u).putInt("station_count",c+1).apply();}refreshStations();}).setNegativeButton("Отмена",null).show();
    }

    private void deleteStation(int index){
        int n=prefs.getInt("station_count",0); SharedPreferences.Editor e=prefs.edit();
        for(int i=index;i<n-1;i++){e.putString("station_name_"+i,prefs.getString("station_name_"+(i+1),""));e.putString("station_url_"+i,prefs.getString("station_url_"+(i+1),""));}
        e.remove("station_name_"+(n-1)).remove("station_url_"+(n-1)).putInt("station_count",Math.max(0,n-1)).apply(); refreshStations();
    }

    private void sendStation(String action, Station s){Intent i=new Intent(this,RadioService.class);i.setAction(action);i.putExtra("station_id",s.index);i.putExtra("station_name",s.name);i.putExtra("station_url",s.url); if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}
    private void sendSimple(String action){Intent i=new Intent(this,RadioService.class);i.setAction(action);if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}
    private static class Station{int index;String name,url;Station(int i,String n,String u){index=i;name=n;url=u;}}
}
