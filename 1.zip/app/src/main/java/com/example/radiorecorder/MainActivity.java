package com.example.radiorecorder;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 32, 32, 32);

        status = new TextView(this);
        status.setText("Готово\nБуфер 8 сек / overlap 1 сек / post-roll 7 сек");
        status.setTextSize(18);

        Button start = new Button(this);
        start.setText("Запустить запись");

        Button stop = new Button(this);
        stop.setText("Остановить");

        layout.addView(status);
        layout.addView(start);
        layout.addView(stop);
        setContentView(layout);

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }

        start.setOnClickListener(v -> {
            Intent i = new Intent(this, RadioService.class);
            i.setAction(RadioService.ACTION_START);
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                startForegroundService(i);
            } else {
                startService(i);
            }
            status.setText("Запись запущена\nБуфер 8 сек / overlap 1 сек / post-roll 7 сек");
        });

        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, RadioService.class);
            i.setAction(RadioService.ACTION_STOP);
            startService(i);
            status.setText("Запись остановлена");
        });
    }
}
