package com.example.radiorecorder;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String PREFS = "radio_settings";
    private static final String STATIONS = "stations";
    private LinearLayout stationsBox;
    private TextView info;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        ensureDefaultStation();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);

        TextView title = new TextView(this);
        title.setText("Radio Recorder");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        info = new TextView(this);
        info.setTextSize(14);
        info.setPadding(0, 12, 0, 12);
        root.addView(info);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);

        Button add = new Button(this);
        add.setText("＋ Радио");
        Button settings = new Button(this);
        settings.setText("Настройки");

        top.addView(add, new LinearLayout.LayoutParams(0, -2, 1));
        top.addView(settings, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(top);

        Button startAll = new Button(this);
        startAll.setText("▶ Запустить все");
        Button stopAll = new Button(this);
        stopAll.setText("■ Остановить все");
        root.addView(startAll);
        root.addView(stopAll);

        ScrollView scroll = new ScrollView(this);
        stationsBox = new LinearLayout(this);
        stationsBox.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(stationsBox);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }

        add.setOnClickListener(v -> showStationDialog(null));
        settings.setOnClickListener(v -> showSettingsDialog());
        startAll.setOnClickListener(v -> sendService(RadioService.ACTION_START_ALL, null));
        stopAll.setOnClickListener(v -> sendService(RadioService.ACTION_STOP_ALL, null));

        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void ensureDefaultStation() {
        if (!prefs.contains(STATIONS)) {
            prefs.edit().putString(STATIONS,
                    "1|Radio Pro|https%3A%2F%2Fplay.pro").apply();
        }
        if (!prefs.contains("ring")) prefs.edit().putString("ring", "8").apply();
        if (!prefs.contains("overlap")) prefs.edit().putString("overlap", "1").apply();
        if (!prefs.contains("postroll")) prefs.edit().putString("postroll", "7").apply();
        if (!prefs.contains("bitrate")) prefs.edit().putString("bitrate", "192").apply();
    }

    private List<Station> getStations() {
        ArrayList<Station> list = new ArrayList<>();
        String raw = prefs.getString(STATIONS, "");
        if (raw == null || raw.isEmpty()) return list;

        for (String line : raw.split("\n")) {
            if (line.trim().isEmpty()) continue;
            String[] p = line.split("\\|", 3);
            if (p.length == 3) {
                try {
                    list.add(new Station(p[0], p[1], java.net.URLDecoder.decode(p[2], "UTF-8")));
                } catch (Exception ignored) {}
            }
        }
        return list;
    }

    private void saveStations(List<Station> list) {
        StringBuilder sb = new StringBuilder();
        for (Station s : list) {
            if (sb.length() > 0) sb.append('\n');
            try {
                sb.append(s.id).append('|').append(s.name.replace("|", " "))
                        .append('|').append(URLEncoder.encode(s.url, "UTF-8"));
            } catch (Exception ignored) {}
        }
        prefs.edit().putString(STATIONS, sb.toString()).apply();
    }

    private void refresh() {
        stationsBox.removeAllViews();

        int ring = intPref("ring", 8);
        int overlap = intPref("overlap", 1);
        int post = intPref("postroll", 7);
        int bitrate = intPref("bitrate", 192);
        info.setText("Буфер " + ring + " сек  •  overlap " + overlap +
                " сек  •  post-roll " + post + " сек  •  " + bitrate + " кбит/с");

        for (Station s : getStations()) addStationView(s);
    }

    private void addStationView(Station s) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(16, 14, 16, 14);

        TextView name = new TextView(this);
        name.setText(s.name);
        name.setTextSize(19);

        TextView url = new TextView(this);
        url.setText(s.url);
        url.setTextSize(12);

        LinearLayout buttons = new LinearLayout(this);
        Button start = new Button(this);
        start.setText("▶");
        Button stop = new Button(this);
        stop.setText("■");
        Button edit = new Button(this);
        edit.setText("Изменить");
        Button del = new Button(this);
        del.setText("Удалить");

        buttons.addView(start, new LinearLayout.LayoutParams(0, -2, 0.7f));
        buttons.addView(stop, new LinearLayout.LayoutParams(0, -2, 0.7f));
        buttons.addView(edit, new LinearLayout.LayoutParams(0, -2, 1.2f));
        buttons.addView(del, new LinearLayout.LayoutParams(0, -2, 1.0f));

        card.addView(name);
        card.addView(url);
        card.addView(buttons);
        stationsBox.addView(card, new LinearLayout.LayoutParams(-1, -2));

        start.setOnClickListener(v -> sendService(RadioService.ACTION_START_STATION, s.id));
        stop.setOnClickListener(v -> {
            Toast.makeText(this, "Станция завершит post-roll перед остановкой",
                    Toast.LENGTH_SHORT).show();
            sendService(RadioService.ACTION_STOP_STATION, s.id);
        });
        edit.setOnClickListener(v -> showStationDialog(s));
        del.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Удалить радио?")
                    .setMessage(s.name)
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Удалить", (d, w) -> {
                        sendService(RadioService.ACTION_STOP_STATION, s.id);
                        List<Station> list = getStations();
                        for (int i = list.size() - 1; i >= 0; i--)
                            if (list.get(i).id.equals(s.id)) list.remove(i);
                        saveStations(list);
                        refresh();
                    }).show();
        });
    }

    private void showStationDialog(Station edit) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32, 8, 32, 0);

        EditText name = new EditText(this);
        name.setHint("Название радио");
        name.setSingleLine(true);

        EditText url = new EditText(this);
        url.setHint("URL потока, например https://...");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);

        if (edit != null) {
            name.setText(edit.name);
            url.setText(edit.url);
        }

        box.addView(name);
        box.addView(url);

        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle(edit == null ? "Добавить радио" : "Изменить радио")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", null)
                .create();

        dlg.setOnShowListener(x -> dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            String u = url.getText().toString().trim();
            if (n.isEmpty() || u.isEmpty()) {
                Toast.makeText(this, "Заполните название и URL", Toast.LENGTH_SHORT).show();
                return;
            }

            List<Station> list = getStations();
            if (edit == null) {
                String id = String.valueOf(System.currentTimeMillis());
                list.add(new Station(id, n, u));
            } else {
                for (Station s : list) {
                    if (s.id.equals(edit.id)) {
                        s.name = n;
                        s.url = u;
                        break;
                    }
                }
                sendService(RadioService.ACTION_RELOAD_STATIONS, null);
            }
            saveStations(list);
            refresh();
            dlg.dismiss();
        }));
        dlg.show();
    }

    private void showSettingsDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32, 8, 32, 0);

        EditText ring = numberEdit("Буфер, секунд", intPref("ring", 8));
        EditText overlap = numberEdit("Overlap, секунд", intPref("overlap", 1));
        EditText post = numberEdit("Post-roll, секунд", intPref("postroll", 7));
        EditText bitrate = numberEdit("Битрейт, кбит/с", intPref("bitrate", 192));

        box.addView(ring);
        box.addView(overlap);
        box.addView(post);
        box.addView(bitrate);

        new AlertDialog.Builder(this)
                .setTitle("Настройки записи")
                .setView(box)
                .setNegativeButton("Отмена", null)
                .setPositiveButton("Сохранить", (d, w) -> {
                    prefs.edit()
                            .putString("ring", cleanNumber(ring.getText().toString(), "8"))
                            .putString("overlap", cleanNumber(overlap.getText().toString(), "1"))
                            .putString("postroll", cleanNumber(post.getText().toString(), "7"))
                            .putString("bitrate", cleanNumber(bitrate.getText().toString(), "192"))
                            .apply();
                    refresh();
                    Toast.makeText(this, "Настройки сохранены. Новые значения применятся к новым записям.",
                            Toast.LENGTH_LONG).show();
                }).show();
    }

    private EditText numberEdit(String hint, int value) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(String.valueOf(value));
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        return e;
    }

    private String cleanNumber(String s, String def) {
        try {
            double x = Double.parseDouble(s.trim());
            if (x <= 0 || x > 3600) return def;
            if (x == (int)x) return String.valueOf((int)x);
            return String.valueOf(x);
        } catch (Exception e) {
            return def;
        }
    }

    private int intPref(String key, int def) {
        try { return Integer.parseInt(prefs.getString(key, String.valueOf(def))); }
        catch (Exception e) { return def; }
    }

    private void sendService(String action, String stationId) {
        Intent i = new Intent(this, RadioService.class);
        i.setAction(action);
        if (stationId != null) i.putExtra(RadioService.EXTRA_STATION_ID, stationId);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private static class Station {
        String id, name, url;
        Station(String id, String name, String url) {
            this.id = id; this.name = name; this.url = url;
        }
    }
}
