package com.example.radiorecorder;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import java.util.*;

public class RecordingsActivity extends Activity {
    LinearLayout list; EditText search; Spinner stationFilter,artistFilter; String[] stationNames,artistNames;
    TextView nowTitle,nowSub;
    @Override public void onCreate(Bundle b){super.onCreate(b);build();load();}
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,float size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.WHITE);return t;}
    GradientDrawable bg(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(8),dp(12),dp(8));root.setBackgroundColor(Color.rgb(15,15,15));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        TextView h=text("DEVIL",23);h.setTypeface(null,1);top.addView(h,new LinearLayout.LayoutParams(0,dp(48),1));
        TextView lib=text("БИБЛИОТЕКА",11);lib.setTextColor(0xffaaaaaa);top.addView(lib);root.addView(top);
        LinearLayout player=new LinearLayout(this);player.setOrientation(LinearLayout.VERTICAL);player.setPadding(dp(14),dp(12),dp(14),dp(12));player.setBackground(bg(0xff202020,16));
        nowTitle=text("Ничего не играет",19);nowTitle.setTypeface(null,1);nowTitle.setGravity(Gravity.CENTER);player.addView(nowTitle);
        nowSub=text("Выберите MP3 ниже",12);nowSub.setTextColor(0xffaaaaaa);nowSub.setGravity(Gravity.CENTER);player.addView(nowSub);
        LinearLayout pc=new LinearLayout(this);pc.setGravity(Gravity.CENTER);Button prev=new Button(this);prev.setText("◀◀");Button p=new Button(this);p.setText("▶");Button next=new Button(this);next.setText("▶▶");pc.addView(prev,new LinearLayout.LayoutParams(0,dp(48),1));pc.addView(p,new LinearLayout.LayoutParams(0,dp(48),1));pc.addView(next,new LinearLayout.LayoutParams(0,dp(48),1));player.addView(pc);root.addView(player);
        search=new EditText(this);search.setHint("Поиск исполнителя или песни");search.setSingleLine(true);search.setTextColor(Color.WHITE);search.setHintTextColor(0xff777777);root.addView(search);
        stationFilter=new Spinner(this);loadStationNames();root.addView(stationFilter);artistFilter=new Spinner(this);loadArtistNames();root.addView(artistFilter);
        ScrollView sc=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        Button back=new Button(this);back.setText("‹ Назад");root.addView(back,new LinearLayout.LayoutParams(-1,dp(46)));setContentView(root);
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){load();}public void afterTextChanged(android.text.Editable e){}});
        stationFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,android.view.View v,int pos,long id){load();}});
        artistFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,android.view.View v,int pos,long id){load();}});
        back.setOnClickListener(v->finish());
    }
    void loadStationNames(){SharedPreferences p=getSharedPreferences("radio_prefs",MODE_PRIVATE);ArrayList<String>a=new ArrayList<>();a.add("Все станции");int n=p.getInt("station_count",0);for(int i=0;i<n;i++)a.add(p.getString("station_name_"+i,"Радио"));stationNames=a.toArray(new String[0]);ArrayAdapter<String>ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,stationNames);ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);stationFilter.setAdapter(ad);}
    void loadArtistNames(){ArrayList<String>a=new MetadataDbHelper(this).allArtists();a.add(0,"Все исполнители");artistNames=a.toArray(new String[0]);ArrayAdapter<String>ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,artistNames);ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);artistFilter.setAdapter(ad);}
    void load(){if(list==null)return;list.removeAllViews();String q=search==null?"":search.getText().toString().trim().toLowerCase(Locale.ROOT);String filter=stationFilter==null||stationFilter.getSelectedItemPosition()<=0?"":stationNames[stationFilter.getSelectedItemPosition()];String artist=artistFilter==null||artistFilter.getSelectedItemPosition()<=0?"":artistNames[artistFilter.getSelectedItemPosition()].toLowerCase(Locale.ROOT);Cursor c=null;try{
        String[] proj={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.DISPLAY_NAME,MediaStore.Audio.Media.RELATIVE_PATH,MediaStore.Audio.Media.DATE_ADDED};
        c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,proj,MediaStore.Audio.Media.RELATIVE_PATH+" LIKE ?",new String[]{"Music/Radio/%"},MediaStore.Audio.Media.DATE_ADDED+" DESC");
        if(c!=null){String currentGroup="";while(c.moveToNext()){
            final String n=c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME));if(!n.toLowerCase(Locale.ROOT).contains(q))continue;if(!artist.isEmpty()&&!n.toLowerCase(Locale.ROOT).contains(artist))continue;String path=c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH));String station=stationFromPath(path);if(!filter.isEmpty()&&!station.equals(filter))continue;
            if(!station.equals(currentGroup)){TextView g=text("📻  "+station,16);g.setTextColor(0xffdddddd);g.setPadding(dp(6),dp(16),dp(6),dp(5));list.addView(g);currentGroup=station;}
            final long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));final Uri u=Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,String.valueOf(id));
            LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(4),dp(4),dp(4));row.setBackground(bg(0xff1c1c1c,12));
            LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);TextView tn=text(n,15);tn.setMaxLines(2);TextView ts=text("MP3  •  "+station,11);ts.setTextColor(0xff888888);info.addView(tn);info.addView(ts);row.addView(info,new LinearLayout.LayoutParams(0,dp(58),1));
            Button play=new Button(this);play.setText("▶");row.addView(play,new LinearLayout.LayoutParams(dp(55),dp(55)));Button del=new Button(this);del.setText("×");row.addView(del,new LinearLayout.LayoutParams(dp(48),dp(55)));list.addView(row,new LinearLayout.LayoutParams(-1,dp(66)));
            play.setOnClickListener(v->{nowTitle.setText(n);nowSub.setText(station+"  •  MP3");Intent i=new Intent(this,PlayerActivity.class);i.putExtra("uri",u.toString());i.putExtra("title",n);startActivity(i);});
            row.setOnClickListener(v->{nowTitle.setText(n);nowSub.setText(station+"  •  MP3");Intent i=new Intent(this,PlayerActivity.class);i.putExtra("uri",u.toString());i.putExtra("title",n);startActivity(i);});
            del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Удалить запись?").setMessage(n).setPositiveButton("Удалить",(d,w)->{getContentResolver().delete(u,null,null);load();}).setNegativeButton("Отмена",null).show());
        }}
    }finally{if(c!=null)c.close();}}
    String stationFromPath(String path){if(path==null)return "Радио";String x=path;if(x.startsWith("Music/Radio/"))x=x.substring("Music/Radio/".length());int p=x.indexOf('/');return p>=0?x.substring(0,p):x.replace("/","");}
}
