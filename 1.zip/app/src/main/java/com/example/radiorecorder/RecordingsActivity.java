package com.example.radiorecorder;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

public class RecordingsActivity extends Activity {
    LinearLayout list; EditText search; Spinner stationFilter; String[] stationNames;
    @Override public void onCreate(Bundle b){super.onCreate(b);build();load();}
    void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(12,8,12,8);
        TextView h=new TextView(this);h.setText("🎵 Записи");h.setTextSize(22);h.setGravity(Gravity.CENTER);root.addView(h);
        search=new EditText(this);search.setHint("Поиск исполнителя или песни");search.setSingleLine(true);root.addView(search);
        stationFilter=new Spinner(this);loadStationNames();root.addView(stationFilter);
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){load();}public void afterTextChanged(android.text.Editable e){}});
        stationFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,android.view.View v,int pos,long id){load();}});
        ScrollView sc=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        Button back=new Button(this);back.setText("Назад");back.setOnClickListener(v->finish());root.addView(back);setContentView(root);
    }
    void loadStationNames(){
        SharedPreferences p=getSharedPreferences("radio_prefs",MODE_PRIVATE);ArrayList<String> a=new ArrayList<>();a.add("Все станции");int n=p.getInt("station_count",0);for(int i=0;i<n;i++)a.add(p.getString("station_name_"+i,"Радио"));stationNames=a.toArray(new String[0]);
        ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,stationNames);ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);stationFilter.setAdapter(ad);
    }
    void load(){if(list==null)return;list.removeAllViews();String q=search==null?"":search.getText().toString().trim().toLowerCase(Locale.ROOT);String filter=stationFilter==null||stationFilter.getSelectedItemPosition()<=0?"":stationNames[stationFilter.getSelectedItemPosition()];Cursor c=null;try{
        String[] proj={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.DISPLAY_NAME,MediaStore.Audio.Media.RELATIVE_PATH,MediaStore.Audio.Media.DATE_ADDED};
        c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,proj,MediaStore.Audio.Media.RELATIVE_PATH+" LIKE ?",new String[]{"Music/Radio/%"},MediaStore.Audio.Media.DATE_ADDED+" DESC");
        if(c!=null){String currentGroup="";while(c.moveToNext()){
            String n=c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME));if(!n.toLowerCase(Locale.ROOT).contains(q))continue;String path=c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH));String station=stationFromPath(path);if(!filter.isEmpty()&&!station.equals(filter))continue;
            if(!station.equals(currentGroup)){TextView g=new TextView(this);g.setText("📻 "+station);g.setTextSize(17);g.setPadding(6,14,6,4);list.addView(g);currentGroup=station;}
            long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));Uri u=Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,String.valueOf(id));
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);Button play=new Button(this);play.setAllCaps(false);play.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);play.setText(n);row.addView(play,new LinearLayout.LayoutParams(0,-2,1));Button del=new Button(this);del.setText("×");row.addView(del,new LinearLayout.LayoutParams(52,-2));
            play.setOnClickListener(v->{try{Intent i=new Intent(Intent.ACTION_VIEW,u);i.setDataAndType(u,"audio/mpeg");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(Exception e){Toast.makeText(this,"Нет проигрывателя MP3",Toast.LENGTH_SHORT).show();}});
            del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Удалить запись?").setMessage(n).setPositiveButton("Удалить",(d,w)->{getContentResolver().delete(u,null,null);load();}).setNegativeButton("Отмена",null).show());
            list.addView(row);
        }}
    }finally{if(c!=null)c.close();}}
    String stationFromPath(String path){if(path==null)return "Радио";String x=path; if(x.startsWith("Music/Radio/"))x=x.substring("Music/Radio/".length());int p=x.indexOf('/');return p>=0?x.substring(0,p):x.replace("/","");}
}
