package com.example.radiorecorder;

import android.app.Activity;
import android.content.*;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class PlayerActivity extends Activity {
    private MediaPlayer player;
    private SeekBar seek;
    private TextView title, time;
    private Button play;
    private Handler handler=new Handler(Looper.getMainLooper());
    private Uri uri;
    private boolean prepared=false;

    @Override public void onCreate(Bundle b){super.onCreate(b); build();
        String s=getIntent().getStringExtra("uri"); String n=getIntent().getStringExtra("title");
        if(s!=null){uri=Uri.parse(s); title.setText(n==null?"Запись":n); prepare();}
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView tv(String s,float z){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(0xffeeeeee);return t;}
    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(18),dp(18),dp(12));root.setBackgroundColor(0xff111111);
        TextView brand=tv("DEVIL  •  PLAYER",13);brand.setTextColor(0xffaaaaaa);root.addView(brand);
        Space sp=new Space(this);root.addView(sp,new LinearLayout.LayoutParams(1,dp(28)));
        TextView note=tv("♫",56);note.setGravity(Gravity.CENTER);note.setTextColor(0xffdddddd);root.addView(note,new LinearLayout.LayoutParams(-1,dp(90)));
        title=tv("Выберите запись",21);title.setGravity(Gravity.CENTER);title.setMaxLines(2);root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        time=tv("00:00 / 00:00",12);time.setGravity(Gravity.CENTER);time.setTextColor(0xffaaaaaa);root.addView(time,new LinearLayout.LayoutParams(-1,dp(30)));
        seek=new SeekBar(this);root.addView(seek,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER); 
        Button back=new Button(this);back.setText("↶ 10"); play=new Button(this);play.setText("▶"); Button fwd=new Button(this);fwd.setText("10 ↷");
        controls.addView(back,new LinearLayout.LayoutParams(0,dp(54),1));controls.addView(play,new LinearLayout.LayoutParams(0,dp(54),1));controls.addView(fwd,new LinearLayout.LayoutParams(0,dp(54),1));root.addView(controls);
        Button close=new Button(this);close.setText("Закрыть");root.addView(close,new LinearLayout.LayoutParams(-1,dp(48)));
        setContentView(root);
        play.setOnClickListener(v->{if(player==null||!prepared)return;if(player.isPlaying()){player.pause();play.setText("▶");}else{player.start();play.setText("Ⅱ");}});
        back.setOnClickListener(v->seekBy(-10000)); fwd.setOnClickListener(v->seekBy(10000)); close.setOnClickListener(v->finish());
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean from){if(from&&player!=null&&prepared)player.seekTo(p);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
    }
    private void prepare(){
        try{if(player!=null)player.release(); player=new MediaPlayer();player.setDataSource(this,uri);player.setOnPreparedListener(mp->{prepared=true;seek.setMax(mp.getDuration());update();});player.setOnCompletionListener(mp->{play.setText("▶");seek.setProgress(0);});player.setOnErrorListener((mp,w,e)->{Toast.makeText(this,"Не удалось воспроизвести запись",Toast.LENGTH_LONG).show();return true;});player.prepareAsync();}
        catch(Exception e){Toast.makeText(this,"Ошибка открытия файла: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void seekBy(int ms){if(player!=null&&prepared)player.seekTo(Math.max(0,Math.min(player.getDuration(),player.getCurrentPosition()+ms)));}
    private void update(){if(player!=null&&prepared){int p=player.getCurrentPosition(),d=player.getDuration();seek.setProgress(p);time.setText(fmt(p)+" / "+fmt(d));}handler.postDelayed(this::update,500);}
    private String fmt(int ms){int sec=Math.max(0,ms/1000);return String.format(Locale.getDefault(),"%02d:%02d",sec/60,sec%60);}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);if(player!=null){player.release();player=null;}super.onDestroy();}
}
