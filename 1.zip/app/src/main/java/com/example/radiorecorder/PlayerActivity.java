package com.example.radiorecorder;

import android.app.Activity;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

/** Встроенный простой плеер/плейлист. Не вызывает системный Android-плеер. */
public class PlayerActivity extends Activity {
    private final ArrayList<Item> playlist=new ArrayList<>();
    private MediaPlayer player;
    private int pos=-1;
    private TextView title,time;
    private SeekBar seek;
    private Button play;
    private boolean prepared=false;

    static class Item { long id; String name; Uri uri; Item(long i,String n){id=i;name=n;uri=Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,String.valueOf(i));} }

    @Override protected void onCreate(Bundle b){super.onCreate(b); build(); loadPlaylist(getIntent().getLongExtra("id",-1));}

    private void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(14,12,14,12);
        TextView h=new TextView(this); h.setText("🎵 Музыка"); h.setTextSize(22); h.setGravity(Gravity.CENTER); root.addView(h);
        title=new TextView(this); title.setText("Загрузка..."); title.setTextSize(18); title.setGravity(Gravity.CENTER); title.setPadding(4,18,4,12); root.addView(title);
        seek=new SeekBar(this); root.addView(seek,new LinearLayout.LayoutParams(-1,-2));
        time=new TextView(this); time.setText("00:00 / 00:00"); time.setGravity(Gravity.CENTER); root.addView(time);
        LinearLayout controls=new LinearLayout(this); controls.setGravity(Gravity.CENTER);
        Button prev=new Button(this);prev.setText("⏮"); play=new Button(this);play.setText("▶"); Button next=new Button(this);next.setText("⏭");
        controls.addView(prev);controls.addView(play);controls.addView(next);root.addView(controls);
        TextView qh=new TextView(this);qh.setText("Плейлист");qh.setTextSize(16);qh.setPadding(4,14,4,6);root.addView(qh);
        ScrollView sc=new ScrollView(this);LinearLayout queue=new LinearLayout(this);queue.setOrientation(LinearLayout.VERTICAL);sc.addView(queue);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        Button close=new Button(this);close.setText("Закрыть");root.addView(close);
        prev.setOnClickListener(v->previous()); next.setOnClickListener(v->next()); play.setOnClickListener(v->{if(player==null)return;if(player.isPlaying()){player.pause();play.setText("▶");}else{player.start();play.setText("⏸");}}); close.setOnClickListener(v->finish());
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){if(f&&player!=null&&prepared)player.seekTo(p);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
        setContentView(root); queue.setTag("queue");
    }

    private void loadPlaylist(long selected){
        CursorWrap cw=new CursorWrap(); cw.load(); playlist.addAll(cw.items);
        if(playlist.isEmpty()){title.setText("Нет записей");return;}
        pos=0; for(int i=0;i<playlist.size();i++)if(playlist.get(i).id==selected){pos=i;break;}
        View qv=findQueue(); if(qv instanceof LinearLayout){LinearLayout q=(LinearLayout)qv; for(int i=0;i<playlist.size();i++){final int x=i;Button b=new Button(this);b.setAllCaps(false);b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);b.setText((i+1)+". "+playlist.get(i).name);b.setOnClickListener(v->{pos=x;openCurrent();});q.addView(b,new LinearLayout.LayoutParams(-1,-2));}}
        openCurrent();
    }
    private View findQueue(){return (View)((ViewGroup)findViewById(android.R.id.content)).getChildAt(0).findViewWithTag("queue");}

    private void openCurrent(){if(pos<0||pos>=playlist.size())return;release();Item it=playlist.get(pos);title.setText(it.name); player=new MediaPlayer();player.setAudioStreamType(AudioManager.STREAM_MUSIC);player.setOnPreparedListener(mp->{prepared=true;seek.setMax(mp.getDuration());time.setText(fmt(0)+" / "+fmt(mp.getDuration()));mp.start();play.setText("⏸");});player.setOnCompletionListener(mp->{play.setText("▶");next();});player.setOnErrorListener((mp,what,extra)->{Toast.makeText(this,"Не удалось воспроизвести запись",Toast.LENGTH_SHORT).show();return true;});try{player.setDataSource(this,it.uri);player.prepareAsync();}catch(Exception e){Toast.makeText(this,"Ошибка открытия файла",Toast.LENGTH_SHORT).show();}}
    private void release(){prepared=false;if(player!=null){try{player.stop();}catch(Exception ignored){}player.release();player=null;}play.setText("▶");}
    private void next(){if(playlist.isEmpty())return;pos=(pos+1)%playlist.size();openCurrent();}
    private void previous(){if(playlist.isEmpty())return; if(player!=null&&prepared&&player.getCurrentPosition()>3000){player.seekTo(0);return;}pos=(pos-1+playlist.size())%playlist.size();openCurrent();}
    private String fmt(int ms){int s=Math.max(0,ms/1000),m=s/60;s%=60;return String.format(Locale.US,"%02d:%02d",m,s);}
    @Override protected void onDestroy(){release();super.onDestroy();}
    @Override public void onResume(){super.onResume(); final Handler h=new Handler();h.post(new Runnable(){public void run(){if(player!=null&&prepared){int p=player.getCurrentPosition();seek.setProgress(p);time.setText(fmt(p)+" / "+fmt(player.getDuration()));}if(!isFinishing())h.postDelayed(this,500);}});}

    class CursorWrap {ArrayList<Item> items=new ArrayList<>();void load(){android.database.Cursor c=null;try{String[] pr={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.DISPLAY_NAME};c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,pr,MediaStore.Audio.Media.RELATIVE_PATH+" LIKE ?",new String[]{"Music/Radio/%"},MediaStore.Audio.Media.DATE_ADDED+" ASC");if(c!=null)while(c.moveToNext())items.add(new Item(c.getLong(0),c.getString(1)));}finally{if(c!=null)c.close();}}}
}
