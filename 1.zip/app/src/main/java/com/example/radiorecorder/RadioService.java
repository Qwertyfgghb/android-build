package com.example.radiorecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.MediaStore;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class RadioService extends Service {
    public static final String ACTION_START_STATION = "START_STATION";
    public static final String ACTION_STOP_STATION = "STOP_STATION";
    public static final String ACTION_START_ALL = "START_ALL";
    public static final String ACTION_STOP_ALL = "STOP_ALL";
    public static final String ACTION_RELOAD_STATIONS = "RELOAD_STATIONS";
    public static final String EXTRA_STATION_ID = "station_id";

    private static final String PREFS = "radio_settings";
    private static final String CHANNEL_ID = "radio_recording";

    private final Map<String, StationRecorder> recorders = new LinkedHashMap<>();
    private final Object lock = new Object();
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();

        if (ACTION_START_STATION.equals(action)) {
            String id = intent.getStringExtra(EXTRA_STATION_ID);
            if (id != null) startStation(id);
        } else if (ACTION_STOP_STATION.equals(action)) {
            String id = intent.getStringExtra(EXTRA_STATION_ID);
            if (id != null) stopStation(id);
        } else if (ACTION_START_ALL.equals(action)) {
            startAll();
        } else if (ACTION_STOP_ALL.equals(action)) {
            stopAll();
        } else if (ACTION_RELOAD_STATIONS.equals(action)) {
            // Новые URL применяются после следующего запуска станции.
        }
        return START_STICKY;
    }

    private void startAll() {
        ArrayList<Station> stations = loadStations();
        for (Station s : stations) startStation(s.id);
    }

    private void startStation(String id) {
        Station s = findStation(id);
        if (s == null) return;

        synchronized (lock) {
            if (recorders.containsKey(id)) return;
            if (recorders.isEmpty()) {
                startForeground(1, notification("Запуск радиостанций…"));
                acquireWakeLock();
            }
            StationRecorder r = new StationRecorder(s);
            recorders.put(id, r);
            r.start();
        }
        updateSummary();
    }

    private void stopAll() {
        synchronized (lock) {
            for (StationRecorder r : recorders.values()) r.requestStop();
        }
        updateSummary();
    }

    private void stopStation(String id) {
        synchronized (lock) {
            StationRecorder r = recorders.get(id);
            if (r != null) r.requestStop();
        }
        updateSummary();
    }

    private void recorderFinished(String id) {
        synchronized (lock) {
            recorders.remove(id);
            if (recorders.isEmpty()) finishService();
        }
        updateSummary();
    }

    private void finishService() {
        releaseWakeLock();
        stopForeground(true);
        stopSelf();
    }

    private void acquireWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) return;
        PowerManager pm = (PowerManager)getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                    "RadioRecorder:Recording");
            wakeLock.acquire();
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
    }

    private Station findStation(String id) {
        for (Station s : loadStations()) if (s.id.equals(id)) return s;
        return null;
    }

    private ArrayList<Station> loadStations() {
        ArrayList<Station> list = new ArrayList<>();
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String raw = p.getString("stations", "");
        if (raw == null) return list;

        for (String line : raw.split("\n")) {
            String[] a = line.split("\\|", 3);
            if (a.length == 3) {
                try {
                    list.add(new Station(a[0], a[1],
                            java.net.URLDecoder.decode(a[2], "UTF-8")));
                } catch (Exception ignored) {}
            }
        }
        return list;
    }

    private Settings settings() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        return new Settings(
                positiveDouble(p.getString("ring", "8"), 8),
                positiveDouble(p.getString("overlap", "1"), 1),
                positiveDouble(p.getString("postroll", "7"), 7),
                positiveInt(p.getString("bitrate", "192"), 192)
        );
    }

    private static double positiveDouble(String s, double d) {
        try {
            double x = Double.parseDouble(s);
            return x > 0 && x <= 3600 ? x : d;
        } catch (Exception e) { return d; }
    }

    private static int positiveInt(String s, int d) {
        try {
            int x = Integer.parseInt(s);
            return x > 0 && x <= 1000 ? x : d;
        } catch (Exception e) { return d; }
    }

    private void updateSummary() {
        int count;
        StringBuilder sb = new StringBuilder();
        synchronized (lock) {
            count = recorders.size();
            for (StationRecorder r : recorders.values()) {
                if (sb.length() > 0) sb.append(" • ");
                sb.append(r.station.name);
            }
        }
        if (count > 0) updateNotification("Записывается: " + sb);
    }

    private Notification notification(String text) {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT |
                        (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setContentTitle("Radio Recorder")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(1, notification(text));
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        synchronized (lock) {
            for (StationRecorder r : recorders.values()) r.requestStop();
            recorders.clear();
        }
        releaseWakeLock();
        super.onDestroy();
    }

    private class StationRecorder extends Thread {
        final Station station;
        final Settings cfg;
        volatile boolean running = true;
        volatile boolean stopRequested = false;

        StationRecorder(Station station) {
            super("RadioRecorder-" + station.id);
            this.station = station;
            this.cfg = settings();
        }

        void requestStop() {
            stopRequested = true;
            interrupt();
        }

        @Override public void run() {
            try {
                recordLoop();
            } finally {
                recorderFinished(station.id);
            }
        }

        private void recordLoop() {
            while (running && !stopRequested) {
                HttpURLConnection conn = null;
                try {
                    URL url = new URL(station.url);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setConnectTimeout(30000);
                    conn.setReadTimeout(120000);
                    conn.setRequestProperty("Icy-MetaData", "1");
                    conn.setRequestProperty("User-Agent", "RadioRecorder/2.0");
                    conn.connect();

                    int metaInt = conn.getHeaderFieldInt("icy-metaint", -1);
                    if (metaInt <= 0) metaInt = 16000;

                    updateSummary();
                    recordStream(conn.getInputStream(), metaInt);
                } catch (Exception e) {
                    if (!stopRequested) {
                        updateNotification(station.name + ": переподключение…");
                        try { Thread.sleep(3000); } catch (InterruptedException ignored) {}
                    }
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }

        private void recordStream(InputStream in, int metaInt) throws Exception {
            int ringBytes = (int)(cfg.bitrate * 1000.0 / 8.0 * cfg.ringSeconds);
            int overlapBytes = (int)(cfg.bitrate * 1000.0 / 8.0 * cfg.overlapSeconds);
            int postrollBytes = (int)(cfg.bitrate * 1000.0 / 8.0 * cfg.postrollSeconds);

            Ring ring = new Ring(Math.max(1024, ringBytes));
            byte[] audio = new byte[8192];
            String currentTitle = null;
            SongWriter current = null;
            ArrayList<SongWriter> pending = new ArrayList<>();
            int audioUntilMeta = metaInt;

            while (!stopRequested) {
                int want = Math.min(audio.length, audioUntilMeta);
                int n = in.read(audio, 0, want);
                if (n < 0) break;
                if (n == 0) continue;

                byte[] chunk = copyOf(audio, n);
                ring.add(chunk);

                if (current != null) current.feed(chunk);
                for (SongWriter w : pending) w.feed(chunk, postrollBytes);
                processPending(pending);

                if (stopRequested && pending.isEmpty()) {
                    if (current != null) {
                        current.deleteNow();
                        current = null;
                    }
                    return;
                }

                audioUntilMeta -= n;
                if (audioUntilMeta == 0) {
                    int metaLenByte = in.read();
                    if (metaLenByte < 0) break;

                    int metaLen = metaLenByte * 16;
                    if (metaLen > 0) {
                        byte[] meta = new byte[metaLen];
                        readFully(in, meta, 0, metaLen);
                        String title = parseStreamTitle(meta);

                        if (title != null && !title.isEmpty() && !stopRequested) {
                            if (currentTitle == null) {
                                currentTitle = title;
                                updateNotification(station.name + ": " + title);
                            } else if (!title.equals(currentTitle)) {
                                if (current != null) {
                                    pending.add(current);
                                    current.startPostroll(postrollBytes);
                                }

                                byte[] history = ring.tail(overlapBytes);
                                current = new SongWriter(RadioService.this, station, title);
                                byte[] frameHistory = findMp3Frame(history);
                                if (frameHistory.length > 0) current.writeInitial(frameHistory);

                                currentTitle = title;
                                updateNotification(station.name + ": " + title);
                            }
                        }
                    }
                    audioUntilMeta = metaInt;
                }
            }

            if (current != null) {
                if (stopRequested) current.deleteNow();
                else current.finishNow();
            }
            for (SongWriter w : pending) {
                if (stopRequested) w.deleteNow();
                else w.finishNow();
            }
            pending.clear();
        }

        private void processPending(ArrayList<SongWriter> p) {
            for (int i = p.size() - 1; i >= 0; i--)
                if (p.get(i).isDone()) p.remove(i);
        }
    }

    private static class Station {
        String id, name, url;
        Station(String id, String name, String url) {
            this.id = id; this.name = name; this.url = url;
        }
    }

    private static class Settings {
        final double ringSeconds, overlapSeconds, postrollSeconds;
        final int bitrate;
        Settings(double r, double o, double p, int b) {
            ringSeconds=r; overlapSeconds=o; postrollSeconds=p; bitrate=b;
        }
    }

    private static class Ring {
        final int max;
        final ByteArrayOutputStream buf = new ByteArrayOutputStream();
        Ring(int max) { this.max = max; }

        synchronized void add(byte[] data) {
            try {
                buf.write(data);
                byte[] all = buf.toByteArray();
                if (all.length > max) {
                    int keep = max;
                    buf.reset();
                    buf.write(all, all.length - keep, keep);
                }
            } catch (IOException ignored) {}
        }

        synchronized byte[] tail(int n) {
            byte[] all = buf.toByteArray();
            int take = Math.min(Math.max(0, n), all.length);
            byte[] out = new byte[take];
            System.arraycopy(all, all.length - take, out, 0, take);
            return out;
        }
    }

    private static class SongWriter {
        final RadioService service;
        final Station station;
        final String title;
        Uri uri;
        OutputStream out;
        int remainingPostroll;
        boolean done;

        SongWriter(RadioService service, Station station, String title) throws IOException {
            this.service=service; this.station=station; this.title=title; open();
        }

        private void open() throws IOException {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Audio.Media.DISPLAY_NAME,
                    uniqueName(service, station, title));
            v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg");

            if (Build.VERSION.SDK_INT >= 29) {
                v.put(MediaStore.Audio.Media.RELATIVE_PATH,
                        "Music/Radio/" + safe(station.name) + "/");
                v.put(MediaStore.Audio.Media.IS_PENDING, 1);
            }

            uri = service.getContentResolver().insert(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IOException("MediaStore insert failed");
            out = service.getContentResolver().openOutputStream(uri);
            if (out == null) throw new IOException("MediaStore output failed");
        }

        void writeInitial(byte[] b) {
            try { out.write(b); out.flush(); } catch (IOException e) { finishNow(); }
        }

        void feed(byte[] b) {
            if (done) return;
            try { out.write(b); } catch (IOException e) { finishNow(); }
        }

        void startPostroll(int bytes) {
            remainingPostroll = bytes;
        }

        void feed(byte[] b, int postrollBytes) {
            if (done) return;
            try {
                if (remainingPostroll > 0) {
                    int take = Math.min(remainingPostroll, b.length);
                    out.write(b, 0, take);
                    remainingPostroll -= take;
                    if (remainingPostroll <= 0) finishNow();
                }
            } catch (IOException e) { finishNow(); }
        }

        boolean isDone() { return done; }

        void finishNow() {
            if (done) return;
            done=true;
            try { if (out != null) out.close(); } catch (IOException ignored) {}
            if (Build.VERSION.SDK_INT >= 29 && uri != null) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Audio.Media.IS_PENDING, 0);
                service.getContentResolver().update(uri, v, null, null);
            }
        }

        void deleteNow() {
            if (done) return;
            done=true;
            try { if (out != null) out.close(); } catch (IOException ignored) {}
            if (uri != null) {
                try { service.getContentResolver().delete(uri, null, null); }
                catch (Exception ignored) {}
            }
        }
    }

    private static String uniqueName(RadioService s, Station st, String title) {
        String base = safe(title);
        if (base.isEmpty()) base = "Unknown";
        String candidate=base+".mp3";
        int n=2;
        while (exists(s, st, candidate)) candidate=base+" ("+(n++)+").mp3";
        return candidate;
    }

    private static boolean exists(RadioService s, Station st, String name) {
        android.database.Cursor c=null;
        try {
            String sel = MediaStore.Audio.Media.DISPLAY_NAME+"=?";
            c=s.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Audio.Media.DISPLAY_NAME}, sel,
                    new String[]{name}, null);
            return c!=null && c.moveToFirst();
        } finally { if(c!=null)c.close(); }
    }

    private static String safe(String x) {
        if (x==null) return "";
        return x.replaceAll("[\\\\/:*?\"<>|]", "_")
                .replaceAll("\\s+", " ").trim();
    }

    private static byte[] copyOf(byte[] src,int len) {
        byte[] out=new byte[len]; System.arraycopy(src,0,out,0,len); return out;
    }

    private static void readFully(InputStream in, byte[] b,int off,int len) throws IOException {
        int done=0;
        while(done<len) {
            int n=in.read(b,off+done,len-done);
            if(n<0) throw new IOException("EOF");
            done+=n;
        }
    }

    private static String parseStreamTitle(byte[] meta) {
        String utf8 = new String(meta, StandardCharsets.UTF_8);
        String title = extractStreamTitle(utf8);
        if (title != null && !title.contains("\uFFFD")) return title;
        return extractStreamTitle(new String(meta, StandardCharsets.ISO_8859_1));
    }

    private static String extractStreamTitle(String s) {
        int p=s.indexOf("StreamTitle='"); char q='\'';
        if(p<0){p=s.indexOf("StreamTitle=\"");q='\"';}
        if(p<0)return null;
        int start=p+"StreamTitle=".length();
        if(start>=s.length())return null;
        if(s.charAt(start)=='\''||s.charAt(start)=='\"')q=s.charAt(start);
        else return null;
        int end=s.indexOf(q,start+1);
        return end<0?null:s.substring(start+1,end).trim();
    }

    private static int mp3FrameLength(byte[] b,int p) {
        if(p+4>b.length)return -1;
        int h=(b[p]&255)<<24|(b[p+1]&255)<<16|(b[p+2]&255)<<8|(b[p+3]&255);
        if((h&0xFFE00000)!=0xFFE00000)return -1;
        int version=(h>>>19)&3, layer=(h>>>17)&3, bi=(h>>>12)&15;
        int si=(h>>>10)&3, pad=(h>>>9)&1;
        if(version==1||layer!=1||bi==0||bi==15||si==3)return -1;
        int[] v1={0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0};
        int[] v2={0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,0};
        int[] r1={44100,48000,32000},r2={22050,24000,16000},r25={11025,12000,8000};
        int kb,rate;
        if(version==3){kb=v1[bi];rate=r1[si];}
        else if(version==2){kb=v2[bi];rate=r2[si];}
        else{kb=v2[bi];rate=r25[si];}
        if(kb<=0||rate<=0)return -1;
        return (version==3?144000:72000)*kb/rate+pad;
    }

    private static byte[] findMp3Frame(byte[] data) {
        for(int i=0;i+417<data.length;i++){
            int a=mp3FrameLength(data,i);
            if(a<=0||i+a+4>=data.length)continue;
            int b=mp3FrameLength(data,i+a);
            if(b<=0)continue;
            int c=mp3FrameLength(data,i+a+b);
            if(c<=0)continue;
            byte[] out=new byte[data.length-i];
            System.arraycopy(data,i,out,0,out.length);
            return out;
        }
        return new byte[0];
    }

    private void createChannel() {
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel(CHANNEL_ID,
                    "Radio recording",NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }
}
