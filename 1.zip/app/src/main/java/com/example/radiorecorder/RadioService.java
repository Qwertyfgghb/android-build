package com.example.radiorecorder;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.media.*;
import java.nio.ByteBuffer;
import android.os.*;
import android.provider.MediaStore;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import com.arthenica.ffmpegkit.FFmpegKit;
import com.arthenica.ffmpegkit.ReturnCode;

public class RadioService extends Service {
    public static final String ACTION_START_STATION="START_STATION", ACTION_STOP_STATION="STOP_STATION", ACTION_STOP_ALL="STOP_ALL";
    public static final String ACTION_STATUS="com.example.radiorecorder.STATUS";
    private static final String CH="radio_recording";
    private final Map<Integer,Recorder> recorders=new ConcurrentHashMap<>();
    private PowerManager.WakeLock lock;
    private MetadataDbHelper metadataDb;

    @Override public void onCreate(){super.onCreate();createChannel();metadataDb=new MetadataDbHelper(this);}
    @Override public int onStartCommand(Intent in,int flags,int id){
        String a=in==null?null:in.getAction();
        if(ACTION_START_STATION.equals(a)){ensureForeground();startStation(in.getIntExtra("station_id",0),in.getStringExtra("station_name"),in.getStringExtra("station_url"),in.getBooleanExtra("scheduled",false),in.getStringExtra("schedule_meta"),in.getBooleanExtra("metadata_only",false),in.getStringExtra("api_url"));}
        else if(ACTION_STOP_STATION.equals(a))stopStation(in.getIntExtra("station_id",0),in.getBooleanExtra("scheduled",false));
        else if(ACTION_STOP_ALL.equals(a))for(Recorder r:recorders.values())r.requestStop();
        return START_STICKY;
    }
    private void ensureForeground(){
        if(lock==null){startForeground(1,notification("Подготовка записи…",null));PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);if(pm!=null){lock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"RadioRecorder:Recording");lock.acquire();}}
    }
    private void startStation(int id,String name,String url,boolean scheduled,String scheduleMeta,boolean metadataOnly,String apiUrl){
        if(url==null||url.trim().isEmpty())return;if(recorders.containsKey(id))return;
        SharedPreferences p=getSharedPreferences("radio_prefs",MODE_PRIVATE);
        boolean auto=p.getBoolean("auto_name_"+id,true);
        if(name==null||name.trim().isEmpty()||auto)name=deriveName(url);
        deleteStalePending(name);
        Recorder r=new Recorder(id,name,url,auto,scheduled,scheduleMeta,metadataOnly,apiUrl);recorders.put(id,r);r.start();updateNotification();
    }
    private String deriveName(String u){try{URI x=new URI(u);String h=x.getHost();if(h!=null&&!h.isEmpty()){if(h.startsWith("www."))h=h.substring(4);return h;}String path=x.getPath();if(path!=null&&!path.isEmpty()){String q=path.substring(path.lastIndexOf('/')+1);if(!q.isEmpty())return q;}}catch(Exception ignored){}return "Радио";}
    private void deleteStalePending(String stationName){
        if(Build.VERSION.SDK_INT<29)return;android.database.Cursor c=null;try{String path=folderPath(stationName);c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media._ID},MediaStore.Audio.Media.IS_PENDING+"=1 AND "+MediaStore.Audio.Media.RELATIVE_PATH+"=?",new String[]{path},null);if(c!=null)while(c.moveToNext()){long id=c.getLong(0);getContentResolver().delete(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,id),null,null);}}catch(Exception ignored){}finally{if(c!=null)c.close();}}
    private String folderPath(String stationName){
        SharedPreferences p=getSharedPreferences("radio_prefs",MODE_PRIVATE);
        String base="Music/Radio/"+safeFolder(stationName)+"/";
        return p.getBoolean("station_date_folders_"+findStationId(stationName),false) ? base+new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date())+"/" : base;
    }
    private int findStationId(String stationName){
        SharedPreferences p=getSharedPreferences("radio_prefs",MODE_PRIVATE); int n=p.getInt("station_count",0);
        for(int i=0;i<n;i++) if(stationName.equals(p.getString("station_name_"+i,""))) return i;
        return -1;
    }
    private void stopStation(int id,boolean scheduled){Recorder r=recorders.get(id);if(r!=null){if(scheduled)r.requestScheduledStop();else r.requestStop();}}
    private void stationFinished(int id){recorders.remove(id);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(1000+id);updateNotification();if(recorders.isEmpty()){if(lock!=null&&lock.isHeld()){lock.release();lock=null;}stopForeground(true);stopSelf();}}
    private void updateNotification(){StringBuilder s=new StringBuilder("Активно: ");if(recorders.isEmpty())s.append("нет станций");else{boolean first=true;for(Recorder r:recorders.values()){if(!first)s.append(" • ");s.append(r.name);first=false;}}((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(1,notification(s.toString(),null));}

    private class Recorder extends Thread {
        final int id; volatile String name; final String url; final boolean autoName; final boolean scheduledStart; final String scheduledMeta; final boolean metadataOnlyStart; final String apiUrl; volatile boolean metadataTriggered=false; volatile String lastApiTitle=""; volatile boolean stopping=false; volatile boolean scheduledStop=false; volatile Writer activeWriter; volatile HttpURLConnection connection; volatile String currentTitle; volatile boolean firstMetadataSeen=false; final ArrayList<Writer> pendingWriters=new ArrayList<>(); volatile int actualKbps=0; volatile boolean sourceIsMp3=true;
        final SharedPreferences p=getSharedPreferences("radio_prefs",MODE_PRIVATE); final Set<Writer> writers=ConcurrentHashMap.newKeySet(); volatile String recordingExt="mp3"; volatile String recordingMime="audio/mpeg";
        Recorder(int i,String n,String u,boolean auto,boolean scheduled,String scheduleMeta,boolean metadataOnly,String api){super("Radio-"+i);id=i;name=n;url=u;autoName=auto;scheduledStart=scheduled;scheduledMeta=scheduleMeta==null?"":scheduleMeta.trim();metadataOnlyStart=metadataOnly;apiUrl=api==null?"":api.trim();}
        String key(String base){return base+"_"+id;} double ringSec(){return getD(key("station_ring_seconds"),8);} double overlapSec(){return getD(key("station_overlap_seconds"),1);} double postSec(){return getD(key("station_postroll_seconds"),7);} int kbps(){return getI(key("station_bitrate_kbps"),192);} String target(){return !scheduledMeta.isEmpty()?scheduledMeta:p.getString(key("station_meta_target"),"").trim();}
        boolean matchesTarget(String title,String wanted){if(wanted==null||wanted.trim().isEmpty())return true;String x=normalizeTitle(title);String mode=p.getString(key("station_meta_mode"),"contains");String[] parts=wanted.split("[,;]");if("exact".equals(mode)) for(String part:parts) if(x.equals(normalizeTitle(part))) return true; if("all".equals(mode)){for(String part:parts){String q=normalizeTitle(part);if(!q.isEmpty()&&!x.contains(q))return false;}return true;} for(String part:parts){String q=normalizeTitle(part);if(!q.isEmpty()&&x.contains(q))return true;}return false;}
        boolean skipDuplicates(){return p.getBoolean(key("station_skip_duplicates"),true);}
        boolean useMetadata(){return p.getBoolean(key("station_use_metadata"),true);}
        boolean useSilence(){return p.getBoolean(key("station_use_silence"),false);}
        boolean skipFirst(){return p.getBoolean(key("station_skip_first"),false);}
        String normalizeTitle(String t){return t==null?"":t.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+"," ").trim().replaceAll("\\s+"," ");} boolean sameTrack(String a,String b){return normalizeTitle(a).equals(normalizeTitle(b));}
        boolean isDuplicateTrack(String t){
            if(!skipDuplicates()) return false;
            String n=normalizeTitle(t);
            if(n.isEmpty()) return false;

            // 1) Уже открытые Writer'ы, включая post-roll.
            for(Writer w:writers){
                if(!w.done && sameTrack(w.title,t)) return true;
            }

            // 2) Постоянная история уже завершённых записей.
            Set<String> seen=new HashSet<>(p.getStringSet(key("recorded_titles"),Collections.emptySet()));
            if(seen.contains(n)) return true;

            // 3) Проверяем реально существующие файлы.
            return hasExistingTrack(t);
        }
        void rememberTrack(String t){
            if(!skipDuplicates()) return;
            String n=normalizeTitle(t); if(n.isEmpty()) return;
            Set<String> seen=new HashSet<>(p.getStringSet(key("recorded_titles"),Collections.emptySet()));
            seen.add(n); if(seen.size()>500){Iterator<String> it=seen.iterator();while(seen.size()>450&&it.hasNext()){it.next();it.remove();}}
            p.edit().putStringSet(key("recorded_titles"),seen).apply();
        }
        boolean hasExistingTrack(String t){
            
            android.database.Cursor c=null;
            try{
                String path=folderPath(name);
                if(Build.VERSION.SDK_INT>=29) c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media.DISPLAY_NAME},MediaStore.Audio.Media.RELATIVE_PATH+"=?",new String[]{path},null);
                else c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media.DISPLAY_NAME},MediaStore.Audio.Media.DISPLAY_NAME+" LIKE ?",new String[]{"%"},null);
                String base=normalizeTitle(t);
                if(c!=null)while(c.moveToNext()){
                    String fn=c.getString(0); if(fn==null)continue;
                    String x=fn.replaceFirst("\\.(mp3|aac|ogg|opus|flac|wav)$","");
                    x=x.replaceAll(" \\(\\d+\\)$","");
                    if(normalizeTitle(x).equals(base))return true;
                }
            }catch(Exception ignored){}finally{if(c!=null)c.close();}
            return false;
        }
        double getD(String k,double d){try{return Double.parseDouble(p.getString(k,String.valueOf(d)));}catch(Exception e){return d;}} int getI(String k,int d){try{return Integer.parseInt(p.getString(k,String.valueOf(d)));}catch(Exception e){return d;}}
        void setFormat(String contentType){
            String ct=contentType==null?"":contentType.toLowerCase(Locale.ROOT);
            sourceIsMp3 = ct.contains("mpeg") || ct.contains("mp3") || ct.isEmpty() || url.toLowerCase(Locale.ROOT).contains(".mp3");
            recordingExt="mp3";
            recordingMime="audio/mpeg";
        }
        void requestStop(){if(stopping)return;stopping=true;for(Writer w:new ArrayList<>(writers))w.deleteNow();activeWriter=null;pendingWriters.clear();HttpURLConnection cc=connection;if(cc!=null)cc.disconnect();broadcast("Остановлено — незаконченная запись удалена",null);}
        void requestScheduledStop(){if(stopping||scheduledStop)return;scheduledStop=true;broadcast("Планировщик: ждём завершение текущего трека…",currentTitle);}
        void broadcast(String status,String track){Intent i=new Intent(ACTION_STATUS);i.setPackage(getPackageName());i.putExtra("station_id",id);i.putExtra("station_name",name);i.putExtra("status",status);i.putExtra("track",track==null?"":track);sendBroadcast(i);}
        void songNotification(String track){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.notify(1000+id,notification(name,track));}
        boolean waitForApiMatch(){
            broadcast("Ожидание метаданных API • проверка каждую секунду",scheduledMeta);
            while(!stopping && !scheduledStop){
                HttpURLConnection c=null;
                try{
                    c=(HttpURLConnection)new URL(apiUrl).openConnection();
                    c.setConnectTimeout(5000);c.setReadTimeout(7000);c.setRequestMethod("GET");
                    c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","RadioRecorder/11");
                    c.connect();
                    if(c.getResponseCode()<200||c.getResponseCode()>=400)throw new IOException("HTTP "+c.getResponseCode());
                    String json=readText(c.getInputStream());
                    String artist="",title="";
                    try{org.json.JSONObject o=new org.json.JSONObject(json);org.json.JSONObject ct=o.optJSONObject("current_track");if(ct!=null){artist=ct.optString("artist","");title=ct.optString("title","");}}
                    catch(Exception ignored){}
                    String combined=(artist.isEmpty()?"":artist)+(artist.isEmpty()||title.isEmpty()?"":" - ")+title;
                    if(!combined.trim().isEmpty()){
                        currentTitle=combined.trim();if(!currentTitle.equals(lastApiTitle)){lastApiTitle=currentTitle;metadataDb.add(id,name,currentTitle);}
                        if(matchesTarget(combined,scheduledMeta)||matchesTarget(title,scheduledMeta)||matchesTarget(artist,scheduledMeta)){
                            metadataTriggered=true;
                            broadcast("Найдено совпадение API — подключаем поток",currentTitle);
                            return true;
                        }
                        broadcast("API • сейчас: "+combined,currentTitle);
                    }
                }catch(Exception e){broadcast("API недоступен — повтор через 1 с",currentTitle);}
                finally{if(c!=null)c.disconnect();}
                try{Thread.sleep(1000);}catch(InterruptedException e){Thread.currentThread().interrupt();return false;}
            }
            return false;
        }
        String readText(InputStream in)throws IOException{try{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toString("UTF-8");}finally{try{in.close();}catch(Exception ignored){}}}
        @Override public void run(){
            if(metadataOnlyStart && !scheduledMeta.isEmpty() && !apiUrl.isEmpty()){
                if(!waitForApiMatch()){stationFinished(id);return;}
            }
            int attempt=0;
            while(!stopping){
                HttpURLConnection c=null;
                try{
                    c=(HttpURLConnection)new URL(url).openConnection(); connection=c;
                    c.setConnectTimeout(30000); c.setReadTimeout(15000); c.setRequestProperty("Icy-MetaData","1"); c.setRequestProperty("User-Agent","RadioRecorder/3.0"); c.connect();
                    if(c.getResponseCode()<200||c.getResponseCode()>=400) throw new IOException("HTTP "+c.getResponseCode());
                    if(autoName){String icy=c.getHeaderField("icy-name");if(icy!=null&&!icy.trim().isEmpty()){name=icy.trim();p.edit().putString("station_name_"+id,name).apply();}else if(name==null||name.isEmpty())name=deriveName(url);}
                    deleteStalePending(name);
                    int mi=c.getHeaderFieldInt("icy-metaint",-1);
                    String ct=c.getContentType();
                    setFormat(ct);
                    String br=c.getHeaderField("icy-br");try{actualKbps=Integer.parseInt(br);}catch(Exception ignored){}
                    attempt=0;
                    broadcast("Подключено • "+(br==null?"bitrate неизвестен":br+" kbps")+" • "+(mi>0? (firstMetadataSeen?"метаданные продолжаются":"ICY metadata обнаружена") : "без ICY metadata")+(sourceIsMp3?" • MP3":" • "+(ct==null?"формат определит FFmpeg":ct)+" → MP3"),currentTitle);
                    recordStream(c.getInputStream(),mi);
                    if(stopping) break;
                    broadcast("Поток завершился — переподключение…",null);
                }catch(Exception e){
                    if(stopping) break; attempt++; broadcast("Нет потока • попытка "+attempt+"/10",null);
                    if(attempt>=10) break;
                }finally{if(c!=null)c.disconnect();connection=null;}
                try{Thread.sleep(Math.min(30000,3000L*attempt));}catch(InterruptedException e){Thread.currentThread().interrupt();break;}
            }
            if(stopping){for(Writer w:new ArrayList<>(writers))w.deleteNow();}else{if(activeWriter!=null&&!activeWriter.done)activeWriter.finish();synchronized(pendingWriters){for(Writer w:pendingWriters)if(!w.done)w.finish();pendingWriters.clear();}} stationFinished(id);
        }

        void recordStream(InputStream in,int metaInt)throws Exception{
            int bitrate=actualKbps>0?actualKbps:kbps();int ringBytes=Math.max(1,(int)(bitrate*1000.0/8*ringSec()));int overlapBytes=Math.max(0,(int)(bitrate*1000.0/8*overlapSec()));Ring ring=new Ring(ringBytes);byte[] buf=new byte[8192];
            Writer current=activeWriter;String title=currentTitle;String wanted=target();int until=metaInt;long totalBytes=0;long startedAt=System.currentTimeMillis();
            if(metaInt<=0 || (!useMetadata() && !useSilence())){
                SilenceDetector silence=useSilence()?new SilenceDetector(recordingMime):null;
                long silentMs=0; boolean silenceSupported=silence!=null&&silence.supported();
                if(current==null && !stopping){
                    String label=currentTitle==null||currentTitle.trim().isEmpty()?"Радио — непрерывная запись":currentTitle;
                    current=newWriter(label,ring,0); activeWriter=current;
                    broadcast(silenceSupported?"Метаданных нет — используем разделение по тишине":"StreamTitle отсутствует — записываем поток целиком",label);
                }
                while(!stopping){
                    int n=in.read(buf);
                    if(n<0)break; if(n==0)continue;
                    byte[] chunk=Arrays.copyOf(buf,n);
                    boolean silent=false; if(silenceSupported){try{silence.feed(chunk);silent=silence.isCurrentlySilent();}catch(Exception ignored){silenceSupported=false;}}
                    if(useSilence()&&silenceSupported){
                        long step=Math.max(20, silence.lastDurationMs());
                        if(silent){silentMs+=step;}else{silentMs=0;}
                        if(silentMs>=1500&&current!=null){current.finish();current=null;activeWriter=null;broadcast("Тишина — трек завершён",null);}
                        if(!silent && current==null){current=newWriter("Без метаданных",ring,0);activeWriter=current;broadcast("Звук появился — новая запись",null);}
                    }
                    if(current!=null)current.feed(chunk);
                    if(scheduledStop){ if(current!=null){current.finish();current=null;activeWriter=null;} return; }
                }
                if(silence!=null)silence.close();
                return;
            }
            if(!metadataOnlyStart && current==null && !stopping){
                current=newWriter("Радио — поток",ring,0);
                activeWriter=current;
                broadcast(useSilence()?"Запись начата без ожидания StreamTitle • контроль тишины":"Запись начата без ожидания StreamTitle",null);
            } else if(metadataOnlyStart && current==null && !stopping){
                broadcast("Режим условия: ждём метаданные, запись пока не создаётся",null);
            }
            SilenceDetector silence=useSilence()?new SilenceDetector(recordingMime):null;
            boolean silenceSupported=silence!=null&&silence.supported(); long silentMs=0;
            while(true){
                if(stopping)return;int want=Math.min(buf.length,until);int n=in.read(buf,0,want);if(n<0)break;if(n==0)continue;byte[] chunk=Arrays.copyOf(buf,n);
                boolean silent=false; if(silenceSupported){try{silence.feed(chunk);silent=silence.isCurrentlySilent();}catch(Exception ignored){silenceSupported=false;}}
                if(useSilence()&&silenceSupported&&!firstMetadataSeen){long step=Math.max(20,silence.lastDurationMs());if(silent)silentMs+=step;else silentMs=0;if(silentMs>=1500&&current!=null&&!useMetadata()){current.finish();current=null;activeWriter=null;}if(!silent&&current==null&&!useMetadata()){current=newWriter("Без метаданных",ring,0);activeWriter=current;}}
                ring.add(chunk); totalBytes+=n;
                if(current!=null)current.feed(chunk);if(current!=null&&current.done){current=null;if(activeWriter!=null&&activeWriter.done)activeWriter=null;}synchronized(pendingWriters){for(Writer w:pendingWriters)w.feed(chunk);for(int i=pendingWriters.size()-1;i>=0;i--)if(pendingWriters.get(i).done)pendingWriters.remove(i); if(scheduledStop && current==null && pendingWriters.isEmpty() && firstMetadataSeen)return;}
                if(current!=null && System.currentTimeMillis()-startedAt>1000){double sec=(System.currentTimeMillis()-startedAt)/1000.0;double kbpsNow=(totalBytes*8.0/sec)/1000.0;broadcast(String.format(Locale.US,"Записывается • %.0f кбит/с • %.1f MB",kbpsNow,totalBytes/1048576.0),current.title);}
                until-=n;if(until==0){int lb=in.read();if(lb<0)break;int ml=lb*16;if(ml>0){byte[] m=new byte[ml];readFully(in,m);String t=useMetadata()?parseTitle(m):null;
                    if(t!=null&&!t.trim().isEmpty()){
                    boolean match=matchesTarget(t,wanted);
                    if(!firstMetadataSeen){
                        firstMetadataSeen=true; title=t; currentTitle=t; metadataDb.add(id,name,t); songNotification(t);
                        if(skipFirst() && !metadataTriggered){
                            if(current!=null){current.deleteNow();current=null;activeWriter=null;}
                            broadcast("Первый трек пропущен — ждём следующий",t);
                        } else if(current!=null && "Радио — поток".equals(current.title) && !isDuplicateTrack(t)){
                            current.renameTitle(t);
                            broadcast("Метаданные получены — текущая запись переименована",t);
                        } else if(current!=null && "Радио — поток".equals(current.title) && isDuplicateTrack(t)){
                            current.deleteNow();current=null;activeWriter=null;
                            broadcast("Дубликат пропущен",t);
                        } else if(wanted.isEmpty()){
                            if(isDuplicateTrack(t)) { current=null; broadcast("Дубликат пропущен",t); }
                            else { current=newWriter(t,ring,overlapBytes); activeWriter=current; broadcast("Записывается",t); }
                        } else if(match && !isDuplicateTrack(t)){ current=newWriter(t,ring,overlapBytes); activeWriter=current; broadcast("Найдено совпадение — запись начата",t); }
                        else if(match){ current=null; broadcast("Дубликат пропущен",t); }
                        else if(metadataOnlyStart) broadcast("Условие метаданных ещё не выполнено: "+wanted,t);
                        else {if(isDuplicateTrack(t)){current=null;broadcast("Дубликат пропущен",t);}else{current=newWriter(t,ring,overlapBytes);activeWriter=current;broadcast("Записывается",t);}}
                    }
                    else if(!sameTrack(t,title)){
                        if(current!=null){current.startPostSeconds(postSec());synchronized(pendingWriters){pendingWriters.add(current);}activeWriter=null;broadcast("Трек завершён, post-roll "+postSec()+" с",current.title);}
                        title=t; currentTitle=t; metadataDb.add(id,name,t); songNotification(t);
                        boolean dup=isDuplicateTrack(t);
                        if(scheduledStop){ current=null; activeWriter=null; broadcast("Планировщик: новый трек не записывается",t); }
                        else if(wanted.isEmpty()){
                            if(dup){current=null;broadcast("Дубликат пропущен",t);}else{current=newWriter(t,ring,overlapBytes);activeWriter=current;broadcast("Записывается",t);}
                        }else if(match){
                            if(dup){current=null;broadcast("Дубликат пропущен",t);}else{current=newWriter(t,ring,overlapBytes);activeWriter=current;broadcast("Найдено совпадение — запись начата",t);}
                        }else if(metadataOnlyStart){current=null;activeWriter=null;broadcast("Условие метаданных ещё не выполнено: "+wanted,t);}
                        else {if(isDuplicateTrack(t)){current=null;broadcast("Дубликат пропущен",t);}else{current=newWriter(t,ring,overlapBytes);activeWriter=current;broadcast("Записывается",t);}}
                    }
                }}until=metaInt;}
            }
            if(scheduledStop && current!=null){current.startPostSeconds(postSec());synchronized(pendingWriters){pendingWriters.add(current);}current=null;activeWriter=null;}
            if(silence!=null)silence.close();
        }
        Writer newWriter(String t,Ring ring,int overlapBytes)throws IOException{Writer w=new Writer(t);writers.add(w);byte[] h=findFrame(ring.tail(overlapBytes));if(h.length>0)w.initial(h);return w;}
        void readFully(InputStream in,byte[] b)throws IOException{int x=0;while(x<b.length){int n=in.read(b,x,b.length-x);if(n<0)throw new EOFException();x+=n;}}
        String parseTitle(byte[] b){
            String[] cs={"UTF-8","windows-1251","ISO-8859-1"};
            for(String csn:cs){
                try{String s=new String(b,csn);String t=extract(s);if(t!=null&&!t.trim().isEmpty()&&!t.contains("\uFFFD"))return cleanMetadata(t);}catch(Exception ignored){}
            }
            return null;
        }
        String extract(String s){
            if(s==null)return null;
            String lower=s.toLowerCase(Locale.ROOT);
            String[] keys={"streamtitle","stream-title","icy-title","icytitle","currenttitle","current_title","tracktitle","track_title","songtitle","song_title","title"};
            int best=-1;String bestKey=null;
            for(String key:keys){int p=lower.indexOf(key);if(p>=0&&(best<0||p<best)){best=p;bestKey=key;}}
            if(best<0)return null;
            int from=best+bestKey.length();
            int eq=lower.indexOf('=',from);
            int colon=lower.indexOf(':',from);
            if(eq<0||(colon>=0&&colon<eq))eq=colon;
            if(eq<0)return null;
            int i=eq+1;while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;
            if(i>=s.length())return null;
            char q=s.charAt(i);
            if(q=='\''||q=='\"'){
                int j=i+1;StringBuilder out=new StringBuilder();boolean esc=false;
                while(j<s.length()){char ch=s.charAt(j);if(esc){out.append(ch);esc=false;}else if(ch=='\\'){esc=true;}else if(ch==q)return out.toString().trim();else out.append(ch);j++;}
                return out.length()>0?out.toString().trim():null;
            }
            int end=s.indexOf(';',i);if(end<0)end=s.length();
            return s.substring(i,end).trim();
        }
        String cleanMetadata(String t){
            t=t.replace("\u0000","").replaceAll("\\s+"," ").trim();
            while(t.startsWith("'")||t.startsWith("\""))t=t.substring(1).trim();
            while(t.endsWith("'")||t.endsWith("\""))t=t.substring(0,t.length()-1).trim();
            return t.replace("&apos;","\'").replace("&quot;","\"").replace("&amp;","&");
        }
        byte[] findFrame(byte[] d){for(int i=0;i+4<d.length;i++){int a=frameLen(d,i);if(a<0||i+a+4>=d.length)continue;int b=frameLen(d,i+a);if(b<0)continue;int c=frameLen(d,i+a+b);if(c<0)continue;return Arrays.copyOfRange(d,i,d.length);}return new byte[0];}
        int frameLen(byte[] b,int p){if(p+4>b.length)return -1;int h=(b[p]&255)<<24|(b[p+1]&255)<<16|(b[p+2]&255)<<8|(b[p+3]&255);if((h&0xFFE00000)!=0xFFE00000)return -1;int v=(h>>>19)&3,l=(h>>>17)&3,bi=(h>>>12)&15,si=(h>>>10)&3,pad=(h>>>9)&1;if(v==1||l!=1||bi==0||bi==15||si==3)return -1;int[] x={0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0};int[] y={0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,0};int br=v==3?x[bi]:y[bi];int[] r1={44100,48000,32000},r2={22050,24000,16000},r25={11025,12000,8000};int sr=v==3?r1[si]:v==2?r2[si]:r25[si];if(br<=0||sr<=0)return -1;return (v==3?144000:72000)*br/sr+pad;}

        class SilenceDetector{
            MediaCodec codec; String mime; boolean ok; long lastMs=20; boolean silent=true;
            SilenceDetector(String m){mime=m==null?"":m.toLowerCase(Locale.ROOT);try{if(mime.contains("mpeg")){codec=MediaCodec.createDecoderByType("audio/mpeg");codec.configure(MediaFormat.createAudioFormat("audio/mpeg",44100,2),null,null,0);codec.start();ok=true;}else if(mime.contains("aac")){ok=false;}else ok=false;}catch(Exception e){ok=false;}}
            boolean supported(){return ok;}
            void feed(byte[] data)throws Exception{if(!ok||data.length==0)return;int pos=0;while(pos+4<=data.length){int len=frameLen(data,pos);if(len<=0||pos+len>data.length)break;int idx=codec.dequeueInputBuffer(0);if(idx<0)break;ByteBuffer in=codec.getInputBuffer(idx);if(in==null)break;in.clear();in.put(data,pos,len);codec.queueInputBuffer(idx,0,len,System.nanoTime()/1000,0);pos+=len;drain();}}
            void drain(){try{MediaCodec.BufferInfo bi=new MediaCodec.BufferInfo();int oi;while((oi=codec.dequeueOutputBuffer(bi,0))>=0){ByteBuffer o=codec.getOutputBuffer(oi);if(o!=null&&bi.size>1){o.position(bi.offset);o.limit(Math.min(o.capacity(),bi.offset+bi.size));int samples=bi.size/2;double sum=0;while(o.remaining()>=2){short v=o.getShort();sum+=(double)v*v;}double rms=Math.sqrt(sum/Math.max(1,samples))/32768.0;silent=rms<0.012;lastMs=Math.max(20,(long)(1000.0*samples/44100.0));}codec.releaseOutputBuffer(oi,false);}}catch(Exception ignored){}}
            long lastDurationMs(){return lastMs;} boolean isCurrentlySilent(){return silent;}
            void close(){try{if(codec!=null){codec.stop();codec.release();}}catch(Exception ignored){}}
        }

        class Writer{
            String title;
            Uri uri;
            OutputStream out;
            File rawFile;
            OutputStream rawOut;
            int remain;
            boolean done;
            Writer(String t)throws IOException{title=t;open();}
            void open()throws IOException{
                if(sourceIsMp3){
                    ContentValues v=new ContentValues();
                    v.put(MediaStore.Audio.Media.DISPLAY_NAME,uniqueName(title));
                    v.put(MediaStore.Audio.Media.MIME_TYPE,"audio/mpeg");
                    if(Build.VERSION.SDK_INT>=29){v.put(MediaStore.Audio.Media.RELATIVE_PATH,folderPath(name));v.put(MediaStore.Audio.Media.IS_PENDING,1);}
                    uri=getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,v);
                    if(uri==null)throw new IOException("MediaStore insert failed");
                    out=getContentResolver().openOutputStream(uri);
                    if(out==null)throw new IOException("Output stream failed");
                }else{
                    rawFile=File.createTempFile("rr_", ".audio", getCacheDir());
                    rawOut=new BufferedOutputStream(new FileOutputStream(rawFile),64*1024);
                }
            }
            void initial(byte[] b){
                if(!sourceIsMp3)return;
                try{if(!done&&b!=null&&b.length>0){out.write(b);out.flush();}}catch(IOException e){deleteNow();}
            }
            void feed(byte[] b){
                if(done)return;
                try{
                    if(remain>0){
                        int n=Math.min(remain,b.length);writeBytes(b,0,n);remain-=n;
                        if(remain==0)finish();
                    }else writeBytes(b,0,b.length);
                    flushBytes();
                }catch(IOException e){deleteNow();}
            }
            void writeBytes(byte[] b,int off,int len)throws IOException{
                if(sourceIsMp3)out.write(b,off,len); else rawOut.write(b,off,len);
            }
            void flushBytes()throws IOException{if(sourceIsMp3)out.flush();else rawOut.flush();}
            void startPostSeconds(double sec){if(done)return;int br=actualKbps>0?actualKbps:kbps();remain=Math.max(0,(int)(br*1000.0/8.0*Math.max(0,sec)));if(remain==0)finish();}
            void renameTitle(String newTitle){
                if(done||newTitle==null||newTitle.trim().isEmpty())return;
                title=newTitle.trim();
                if(sourceIsMp3 && uri!=null){
                    ContentValues v=new ContentValues();v.put(MediaStore.Audio.Media.DISPLAY_NAME,uniqueName(title));
                    try{getContentResolver().update(uri,v,null,null);}catch(Exception ignored){}
                }
            }
            void deleteNow(){
                if(done)return;done=true;
                try{if(out!=null)out.close();}catch(Exception ignored){}
                try{if(rawOut!=null)rawOut.close();}catch(Exception ignored){}
                if(uri!=null)try{getContentResolver().delete(uri,null,null);}catch(Exception ignored){}
                if(rawFile!=null)try{rawFile.delete();}catch(Exception ignored){}
                writers.remove(this);
            }
            void finish(){
                if(done)return;
                if(!sourceIsMp3){finishTranscoded();return;}
                done=true;
                try{out.close();}catch(Exception ignored){}
                if(Build.VERSION.SDK_INT>=29&&uri!=null){ContentValues v=new ContentValues();v.put(MediaStore.Audio.Media.IS_PENDING,0);getContentResolver().update(uri,v,null,null);}
                rememberTrack(title);writers.remove(this);
            }
            void finishTranscoded(){
                done=true;
                try{rawOut.close();}catch(Exception ignored){}
                if(rawFile==null||rawFile.length()==0){try{if(rawFile!=null)rawFile.delete();}catch(Exception ignored){}writers.remove(this);return;}
                File mp3=null;
                try{mp3=File.createTempFile("rr_mp3_", ".mp3", getCacheDir());}catch(IOException e){broadcast("Не удалось создать временный MP3",title);try{rawFile.delete();}catch(Exception ignored){}writers.remove(this);return;}
                String cmd="-y -hide_banner -loglevel error -i "+quote(rawFile.getAbsolutePath())+" -vn -map 0:a:0 -c:a libmp3lame -b:a "+Math.max(32,kbps())+"k -id3v2_version 3 "+quote(mp3.getAbsolutePath());
                try{
                    com.arthenica.ffmpegkit.FFmpegSession session=FFmpegKit.execute(cmd);
                    if(ReturnCode.isSuccess(session.getReturnCode()) && mp3.exists() && mp3.length()>0){
                        insertMp3(mp3);
                        rememberTrack(title);
                        broadcast("Транскодировано в MP3",title);
                    }else{
                        broadcast("FFmpeg не смог преобразовать поток в MP3",title);
                    }
                }catch(Throwable e){broadcast("Ошибка FFmpeg: "+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()),title);}
                try{rawFile.delete();}catch(Exception ignored){}
                try{mp3.delete();}catch(Exception ignored){}
                writers.remove(this);
            }
            void insertMp3(File file)throws IOException{
                ContentValues v=new ContentValues();
                v.put(MediaStore.Audio.Media.DISPLAY_NAME,uniqueName(title));
                v.put(MediaStore.Audio.Media.MIME_TYPE,"audio/mpeg");
                if(Build.VERSION.SDK_INT>=29){v.put(MediaStore.Audio.Media.RELATIVE_PATH,folderPath(name));v.put(MediaStore.Audio.Media.IS_PENDING,1);}
                Uri u=getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,v);
                if(u==null)throw new IOException("MediaStore insert failed");
                try(OutputStream o=getContentResolver().openOutputStream(u);InputStream i=new BufferedInputStream(new FileInputStream(file))){
                    if(o==null)throw new IOException("Output stream failed");
                    byte[] b=new byte[64*1024];int n;while((n=i.read(b))!=-1)o.write(b,0,n);o.flush();
                }catch(Exception e){try{getContentResolver().delete(u,null,null);}catch(Exception ignored){}if(e instanceof IOException)throw (IOException)e;throw new IOException(e);}
                if(Build.VERSION.SDK_INT>=29){ContentValues doneValues=new ContentValues();doneValues.put(MediaStore.Audio.Media.IS_PENDING,0);getContentResolver().update(u,doneValues,null,null);}
            }
            String quote(String x){return "'"+x.replace("'","'\\''")+"'";}
            String uniqueName(String t){String s=safe(t);String c=s+".mp3";int n=2;while(exists(c)){c=s+" ("+n+").mp3";n++;}return c;}
        }
        boolean exists(String n){android.database.Cursor c=null;try{String path=folderPath(name);if(Build.VERSION.SDK_INT>=29)c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media.DISPLAY_NAME},MediaStore.Audio.Media.DISPLAY_NAME+"=? AND "+MediaStore.Audio.Media.RELATIVE_PATH+"=?",new String[]{n,path},null);else c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media.DISPLAY_NAME},MediaStore.Audio.Media.DISPLAY_NAME+"=?",new String[]{n},null);return c!=null&&c.moveToFirst();}finally{if(c!=null)c.close();}}
    }

    static String safe(String s){String x=s.replaceAll("[\\\\/:*?\"<>|]","_").replaceAll("\\s+"," ").trim();return x.isEmpty()?"Unknown":x;}
    static String safeFolder(String s){return safe(s).replace(".","_");}
    static class Ring{final int max;final ByteArrayOutputStream b=new ByteArrayOutputStream();Ring(int m){max=Math.max(1,m);}synchronized void add(byte[] d){try{b.write(d);byte[] a=b.toByteArray();if(a.length>max){b.reset();b.write(a,a.length-max,max);}}catch(Exception ignored){}}synchronized byte[] tail(int n){byte[] a=b.toByteArray();int k=Math.min(Math.max(0,n),a.length);return Arrays.copyOfRange(a,a.length-k,a.length);}}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CH,"Радио — новые песни",NotificationManager.IMPORTANCE_DEFAULT);c.setDescription("Уведомления о новых названиях песен и записи");getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    private Notification notification(String title,String text){Intent i=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH):new Notification.Builder(this);b.setContentTitle(title).setContentText(text==null?"":text).setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).setOngoing(text==null);return b.build();}
    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){for(Recorder r:recorders.values())r.requestStop();if(lock!=null&&lock.isHeld())lock.release();super.onDestroy();}
}
