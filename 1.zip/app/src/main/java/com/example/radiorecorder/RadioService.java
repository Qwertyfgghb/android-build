package com.example.radiorecorder;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class RadioService extends Service {
    public static final String ACTION_START_STATION="START_STATION", ACTION_STOP_STATION="STOP_STATION", ACTION_STOP_ALL="STOP_ALL";
    public static final String ACTION_STATUS="com.example.radiorecorder.STATUS";
    private static final String CH="radio_recording";
    private final Map<Integer,Recorder> recorders=new ConcurrentHashMap<>();
    private PowerManager.WakeLock lock;

    @Override public void onCreate(){super.onCreate();createChannel();}
    @Override public int onStartCommand(Intent in,int flags,int id){
        String a=in==null?null:in.getAction();
        if(ACTION_START_STATION.equals(a)){ensureForeground();startStation(in.getIntExtra("station_id",0),in.getStringExtra("station_name"),in.getStringExtra("station_url"));}
        else if(ACTION_STOP_STATION.equals(a))stopStation(in.getIntExtra("station_id",0));
        else if(ACTION_STOP_ALL.equals(a))for(Recorder r:recorders.values())r.requestStop();
        return START_STICKY;
    }
    private void ensureForeground(){
        if(lock==null){startForeground(1,notification("Подготовка записи…",null));PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);if(pm!=null){lock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"RadioRecorder:Recording");lock.acquire();}}
    }
    private void startStation(int id,String name,String url){
        if(url==null||url.trim().isEmpty())return;if(recorders.containsKey(id))return;
        SharedPreferences p=getSharedPreferences("radio_prefs",MODE_PRIVATE);
        boolean auto=p.getBoolean("auto_name_"+id,true);
        if(name==null||name.trim().isEmpty()||auto)name=deriveName(url);
        deleteStalePending(name);
        Recorder r=new Recorder(id,name,url,auto);recorders.put(id,r);r.start();updateNotification();
    }
    private String deriveName(String u){try{URI x=new URI(u);String h=x.getHost();if(h!=null&&!h.isEmpty()){if(h.startsWith("www."))h=h.substring(4);return h;}String path=x.getPath();if(path!=null&&!path.isEmpty()){String q=path.substring(path.lastIndexOf('/')+1);if(!q.isEmpty())return q;}}catch(Exception ignored){}return "Радио";}
    private void deleteStalePending(String stationName){
        if(Build.VERSION.SDK_INT<29)return;android.database.Cursor c=null;try{String path=folderPath(stationName);c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media._ID},MediaStore.Audio.Media.IS_PENDING+"=1 AND "+MediaStore.Audio.Media.RELATIVE_PATH+"=?",new String[]{path},null);if(c!=null)while(c.moveToNext()){long id=c.getLong(0);getContentResolver().delete(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,id),null,null);}}catch(Exception ignored){}finally{if(c!=null)c.close();}}
    private String folderPath(String stationName){
        SharedPreferences p=getSharedPreferences("radio_prefs",MODE_PRIVATE);
        String base="Music/Radio/"+safeFolder(stationName)+"/";
        return p.getBoolean("station_date_folders_"+findStationId(stationName),false) ? base+new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date())+"/" : base;
    }
    private int findStationId(String stationName){
        SharedPreferences p=getSharedPreferences("radio_prefs",MODE_PRIVATE); int n=p.getInt("station_count",0);
        for(int i=0;i<n;i++) if(stationName.equals(p.getString("station_name_"+i,""))) return i;
        return -1;
    }
    private void stopStation(int id){Recorder r=recorders.get(id);if(r!=null)r.requestStop();}
    private void stationFinished(int id){recorders.remove(id);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).cancel(1000+id);updateNotification();if(recorders.isEmpty()){if(lock!=null&&lock.isHeld()){lock.release();lock=null;}stopForeground(true);stopSelf();}}
    private void updateNotification(){StringBuilder s=new StringBuilder("Активно: ");if(recorders.isEmpty())s.append("нет станций");else{boolean first=true;for(Recorder r:recorders.values()){if(!first)s.append(" • ");s.append(r.name);first=false;}}((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(1,notification(s.toString(),null));}

    private class Recorder extends Thread {
        final int id; volatile String name; final String url; final boolean autoName; volatile boolean stopping=false; volatile Writer activeWriter; volatile HttpURLConnection connection;
        final SharedPreferences p=getSharedPreferences("radio_prefs",MODE_PRIVATE); final Set<Writer> writers=ConcurrentHashMap.newKeySet();
        Recorder(int i,String n,String u,boolean auto){super("Radio-"+i);id=i;name=n;url=u;autoName=auto;}
        String key(String base){return base+"_"+id;} double ringSec(){return getD(key("station_ring_seconds"),8);} double overlapSec(){return getD(key("station_overlap_seconds"),1);} double postSec(){return getD(key("station_postroll_seconds"),7);} int kbps(){return getI(key("station_bitrate_kbps"),192);} String target(){return p.getString(key("station_meta_target"),"").trim();}
        boolean matchesTarget(String title,String wanted){if(wanted==null||wanted.trim().isEmpty())return true;String x=normalizeTitle(title);String mode=p.getString(key("station_meta_mode"),"contains");String[] parts=wanted.split("[,;]");if("exact".equals(mode)) for(String part:parts) if(x.equals(normalizeTitle(part))) return true; if("all".equals(mode)){for(String part:parts){String q=normalizeTitle(part);if(!q.isEmpty()&&!x.contains(q))return false;}return true;} for(String part:parts){String q=normalizeTitle(part);if(!q.isEmpty()&&x.contains(q))return true;}return false;}
        boolean skipDuplicates(){return p.getBoolean(key("station_skip_duplicates"),true);}
        String normalizeTitle(String t){return t==null?"":t.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+"," ").trim().replaceAll("\\s+"," ");}
        boolean isDuplicateTrack(String t){
            if(!skipDuplicates()) return false;
            String n=normalizeTitle(t); if(n.isEmpty()) return false;
            Set<String> seen=new HashSet<>(p.getStringSet(key("recorded_titles"),Collections.emptySet()));
            if(seen.contains(n)) return true;
            for(Writer w:writers)if(!w.done && normalizeTitle(w.title).equals(n))return true;
            return hasExistingTrack(t);
        }
        void rememberTrack(String t){
            if(!skipDuplicates()) return;
            String n=normalizeTitle(t); if(n.isEmpty()) return;
            Set<String> seen=new HashSet<>(p.getStringSet(key("recorded_titles"),Collections.emptySet()));
            seen.add(n); if(seen.size()>500){Iterator<String> it=seen.iterator();while(seen.size()>450&&it.hasNext()){it.next();it.remove();}}
            p.edit().putStringSet(key("recorded_titles"),seen).apply();
        }
        boolean hasExistingTrack(String t){
            if(Build.VERSION.SDK_INT<29)return false;
            android.database.Cursor c=null;
            try{
                String path=folderPath(name);
                c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media.DISPLAY_NAME},MediaStore.Audio.Media.RELATIVE_PATH+"=?",new String[]{path},null);
                String base=normalizeTitle(t);
                if(c!=null)while(c.moveToNext()){
                    String fn=c.getString(0); if(fn==null)continue;
                    String x=fn.endsWith(".mp3")?fn.substring(0,fn.length()-4):fn;
                    x=x.replaceAll(" \\(\\d+\\)$","");
                    if(normalizeTitle(x).equals(base))return true;
                }
            }catch(Exception ignored){}finally{if(c!=null)c.close();}
            return false;
        }
        double getD(String k,double d){try{return Double.parseDouble(p.getString(k,String.valueOf(d)));}catch(Exception e){return d;}} int getI(String k,int d){try{return Integer.parseInt(p.getString(k,String.valueOf(d)));}catch(Exception e){return d;}}
        void requestStop(){if(stopping)return;stopping=true;for(Writer w:new ArrayList<>(writers))w.deleteNow();activeWriter=null;HttpURLConnection cc=connection;if(cc!=null)cc.disconnect();broadcast("Остановлено — незаконченная запись удалена",null);}
        void broadcast(String status,String track){Intent i=new Intent(ACTION_STATUS);i.setPackage(getPackageName());i.putExtra("station_id",id);i.putExtra("station_name",name);i.putExtra("status",status);i.putExtra("track",track==null?"":track);sendBroadcast(i);}
        void songNotification(String track){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.notify(1000+id,notification(name,track));}
        @Override public void run(){
            int attempt=0;
            while(!stopping){
                HttpURLConnection c=null;
                try{
                    c=(HttpURLConnection)new URL(url).openConnection(); connection=c;
                    c.setConnectTimeout(30000); c.setReadTimeout(15000); c.setRequestProperty("Icy-MetaData","1"); c.setRequestProperty("User-Agent","RadioRecorder/3.0"); c.connect();
                    if(c.getResponseCode()<200||c.getResponseCode()>=400) throw new IOException("HTTP "+c.getResponseCode());
                    if(autoName){String icy=c.getHeaderField("icy-name");if(icy!=null&&!icy.trim().isEmpty()){name=icy.trim();p.edit().putString("station_name_"+id,name).apply();}else if(name==null||name.isEmpty())name=deriveName(url);}
                    deleteStalePending(name);
                    int mi=c.getHeaderFieldInt("icy-metaint",16000); if(mi<=0)mi=16000;
                    attempt=0; broadcast("Подключено • "+c.getHeaderField("icy-br")+" kbps • ждём StreamTitle…",null);
                    recordStream(c.getInputStream(),mi);
                    if(stopping) break;
                    broadcast("Поток завершился — переподключение…",null);
                }catch(Exception e){
                    if(stopping) break; attempt++; broadcast("Нет потока • попытка "+attempt+"/10",null);
                    if(attempt>=10) break;
                }finally{if(c!=null)c.disconnect();connection=null;}
                try{Thread.sleep(Math.min(30000,3000L*attempt));}catch(InterruptedException e){Thread.currentThread().interrupt();break;}
            }
            activeWriter=null; stationFinished(id);
        }

        void recordStream(InputStream in,int metaInt)throws Exception{
            int bitrate=kbps();int ringBytes=Math.max(1,(int)(bitrate*1000.0/8*ringSec()));int overlapBytes=Math.max(0,(int)(bitrate*1000.0/8*overlapSec()));Ring ring=new Ring(ringBytes);byte[] buf=new byte[8192];
            String title=null;Writer current=null;ArrayList<Writer> pending=new ArrayList<>();String wanted=target();int until=metaInt;long totalBytes=0;long startedAt=System.currentTimeMillis();
            if(!wanted.isEmpty())broadcast("Ждём метаданные: "+wanted,null);
            while(true){
                if(stopping)return;int want=Math.min(buf.length,until);int n=in.read(buf,0,want);if(n<0)break;if(n==0)continue;byte[] chunk=Arrays.copyOf(buf,n);ring.add(chunk); totalBytes+=n;
                if(current!=null)current.feed(chunk);for(Writer w:pending)w.feed(chunk);for(int i=pending.size()-1;i>=0;i--)if(pending.get(i).done)pending.remove(i);
                if(current!=null && System.currentTimeMillis()-startedAt>1000){double sec=(System.currentTimeMillis()-startedAt)/1000.0;double kbpsNow=(totalBytes*8.0/sec)/1000.0;broadcast(String.format(Locale.US,"Записывается • %.0f кбит/с • %.1f MB",kbpsNow,totalBytes/1048576.0),current.title);}
                until-=n;if(until==0){int lb=in.read();if(lb<0)break;int ml=lb*16;if(ml>0){byte[] m=new byte[ml];readFully(in,m);String t=parseTitle(m);if(t!=null&&!t.isEmpty()){
                    boolean match=matchesTarget(t,wanted);
                    if(title==null){
                        title=t; songNotification(t);
                        if(wanted.isEmpty()){
                            if(isDuplicateTrack(t)) { current=null; broadcast("Дубликат пропущен",t); }
                            else { current=newWriter(t,ring,overlapBytes); broadcast("Записывается",t); }
                        } else {
                            if(match && !isDuplicateTrack(t)){ current=newWriter(t,ring,overlapBytes); broadcast("Найдено совпадение — запись начата",t); }
                            else if(match){ current=null; broadcast("Дубликат пропущен",t); }
                            else broadcast("Ждём метаданные: "+wanted,t);
                        }
                    }
                    else if(!t.equals(title)){
                        if(current!=null){current.startPostSeconds(postSec());pending.add(current);broadcast("Трек завершён, post-roll "+postSec()+" с",current.title);}
                        title=t; songNotification(t);
                        boolean dup=isDuplicateTrack(t);
                        if(wanted.isEmpty()){
                            if(dup){current=null;broadcast("Дубликат пропущен",t);}else{current=newWriter(t,ring,overlapBytes);broadcast("Записывается",t);}
                        }else if(match){
                            if(dup){current=null;broadcast("Дубликат пропущен",t);}else{current=newWriter(t,ring,overlapBytes);broadcast("Найдено совпадение — запись начата",t);}
                        }else{current=null;broadcast("Ожидание метаданных: "+wanted,t);}
                    }
                }}until=metaInt;}
            }
            if(current!=null&&!stopping)current.finish();for(Writer w:pending)if(!w.done)w.finish();
        }
        Writer newWriter(String t,Ring ring,int overlapBytes)throws IOException{Writer w=new Writer(t);writers.add(w);activeWriter=w;byte[] h=findFrame(ring.tail(overlapBytes));if(h.length>0)w.initial(h);return w;}
        void readFully(InputStream in,byte[] b)throws IOException{int x=0;while(x<b.length){int n=in.read(b,x,b.length-x);if(n<0)throw new EOFException();x+=n;}}
        String parseTitle(byte[] b){String a=new String(b,StandardCharsets.UTF_8),t=extract(a);if(t!=null&&!t.contains("\uFFFD"))return t;return extract(new String(b,StandardCharsets.ISO_8859_1));}
        String extract(String s){int p=s.indexOf("StreamTitle='");char q='\'';if(p<0){p=s.indexOf("StreamTitle=\"");q='"';}if(p<0)return null;int st=p+12;if(st>=s.length())return null;if(s.charAt(st)=='\''||s.charAt(st)=='"')q=s.charAt(st);else return null;int en=s.indexOf(q,st+1);return en<0?null:s.substring(st+1,en).trim();}
        byte[] findFrame(byte[] d){for(int i=0;i+4<d.length;i++){int a=frameLen(d,i);if(a<0||i+a+4>=d.length)continue;int b=frameLen(d,i+a);if(b<0)continue;int c=frameLen(d,i+a+b);if(c<0)continue;return Arrays.copyOfRange(d,i,d.length);}return new byte[0];}
        int frameLen(byte[] b,int p){if(p+4>b.length)return -1;int h=(b[p]&255)<<24|(b[p+1]&255)<<16|(b[p+2]&255)<<8|(b[p+3]&255);if((h&0xFFE00000)!=0xFFE00000)return -1;int v=(h>>>19)&3,l=(h>>>17)&3,bi=(h>>>12)&15,si=(h>>>10)&3,pad=(h>>>9)&1;if(v==1||l!=1||bi==0||bi==15||si==3)return -1;int[] x={0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0};int[] y={0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,0};int br=v==3?x[bi]:y[bi];int[] r1={44100,48000,32000},r2={22050,24000,16000},r25={11025,12000,8000};int sr=v==3?r1[si]:v==2?r2[si]:r25[si];if(br<=0||sr<=0)return -1;return (v==3?144000:72000)*br/sr+pad;}

        class Writer{
            final String title;Uri uri;OutputStream out;int remain;boolean done;
            Writer(String t)throws IOException{title=t;open();}
            void open()throws IOException{ContentValues v=new ContentValues();v.put(MediaStore.Audio.Media.DISPLAY_NAME,uniqueName(title));v.put(MediaStore.Audio.Media.MIME_TYPE,"audio/mpeg");if(Build.VERSION.SDK_INT>=29){v.put(MediaStore.Audio.Media.RELATIVE_PATH,folderPath(name));v.put(MediaStore.Audio.Media.IS_PENDING,1);}uri=getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new IOException("MediaStore insert failed");out=getContentResolver().openOutputStream(uri);if(out==null)throw new IOException("Output stream failed");}
            void initial(byte[] b){try{if(!done){out.write(b);out.flush();}}catch(IOException e){deleteNow();}}
            void feed(byte[] b){if(done)return;try{if(remain>0){int n=Math.min(remain,b.length);out.write(b,0,n);remain-=n;if(remain==0)finish();}else out.write(b);out.flush();}catch(IOException e){deleteNow();}}
            void startPostSeconds(double sec){if(done)return;remain=Math.max(0,(int)(kbps()*1000.0/8.0*Math.max(0,sec)));if(remain==0)finish();}
            void deleteNow(){if(done)return;done=true;try{if(out!=null)out.close();}catch(Exception ignored){}if(uri!=null)try{getContentResolver().delete(uri,null,null);}catch(Exception ignored){}writers.remove(this);}
            void finish(){if(done)return;done=true;try{out.close();}catch(Exception ignored){}if(Build.VERSION.SDK_INT>=29&&uri!=null){ContentValues v=new ContentValues();v.put(MediaStore.Audio.Media.IS_PENDING,0);getContentResolver().update(uri,v,null,null);}rememberTrack(title);writers.remove(this);}
            String uniqueName(String t){String s=safe(t);String c=s+".mp3";int n=2;while(exists(c)){c=s+" ("+n+").mp3";n++;}return c;}
        }
        boolean exists(String n){android.database.Cursor c=null;try{String path=folderPath(name);if(Build.VERSION.SDK_INT>=29)c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media.DISPLAY_NAME},MediaStore.Audio.Media.DISPLAY_NAME+"=? AND "+MediaStore.Audio.Media.RELATIVE_PATH+"=?",new String[]{n,path},null);else c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media.DISPLAY_NAME},MediaStore.Audio.Media.DISPLAY_NAME+"=?",new String[]{n},null);return c!=null&&c.moveToFirst();}finally{if(c!=null)c.close();}}
    }

    static String safe(String s){String x=s.replaceAll("[\\\\/:*?\"<>|]","_").replaceAll("\\s+"," ").trim();return x.isEmpty()?"Unknown":x;}
    static String safeFolder(String s){return safe(s).replace(".","_");}
    static class Ring{final int max;final ByteArrayOutputStream b=new ByteArrayOutputStream();Ring(int m){max=Math.max(1,m);}synchronized void add(byte[] d){try{b.write(d);byte[] a=b.toByteArray();if(a.length>max){b.reset();b.write(a,a.length-max,max);}}catch(Exception ignored){}}synchronized byte[] tail(int n){byte[] a=b.toByteArray();int k=Math.min(Math.max(0,n),a.length);return Arrays.copyOfRange(a,a.length-k,a.length);}}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CH,"Радио — новые песни",NotificationManager.IMPORTANCE_DEFAULT);c.setDescription("Уведомления о новых названиях песен и записи");getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    private Notification notification(String title,String text){Intent i=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH):new Notification.Builder(this);b.setContentTitle(title).setContentText(text==null?"":text).setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).setOngoing(text==null);return b.build();}
    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){for(Recorder r:recorders.values())r.requestStop();if(lock!=null&&lock.isHeld())lock.release();super.onDestroy();}
}
