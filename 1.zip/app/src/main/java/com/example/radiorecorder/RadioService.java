package com.example.radiorecorder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.MediaStore;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Queue;
import java.util.regex.Pattern;

public class RadioService extends Service {
    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";

    private static final String RADIO_URL = "https://play.prod.iziyo.xyz/radio-restreamer/s132-8020/";
    private static final int BITRATE_KBPS = 192;
    private static final int READ_SIZE = 8192;

    // ТОЧНЫЕ НАСТРОЙКИ:
    // Внутренний буфер
    private static final double RING_BUFFER_SECONDS = 8.0;

    // Сколько секунд из буфера добавлять в начало новой песни
    private static final double OVERLAP_SECONDS = 1.0;

    // Сколько секунд продолжать старую песню после нового StreamTitle
    private static final double POSTROLL_SECONDS = 7.0;

    private static final int RING_BYTES =
            (int)(BITRATE_KBPS * 1000.0 / 8.0 * RING_BUFFER_SECONDS);
    private static final int OVERLAP_BYTES =
            (int)(BITRATE_KBPS * 1000.0 / 8.0 * OVERLAP_SECONDS);
    private static final int POSTROLL_BYTES =
            (int)(BITRATE_KBPS * 1000.0 / 8.0 * POSTROLL_SECONDS);

    private static final String CHANNEL_ID = "radio_recording";
    private volatile boolean running;
    private Thread worker;
    private PowerManager.WakeLock wakeLock;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_STOP.equals(action)) {
            stopRecording();
            return START_NOT_STICKY;
        }

        if (ACTION_START.equals(action) && !running) {
            startForeground(1, notification("Подключение к радио…"));
            startRecording();
        }
        return START_STICKY;
    }

    private void startRecording() {
        running = true;

        PowerManager pm = (PowerManager)getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "RadioRecorder:Recording"
            );
            wakeLock.acquire();
        }

        worker = new Thread(this::recordLoop, "RadioRecorder");
        worker.start();
    }

    private void stopRecording() {
        running = false;
        if (worker != null) worker.interrupt();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        stopForeground(true);
        stopSelf();
    }

    private void recordLoop() {
        while (running) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(RADIO_URL);
                conn = (HttpURLConnection)url.openConnection();
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(120000);
                conn.setRequestProperty("Icy-MetaData", "1");
                conn.setRequestProperty("User-Agent", "RadioRecorder/1.0");
                conn.connect();

                int metaInt = conn.getHeaderFieldInt("icy-metaint", -1);
                if (metaInt <= 0) metaInt = 16000;

                updateNotification("Запись: подключено");

                InputStream in = conn.getInputStream();
                recordStream(in, metaInt);
            } catch (Exception e) {
                updateNotification("Ошибка соединения, переподключение…");
                try { Thread.sleep(3000); } catch (InterruptedException ignored) {}
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
    }

    private void recordStream(InputStream in, int metaInt) throws Exception {
        Ring ring = new Ring(RING_BYTES);
        byte[] audio = new byte[READ_SIZE];
        String currentTitle = null;
        SongWriter current = null;
        ArrayList<SongWriter> pending = new ArrayList<>();
        int audioUntilMeta = metaInt;

        while (running) {
            int want = Math.min(audio.length, audioUntilMeta);
            int n = readFullySome(in, audio, 0, want);
            if (n < 0) break;
            if (n == 0) continue;

            byte[] chunk = copyOf(audio, n);
            ring.add(chunk);

            if (current != null) current.feed(chunk);
            for (SongWriter w : pending) w.feed(chunk);
            processPending(pending);

            audioUntilMeta -= n;
            if (audioUntilMeta == 0) {
                int metaLenByte = in.read();
                if (metaLenByte < 0) break;

                int metaLen = metaLenByte * 16;
                if (metaLen > 0) {
                    byte[] meta = new byte[metaLen];
                    readFully(in, meta, 0, metaLen);
                    String title = parseStreamTitle(meta);

                    if (title != null && !title.isEmpty()) {
                        if (currentTitle == null) {
                            // Первый StreamTitle только запоминаем.
                            currentTitle = title;
                            updateNotification("Первый трек: " + title);
                        } else if (!title.equals(currentTitle)) {
                            // Старый трек продолжает записываться ещё POSTROLL_SECONDS.
                            if (current != null) {
                                pending.add(current);
                                current.startPostroll();
                            }

                            // Новый трек получает последние OVERLAP_SECONDS из кольцевого буфера.
                            byte[] history = ring.tail(OVERLAP_BYTES);
                            current = new SongWriter(this, title);

                            byte[] frameHistory = findMp3Frame(history);
                            if (frameHistory.length > 0) {
                                current.writeInitial(frameHistory);
                            }

                            currentTitle = title;
                            updateNotification("Новый трек: " + title);
                        }
                    }
                }
                audioUntilMeta = metaInt;
            }
        }

        if (current != null) current.finishNow();
        for (SongWriter w : pending) w.finishNow();
    }

    private void processPending(ArrayList<SongWriter> pending) {
        for (int i = pending.size() - 1; i >= 0; i--) {
            if (pending.get(i).isDone()) pending.remove(i);
        }
    }

    private static int readFullySome(InputStream in, byte[] b, int off, int len)
            throws IOException {
        int n = in.read(b, off, len);
        return n;
    }

    private static void readFully(InputStream in, byte[] b, int off, int len)
            throws IOException {
        int done = 0;
        while (done < len) {
            int n = in.read(b, off + done, len - done);
            if (n < 0) throw new IOException("EOF");
            done += n;
        }
    }

    private static byte[] copyOf(byte[] src, int len) {
        byte[] out = new byte[len];
        System.arraycopy(src, 0, out, 0, len);
        return out;
    }

    private static String parseStreamTitle(byte[] meta) {
        String s = new String(meta, StandardCharsets.ISO_8859_1);
        int p = s.indexOf("StreamTitle='");
        if (p < 0) p = s.indexOf("StreamTitle=\"");
        if (p < 0) return null;

        int start = p + "StreamTitle=".length();
        if (start >= s.length()) return null;
        char quote = s.charAt(start);
        if (quote != '\'' && quote != '"') return null;

        int end = s.indexOf(quote, start + 1);
        if (end < 0) return null;

        return s.substring(start + 1, end).trim();
    }

    private static byte[] findMp3Frame(byte[] data) {
        for (int i = 0; i + 417 < data.length; i++) {
            int len1 = mp3FrameLength(data, i);
            if (len1 <= 0 || i + len1 + 4 >= data.length) continue;

            int len2 = mp3FrameLength(data, i + len1);
            if (len2 <= 0) continue;

            int len3 = mp3FrameLength(data, i + len1 + len2);
            if (len3 <= 0) continue;

            byte[] out = new byte[data.length - i];
            System.arraycopy(data, i, out, 0, out.length);
            return out;
        }
        return new byte[0];
    }

    private static int mp3FrameLength(byte[] b, int p) {
        if (p + 4 > b.length) return -1;
        int h = (b[p] & 255) << 24 |
                (b[p + 1] & 255) << 16 |
                (b[p + 2] & 255) << 8 |
                (b[p + 3] & 255);

        if ((h & 0xFFE00000) != 0xFFE00000) return -1;

        int version = (h >>> 19) & 3;
        int layer = (h >>> 17) & 3;
        int bitrateIndex = (h >>> 12) & 15;
        int sampleIndex = (h >>> 10) & 3;
        int padding = (h >>> 9) & 1;

        if (version == 1 || layer != 1 || bitrateIndex == 0 ||
                bitrateIndex == 15 || sampleIndex == 3) return -1;

        int[] brV1L3 = {0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0};
        int[] brV2L3 = {0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,0};
        int[] ratesV1 = {44100,48000,32000};
        int[] ratesV2 = {22050,24000,16000};
        int[] ratesV25 = {11025,12000,8000};

        int kbps;
        int sampleRate;
        if (version == 3) {
            kbps = brV1L3[bitrateIndex];
            sampleRate = ratesV1[sampleIndex];
        } else if (version == 2) {
            kbps = brV2L3[bitrateIndex];
            sampleRate = ratesV2[sampleIndex];
        } else {
            kbps = brV2L3[bitrateIndex];
            sampleRate = ratesV25[sampleIndex];
        }

        if (kbps <= 0 || sampleRate <= 0) return -1;

        return (version == 3 ? 144000 : 72000) * kbps / sampleRate + padding;
    }

    private static class Ring {
        private final int max;
        private final ByteArrayOutputStream buf = new ByteArrayOutputStream();

        Ring(int max) { this.max = max; }

        synchronized void add(byte[] data) {
            try {
                buf.write(data);
                byte[] all = buf.toByteArray();
                if (all.length > max) {
                    int keep = Math.min(max, all.length);
                    buf.reset();
                    buf.write(all, all.length - keep, keep);
                }
            } catch (IOException ignored) {}
        }

        synchronized byte[] tail(int n) {
            byte[] all = buf.toByteArray();
            int take = Math.min(n, all.length);
            byte[] out = new byte[take];
            System.arraycopy(all, all.length - take, out, 0, take);
            return out;
        }
    }

    private static class SongWriter {
        private final RadioService service;
        private final String title;
        private Uri uri;
        private OutputStream out;
        private int remainingPostroll = 0;
        private boolean done = false;

        SongWriter(RadioService service, String title) throws IOException {
            this.service = service;
            this.title = title;
            open();
        }

        private void open() throws IOException {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Audio.Media.DISPLAY_NAME,
                    uniqueName(service, title));
            values.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Radio");
                values.put(MediaStore.Audio.Media.IS_PENDING, 1);
            }

            uri = service.getContentResolver().insert(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values);

            if (uri == null) throw new IOException("Cannot create MediaStore item");
            out = service.getContentResolver().openOutputStream(uri);
            if (out == null) throw new IOException("Cannot open output stream");
        }

        void writeInitial(byte[] data) {
            try {
                out.write(data);
                out.flush();
            } catch (IOException ignored) {}
        }

        void feed(byte[] data) {
            if (done) return;
            try {
                if (remainingPostroll > 0) {
                    int take = Math.min(remainingPostroll, data.length);
                    out.write(data, 0, take);
                    remainingPostroll -= take;
                    if (remainingPostroll == 0) finishNow();
                } else {
                    out.write(data);
                }
            } catch (IOException e) {
                finishNow();
            }
        }

        void startPostroll() {
            remainingPostroll = POSTROLL_BYTES;
        }

        boolean isDone() { return done; }

        void finishNow() {
            if (done) return;
            done = true;
            try {
                if (out != null) out.close();
            } catch (IOException ignored) {}

            if (Build.VERSION.SDK_INT >= 29 && uri != null) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Audio.Media.IS_PENDING, 0);
                service.getContentResolver().update(uri, values, null, null);
            }
        }
    }

    private static String uniqueName(RadioService service, String title) {
        String safe = title.replaceAll("[\\\\/:*?\"<>|]", "_")
                .replaceAll("\\s+", " ").trim();
        if (safe.isEmpty()) safe = "Unknown";

        String base = safe;
        String candidate = base + ".mp3";
        int n = 2;

        while (exists(service, candidate)) {
            candidate = base + " (" + n + ").mp3";
            n++;
        }
        return candidate;
    }

    private static boolean exists(RadioService service, String name) {
        android.database.Cursor c = null;
        try {
            c = service.getContentResolver().query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Audio.Media.DISPLAY_NAME},
                    MediaStore.Audio.Media.DISPLAY_NAME + "=?",
                    new String[]{name},
                    null
            );
            return c != null && c.moveToFirst();
        } finally {
            if (c != null) c.close();
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Radio recording",
                    NotificationManager.IMPORTANCE_LOW
            );
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification notification(String text) {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT |
                        (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0)
        );

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return b.setContentTitle("Radio Recorder")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(1, notification(text));
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        running = false;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }
}
