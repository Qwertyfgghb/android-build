package com.example.radiorecorder;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class RadioService extends Service {
    public static final String ACTION_START_STATION="START_STATION", ACTION_STOP_STATION="STOP_STATION", ACTION_STOP_ALL="STOP_ALL";
    public static final String ACTION_STATUS="com.example.radiorecorder.STATUS";
    private static final String CH="radio_recording";
    private final Map<Integer,Recorder> recorders=new ConcurrentHashMap<>();
    private PowerManager.WakeLock lock;

    @Override public void onCreate(){ super.onCreate(); createChannel(); }

    @Override public int onStartCommand(Intent in,int flags,int id){
        String a=in==null?null:in.getAction();
        if(ACTION_START_STATION.equals(a)){
            ensureForeground();
            int sid=in.getIntExtra("station_id",0);
            startStation(sid,in.getStringExtra("station_name"),in.getStringExtra("station_url"));
        } else if(ACTION_STOP_STATION.equals(a)){
            stopStation(in.getIntExtra("station_id",0));
        } else if(ACTION_STOP_ALL.equals(a)){
            for(Recorder r:recorders.values()) r.requestStop();
        }
        return START_STICKY;
    }

    private void ensureForeground(){
        if(lock==null){
            startForeground(1,notification("Подготовка…"));
            PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
            if(pm!=null){ lock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"RadioRecorder:Recording"); lock.acquire(); }
        }
    }

    private void startStation(int id,String name,String url){
        if(name==null||name.trim().isEmpty()) name="Радио "+(char)('A'+Math.max(0,Math.min(25,id)));
        if(url==null||url.trim().isEmpty()) return;
        if(recorders.containsKey(id)) return;
        deleteStalePending(name);
        Recorder r=new Recorder(id,name,url); recorders.put(id,r); r.start(); updateNotification();
    }

    private void deleteStalePending(String stationName){
        if(Build.VERSION.SDK_INT<29) return;
        android.database.Cursor c=null;
        try{
            String path="Music/Radio/"+safeFolder(stationName)+"/";
            c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Audio.Media._ID},
                    MediaStore.Audio.Media.IS_PENDING+"=1 AND "+MediaStore.Audio.Media.RELATIVE_PATH+"=?",
                    new String[]{path},null);
            if(c!=null){
                while(c.moveToNext()){
                    long id=c.getLong(0);
                    Uri u=ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,id);
                    getContentResolver().delete(u,null,null);
                }
            }
        }catch(Exception ignored){} finally{if(c!=null)c.close();}
    }

    private void stopStation(int id){ Recorder r=recorders.get(id); if(r!=null) r.requestStop(); }

    private void stationFinished(int id){
        recorders.remove(id); updateNotification();
        if(recorders.isEmpty()){
            if(lock!=null&&lock.isHeld()){ lock.release(); lock=null; }
            stopForeground(true); stopSelf();
        }
    }

    private void updateNotification(){
        StringBuilder s=new StringBuilder("Запись: ");
        if(recorders.isEmpty()) s.append("нет активных станций");
        else { boolean first=true; for(Recorder r:recorders.values()){ if(!first)s.append(", "); s.append(r.name); first=false; } }
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(1,notification(s.toString()));
    }

    private class Recorder extends Thread {
        final int id; final String name,url; volatile boolean stopping=false; volatile Writer activeWriter; volatile HttpURLConnection connection;
        final SharedPreferences p=getSharedPreferences("radio_prefs",MODE_PRIVATE);
        final Set<Writer> writers=ConcurrentHashMap.newKeySet();
        Recorder(int i,String n,String u){super("Radio-"+i);id=i;name=n;url=u;}

        String key(String base){ return base+"_"+id; }
        double ringSec(){return getD(key("station_ring_seconds"),8);}
        double overlapSec(){return getD(key("station_overlap_seconds"),1);}
        double postSec(){return getD(key("station_postroll_seconds"),7);}
        int kbps(){return getI(key("station_bitrate_kbps"),192);}
        double getD(String k,double d){try{return Double.parseDouble(p.getString(k,String.valueOf(d)));}catch(Exception e){return d;}}
        int getI(String k,int d){try{return Integer.parseInt(p.getString(k,String.valueOf(d)));}catch(Exception e){return d;}}

        void requestStop(){
            if(stopping) return;
            stopping=true;
            // При ручном Stop ВСЕ незаконченные записи этой станции удаляем сразу.
            // Это включает текущий трек и треки, которые ещё находились в post-roll.
            for(Writer w:new ArrayList<>(writers)) w.deleteNow();
            activeWriter=null;
            HttpURLConnection cc=connection;
            if(cc!=null) cc.disconnect();
            broadcast("Остановлено: незаконченные треки удалены",null);
        }

        String formatSec(double v){return String.format(Locale.US,"%.1f",v).replace(".0","");}

        void broadcast(String status,String track){
            Intent i=new Intent(ACTION_STATUS); i.setPackage(getPackageName());
            i.putExtra("station_id",id); i.putExtra("station_name",name);
            i.putExtra("status",status); i.putExtra("track",track==null?"":track);
            sendBroadcast(i);
        }

        @Override public void run(){
            HttpURLConnection c=null;
            try{
                c=(HttpURLConnection)new URL(url).openConnection();
                connection=c;
                c.setConnectTimeout(30000); c.setReadTimeout(15000);
                c.setRequestProperty("Icy-MetaData","1"); c.setRequestProperty("User-Agent","RadioRecorder/1.0"); c.connect();
                int mi=c.getHeaderFieldInt("icy-metaint",16000); if(mi<=0)mi=16000;
                broadcast("Подключено. Ожидание названия трека…",null);
                recordStream(c.getInputStream(),mi);
            }catch(Exception e){
                if(!stopping) broadcast("Ошибка: "+(e.getMessage()==null?"соединение":e.getMessage()),null);
            }finally{
                if(c!=null)c.disconnect();
                connection=null;
                activeWriter=null;
                stationFinished(id);
            }
        }

        void recordStream(InputStream in,int metaInt)throws Exception{
            int bitrate=kbps();
            int ringBytes=Math.max(1,(int)(bitrate*1000.0/8*ringSec()));
            int overlapBytes=Math.max(0,(int)(bitrate*1000.0/8*overlapSec()));
            int normalPostBytes=Math.max(0,(int)(bitrate*1000.0/8*postSec()));

            Ring ring=new Ring(ringBytes); byte[] buf=new byte[8192];
            String title=null; Writer current=null; ArrayList<Writer> pending=new ArrayList<>();
            int until=metaInt;

            while(true){
                if(stopping) return;

                int want=Math.min(buf.length,until);
                int n=in.read(buf,0,want);
                if(n<0) break;
                if(n==0) continue;
                byte[] chunk=Arrays.copyOf(buf,n); ring.add(chunk);

                if(current!=null) current.feed(chunk);
                for(Writer w:pending) w.feed(chunk);
                for(int i=pending.size()-1;i>=0;i--) if(pending.get(i).done) pending.remove(i);

                if(current!=null) broadcast("Записывается",current.title);

                until-=n;
                if(until==0){
                    int lb=in.read();
                    if(lb<0) break;
                    int ml=lb*16;
                    if(ml>0){
                        byte[] m=new byte[ml]; readFully(in,m); String t=parseTitle(m);
                        if(t!=null&&!t.isEmpty()){
                            if(title==null){
                                title=t; broadcast("Первый трек запомнен — ждём следующую смену",t);
                            } else if(!t.equals(title)){
                                if(current!=null){
                                    current.startPostSeconds(postSec());
                                    pending.add(current);
                                    broadcast(stopping ? "Стоп: название изменилось, дописываем текущий трек" : "Трек завершён, дописываем post-roll",current.title);
                                }
                                title=t;
                                current=new Writer(t);
                                writers.add(current);
                                activeWriter=current;
                                byte[] h=findFrame(ring.tail(overlapBytes)); if(h.length>0) current.initial(h);
                                broadcast("Записывается",t);
                            }
                        }
                    }
                    until=metaInt;
                }
            }

            if(current!=null){
                if(!stopping) current.finish();
            }
            for(Writer w:pending){ if(!w.done) w.finish(); }
        }

        void readFully(InputStream in,byte[] b)throws IOException{int x=0;while(x<b.length){int n=in.read(b,x,b.length-x);if(n<0)throw new EOFException();x+=n;}}
        String parseTitle(byte[] b){String a=new String(b,StandardCharsets.UTF_8),t=extract(a);if(t!=null&&!t.contains("\uFFFD"))return t;return extract(new String(b,StandardCharsets.ISO_8859_1));}
        String extract(String s){int p=s.indexOf("StreamTitle='");char q='\'';if(p<0){p=s.indexOf("StreamTitle=\"");q='"';}if(p<0)return null;int st=p+12;if(st>=s.length())return null;if(s.charAt(st)=='\''||s.charAt(st)=='"')q=s.charAt(st);else return null;int en=s.indexOf(q,st+1);return en<0?null:s.substring(st+1,en).trim();}
        byte[] findFrame(byte[] d){for(int i=0;i+4<d.length;i++){int a=frameLen(d,i);if(a<0||i+a+4>=d.length)continue;int b=frameLen(d,i+a);if(b<0)continue;int c=frameLen(d,i+a+b);if(c<0)continue;return Arrays.copyOfRange(d,i,d.length);}return new byte[0];}
        int frameLen(byte[] b,int p){if(p+4>b.length)return -1;int h=(b[p]&255)<<24|(b[p+1]&255)<<16|(b[p+2]&255)<<8|(b[p+3]&255);if((h&0xFFE00000)!=0xFFE00000)return -1;int v=(h>>>19)&3,l=(h>>>17)&3,bi=(h>>>12)&15,si=(h>>>10)&3,pad=(h>>>9)&1;if(v==1||l!=1||bi==0||bi==15||si==3)return -1;int[] x={0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0};int[] y={0,8,16,24,32,40,48,56,64,80,96,112,128,144,160,0};int br=v==3?x[bi]:y[bi];int[] r1={44100,48000,32000},r2={22050,24000,16000},r25={11025,12000,8000};int sr=v==3?r1[si]:v==2?r2[si]:r25[si];if(br<=0||sr<=0)return -1;return (v==3?144000:72000)*br/sr+pad;}

        class Writer{
            final String title; Uri uri; OutputStream out; int remain; boolean done; long postReceived=0; double stopSeconds=0; long postStartMs=0;
            Writer(String t)throws IOException{title=t;open();}
            void open()throws IOException{
                ContentValues v=new ContentValues(); v.put(MediaStore.Audio.Media.DISPLAY_NAME,uniqueName(title)); v.put(MediaStore.Audio.Media.MIME_TYPE,"audio/mpeg");
                if(Build.VERSION.SDK_INT>=29){v.put(MediaStore.Audio.Media.RELATIVE_PATH,"Music/Radio/"+safeFolder(name));v.put(MediaStore.Audio.Media.IS_PENDING,1);}
                uri=getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,v); if(uri==null)throw new IOException("MediaStore insert failed");
                out=getContentResolver().openOutputStream(uri); if(out==null)throw new IOException("Output stream failed");
            }
            void initial(byte[] b){try{if(!done){out.write(b);out.flush();}}catch(IOException e){finish();}}
            void feed(byte[] b){
                if(done)return;
                try{
                    if(remain>0){
                        int n=Math.min(remain,b.length);
                        out.write(b,0,n);
                        postReceived+=n;
                        remain-=n;
                        if(remain==0)finish();
                    } else out.write(b);
                    out.flush();
                }catch(IOException e){finish();}
            }
            void startPost(int n){if(!done){remain=Math.max(remain,n);postReceived=0;}}
            void startPostSeconds(double sec){
                if(done)return;
                stopSeconds=Math.max(0,sec);
                postStartMs=System.currentTimeMillis();
                postReceived=0;
                remain=Math.max(0,(int)(kbps()*1000.0/8.0*stopSeconds));
                if(remain==0) finish();
            }
            void deleteNow(){
                if(done)return;
                done=true;
                try{if(out!=null)out.close();}catch(Exception ignored){}
                if(uri!=null){
                    try{getContentResolver().delete(uri,null,null);}catch(Exception ignored){}
                }
                writers.remove(this);
            }
            void finish(){
                if(done)return;
                done=true;
                try{out.close();}catch(Exception ignored){}
                if(Build.VERSION.SDK_INT>=29&&uri!=null){
                    ContentValues v=new ContentValues();
                    v.put(MediaStore.Audio.Media.IS_PENDING,0);
                    getContentResolver().update(uri,v,null,null);
                }
                writers.remove(this);
            }
            String uniqueName(String t){String s=safe(t);String c=s+".mp3";int n=2;while(exists(c)){c=s+" ("+n+").mp3";n++;}return c;}
        }
        boolean exists(String n){android.database.Cursor c=null;try{String path="Music/Radio/"+safeFolder(name);if(Build.VERSION.SDK_INT>=29){c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media.DISPLAY_NAME},MediaStore.Audio.Media.DISPLAY_NAME+"=? AND "+MediaStore.Audio.Media.RELATIVE_PATH+"=?",new String[]{n,path+"/"},null);}else c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media.DISPLAY_NAME},MediaStore.Audio.Media.DISPLAY_NAME+"=?",new String[]{n},null);return c!=null&&c.moveToFirst();}finally{if(c!=null)c.close();}}
    }

    static String safe(String s){String x=s.replaceAll("[\\\\/:*?\"<>|]","_").replaceAll("\\s+"," ").trim();return x.isEmpty()?"Unknown":x;}
    static String safeFolder(String s){return safe(s).replace(".","_");}
    static class Ring{final int max;final ByteArrayOutputStream b=new ByteArrayOutputStream();Ring(int m){max=Math.max(1,m);}synchronized void add(byte[] d){try{b.write(d);byte[] a=b.toByteArray();if(a.length>max){b.reset();b.write(a,a.length-max,max);}}catch(Exception ignored){}}synchronized byte[] tail(int n){byte[] a=b.toByteArray();int k=Math.min(Math.max(0,n),a.length);return Arrays.copyOfRange(a,a.length-k,a.length);}}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CH,"Radio recording",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    private Notification notification(String t){Intent i=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CH):new Notification.Builder(this);return b.setContentTitle("Radio Recorder").setContentText(t).setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).setOngoing(true).build();}
    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){for(Recorder r:recorders.values())r.requestStop();if(lock!=null&&lock.isHeld())lock.release();super.onDestroy();}
}
