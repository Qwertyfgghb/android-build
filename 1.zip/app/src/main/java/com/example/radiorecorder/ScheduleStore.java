package com.example.radiorecorder;

import android.content.SharedPreferences;
import org.json.*;
import java.util.*;

public final class ScheduleStore {
    public static class Item { public int id; public long start,stop; public String repeat="once",meta=""; public boolean enabled=true;
        Item(){} Item(int i){id=i;}
    }
    private ScheduleStore(){}
    private static String key(int station){return "schedules_"+station;}
    public static ArrayList<Item> load(SharedPreferences p,int station){ArrayList<Item> out=new ArrayList<>();String raw=p.getString(key(station),"");if(raw.isEmpty())return out;try{JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Item x=new Item(o.optInt("id",i+1));x.start=o.optLong("start",0);x.stop=o.optLong("stop",0);x.repeat=o.optString("repeat","once");x.meta=o.optString("meta","");x.enabled=o.optBoolean("enabled",true);out.add(x);}}catch(Exception ignored){}return out;}
    public static void save(SharedPreferences p,int station,ArrayList<Item> list){JSONArray a=new JSONArray();try{for(Item x:list){JSONObject o=new JSONObject();o.put("id",x.id);o.put("start",x.start);o.put("stop",x.stop);o.put("repeat",x.repeat);o.put("meta",x.meta);o.put("enabled",x.enabled);a.put(o);}}catch(Exception ignored){}p.edit().putString(key(station),a.toString()).apply();}
    public static int nextId(ArrayList<Item> list){int n=0;for(Item x:list)n=Math.max(n,x.id);return n+1;}
    public static long next(long old,String repeat){if(old<=0||"once".equals(repeat))return 0;Calendar c=Calendar.getInstance();c.setTimeInMillis(old);if("daily".equals(repeat))c.add(Calendar.DAY_OF_YEAR,1);else c.add(Calendar.WEEK_OF_YEAR,1);while(c.getTimeInMillis()<=System.currentTimeMillis()){if("daily".equals(repeat))c.add(Calendar.DAY_OF_YEAR,1);else c.add(Calendar.WEEK_OF_YEAR,1);}return c.getTimeInMillis();}
}
