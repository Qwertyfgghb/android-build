package com.example.radiorecorder;
import android.app.Activity;import android.os.Bundle;import android.view.Gravity;import android.widget.*;
public class SettingsActivity extends Activity{
 @Override protected void onCreate(Bundle b){super.onCreate(b);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(28,28,28,28);TextView t=new TextView(this);t.setText("Параметры теперь задаются отдельно для каждой радиостанции.\n\nОткройте радио кнопкой ✎ и измените:\n• кольцевой буфер\n• overlap\n• post-roll\n• битрейт\n\nПри ручном Стоп автоматически добавляются +3 секунды к post-roll.");t.setTextSize(18);t.setGravity(Gravity.CENTER_VERTICAL);r.addView(t,new LinearLayout.LayoutParams(-1,0,1));Button btm=new Button(this);btm.setText("Назад");btm.setOnClickListener(v->finish());r.addView(btm);setContentView(r);}
}
