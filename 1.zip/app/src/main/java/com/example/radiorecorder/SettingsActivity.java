package com.example.radiorecorder;
import android.app.Activity;import android.os.Bundle;import android.view.Gravity;import android.widget.*;
public class SettingsActivity extends Activity{
 @Override protected void onCreate(Bundle b){super.onCreate(b);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(28,28,28,28);TextView t=new TextView(this);t.setText("Настройки задаются отдельно для каждой станции.\n\n• название автоматически из ссылки/icy-name\n• кольцевой буфер и overlap\n• post-roll при смене песни\n• уведомление с каждым новым StreamTitle\n• запись только при заданном StreamTitle\n• планировщик начала и остановки записи\n\nПри ручном Стоп незаконченный текущий трек удаляется сразу.");t.setTextSize(17);t.setGravity(Gravity.CENTER_VERTICAL);r.addView(t,new LinearLayout.LayoutParams(-1,0,1));Button btm=new Button(this);btm.setText("Назад");btm.setOnClickListener(v->finish());r.addView(btm);setContentView(r);}
}
