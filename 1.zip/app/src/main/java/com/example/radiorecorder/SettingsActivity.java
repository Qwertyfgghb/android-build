package com.example.radiorecorder;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;

public class SettingsActivity extends Activity {
    private SharedPreferences p;
    private EditText ring, overlap, postroll, bitrate;
    @Override protected void onCreate(Bundle b){super.onCreate(b);p=getSharedPreferences("radio_prefs",MODE_PRIVATE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(28,28,28,28);
        TextView title=new TextView(this);title.setText("Настройки записи");title.setTextSize(24);title.setTypeface(null,Typeface.BOLD);title.setGravity(Gravity.CENTER);root.addView(title);
        ring=field(root,"Кольцевой буфер, секунд","8.0"); overlap=field(root,"Overlap, секунд","1.0"); postroll=field(root,"Post-roll, секунд","7.0"); bitrate=field(root,"Битрейт, кбит/с","192");
        ring.setText(p.getString("ring_seconds","8.0"));overlap.setText(p.getString("overlap_seconds","1.0"));postroll.setText(p.getString("postroll_seconds","7.0"));bitrate.setText(p.getString("bitrate_kbps","192"));
        TextView info=new TextView(this);info.setText("Эти параметры применяются ко всем радиостанциям.\nДля каждой станции можно отдельно менять название и URL.");info.setPadding(0,20,0,20);root.addView(info);
        Button save=new Button(this);save.setText("Сохранить");root.addView(save);save.setOnClickListener(v->{save();finish();});
        Button defaults=new Button(this);defaults.setText("Восстановить 8 / 1 / 7 / 192");root.addView(defaults);defaults.setOnClickListener(v->{ring.setText("8.0");overlap.setText("1.0");postroll.setText("7.0");bitrate.setText("192");});
        setContentView(root);
    }
    private EditText field(LinearLayout r,String label,String def){TextView t=new TextView(this);t.setText(label);t.setPadding(0,12,0,0);r.addView(t);EditText e=new EditText(this);e.setText(def);e.setInputType(2|8192);r.addView(e);return e;}
    private void save(){try{double a=Double.parseDouble(ring.getText().toString());double b=Double.parseDouble(overlap.getText().toString());double c=Double.parseDouble(postroll.getText().toString());int d=Integer.parseInt(bitrate.getText().toString());if(a<=0||b<0||c<0||d<=0)throw new Exception();p.edit().putString("ring_seconds",String.valueOf(a)).putString("overlap_seconds",String.valueOf(b)).putString("postroll_seconds",String.valueOf(c)).putString("bitrate_kbps",String.valueOf(d)).apply();}catch(Exception e){Toast.makeText(this,"Проверьте значения",Toast.LENGTH_LONG).show();}}
}
