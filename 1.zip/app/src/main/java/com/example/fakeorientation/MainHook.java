package com.example.fakeorientation;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XC_MethodHook;

public class MainHook implements IXposedHookLoadPackage {

    // направление движения
    private static float fakeAzimuth = 0f;

    // предыдущая GPS точка
    private static Location lastLocation = null;

    private static boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        // только карты
        if (!lpparam.packageName.contains("maps"))
            return;

        // запуск GPS
        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {

                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {

                        if (started)
                            return;

                        started = true;

                        Context context =
                                (Context) param.thisObject;

                        startLocation(context);
                    }
                }
        );

        // отдаём направление
        XposedHelpers.findAndHookMethod(
                Location.class,
                "getBearing",
                new XC_MethodHook() {

                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {

                        param.setResult(fakeAzimuth);
                    }
                }
        );

        // отключить cone/compass
        XposedHelpers.findAndHookMethod(
                Location.class,
                "hasBearing",
                new XC_MethodHook() {

                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {

                        param.setResult(false);
                    }
                }
        );

        // отключить speed arrow
        XposedHelpers.findAndHookMethod(
                Location.class,
                "hasSpeed",
                new XC_MethodHook() {

                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {

                        param.setResult(false);
                    }
                }
        );

        // скорость = 0
        XposedHelpers.findAndHookMethod(
                Location.class,
                "getSpeed",
                new XC_MethodHook() {

                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {

                        param.setResult(0f);
                    }
                }
        );
    }

    private static void startLocation(Context context) {

        LocationManager lm =
                (LocationManager)
                        context.getSystemService(
                                Context.LOCATION_SERVICE);

        LocationListener listener =
                new LocationListener() {

                    @Override
                    public void onLocationChanged(Location location) {

                        updateDirection(location);
                    }

                    @Override
                    public void onStatusChanged(
                            String s,
                            int i,
                            Bundle b
                    ) {}

                    @Override
                    public void onProviderEnabled(String s) {}

                    @Override
                    public void onProviderDisabled(String s) {}
                };

        try {

            lm.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    0,
                    0,
                    listener
            );

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    private static void updateDirection(Location location) {

        if (location == null)
            return;

        if (lastLocation != null) {

            // расстояние между GPS точками
            float distance =
                    location.distanceTo(lastLocation);

            // защита от GPS шума
            if (distance < 0.3f)
                return;

            // координаты
            double lat1 =
                    Math.toRadians(
                            lastLocation.getLatitude());

            double lon1 =
                    Math.toRadians(
                            lastLocation.getLongitude());

            double lat2 =
                    Math.toRadians(
                            location.getLatitude());

            double lon2 =
                    Math.toRadians(
                            location.getLongitude());

            double dLon = lon2 - lon1;

            // вычисление азимута
            double y =
                    Math.sin(dLon)
                            * Math.cos(lat2);

            double x =
                    Math.cos(lat1)
                            * Math.sin(lat2)
                            - Math.sin(lat1)
                            * Math.cos(lat2)
                            * Math.cos(dLon);

            double bearing =
                    Math.toDegrees(
                            Math.atan2(y, x));

            if (bearing < 0)
                bearing += 360;

            // мгновенное направление
            fakeAzimuth = (float) bearing;
        }

        lastLocation = location;
    }
}