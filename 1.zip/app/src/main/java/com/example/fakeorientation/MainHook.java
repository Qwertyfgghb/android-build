package com.example.fakeorientation;

import android.content.Context;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XC_MethodHook;

public class MainHook implements IXposedHookLoadPackage {

private static Location lastLocation = null;
private static float fakeAzimuth = 0f;
private static float lastAzimuth = 0f;

private static void updateFromLocation(Location location) {

    if (location == null) return;

    if (lastLocation != null) {

        float distance = location.distanceTo(lastLocation);

        // 🔥 игнорируем шум GPS
        if (distance > 2.0f) {   // 2 метра — оптимально

            float bearing = lastLocation.bearingTo(location);

            // 🔥 защита от скачков (например 0 → 300°)
            float diff = Math.abs(bearing - lastAzimuth);
            if (diff > 180) diff = 360 - diff;

            if (diff < 45) { // игнорируем резкие повороты

                // 🔥 сглаживание (очень важно)
                fakeAzimuth = (lastAzimuth * 0.8f) + (bearing * 0.2f);

                lastAzimuth = fakeAzimuth;
            }
        }
    }

    lastLocation = location;
}
    