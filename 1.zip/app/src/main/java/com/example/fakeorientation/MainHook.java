package com.example.fakeorientation;

import android.content.Context;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XC_MethodHook;

public class MainHook implements IXposedHookLoadPackage {

    private static float fakeAzimuth = 0f;
    private static float targetAzimuth = 0f;
    private static Location lastLocation = null;
    private static boolean started = false;
    private static boolean isMoving = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        // ✅ Запуск GPS через Application.onCreate
        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {

                        if (started) return;
                        started = true;

                        Context context = (Context) param.thisObject;
                        startLocation(context);
                    }
                }
        );

        // ✅ Главный хук направления
        XposedHelpers.findAndHookMethod(
                Location.class,
                "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {

                        // если стоим — вообще не двигаем стрелку
                        if (!isMoving) {
                            param.setResult(fakeAzimuth);
                            return;
                        }

                        float diff = targetAzimuth - fakeAzimuth;

                        if (diff > 180) diff -= 360;
                        if (diff < -180) diff += 360;

                        // плавность
                        fakeAzimuth += diff * 0.15f;

                        param.setResult(fakeAzimuth);
                    }
                }
        );

        // ✅ Всегда есть bearing (иначе конуса нет)
        XposedHelpers.findAndHookMethod(
                Location.class,
                "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // ✅ Совместимость с сенсорами
        XposedHelpers.findAndHookMethod(
                SensorManager.class,
                "getOrientation",
                float[].class,
                float[].class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        float[] values = (float[]) param.args[1];
                        values[0] = (float) Math.toRadians(fakeAzimuth);
                    }
                }
        );
    }

    private static void startLocation(Context context) {

        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                updateFromLocation(location);
            }

            @Override public void onStatusChanged(String s, int i, Bundle b) {}
            @Override public void onProviderEnabled(String s) {}
            @Override public void onProviderDisabled(String s) {}
        };

        try {
            lm.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    200,   // 🔥 быстрее обновления
                    0,
                    listener
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 🔥🔥🔥 ВОТ ТВОЙ ФИНАЛЬНЫЙ FIX
    private static void updateFromLocation(Location location) {

        if (location == null) return;

        if (lastLocation != null) {

            float distance = location.distanceTo(lastLocation);
            float speed = location.getSpeed();
            long dt = location.getTime() - lastLocation.getTime();

            // ❌ ФИЛЬТР ШУМА (главное)
            if (speed < 0.3f || distance < 1.0f || dt < 300) {
                isMoving = false;
                return;
            }

            isMoving = true;

            float bearing = lastLocation.bearingTo(location);
            if (bearing < 0) bearing += 360;

            float diff = bearing - targetAzimuth;

            if (diff > 180) diff -= 360;
            if (diff < -180) diff += 360;

            // 🔥 плавное, но быстрое обновление
            targetAzimuth += diff * 0.5f;
        }

        lastLocation = location;
    }
}