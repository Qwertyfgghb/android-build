package com.example.fakeorientation;

import android.content.Context;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XC_MethodHook;

public class MainHook implements IXposedHookLoadPackage {

    private static float azimuth = 0f;
    private static boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        // ✅ запускаем GPS
        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {

                        if (started) return;
                        started = true;

                        Context context = (Context) param.thisObject;
                        startLocation(context);
                    }
                }
        );

        // ✅ подмена направления
        XposedHelpers.findAndHookMethod(
                Location.class,
                "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(azimuth);
                    }
                }
        );

        // ✅ всегда есть направление
        XposedHelpers.findAndHookMethod(
                Location.class,
                "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // ✅ для совместимости
        XposedHelpers.findAndHookMethod(
                SensorManager.class,
                "getOrientation",
                float[].class,
                float[].class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        float[] values = (float[]) param.args[1];
                        values[0] = (float) Math.toRadians(azimuth);
                    }
                }
        );
    }

    private static void startLocation(Context context) {

        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {

                // 🔥 ВАЖНО: используем только РЕАЛЬНЫЙ GPS bearing
                if (location.hasBearing() && location.getSpeed() > 0.5f) {

                    float gpsBearing = location.getBearing();

                    // сглаживание
                    float diff = gpsBearing - azimuth;

                    if (diff > 180) diff -= 360;
                    if (diff < -180) diff += 360;

                    azimuth += diff * 0.3f;
                }
            }

            @Override public void onStatusChanged(String s, int i, Bundle b) {}
            @Override public void onProviderEnabled(String s) {}
            @Override public void onProviderDisabled(String s) {}
        };

        try {
            lm.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    200,
                    0,
                    listener
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}