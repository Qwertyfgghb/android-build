package com.example.fakeorientation;

import android.content.Context;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XC_MethodHook;

public class MainHook implements IXposedHookLoadPackage {

    private static float fakeAzimuth = 0f;
    private static Location lastLocation = null;
    private static boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        // только карты (можно убрать фильтр если нужно глобально)
        if (!lpparam.packageName.contains("maps")) return;

        // старт GPS
        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {

                        if (started) return;
                        started = true;

                        Context context = (Context) param.thisObject;
                        startLocation(context);
                    }
                }
        );

        // 🔥 FAKE BEARING (для cone)
        XposedHelpers.findAndHookMethod(
                Location.class,
                "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(fakeAzimuth);
                    }
                }
        );

        // 🔥 ВСЕГДА есть направление
        XposedHelpers.findAndHookMethod(
                Location.class,
                "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // (оставляем для совместимости со стрелкой)
        XposedHelpers.findAndHookMethod(
                SensorManager.class,
                "getOrientation",
                float[].class,
                float[].class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        float[] values = (float[]) param.args[1];
                        values[0] = (float) Math.toRadians(fakeAzimuth);
                    }
                }
        );
    }

    private static void startLocation(Context context) {

        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                updateFromLocation(location);
            }

            @Override public void onStatusChanged(String s, int i, Bundle b) {}
            @Override public void onProviderEnabled(String s) {}
            @Override public void onProviderDisabled(String s) {}
        };

        try {
            // 🔥 только GPS — максимально стабильно
            lm.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    0,
                    0,
                    listener
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void updateFromLocation(Location location) {

        if (location == null) return;

        if (lastLocation != null) {

            float distance = location.distanceTo(lastLocation);

            // 🔥 чувствительность (можешь менять)
            if (distance > 0.1f) { // 10 см
                float bearing = lastLocation.bearingTo(location);
                fakeAzimuth = bearing;
            }
        }

        lastLocation = location;
    }
}