package com.example.fakeorientation;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XC_MethodHook;

public class MainHook implements IXposedHookLoadPackage {

    private static float azimuth = 0f;
    private static float targetAzimuth = 0f;

    private static float velocity = 0f;

    private static Location lastLocation = null;
    private static boolean isMoving = false;
    private static long lastMoveTime = 0;

    private static SensorManager sensorManager;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        // запуск
        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {

                        Context context = (Context) param.thisObject;

                        startSensors(context);
                        startGPS(context);
                    }
                }
        );

        // ❌ игнор GPS bearing
        XposedHelpers.findAndHookMethod(
                Location.class,
                "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(azimuth);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class,
                "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // 🔥 главный фильтр (гиро-эффект)
        XposedHelpers.findAndHookMethod(
                SensorManager.class,
                "getOrientation",
                float[].class,
                float[].class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {

                        float diff = targetAzimuth - azimuth;

                        if (diff > 180) diff -= 360;
                        if (diff < -180) diff += 360;

                        // 🔥 pseudo-Kalman
                        velocity += diff * 0.02f;
                        velocity *= 0.92f;

                        azimuth += velocity;

                        float[] values = (float[]) param.args[1];
                        values[0] = (float) Math.toRadians(azimuth);
                    }
                }
        );
    }

    private static void startSensors(Context context) {

        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);

        Sensor acc = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        sensorManager.registerListener(new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {

                float x = event.values[0];
                float y = event.values[1];

                // если телефон сильно двигается → считаем что пользователь активен
                float motion = Math.abs(x) + Math.abs(y);

                if (motion > 2.0f) {
                    isMoving = true;
                }
            }

            @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}
        }, acc, SensorManager.SENSOR_DELAY_GAME);
    }

    private static void startGPS(Context context) {

        LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                updateGPS(location);
            }

            @Override public void onStatusChanged(String s, int i, Bundle b) {}
            @Override public void onProviderEnabled(String s) {}
            @Override public void onProviderDisabled(String s) {}
        };

        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, listener);
        } catch (Exception e) {}
    }

    private static void updateGPS(Location location) {

        if (location == null) return;

        long now = System.currentTimeMillis();

        if (lastLocation != null) {

            float distance = location.distanceTo(lastLocation);

            if (distance > 0.8f) {

                float bearing = lastLocation.bearingTo(location);
                if (bearing < 0) bearing += 360;

                targetAzimuth = bearing;

                isMoving = true;
                lastMoveTime = now;
            }
        }

        // авто стоп
        if (now - lastMoveTime > 1500) {
            isMoving = false;
        }

        lastLocation = location;
    }
}