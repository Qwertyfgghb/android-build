package com.example.youtubelogger

import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class AudioOnlyModule : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "AudioOnly"
        private const val TARGET_PACKAGE = "app.revanced.android.youtube"
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET_PACKAGE) return

        Log.i(TAG, "YouTube ReVanced загружен, активируем AudioOnly...")

        try {
            // Пример для ExoPlayer: блокируем VideoRenderer
            val playerClass = XposedHelpers.findClass(
                "com.google.android.exoplayer2.SimpleExoPlayer",
                lpparam.classLoader
            )

            XposedHelpers.findAndHookMethod(
                playerClass,
                "setVideoSurface", // метод, который задаёт Surface для видео
                android.view.Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        Log.i(TAG, "Видео отключено, оставляем только аудио")
                        param.args[0] = null // не передаём Surface
                    }
                }
            )

        } catch (e: Throwable) {
            Log.e(TAG, "Ошибка AudioOnly", e)
        }
    }
}