package com.example.youtubelogger

import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class YouTubeLoggerModule : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "YouTubeLogger"
        private const val TARGET_PACKAGE = "app.revanced.android.youtube"
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET_PACKAGE) return

        Log.i(TAG, "YouTube загружен, включаем логирование классов видео...")

        try {
            // Перебираем все загруженные классы
            val loadedClasses = XposedHelpers.findClass("java.lang.ClassLoader", lpparam.classLoader)
            // Можно здесь фильтровать через Java.use, но проще через поиск по Video
            XposedHelpers.findAndHookMethod(
                "java.lang.ClassLoader",
                lpparam.classLoader,
                "loadClass",
                String::class.java,
                Boolean::class.javaPrimitiveType,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val className = param.args[0] as String
                        if (className.contains("Video", ignoreCase = true)) {
                            try {
                                val clazz = XposedHelpers.findClass(className, lpparam.classLoader)
                                Log.i(TAG, "Найден класс Video: $className")

                                // Логируем все поля класса
                                clazz.declaredFields.forEach { field ->
                                    Log.i(TAG, "Поле: ${field.name} (${field.type.name})")
                                }

                                // Логируем все методы класса
                                clazz.declaredMethods.forEach { method ->
                                    Log.i(TAG, "Метод: ${method.name}")
                                }

                            } catch (e: Throwable) {
                                Log.e(TAG, "Ошибка при логировании класса $className", e)
                            }
                        }
                    }
                }
            )

        } catch (e: Throwable) {
            Log.e(TAG, "Ошибка при инициализации модуля логирования", e)
        }
    }
}