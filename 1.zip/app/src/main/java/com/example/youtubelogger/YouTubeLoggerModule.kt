package com.example.youtubelogger

import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.lang.reflect.Modifier

class ClassLoggerModule : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "YouTubeLogger"
        private val TARGET_PACKAGES = listOf(
            "com.google.android.youtube",        // оригинальный YouTube
            "app.revanced.android.youtube"       // ReVanced YouTube
        )
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName !in TARGET_PACKAGES) return

        Log.i(TAG, "YouTube/ReVanced загружен, начинаем логирование классов...")

        try {
            // Получаем все классы из classLoader
            val classLoader = lpparam.classLoader

            val classesToInspect = listOf(
                "com.google.android.youtube",    // основной пакет
                "app.revanced.android.youtube"   // ReVanced
            )

            classesToInspect.forEach { pkg ->
                logClassesRecursively(pkg, classLoader)
            }

        } catch (e: Throwable) {
            Log.e(TAG, "Ошибка логирования классов", e)
        }
    }

    private fun logClassesRecursively(packagePrefix: String, classLoader: ClassLoader) {
        try {
            val loadedClassesField = ClassLoader::class.java.getDeclaredField("pathList")
            loadedClassesField.isAccessible = true
            val pathList = loadedClassesField.get(classLoader)
            val dexElementsField = pathList.javaClass.getDeclaredField("dexElements")
            dexElementsField.isAccessible = true
            val dexElements = dexElementsField.get(pathList) as Array<*>

            dexElements.forEach { element ->
                try {
                    val dexClass = element?.javaClass?.getDeclaredField("dexFile")
                    dexClass?.isAccessible = true
                    val dexFile = dexClass?.get(element)
                    val getClassNames = dexFile?.javaClass?.getMethod("entries")
                    val classes = getClassNames?.invoke(dexFile) as? Enumeration<*>
                    classes?.toList()?.filterIsInstance<String>()
                        ?.filter { it.startsWith(packagePrefix) }
                        ?.forEach { clsName ->
                            Log.i(TAG, "Found class: $clsName")
                            try {
                                val cls = Class.forName(clsName, false, classLoader)
                                cls.declaredFields.forEach { f ->
                                    Log.i(TAG, "Field: ${cls.simpleName}.${f.name} : ${f.type.simpleName} ${Modifier.toString(f.modifiers)}")
                                }
                                cls.declaredMethods.forEach { m ->
                                    Log.i(TAG, "Method: ${cls.simpleName}.${m.name}(${m.parameterTypes.joinToString { it.simpleName }}) : ${m.returnType.simpleName}")
                                }
                            } catch (_: Throwable) {}
                        }
                } catch (_: Throwable) {}
            }

        } catch (e: Throwable) {
            Log.e(TAG, "Не удалось логировать классы пакета $packagePrefix", e)
        }
    }
}