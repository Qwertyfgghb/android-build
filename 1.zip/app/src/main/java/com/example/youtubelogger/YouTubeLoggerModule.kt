package com.example.youtubelogger

import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.lang.reflect.Modifier
import java.util.Enumeration

class YouTubeLoggerModule : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "YouTubeLogger"
        private const val TARGET_PACKAGE = "app.revanced.android.youtube"
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET_PACKAGE) return

        Log.i(TAG, "YouTube загружен, включаем логирование классов видео...")

        try {
            logClassesRecursively("com.google.android.youtube", lpparam.classLoader)
        } catch (e: Throwable) {
            Log.e(TAG, "Ошибка при логировании классов", e)
        }
    }

    private fun logClassesRecursively(packagePrefix: String, classLoader: ClassLoader) {
        try {
            val pathListField = ClassLoader::class.java.getDeclaredField("pathList")
            pathListField.isAccessible = true
            val pathList = pathListField.get(classLoader)
            val dexElementsField = pathList.javaClass.getDeclaredField("dexElements")
            dexElementsField.isAccessible = true
            val dexElements = dexElementsField.get(pathList) as Array<*>

            dexElements.forEach { element ->
                try {
                    val dexFileField = element?.javaClass?.getDeclaredField("dexFile")
                    dexFileField?.isAccessible = true
                    val dexFile = dexFileField?.get(element) ?: return@forEach
                    val getClassNamesMethod = dexFile.javaClass.getMethod("entries")
                    val classesEnum = getClassNamesMethod.invoke(dexFile) as? Enumeration<*>
                    val classesList: List<String> = classesEnum?.toList()?.filterIsInstance<String>() ?: emptyList()

                    classesList.filter { it.startsWith(packagePrefix) }.forEach { clsName: String ->
                        Log.i(TAG, "Found class: $clsName")
                        try {
                            val cls = Class.forName(clsName, false, classLoader)
                            cls.declaredFields.forEach { f ->
                                Log.i(
                                    TAG,
                                    "Field: ${cls.simpleName}.${f.name} : ${f.type.simpleName} ${Modifier.toString(f.modifiers)}"
                                )
                            }
                            cls.declaredMethods.forEach { m ->
                                Log.i(
                                    TAG,
                                    "Method: ${cls.simpleName}.${m.name}(${m.parameterTypes.joinToString { pt -> pt.simpleName }}) : ${m.returnType.simpleName}"
                                )
                            }
                        } catch (_: Throwable) {
                        }
                    }
                } catch (_: Throwable) {
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Не удалось логировать классы пакета $packagePrefix", e)
        }
    }
}