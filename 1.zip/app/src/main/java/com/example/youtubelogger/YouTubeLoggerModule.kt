package com.example.youtubelogger

import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class StrictNoMusicModule : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "StrictNoMusicFilter"
        private const val YOUTUBE_PACKAGE = "app.revanced.android.youtube"

        // Слова для распознавания музыкального контента
        private val MUSIC_KEYWORDS = listOf(
            "Music", "Song", "Instrumental", "Remix", "Piano", "Guitar",
            "Violin", "Drums", "Cover"
        )
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != YOUTUBE_PACKAGE) return

        Log.i(TAG, "YouTube загружен, включен строгий фильтр музыкальных видео...")

        try {
            val videoClass = XposedHelpers.findClass(
                "com.google.android.libraries.youtube.media.interfaces.VideoClip",
                lpparam.classLoader
            )

            // Перехватываем аудио поток
            XposedHelpers.findAndHookMethod(
                videoClass,
                "getAudioUrl",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val title = XposedHelpers.callMethod(param.thisObject, "getTitle") as? String ?: ""
                        val description = XposedHelpers.callMethod(param.thisObject, "getDescription") as? String ?: ""
                        if (MUSIC_KEYWORDS.any { title.contains(it, ignoreCase = true) || description.contains(it, ignoreCase = true) }) {
                            Log.i(TAG, "Отключаем аудио музыкального видео: $title")
                            param.result = null // блокируем аудио
                        }
                    }
                }
            )

            // Перехватываем видео поток
            XposedHelpers.findAndHookMethod(
                videoClass,
                "getVideoUrl",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val title = XposedHelpers.callMethod(param.thisObject, "getTitle") as? String ?: ""
                        val description = XposedHelpers.callMethod(param.thisObject, "getDescription") as? String ?: ""
                        if (MUSIC_KEYWORDS.any { title.contains(it, ignoreCase = true) || description.contains(it, ignoreCase = true) }) {
                            Log.i(TAG, "Отключаем видео музыкального видео: $title")
                            param.result = null // блокируем видео
                        }
                    }
                }
            )

        } catch (e: Throwable) {
            Log.e(TAG, "Ошибка StrictNoMusicModule", e)
        }
    }
}