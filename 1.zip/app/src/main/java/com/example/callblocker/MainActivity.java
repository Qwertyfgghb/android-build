package com.example.callblocker;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText inputNumber;
    private Button addBlack, addWhite;
    private Switch blockHidden;
    private TextView logView;
    private ListView blacklistView, whitelistView;

    private ArrayAdapter<String> blackAdapter, whiteAdapter;
    private ArrayList<String> blackListItems, whiteListItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputNumber = findViewById(R.id.input_number);
        addBlack = findViewById(R.id.button_add_black);
        addWhite = findViewById(R.id.button_add_white);
        blockHidden = findViewById(R.id.switch_block_hidden);
        logView = findViewById(R.id.log_view);
        blacklistView = findViewById(R.id.blacklist_view);
        whitelistView = findViewById(R.id.whitelist_view);

        BlacklistManager.init(this);

        // Загружаем списки
        blackListItems = new ArrayList<>(BlacklistManager.getBlackList());
        whiteListItems = new ArrayList<>(BlacklistManager.getWhiteList());

        blackAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, blackListItems);
        whiteAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, whiteListItems);

        blacklistView.setAdapter(blackAdapter);
        whitelistView.setAdapter(whiteAdapter);

        // Добавление номера в черный список
        addBlack.setOnClickListener(v -> {
            String num = inputNumber.getText().toString().trim();
            if(!num.isEmpty()){
                BlacklistManager.addBlack(num);
                blackListItems.add(num);
                blackAdapter.notifyDataSetChanged();
                inputNumber.setText("");
            }
        });

        // Добавление номера в белый список
        addWhite.setOnClickListener(v -> {
            String num = inputNumber.getText().toString().trim();
            if(!num.isEmpty()){
                BlacklistManager.addWhite(num);
                whiteListItems.add(num);
                whiteAdapter.notifyDataSetChanged();
                inputNumber.setText("");
            }
        });

        // Переключатель блокировки скрытых номеров
        blockHidden.setChecked(true);
        blockHidden.setOnCheckedChangeListener((buttonView, isChecked) -> BlacklistManager.setBlockHidden(isChecked));

        // Удаление номера из черного списка по долгому клику
        blacklistView.setOnItemLongClickListener((parent, view, position, id) -> {
            String num = blackListItems.get(position);
            blackListItems.remove(position);
            BlacklistManager.getBlackList().remove(num);
            BlacklistManager.init(this); // сохранить изменения
            blackAdapter.notifyDataSetChanged();
            return true;
        });

        // Удаление номера из белого списка по долгому клику
        whitelistView.setOnItemLongClickListener((parent, view, position, id) -> {
            String num = whiteListItems.get(position);
            whiteListItems.remove(position);
            BlacklistManager.getWhiteList().remove(num);
            BlacklistManager.init(this);
            whiteAdapter.notifyDataSetChanged();
            return true;
        });
    }

    public void logCall(String msg){
        runOnUiThread(() -> logView.append(msg + "\n"));
    }
}