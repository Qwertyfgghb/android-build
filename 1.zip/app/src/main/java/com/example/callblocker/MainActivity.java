package com.example.callblocker;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.view.View;

public class MainActivity extends Activity {

    private EditText inputNumber;
    private Button addBlack, addWhite;
    private Switch blockHidden;
    private TextView logView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputNumber = findViewById(R.id.input_number);
        addBlack = findViewById(R.id.button_add_black);
        addWhite = findViewById(R.id.button_add_white);
        blockHidden = findViewById(R.id.switch_block_hidden);
        logView = findViewById(R.id.log_view);

        BlacklistManager.init(this);

        addBlack.setOnClickListener(v -> {
            String num = inputNumber.getText().toString().trim();
            if(!num.isEmpty()) {
                BlacklistManager.addBlack(num);
                Toast.makeText(this,"Добавлено в черный список",Toast.LENGTH_SHORT).show();
            }
        });

        addWhite.setOnClickListener(v -> {
            String num = inputNumber.getText().toString().trim();
            if(!num.isEmpty()) {
                BlacklistManager.addWhite(num);
                Toast.makeText(this,"Добавлено в белый список",Toast.LENGTH_SHORT).show();
            }
        });

        blockHidden.setOnCheckedChangeListener((buttonView, isChecked) -> {
            BlacklistManager.setBlockHidden(isChecked);
        });
    }

    public void logCall(String msg) {
        runOnUiThread(() -> logView.append(msg + "\n"));
    }
}