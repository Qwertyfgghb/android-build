package com.example.callblocker;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {

    EditText input;
    ArrayAdapter<String> blackAdapter, whiteAdapter;
    ArrayList<String> blackList, whiteList;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        input = findViewById(R.id.input);
        Button addBlack = findViewById(R.id.add_black);
        Button addWhite = findViewById(R.id.add_white);
        Switch sw = findViewById(R.id.switch_hidden);

        ListView blackView = findViewById(R.id.black_list);
        ListView whiteView = findViewById(R.id.white_list);

        blackList = new ArrayList<>(SettingsManager.getBlack(this));
        whiteList = new ArrayList<>(SettingsManager.getWhite(this));

        blackAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, blackList);
        whiteAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, whiteList);

        blackView.setAdapter(blackAdapter);
        whiteView.setAdapter(whiteAdapter);

        sw.setChecked(SettingsManager.isHiddenBlock(this));
        sw.setOnCheckedChangeListener((v, checked) ->
                SettingsManager.setHidden(this, checked));

        addBlack.setOnClickListener(v -> {
            String val = input.getText().toString();
            if (!val.isEmpty()) {
                blackList.add(val);
                save();
            }
        });

        addWhite.setOnClickListener(v -> {
            String val = input.getText().toString();
            if (!val.isEmpty()) {
                whiteList.add(val);
                save();
            }
        });

        blackView.setOnItemClickListener((a, v, i, l) -> {
            blackList.remove(i);
            save();
        });

        whiteView.setOnItemClickListener((a, v, i, l) -> {
            whiteList.remove(i);
            save();
        });
    }

    private void save() {
        SettingsManager.saveBlack(this, new HashSet<>(blackList));
        SettingsManager.saveWhite(this, new HashSet<>(whiteList));
        blackAdapter.notifyDataSetChanged();
        whiteAdapter.notifyDataSetChanged();
    }
}