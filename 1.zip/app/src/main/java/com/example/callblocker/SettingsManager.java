package com.example.callblocker;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

public class SettingsManager {

    private static final String PREF = "call_blocker";
    private static final String KEY_BLACK = "black";
    private static final String KEY_WHITE = "white";
    private static final String KEY_HIDDEN = "hidden";

    public static Set<String> getBlack(Context c) {
        return c.getSharedPreferences(PREF, 0)
                .getStringSet(KEY_BLACK, new HashSet<>());
    }

    public static Set<String> getWhite(Context c) {
        return c.getSharedPreferences(PREF, 0)
                .getStringSet(KEY_WHITE, new HashSet<>());
    }

    public static void saveBlack(Context c, Set<String> set) {
        c.getSharedPreferences(PREF, 0).edit()
                .putStringSet(KEY_BLACK, set).apply();
    }

    public static void saveWhite(Context c, Set<String> set) {
        c.getSharedPreferences(PREF, 0).edit()
                .putStringSet(KEY_WHITE, set).apply();
    }

    public static boolean isHiddenBlock(Context c) {
        return c.getSharedPreferences(PREF, 0)
                .getBoolean(KEY_HIDDEN, true);
    }

    public static void setHidden(Context c, boolean val) {
        c.getSharedPreferences(PREF, 0).edit()
                .putBoolean(KEY_HIDDEN, val).apply();
    }
}