package com.example.callblocker;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;

public class BlacklistManager {

    private static SharedPreferences prefs;
    private static Set<String> blackSet = new HashSet<>();
    private static Set<String> whiteSet = new HashSet<>();
    private static boolean blockHidden = true;

    public static void init(Context ctx){
        prefs = ctx.getSharedPreferences("callblocker", Context.MODE_PRIVATE);
        blackSet = prefs.getStringSet("blacklist", new HashSet<>());
        whiteSet = prefs.getStringSet("whitelist", new HashSet<>());
        blockHidden = prefs.getBoolean("blockHidden", true);
    }

    public static void addBlack(String pattern){
        blackSet.add(pattern);
        prefs.edit().putStringSet("blacklist", blackSet).apply();
    }

    public static void addWhite(String pattern){
        whiteSet.add(pattern);
        prefs.edit().putStringSet("whitelist", whiteSet).apply();
    }

    public static boolean isBlocked(String num){
        if(num == null || num.trim().isEmpty() || num.equalsIgnoreCase("Unknown") || num.equalsIgnoreCase("Private")){
            return blockHidden;
        }

        // Белый список имеет приоритет
        for (String pattern : whiteSet) {
            if (num.matches(pattern)) return false;
        }

        for (String pattern : blackSet) {
            if (num.matches(pattern)) return true;
        }

        return false;
    }

    public static void setBlockHidden(boolean b){
        blockHidden = b;
        prefs.edit().putBoolean("blockHidden", b).apply();
    }

    public static Set<String> getBlackList(){ return blackSet; }
    public static Set<String> getWhiteList(){ return whiteSet; }
}