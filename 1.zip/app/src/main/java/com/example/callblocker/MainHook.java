package com.example.callblocker;

import android.os.Process;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TARGET = "7715676215";

    private String normalize(String n) {
        if (n == null) return "";
        return n.replaceAll("[^0-9+]", "");
    }

    private boolean match(String num) {
        return num.contains(TARGET);
    }

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.equals("com.android.phone"))
            return;

        XposedBridge.log("🔥 OFFLINE BLOCK MODULE LOADED");

        // =========================================================
        // 💣 1. GSM / 3G (самый важный для тебя)
        // =========================================================
        try {
            XposedHelpers.findAndHookMethod(
                    "com.android.internal.telephony.GsmCdmaCallTracker",
                    lpparam.classLoader,
                    "handlePollCalls",
                    new XC_MethodHook() {

                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {

                            try {
                                Object tracker = param.thisObject;

                                Object[] connections = (Object[]) XposedHelpers.getObjectField(
                                        tracker,
                                        "mConnections"
                                );

                                if (connections == null) return;

                                for (Object conn : connections) {

                                    if (conn == null) continue;

                                    String num = (String) XposedHelpers.callMethod(conn, "getAddress");
                                    String clean = normalize(num);

                                    if (clean.isEmpty()) continue;

                                    XposedBridge.log("📞 3G DETECT: " + clean);

                                    if (match(clean)) {

                                        XposedBridge.log("💣 BLOCK 3G EARLY");

                                        // 💀 разрыв сразу
                                        XposedHelpers.callMethod(conn, "onDisconnect", 1);

                                        // 💣 убираем звонок полностью
                                        param.setResult(null);
                                        return;
                                    }
                                }

                            } catch (Throwable t) {
                                XposedBridge.log("3G ERROR: " + t);
                            }
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("❌ 3G HOOK FAIL: " + t);
        }

        // =========================================================
        // 💣 2. GSM причина (делаем "телефон выключен")
        // =========================================================
        try {
            XposedHelpers.findAndHookMethod(
                    "com.android.internal.telephony.GsmCdmaConnection",
                    lpparam.classLoader,
                    "onDisconnect",
                    int.class,
                    new XC_MethodHook() {

                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {

                            int cause = (int) param.args[0];

                            // 💀 меняем причину
                            param.args[0] = 1; // UNOBTAINABLE

                            XposedBridge.log("💀 FORCE OFFLINE (3G)");
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("❌ GSM CAUSE FAIL: " + t);
        }

        // =========================================================
        // 💣 3. IMS / VoLTE (4G)
        // =========================================================
        try {
            XposedHelpers.findAndHookMethod(
                    "com.android.internal.telephony.imsphone.ImsPhoneConnection",
                    lpparam.classLoader,
                    "onDisconnect",
                    int.class,
                    new XC_MethodHook() {

                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {

                            param.args[0] = 2;

                            XposedBridge.log("💣 IMS OFFLINE");
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("❌ IMS FAIL: " + t);
        }

        // =========================================================
        // 💣 4. TELECOM (UI уровень)
        // =========================================================
        try {
            XposedHelpers.findAndHookMethod(
                    "android.telecom.Connection",
                    lpparam.classLoader,
                    "setDisconnected",
                    XposedHelpers.findClass("android.telecom.DisconnectCause", lpparam.classLoader),
                    new XC_MethodHook() {

                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {

                            try {
                                Class<?> dc = XposedHelpers.findClass(
                                        "android.telecom.DisconnectCause",
                                        lpparam.classLoader
                                );

                                Object offline = XposedHelpers.newInstance(dc, 2);

                                param.args[0] = offline;

                                XposedBridge.log("💀 TELECOM OFFLINE");

                            } catch (Throwable ignored) {}
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("❌ TELECOM FAIL: " + t);
        }
    }
}