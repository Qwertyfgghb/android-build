package com.example.callblocker

import android.app.AndroidAppHelper
import android.os.Process
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.util.regex.Pattern

class MainHook : IXposedHookLoadPackage {

    private var killed = false

    private fun normalize(n: String?): String {
        if (n == null) return ""
        return n.replace(Regex("[^\\d+]"), "")
    }

    private fun matchList(num: String, list: Set<String>?): Boolean {
        if (list == null) return false

        for (patternStr in list) {
            try {
                val p = Pattern.compile(patternStr)
                if (p.matcher(num).find()) return true
            } catch (_: Throwable) {}
        }
        return false
    }

    private fun killNow() {
        if (killed) return
        killed = true

        XposedBridge.log("💣 KILL com.android.phone")

        try {
            val pid = Process.myPid()

            Process.killProcess(pid)
            Runtime.getRuntime().exit(0)

        } catch (t: Throwable) {
            XposedBridge.log("Kill error: $t")
        }
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "com.android.phone") return

        XposedBridge.log("🔥 KILL MODULE + LISTS LOADED")

        val context = AndroidAppHelper.currentApplication()

        // 🔥 IMS (ранний)
        try {
            XposedHelpers.findAndHookMethod(
                "android.telephony.ims.ImsCallProfile",
                lpparam.classLoader,
                "getCallExtra",
                String::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        try {
                            val res = param.result as? String ?: return
                            val num = normalize(res)

                            val black = SettingsManager.getBlack(context)
                            val white = SettingsManager.getWhite(context)

                            // whitelist
                            if (matchList(num, white)) {
                                XposedBridge.log("✅ WHITELIST: $num")
                                return
                            }

                            // blacklist
                            if (matchList(num, black)) {
                                XposedBridge.log("📡 IMS MATCH → KILL: $num")
                                killNow()
                            }

                        } catch (_: Throwable) {}
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("IMS hook error: $t")
        }

        // 🔥 fallback (Connection)
        try {
            XposedHelpers.findAndHookMethod(
                "com.android.internal.telephony.Connection",
                lpparam.classLoader,
                "getAddress",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        try {
                            val num = param.result as? String ?: return
                            val clean = normalize(num)

                            val black = SettingsManager.getBlack(context)
                            val white = SettingsManager.getWhite(context)

                            // whitelist
                            if (matchList(clean, white)) {
                                XposedBridge.log("✅ WHITELIST: $clean")
                                return
                            }

                            // blacklist
                            if (matchList(clean, black)) {
                                XposedBridge.log("📞 CONN MATCH → KILL: $clean")
                                killNow()
                            }

                        } catch (_: Throwable) {}
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("Connection hook error: $t")
        }
    }
}