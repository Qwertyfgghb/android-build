package com.example.callblocker;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;

public class MainHook implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        if (!lpparam.packageName.equals("com.android.phone")) return;

        XposedBridge.log("CallBlocker loaded into com.android.phone");

        // IMS (VoLTE)
        try {
            Class<?> imsCls = XposedHelpers.findClass(
                    "com.android.internal.telephony.imsphone.ImsPhoneCallTracker",
                    lpparam.classLoader
            );

            XposedHelpers.findAndHookMethod(
                    imsCls,
                    "addConnection",
                    Object.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            Object conn = param.args[0];
                            String number = getNumber(conn);

                            if (BlacklistManager.isBlocked(number)) {
                                hangup(conn);
                                param.setResult(null);
                                XposedBridge.log("BLOCK IMS: " + number);
                            }
                        }
                    }
            );

        } catch (Throwable e) {
            XposedBridge.log("IMS hook error: " + e);
        }

        // Connection fallback (2G/3G)
        try {
            Class<?> connCls = XposedHelpers.findClass(
                    "com.android.internal.telephony.Connection",
                    lpparam.classLoader
            );

            XposedHelpers.findAndHookMethod(
                    connCls,
                    "getAddress",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            String number = (String) param.getResult();
                            Object conn = param.thisObject;

                            if (BlacklistManager.isBlocked(number)) {
                                final Object c = conn;
                                new Thread(() -> {
                                    try {
                                        Thread.sleep(50);
                                        hangup(c);
                                    } catch (Exception ignored) {}
                                }).start();
                            }
                        }
                    }
            );

        } catch (Throwable e) {
            XposedBridge.log("Connection hook error: " + e);
        }
    }

    private static String getNumber(Object conn) {
        try {
            return (String) XposedHelpers.callMethod(conn, "getAddress");
        } catch (Throwable e) {
            return null;
        }
    }

    private static void hangup(Object conn) {
        try { XposedHelpers.callMethod(conn, "hangup"); } catch (Throwable ignored) {}
    }
}