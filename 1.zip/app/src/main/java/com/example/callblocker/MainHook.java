package com.example.callblocker;

import android.app.AndroidAppHelper;
import android.content.Context;
import android.os.Process;

import java.util.Set;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

// ---------------- SETTINGS MANAGER ----------------
class SettingsManager {

    private static Set<String> blackList = new java.util.HashSet<>();
    private static Set<String> whiteList = new java.util.HashSet<>();

    public static Set<String> getBlack(Context context) {
        return blackList;
    }

    public static Set<String> getWhite(Context context) {
        return whiteList;
    }

    public static void addBlack(Context context, String num) {
        blackList.add(num);
        XposedBridge.log("➕ Added to black: " + num);
    }

    public static void removeBlack(Context context, String num) {
        blackList.remove(num);
        XposedBridge.log("➖ Removed from black: " + num);
    }

    public static void addWhite(Context context, String num) {
        whiteList.add(num);
        XposedBridge.log("➕ Added to white: " + num);
    }

    public static void removeWhite(Context context, String num) {
        whiteList.remove(num);
        XposedBridge.log("➖ Removed from white: " + num);
    }

    public static boolean matchRegex(String num, Set<String> list) {
        if (list == null) return false;
        for (String patternStr : list) {
            try {
                Pattern p = Pattern.compile(patternStr);
                if (p.matcher(num).find()) return true;
            } catch (Throwable ignored) {}
        }
        return false;
    }
}

// ---------------- MAIN HOOK ----------------
public class MainHook implements IXposedHookLoadPackage {

    private boolean killed = false;

    private String normalize(String n) {
        if (n == null) return "";
        return n.replaceAll("[^0-9+]", "");
    }

    private void killNow() {
        if (killed) return;
        killed = true;

        XposedBridge.log("💣 KILL com.android.phone");
        try {
            int pid = Process.myPid();
            Process.killProcess(pid);
            Runtime.getRuntime().exit(0);
        } catch (Throwable t) {
            XposedBridge.log("Kill error: " + t);
        }
    }

    private boolean checkLists(Context context, String num) {
        Set<String> black = SettingsManager.getBlack(context);
        Set<String> white = SettingsManager.getWhite(context);

        if (SettingsManager.matchRegex(num, white)) {
            XposedBridge.log("✅ WHITELIST: " + num);
            return false;
        }

        if (SettingsManager.matchRegex(num, black)) {
            XposedBridge.log("🔥 BLACKLIST MATCH: " + num + " → kill");
            return true;
        }

        return false;
    }

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.equals("com.android.phone")) return;

        XposedBridge.log("🔥 AUTO RIL KILLER + INTERFACE LOADED");

        final Context context = AndroidAppHelper.currentApplication();

        // ---------------- IMS HOOK ----------------
        try {
            XposedHelpers.findAndHookMethod(
                    "android.telephony.ims.ImsCallProfile",
                    lpparam.classLoader,
                    "getCallExtra",
                    String.class,
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            try {
                                Object result = param.getResult();
                                if (result == null) return;
                                String num = normalize(result.toString());

                                if (!killed && checkLists(context, num)) {
                                    killNow();
                                }
                            } catch (Throwable ignored) {}
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("IMS hook error: " + t);
        }

        // ---------------- CONNECTION HOOK ----------------
        try {
            XposedHelpers.findAndHookMethod(
                    "com.android.internal.telephony.Connection",
                    lpparam.classLoader,
                    "getAddress",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            try {
                                Object result = param.getResult();
                                if (result == null) return;
                                String num = normalize(result.toString());

                                if (!killed && checkLists(context, num)) {
                                    killNow();
                                }
                            } catch (Throwable ignored) {}
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("Connection hook error: " + t);
        }
    }
}