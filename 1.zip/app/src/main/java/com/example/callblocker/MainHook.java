package com.example.callblocker;

import java.lang.reflect.Field;
import java.util.Arrays;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TARGET = "7715676215";

    // =============================
    // 🔍 НОРМАЛИЗАЦИЯ
    // =============================
    private String normalize(String n) {
        if (n == null) return "";
        return n.replaceAll("[^0-9+]", "");
    }

    private boolean match(String n) {
        return normalize(n).contains(TARGET);
    }

    // =============================
    // 🔍 ГЛУБОКИЙ ПОИСК НОМЕРА
    // =============================
    private String findNumber(Object obj) {
        if (obj == null) return null;

        try {
            if (obj instanceof String) {
                String s = (String) obj;
                if (match(s)) return s;
            }

            // 🔍 пробуем getAddress()
            try {
                Object res = XposedHelpers.callMethod(obj, "getAddress");
                if (res instanceof String && match((String) res)) {
                    return (String) res;
                }
            } catch (Throwable ignored) {}

            // 🔍 пробуем поле number
            try {
                Field f = obj.getClass().getDeclaredField("number");
                f.setAccessible(true);
                Object val = f.get(obj);

                if (val instanceof String && match((String) val)) {
                    return (String) val;
                }
            } catch (Throwable ignored) {}

            // 🔍 пробуем ВСЕ поля
            for (Field field : obj.getClass().getDeclaredFields()) {
                field.setAccessible(true);

                Object val = field.get(obj);

                if (val instanceof String) {
                    String s = (String) val;
                    if (match(s)) return s;
                }
            }

        } catch (Throwable ignored) {}

        return null;
    }

    // =============================
    // 💣 ДЕЙСТВИЕ (BLOCK)
    // =============================
    private void block(MethodHookParam param, String num) {

        XposedBridge.log("💣 AUTO BLOCK: " + num);

        try {
            // 💀 обрываем выполнение
            param.setResult(null);
        } catch (Throwable ignored) {}

        try {
            throw new RuntimeException("CALL BLOCKED");
        } catch (Throwable ignored) {}
    }

    // =============================
    // 🔥 AUTO HOOK
    // =============================
    private void hookClass(Class<?> clazz) {

        for (java.lang.reflect.Method m : clazz.getDeclaredMethods()) {

            XposedBridge.hookMethod(m, new XC_MethodHook() {

                @Override
                protected void beforeHookedMethod(MethodHookParam param) {

                    try {
                        if (param.args == null) return;

                        for (Object arg : param.args) {

                            String num = findNumber(arg);

                            if (num != null) {

                                XposedBridge.log("📞 FOUND IN: "
                                        + param.method.getName()
                                        + " → " + num);

                                block(param, num);
                                return;
                            }
                        }

                    } catch (Throwable t) {
                        XposedBridge.log("AUTO ERR: " + t);
                    }
                }
            });
        }

        XposedBridge.log("✅ AUTO HOOKED: " + clazz.getName());
    }

    // =============================
    // 🚀 ENTRY
    // =============================
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.equals("com.android.phone"))
            return;

        XposedBridge.log("🔥 AUTO SCAN (FRIDA STYLE) LOADED");

        try {

            // 💣 ОСНОВНЫЕ КЛАССЫ ДЛЯ СКАНА
            String[] targets = {

                    "com.android.internal.telephony.Connection",
                    "com.android.internal.telephony.GsmCdmaConnection",
                    "com.android.internal.telephony.imsphone.ImsPhoneConnection",
                    "com.android.internal.telephony.CallManager",
                    "com.android.internal.telephony.RIL",
                    "android.telecom.Connection"
            };

            for (String cls : targets) {
                try {
                    Class<?> c = XposedHelpers.findClass(cls, lpparam.classLoader);
                    hookClass(c);
                } catch (Throwable t) {
                    XposedBridge.log("❌ CLASS FAIL: " + cls + " | " + t);
                }
            }

        } catch (Throwable t) {
            XposedBridge.log("FATAL: " + t);
        }
    }
}