package com.example.callblocker;

import android.content.Context;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    // ---------------- Utils ----------------

    private String normalize(String n) {
        if (n == null) return "";
        return n.replaceAll("[^0-9+]", "");
    }

    private boolean matchList(String num, Set<String> list) {
        if (list == null) return false;

        for (String patternStr : list) {
            try {
                Pattern p = Pattern.compile(patternStr);
                if (p.matcher(num).find()) return true;
            } catch (Throwable ignored) {}
        }
        return false;
    }

    private String extractNumber(Object callObj) {

        try {
            Field baseField = callObj.getClass().getField("base");
            Object base = baseField.get(callObj);

            Field numberField = base.getClass().getField("number");
            return (String) numberField.get(base);

        } catch (Throwable e) {

            try {
                Field numberField = callObj.getClass().getField("number");
                return (String) numberField.get(callObj);
            } catch (Throwable ignored) {}

        }

        return null;
    }

    // ---------------- Core ----------------

    private void processCalls(Context context, ArrayList<?> calls) {

        if (context == null) {
            XposedBridge.log("❌ Context NULL — skip");
            return;
        }

        if (calls == null) return;

        Set<String> black = SettingsManager.getBlack(context);
        Set<String> white = SettingsManager.getWhite(context);

        Iterator<?> it = calls.iterator();

        while (it.hasNext()) {
            Object call = it.next();

            String num = extractNumber(call);
            String clean = normalize(num);

            if (clean.isEmpty()) continue;

            XposedBridge.log("📞 RIL NUMBER: " + clean);

            // белый список
            if (matchList(clean, white)) {
                XposedBridge.log("✅ WHITELIST: " + clean);
                continue;
            }

            // чёрный список
            if (matchList(clean, black)) {
                XposedBridge.log("🔥 BLOCKED: " + clean);

                it.remove();              // удаляем из списка
                // calls.clear();         // можно включить если хочешь жёсткий блок
            }
        }
    }

    // ---------------- Hook ----------------

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.equals("com.android.phone"))
            return;

        XposedBridge.log("🔥 RIL AUTO-DETECT FINAL LOADED");

        // ✅ ПРАВИЛЬНЫЙ CONTEXT (FIX)
        final Context context;

        try {
            Object at = XposedHelpers.callStaticMethod(
                    XposedHelpers.findClass("android.app.ActivityThread", null),
                    "currentActivityThread"
            );

            context = (Context) XposedHelpers.callMethod(at, "getSystemContext");

        } catch (Throwable e) {
            XposedBridge.log("❌ Context error: " + e);
            return;
        }

        try {
            Class<?> clazz = XposedHelpers.findClass(
                    "com.android.internal.telephony.RadioResponse",
                    lpparam.classLoader
            );

            // 🔥 AUTO-DETECT ВСЕХ МЕТОДОВ
            for (java.lang.reflect.Method m : clazz.getDeclaredMethods()) {

                String name = m.getName();

                if (!name.toLowerCase().contains("call")) continue;

                XposedBridge.log("📡 FOUND METHOD: " + name);

                XposedBridge.hookAllMethods(clazz, name, new XC_MethodHook() {

                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {

                        try {
                            Object[] args = param.args;
                            if (args == null) return;

                            for (Object arg : args) {

                                if (arg instanceof ArrayList) {

                                    ArrayList<?> calls = (ArrayList<?>) arg;

                                    if (calls.isEmpty()) return;

                                    XposedBridge.log("📡 PROCESSING: " + param.method.getName());

                                    processCalls(context, calls);
                                }
                            }

                        } catch (Throwable t) {
                            XposedBridge.log("❌ PROCESS ERROR: " + t);
                        }
                    }
                });
            }

            XposedBridge.log("✅ Dynamic RIL hook OK");

        } catch (Throwable t) {
            XposedBridge.log("❌ RIL AUTO HOOK ERROR: " + t);
        }
    }
}