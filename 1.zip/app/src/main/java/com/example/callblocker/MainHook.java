package com.example.callblocker;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final Set<String> BLACKLIST = new HashSet<>();
    private static final Set<String> WHITELIST = new HashSet<>();
    private static final boolean BLOCK_HIDDEN = true;

    static {
        BLACKLIST.add("77715676215"); // пример черного номера
        // WHITELIST.add("79161234567"); // пример белого номера
    }

    private String normalize(String n) {
        if (n == null) return "";
        return n.replaceAll("[^0-9+]", "");
    }

    private boolean match(String num, Set<String> list) {
        if (num == null || num.isEmpty()) return false;
        for (String pattern : list) {
            try {
                if (Pattern.compile(pattern).matcher(num).find()) return true;
            } catch (Throwable ignored) {}
        }
        return false;
    }

    private boolean checkCall(ArrayList<?> calls) {
        if (calls == null || calls.isEmpty()) return false;

        Iterator<?> it = calls.iterator();
        while (it.hasNext()) {
            Object call = it.next();
            String num = null;

            try {
                try {
                    Object base = call.getClass().getField("base").get(call);
                    num = (String) base.getClass().getField("number").get(base);
                } catch (NoSuchFieldException ignored) {
                    num = (String) call.getClass().getField("number").get(call);
                }
            } catch (Throwable ignored) {}

            String clean = normalize(num);

            if ((BLOCK_HIDDEN && clean.isEmpty()) || match(clean, BLACKLIST)) {
                XposedBridge.log("💣 BLOCK CALL: " + clean);
                calls.clear();
                return true;
            }

            if (match(clean, WHITELIST)) {
                XposedBridge.log("✅ WHITELIST: " + clean);
                continue;
            }
        }

        return false;
    }

    private void killPhoneProcess() {
        try {
            XposedBridge.log("💀 KILLING com.android.phone");
            android.os.Process.killProcess(android.os.Process.myPid());
        } catch (Throwable t) {
            XposedBridge.log("❌ KILL ERROR: " + t);
        }
    }

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.equals("com.android.phone")) return;

        XposedBridge.log("🔥 ULTRA TRUECALLER BLOCKER LOADED");

        // ---------------- RIL HOOK ----------------
        try {
            Class<?> clazz = XposedHelpers.findClass(
                    "com.android.internal.telephony.RadioResponse",
                    lpparam.classLoader
            );

            for (Method m : clazz.getDeclaredMethods()) {
                String name = m.getName();
                if (!name.toLowerCase().contains("call")) continue;

                XposedBridge.log("📡 FOUND RIL METHOD: " + name);

                XposedBridge.hookAllMethods(clazz, name, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        try {
                            Object[] args = param.args;
                            if (args == null) return;

                            for (Object arg : args) {
                                if (arg instanceof ArrayList) {
                                    ArrayList<?> calls = (ArrayList<?>) arg;
                                    if (!calls.isEmpty()) {
                                        XposedBridge.log("📡 PROCESSING RIL: " + param.method.getName());
                                        checkCall(calls);
                                    }
                                }
                            }
                        } catch (Throwable t) {
                            XposedBridge.log("❌ RIL PROCESS ERROR: " + t);
                        }
                    }
                });
            }
        } catch (Throwable t) {
            XposedBridge.log("❌ RIL HOOK FAIL: " + t);
        }

        // ---------------- CONNECTION HOOK ----------------
        try {
            String[] connectionClasses = {
                    "com.android.internal.telephony.Connection",
                    "com.android.internal.telephony.GsmConnection",
                    "com.android.internal.telephony.CdmaConnection"
            };

            for (String cls : connectionClasses) {
                XposedHelpers.findAndHookMethod(
                        cls,
                        lpparam.classLoader,
                        "getAddress",
                        new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                try {
                                    String num = (String) param.getResult();
                                    String clean = normalize(num);
                                    XposedBridge.log("📞 CONN NUMBER: " + clean);

                                    if ((BLOCK_HIDDEN && clean.isEmpty()) || match(clean, BLACKLIST)) {
                                        XposedBridge.log("💣 HARD BLOCK " + cls + " " + clean);

                                        // --- 1️⃣ Попытка setDisconnected()
                                        try {
                                            Method setDisc = param.thisObject.getClass().getMethod("setDisconnected");
                                            setDisc.invoke(param.thisObject);
                                            XposedBridge.log("✅ CALL SET DISCONNECTED");
                                        } catch (NoSuchMethodException ignored) {
                                            // --- 2️⃣ fallback: убиваем процесс com.android.phone
                                            killPhoneProcess();
                                        }

                                        // --- 3️⃣ скрыть номер для вызывающего → Out of service
                                        param.setResult(null);
                                    }
                                } catch (Throwable t) {
                                    XposedBridge.log("❌ CONNECTION ERROR: " + t);
                                }
                            }
                        }
                );
            }
        } catch (Throwable t) {
            XposedBridge.log("❌ CONNECTION HOOK FAIL: " + t);
        }
    }
}