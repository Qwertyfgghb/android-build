package com.example.callblocker;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    // ---------------- Настройки ----------------
    private static final Set<String> BLACKLIST = new HashSet<>();
    private static final Set<String> WHITELIST = new HashSet<>();
    private static final boolean BLOCK_HIDDEN = true;

    static {
        // Добавь номера или regex прямо сюда
        BLACKLIST.add("77715676215");   // пример черного списка
        // WHITELIST.add("79161234567"); // пример белого списка
    }

    private String normalize(String n) {
        if (n == null) return "";
        return n.replaceAll("[^0-9+]", "");
    }

    private String extractNumber(Object callObj) {
        try {
            Field baseField = callObj.getClass().getField("base");
            Object base = baseField.get(callObj);
            Field numberField = base.getClass().getField("number");
            return (String) numberField.get(base);
        } catch (Throwable e) {
            try {
                Field numberField = callObj.getClass().getField("number");
                return (String) numberField.get(callObj);
            } catch (Throwable ignored) {}
        }
        return null;
    }

    private boolean match(String num, Set<String> list) {
        if (num == null || num.isEmpty()) return false;
        for (String pattern : list) {
            try {
                if (Pattern.compile(pattern).matcher(num).find()) return true;
            } catch (Throwable ignored) {}
        }
        return false;
    }

    // ---------------- Core ----------------
    private boolean checkCall(ArrayList<?> calls) {
        if (calls == null || calls.isEmpty()) return false;

        for (Object call : calls) {
            String num = normalize(extractNumber(call));
            if (num.isEmpty() && BLOCK_HIDDEN) {
                XposedBridge.log("🚫 HIDDEN BLOCK");
                calls.clear();
                return true;
            }

            if (match(num, WHITELIST)) {
                XposedBridge.log("✅ WHITELIST: " + num);
                continue;
            }

            if (match(num, BLACKLIST)) {
                XposedBridge.log("🔥 BLACKLIST BLOCK: " + num);
                calls.clear(); // 💣 Жёсткий блок
                return true;
            }
        }
        return false;
    }

    // ---------------- Hook ----------------
    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.equals("com.android.phone")) return;

        XposedBridge.log("🔥 ULTRA TRUECALLER BLOCKER LOADED");

        // --- AUTO-DETECT RIL ---
        try {
            Class<?> clazz = XposedHelpers.findClass(
                    "com.android.internal.telephony.RadioResponse",
                    lpparam.classLoader
            );

            for (Method m : clazz.getDeclaredMethods()) {
                String name = m.getName();
                if (!name.toLowerCase().contains("call")) continue;

                XposedBridge.log("📡 FOUND RIL METHOD: " + name);

                XposedBridge.hookAllMethods(clazz, name, new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        try {
                            Object[] args = param.args;
                            if (args == null) return;
                            for (Object arg : args) {
                                if (arg instanceof ArrayList) {
                                    ArrayList<?> calls = (ArrayList<?>) arg;
                                    if (!calls.isEmpty()) {
                                        XposedBridge.log("📡 PROCESSING RIL: " + param.method.getName());
                                        checkCall(calls);
                                    }
                                }
                            }
                        } catch (Throwable t) {
                            XposedBridge.log("❌ RIL PROCESS ERROR: " + t);
                        }
                    }
                });
            }
        } catch (Throwable t) {
            XposedBridge.log("❌ RIL HOOK FAIL: " + t);
        }

        // --- CONNECTION HOOK (HARD BLOCK до UI) ---
        try {
            XposedHelpers.findAndHookMethod(
                    "com.android.internal.telephony.Connection",
                    lpparam.classLoader,
                    "getAddress",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                            try {
                                String num = (String) param.getResult();
                                String clean = normalize(num);
                                XposedBridge.log("📞 CONN NUMBER: " + clean);

                                if ((BLOCK_HIDDEN && clean.equals("")) || match(clean, BLACKLIST)) {
                                    XposedBridge.log("💣 HARD BLOCK (CONNECTION) " + clean);
                                    param.setResult("");          // убираем номер полностью
                                    // param.setResult(null);      // альтернативный вариант
                                    // throw new RuntimeException("BLOCK CALL"); // ультра жесткий
                                }
                            } catch (Throwable t) {
                                XposedBridge.log("❌ CONN ERROR: " + t);
                            }
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("❌ CONNECTION HOOK FAIL: " + t);
        }
    }
}