package com.example.callblocker;

import android.app.AndroidAppHelper;
import android.content.Context;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    // -------- utils --------

    private String normalize(String n) {
        if (n == null) return "";
        return n.replaceAll("[^0-9+]", "");
    }

    private String extractNumber(Object callObj) {
        try {
            Field baseField = callObj.getClass().getField("base");
            Object base = baseField.get(callObj);

            Field numberField = base.getClass().getField("number");
            return (String) numberField.get(base);

        } catch (Throwable e) {
            try {
                Field numberField = callObj.getClass().getField("number");
                return (String) numberField.get(callObj);
            } catch (Throwable ignored) {}
        }
        return null;
    }

    private boolean isHidden(String num) {
        return num == null || num.isEmpty();
    }

    // -------- core --------

    private void processCalls(Context context, ArrayList<?> calls) {

        if (calls == null) return;

        Set<String> black = SettingsManager.getBlack(context);
        Set<String> white = SettingsManager.getWhite(context);
        boolean blockHidden = SettingsManager.isHiddenBlock(context);

        Iterator<?> it = calls.iterator();

        while (it.hasNext()) {

            Object call = it.next();

            String raw = extractNumber(call);
            String num = normalize(raw);

            // 🔍 лог
            XposedBridge.log("📡 RIL NUMBER: " + num);

            // ---- скрытые ----
            if (isHidden(raw)) {
                if (blockHidden) {
                    XposedBridge.log("🚫 BLOCK HIDDEN");
                    it.remove();
                }
                continue;
            }

            // ---- whitelist ----
            if (SettingsManager.matchRegex(num, white)) {
                XposedBridge.log("✅ WHITELIST: " + num);
                continue;
            }

            // ---- blacklist ----
            if (SettingsManager.matchRegex(num, black)) {
                XposedBridge.log("🔥 BLOCKED: " + num);
                it.remove(); // 💣 ГЛАВНОЕ
            }
        }
    }

    // -------- hook --------

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.equals("com.android.phone"))
            return;

        XposedBridge.log("🔥 RIL AUTO-DETECT LOADED");

        final Context context = AndroidAppHelper.currentApplication();

        // 🔥 универсальный авто-детект (твоя версия)
        String[] methods = {
                "responseCurrentCalls_1_0",
                "responseCurrentCalls_1_1",
                "responseCurrentCalls_1_2",
                "getCurrentCallsResponse_1_0",
                "getCurrentCallsResponse_1_1",
                "getCurrentCallsResponse_1_2",
                "getCurrentCallsResponse_1_4"
        };

        for (String m : methods) {
            try {

                XposedHelpers.findAndHookMethod(
                        "com.android.internal.telephony.RadioResponse",
                        lpparam.classLoader,
                        m,
                        new XC_MethodHook() {

                            @Override
                            protected void beforeHookedMethod(MethodHookParam param) {

                                Object[] args = param.args;
                                if (args == null) return;

                                for (Object arg : args) {

                                    if (arg instanceof ArrayList) {

                                        ArrayList<?> calls = (ArrayList<?>) arg;

                                        if (calls.isEmpty()) return;

                                        XposedBridge.log("📡 RIL METHOD: " + param.method.getName());

                                        processCalls(context, calls);
                                    }
                                }
                            }
                        }
                );

                XposedBridge.log("✅ Hook success: " + m);

            } catch (Throwable t) {
                XposedBridge.log("❌ Hook fail: " + m + " | " + t);
            }
        }
    }
}