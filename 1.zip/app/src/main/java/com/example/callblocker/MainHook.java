package com.example.callblocker;

import android.app.AndroidAppHelper;
import android.content.Context;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedHelpers;

public class MainHook implements IXposedHookLoadPackage {

    // ---------------- Utils ----------------

    private String normalize(String n) {
        if (n == null) return "";
        return n.replaceAll("[^0-9+]", "");
    }

    private boolean matchList(String num, Set<String> list) {
        if (list == null) return false;

        for (String patternStr : list) {
            try {
                Pattern p = Pattern.compile(patternStr);
                if (p.matcher(num).find()) return true;
            } catch (Throwable ignored) {}
        }
        return false;
    }

    private String extractNumber(Object callObj) {

        try {
            // MTK / HIDL структура
            Field baseField = callObj.getClass().getField("base");
            Object base = baseField.get(callObj);

            Field numberField = base.getClass().getField("number");
            return (String) numberField.get(base);

        } catch (Throwable e) {

            try {
                // fallback (иногда напрямую)
                Field numberField = callObj.getClass().getField("number");
                return (String) numberField.get(callObj);
            } catch (Throwable ignored) {}

        }

        return null;
    }

    // ---------------- Core ----------------

    private void processCalls(Context context, ArrayList<?> calls) {

        if (calls == null) return;

        Set<String> black = SettingsManager.getBlack(context);
        Set<String> white = SettingsManager.getWhite(context);

        Iterator<?> it = calls.iterator();

        while (it.hasNext()) {
            Object call = it.next();

            String num = extractNumber(call);
            String clean = normalize(num);

            if (clean.isEmpty()) continue;

            // белый список
            if (matchList(clean, white)) {
                XposedBridge.log("✅ WHITELIST: " + clean);
                continue;
            }

            // чёрный список
            if (matchList(clean, black)) {
                XposedBridge.log("🔥 RIL BLOCK: " + clean);
                it.remove(); // 💣 удаляем вызов
            }
        }
    }

    // ---------------- Hook ----------------

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.equals("com.android.phone"))
            return;

        XposedBridge.log("🔥 AUTO RIL BLOCKER LOADED");

        final Context context = AndroidAppHelper.currentApplication();

        try {
            Class<?> clazz = XposedHelpers.findClass(
                    "com.android.internal.telephony.RadioResponse",
                    lpparam.classLoader
            );

            // 🔥 ХУКАЕМ ВСЕ МЕТОДЫ КЛАССА
            XposedBridge.hookAllMethods(clazz, null, new XC_MethodHook() {

                @Override
                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {

                    Object[] args = param.args;

                    if (args == null) return;

                    for (Object arg : args) {

                        if (arg instanceof ArrayList) {

                            ArrayList<?> calls = (ArrayList<?>) arg;

                            // быстрый фильтр — это список вызовов?
                            if (!calls.isEmpty()) {

                                Object first = calls.get(0);

                                if (first != null) {

                                    String test = extractNumber(first);

                                    if (test != null) {
                                        // 🔥 это список звонков
                                        XposedBridge.log("📡 RIL calls detected in: " + param.method.getName());

                                        processCalls(context, calls);
                                    }
                                }
                            }
                        }
                    }
                }
            });

        } catch (Throwable t) {
            XposedBridge.log("RIL AUTO HOOK ERROR: " + t);
        }
    }
}