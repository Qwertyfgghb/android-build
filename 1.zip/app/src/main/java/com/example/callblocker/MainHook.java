package com.example.callblocker;

import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    // ---------------- Настройки ----------------
    private static final Set<String> BLACKLIST = new HashSet<>();
    private static final Set<String> WHITELIST = new HashSet<>();
    private static final boolean BLOCK_HIDDEN = true;

    static {
        BLACKLIST.add("77715676215"); // пример черного номера
        // WHITELIST.add("79161234567"); // пример белого номера
    }

    private String normalize(String n) {
        if (n == null) return "";
        return n.replaceAll("[^0-9+]", "");
    }

    private boolean match(String num, Set<String> list) {
        if (num == null || num.isEmpty()) return false;
        for (String pattern : list) {
            try {
                if (Pattern.compile(pattern).matcher(num).find()) return true;
            } catch (Throwable ignored) {}
        }
        return false;
    }

    private String extractNumber(Object callObj) {
        try {
            Field baseField = callObj.getClass().getField("base");
            Object base = baseField.get(callObj);
            Field numberField = base.getClass().getField("number");
            return (String) numberField.get(base);
        } catch (Throwable e) {
            try {
                Field numberField = callObj.getClass().getField("number");
                return (String) numberField.get(callObj);
            } catch (Throwable ignored) {}
        }
        return null;
    }

    private void killPhoneProcess() {
        try {
            XposedBridge.log("💀 KILLING com.android.phone");
            android.os.Process.killProcess(android.os.Process.myPid());
        } catch (Throwable t) {
            XposedBridge.log("❌ KILL ERROR: " + t);
        }
    }

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.equals("com.android.phone")) return;

        XposedBridge.log("🔥 UNIVERSAL TRUECALLER BLOCKER LOADED");

        // ---------------- RIL HOOK ----------------
        try {
            Class<?> radioResponse = XposedHelpers.findClass(
                    "com.android.internal.telephony.RadioResponse",
                    lpparam.classLoader
            );

            for (Method m : radioResponse.getDeclaredMethods()) {
                String name = m.getName().toLowerCase();
                if (!name.contains("call")) continue;

                XposedBridge.log("📡 FOUND RIL METHOD: " + name);

                XposedBridge.hookAllMethods(radioResponse, m.getName(), new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        try {
                            Object[] args = param.args;
                            if (args == null) return;

                            for (Object arg : args) {
                                if (arg instanceof ArrayList) {
                                    ArrayList<?> calls = (ArrayList<?>) arg;
                                    if (!calls.isEmpty()) {
                                        Iterator<?> it = calls.iterator();
                                        while (it.hasNext()) {
                                            Object call = it.next();
                                            String num = normalize(extractNumber(call));
                                            if ((BLOCK_HIDDEN && num.isEmpty()) || match(num, BLACKLIST)) {
                                                XposedBridge.log("💣 PRE-GUDOK BLOCK (RIL): " + num);
                                                it.remove(); // удаляем звонок до UI (VoLTE / 4G)
                                            }
                                        }
                                    }
                                }
                            }
                        } catch (Throwable t) {
                            XposedBridge.log("❌ RIL PROCESS ERROR: " + t);
                        }
                    }
                });
            }
        } catch (Throwable t) {
            XposedBridge.log("❌ RIL HOOK FAIL: " + t);
        }

        // ---------------- CONNECTION HOOK / 3G-2G fallback ----------------
        String[] connectionClasses = {
                "com.android.internal.telephony.Connection",
                "com.android.internal.telephony.GsmConnection",
                "com.android.internal.telephony.CdmaConnection"
        };

        for (String cls : connectionClasses) {
            try {
                XposedHelpers.findAndHookMethod(
                        cls,
                        lpparam.classLoader,
                        "getAddress",
                        new XC_MethodHook() {
                            @Override
                            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                                try {
                                    String num = (String) param.getResult();
                                    String clean = normalize(num);
                                    XposedBridge.log("📞 CONN NUMBER: " + clean);

                                    if ((BLOCK_HIDDEN && clean.isEmpty()) || match(clean, BLACKLIST)) {
                                        XposedBridge.log("💣 HARD BLOCK (CONNECTION): " + cls + " " + clean);

                                        // Попытка setDisconnected()
                                        try {
                                            Method setDisc = param.thisObject.getClass().getMethod("setDisconnected");
                                            setDisc.invoke(param.thisObject);
                                            XposedBridge.log("✅ CALL SET DISCONNECTED");
                                        } catch (NoSuchMethodException ignored) {
                                            // fallback: kill phone
                                            killPhoneProcess();
                                        }

                                        // скрыть номер для вызывающего
                                        param.setResult(null);
                                    }
                                } catch (Throwable t) {
                                    XposedBridge.log("❌ CONNECTION ERROR: " + t);
                                }
                            }
                        }
                );
            } catch (XposedHelpers.ClassNotFoundError e) {
                XposedBridge.log("❌ CONNECTION HOOK FAIL: " + cls + " not found (3G/2G fallback will use kill process)");
            }
        }
    }
}