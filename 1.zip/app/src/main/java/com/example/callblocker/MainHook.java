package com.example.callblocker;

import android.app.AndroidAppHelper;
import android.content.Context;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    // -------- utils --------

    private String normalize(String n) {
        if (n == null) return "";
        return n.replaceAll("[^0-9+]", "");
    }

    private String extractNumber(Object callObj) {
        try {
            // MTK / HIDL структура
            Field baseField = callObj.getClass().getField("base");
            Object base = baseField.get(callObj);
            Field numberField = base.getClass().getField("number");
            return (String) numberField.get(base);
        } catch (Throwable e) {
            try {
                Field numberField = callObj.getClass().getField("number");
                return (String) numberField.get(callObj);
            } catch (Throwable ignored) {}
        }
        return null;
    }

    private boolean isHidden(String num) {
        return num == null || num.isEmpty();
    }

    private void processCalls(Context context, ArrayList<?> calls) {
        if (calls == null) return;

        Set<String> black = SettingsManager.getBlack(context);
        Set<String> white = SettingsManager.getWhite(context);
        boolean blockHidden = SettingsManager.isHiddenBlock(context);

        Iterator<?> it = calls.iterator();

        while (it.hasNext()) {
            Object call = it.next();
            String raw = extractNumber(call);
            String num = normalize(raw);

            XposedBridge.log("📡 RIL NUMBER DETECTED: " + num);

            // Скрытые номера
            if (isHidden(raw)) {
                if (blockHidden) {
                    XposedBridge.log("🚫 BLOCK HIDDEN NUMBER");
                    it.remove();
                }
                continue;
            }

            // Whitelist
            if (SettingsManager.matchRegex(num, white)) {
                XposedBridge.log("✅ WHITELIST: " + num);
                continue;
            }

            // Blacklist
            if (SettingsManager.matchRegex(num, black)) {
                XposedBridge.log("🔥 BLACKLIST BLOCK: " + num);
                it.remove(); // основная логика блокировки
            }
        }
    }

    // -------- hook --------
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.equals("com.android.phone")) return;

        XposedBridge.log("🔥 AUTO RIL DEEP SCANNER LOADED");

        final Context context = AndroidAppHelper.currentApplication();

        // Все возможные версии RIL методов
        String[] methods = {
                "responseCurrentCalls_1_0",
                "responseCurrentCalls_1_1",
                "responseCurrentCalls_1_2",
                "getCurrentCallsResponse_1_0",
                "getCurrentCallsResponse_1_1",
                "getCurrentCallsResponse_1_2",
                "getCurrentCallsResponse_1_4"
        };

        for (String m : methods) {
            try {
                XposedHelpers.findAndHookMethod(
                        "com.android.internal.telephony.RadioResponse",
                        lpparam.classLoader,
                        m,
                        android.hardware.radio.V1_0.RadioResponseInfo.class,
                        ArrayList.class,
                        new XC_MethodHook() {
                            @Override
                            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                                Object arg = param.args[1];
                                if (arg instanceof ArrayList) {
                                    ArrayList<?> calls = (ArrayList<?>) arg;
                                    if (!calls.isEmpty()) {
                                        XposedBridge.log("📡 RIL METHOD HOOKED: " + param.method.getName());
                                        processCalls(context, calls);
                                    }
                                }
                            }
                        }
                );
                XposedBridge.log("✅ Hooked RIL method: " + m);
            } catch (Throwable t) {
                XposedBridge.log("❌ Failed to hook RIL method: " + m + " | " + t);
            }
        }
    }
}