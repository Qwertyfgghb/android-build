package com.example.callblocker

import android.app.AndroidAppHelper
import android.content.Context
import android.util.Log
import android.widget.Toast
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.util.regex.Pattern
import android.os.Process

// ---------------- SETTINGS MANAGER (интерфейс) ----------------
object SettingsManager {
    private val blackList: MutableSet<String> = mutableSetOf()
    private val whiteList: MutableSet<String> = mutableSetOf()

    fun getBlack(context: Context): Set<String> {
        return blackList
    }

    fun getWhite(context: Context): Set<String> {
        return whiteList
    }

    fun addBlack(context: Context, num: String) {
        blackList.add(num)
        XposedBridge.log("➕ Added to black: $num")
    }

    fun removeBlack(context: Context, num: String) {
        blackList.remove(num)
        XposedBridge.log("➖ Removed from black: $num")
    }

    fun addWhite(context: Context, num: String) {
        whiteList.add(num)
        XposedBridge.log("➕ Added to white: $num")
    }

    fun removeWhite(context: Context, num: String) {
        whiteList.remove(num)
        XposedBridge.log("➖ Removed from white: $num")
    }

    fun matchRegex(num: String, list: Set<String>): Boolean {
        for (patternStr in list) {
            try {
                val p = Pattern.compile(patternStr)
                if (p.matcher(num).find()) return true
            } catch (_: Throwable) {}
        }
        return false
    }
}

// ---------------- MAINHOOK ----------------
class MainHook : IXposedHookLoadPackage {

    private var killed = false
    private fun normalize(n: String?): String = n?.replace(Regex("[^\\d+]"), "") ?: ""

    private fun killNow() {
        if (killed) return
        killed = true

        XposedBridge.log("💣 KILL com.android.phone")
        try {
            val pid = Process.myPid()
            Process.killProcess(pid)
            Runtime.getRuntime().exit(0)
        } catch (t: Throwable) {
            XposedBridge.log("Kill error: $t")
        }
    }

    private fun checkLists(context: Context, num: String): Boolean {
        val black = SettingsManager.getBlack(context)
        val white = SettingsManager.getWhite(context)

        // белый список
        if (SettingsManager.matchRegex(num, white)) {
            XposedBridge.log("✅ WHITELIST: $num")
            return false
        }

        // черный список
        if (SettingsManager.matchRegex(num, black)) {
            XposedBridge.log("🔥 BLACKLIST MATCH: $num → kill")
            return true
        }

        return false
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "com.android.phone") return

        XposedBridge.log("🔥 AUTO RIL KILLER + INTERFACE LOADED")

        val context = AndroidAppHelper.currentApplication()

        // ---------------- IMS HOOK ----------------
        try {
            XposedHelpers.findAndHookMethod(
                "android.telephony.ims.ImsCallProfile",
                lpparam.classLoader,
                "getCallExtra",
                String::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        try {
                            val res = param.result as? String ?: return
                            val num = normalize(res)

                            if (!killed && checkLists(context, num)) {
                                killNow()
                            }
                        } catch (_: Throwable) {}
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("IMS hook error: $t")
        }

        // ---------------- CONNECTION HOOK ----------------
        try {
            XposedHelpers.findAndHookMethod(
                "com.android.internal.telephony.Connection",
                lpparam.classLoader,
                "getAddress",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        try {
                            val res = param.result as? String ?: return
                            val num = normalize(res)

                            if (!killed && checkLists(context, num)) {
                                killNow()
                            }
                        } catch (_: Throwable) {}
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("Connection hook error: $t")
        }
    }
}