package com.example.callblocker;

import java.lang.reflect.Field;
import java.util.ArrayList;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    // 🔥 ТВОЙ НОМЕР
    private static final String TARGET = "7715676215";

    // ---------------- Utils ----------------

    private String normalize(String n) {
        if (n == null) return "";
        return n.replaceAll("[^0-9+]", "");
    }

    private String extractNumber(Object callObj) {

        try {
            Field baseField = callObj.getClass().getField("base");
            Object base = baseField.get(callObj);

            Field numberField = base.getClass().getField("number");
            return (String) numberField.get(base);

        } catch (Throwable e) {

            try {
                Field numberField = callObj.getClass().getField("number");
                return (String) numberField.get(callObj);
            } catch (Throwable ignored) {}

        }

        return null;
    }

    // ---------------- Core ----------------

    private void processCalls(ArrayList<?> calls) {

        if (calls == null || calls.isEmpty()) return;

        for (Object call : calls) {

            String num = extractNumber(call);
            String clean = normalize(num);

            if (clean.isEmpty()) continue;

            XposedBridge.log("📞 RIL NUMBER: " + clean);

            // 🔥 MATCH
            if (clean.contains(TARGET)) {

                XposedBridge.log("🔥 BLOCKED (ULTRA): " + clean);

                // 💣 ЖЁСТКИЙ БЛОК
                calls.clear();

                return;
            }
        }
    }

    // ---------------- Hook ----------------

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.equals("com.android.phone"))
            return;

        XposedBridge.log("🔥 ULTRA RIL BLOCKER LOADED");

        try {
            Class<?> clazz = XposedHelpers.findClass(
                    "com.android.internal.telephony.RadioResponse",
                    lpparam.classLoader
            );

            // 🔥 АВТО-ДЕТЕКТ КАК FRIDA
            for (java.lang.reflect.Method m : clazz.getDeclaredMethods()) {

                String name = m.getName();

                if (!name.toLowerCase().contains("call")) continue;

                XposedBridge.log("📡 FOUND: " + name);

                XposedBridge.hookAllMethods(clazz, name, new XC_MethodHook() {

                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {

                        try {
                            Object[] args = param.args;
                            if (args == null) return;

                            for (Object arg : args) {

                                if (arg instanceof ArrayList) {

                                    ArrayList<?> calls = (ArrayList<?>) arg;

                                    if (!calls.isEmpty()) {

                                        XposedBridge.log("📡 PROCESSING: " + param.method.getName());

                                        processCalls(calls);
                                    }
                                }
                            }

                        } catch (Throwable t) {
                            XposedBridge.log("❌ ERROR: " + t);
                        }
                    }
                });
            }

            XposedBridge.log("✅ ULTRA HOOK READY");

        } catch (Throwable t) {
            XposedBridge.log("❌ HOOK FAIL: " + t);
        }
    }
}