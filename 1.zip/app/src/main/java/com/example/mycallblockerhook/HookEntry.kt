package com.example.mycallblockerhook

import android.app.ActivityManager
import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers

class HookEntry : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam) {
        try {
            val classLoader = lpparam.classLoader
            XposedHelpers.findAndHookMethod(
                "com.android.internal.telephony.RadioResponse",
                classLoader,
                "getCurrentCallsResponse_1_2",
                Array<Any>::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val calls = param.args[0] as Array<*>
                        val context = param.thisObject.javaClass
                            .getDeclaredMethod("getContext")
                            .invoke(param.thisObject) as Context

                        val prefs = context.getSharedPreferences("NumberFilterPrefs", Context.MODE_PRIVATE)
                        val blackList = prefs.getStringSet("blackList", setOf()) ?: setOf()
                        val whiteList = prefs.getStringSet("whiteList", setOf()) ?: setOf()
                        val blackRegex = blackList.map { Regex(it) }

                        for (call in calls) {
                            val base = XposedHelpers.getObjectField(call, "base")
                            val number = XposedHelpers.getObjectField(base, "number") as String
                            val presentation = XposedHelpers.getObjectField(base, "numberPresentation") as Int

                            if (presentation != 1) continue // игнор скрытых номеров

                            val shouldKill = blackRegex.any { it.matches(number) } ||
                                    (whiteList.isNotEmpty() && number !in whiteList)

                            if (shouldKill) {
                                val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                                for (proc in am.runningAppProcesses) {
                                    if (proc.processName == "com.android.phone") {
                                        android.os.Process.killProcess(proc.pid)
                                    }
                                }
                            }
                        }
                    }
                }
            )
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }
}