package com.example.mycallblocker

import android.content.Context

object PreferencesManager {
    private const val PREFS_NAME = "NumberFilterPrefs"
    private const val KEY_BLACKLIST = "blackList"
    private const val KEY_WHITELIST = "whiteList"

    fun getBlackList(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_BLACKLIST, setOf()) ?: setOf()
    }

    fun getWhiteList(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_WHITELIST, setOf()) ?: setOf()
    }

    fun saveBlackList(context: Context, list: Set<String>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putStringSet(KEY_BLACKLIST, list).apply()
    }

    fun saveWhiteList(context: Context, list: Set<String>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putStringSet(KEY_WHITELIST, list).apply()
    }
}