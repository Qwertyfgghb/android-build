package com.example.mycallblocker

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var blackListView: ListView
    private lateinit var adapter: NumberAdapter
    private lateinit var inputNumber: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        blackListView = findViewById(R.id.blackListView)
        inputNumber = findViewById(R.id.inputNumber)
        val addButton: Button = findViewById(R.id.addButton)

        val blackList = PreferencesManager.getBlackList(this).toMutableList()
        adapter = NumberAdapter(this, blackList) { number ->
            blackList.remove(number)
            PreferencesManager.saveBlackList(this, blackList.toSet())
            adapter.notifyDataSetChanged()
        }
        blackListView.adapter = adapter

        addButton.setOnClickListener {
            val number = inputNumber.text.toString()
            if (number.isNotEmpty() && !blackList.contains(number)) {
                blackList.add(number)
                PreferencesManager.saveBlackList(this, blackList.toSet())
                adapter.notifyDataSetChanged()
                inputNumber.text.clear()
            }
        }
    }
}