package com.example.mycallblocker

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageButton
import android.widget.TextView

class NumberAdapter(
    private val context: Context,
    private val numbers: MutableList<String>,
    private val onDelete: (String) -> Unit
) : BaseAdapter() {

    override fun getCount(): Int = numbers.size
    override fun getItem(position: Int): Any = numbers[position]
    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_number, parent, false)
        val numberText = view.findViewById<TextView>(R.id.numberText)
        val deleteButton = view.findViewById<ImageButton>(R.id.deleteButton)

        val number = numbers[position]
        numberText.text = number

        deleteButton.setOnClickListener {
            onDelete(number)
        }

        return view
    }
}