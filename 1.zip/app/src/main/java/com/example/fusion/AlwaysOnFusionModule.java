package com.example.fusion;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.util.Log;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.android.AndroidAppHelper;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class AlwaysOnFusionModule implements IXposedHookLoadPackage, SensorEventListener {

    private static final String TAG = "AlwaysOnFusion";

    private SensorManager sensorManager;
    private Sensor rotationVector;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // Для всех приложений (fusion sensor всегда активен)
        try {
            Context context = AndroidAppHelper.currentApplication();

            if (sensorManager == null) {
                sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
                rotationVector = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);

                if (rotationVector != null) {
                    // Регистрируем listener на высокой частоте
                    sensorManager.registerListener(this, rotationVector, SensorManager.SENSOR_DELAY_GAME);
                    Log.i(TAG, "Fusion sensor listener registered");
                } else {
                    Log.e(TAG, "Rotation Vector sensor not available!");
                }
            }

        } catch (Throwable t) {
            Log.e(TAG, "Error initializing Fusion Sensor", t);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
            float azimuth = event.values[2]; // Z = направление
            float pitch = event.values[0];   // X
            float roll = event.values[1];    // Y

            Log.i(TAG, String.format("Azimuth: %.2f | Pitch: %.2f | Roll: %.2f",
                    azimuth, pitch, roll));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Не нужно
    }
}