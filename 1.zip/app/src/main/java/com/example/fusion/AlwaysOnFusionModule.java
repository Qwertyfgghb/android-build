package com.example.fusion;

import android.util.Log;

import java.io.FileOutputStream;
import java.io.IOException;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class AlwaysOnFusionModule implements IXposedHookLoadPackage {

    private static final String TAG = "AlwaysOnFusion";
    private static final String FUSION_SYSFS = "/sys/class/sensor/m_fusion_misc/fusionactive";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // Фильтруем, чтобы активировать только для Яндекс.Карт
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) {
            return;
        }

        Log.i(TAG, "Yandex Maps loaded, trying to activate Fusion Sensor");

        try {
            // Форсируем Fusion Sensor активным
            FileOutputStream fos = new FileOutputStream(FUSION_SYSFS);
            String forceOn = "1,1,1,1,1,1,1,1";  // формат для MTK Fusion Sensor
            fos.write(forceOn.getBytes());
            fos.flush();
            fos.close();

            Log.i(TAG, "Fusion Sensor activated: " + forceOn);
        } catch (IOException e) {
            Log.e(TAG, "Failed to activate Fusion Sensor", e);
        }
    }
}