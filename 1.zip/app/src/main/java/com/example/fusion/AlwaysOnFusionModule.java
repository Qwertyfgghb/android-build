package com.example.fusion;

import android.util.Log;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

import java.io.DataOutputStream;

public class AlwaysOnFusionModule implements IXposedHookLoadPackage {

    private static final String TAG = "AlwaysOnFusion";
    private static final String FUSION_PATH = "/sys/class/sensor/m_fusion_misc/fusionactive";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        // Подставь пакет приложения, для которого нужен Fusion Sensor
        if (!lpparam.packageName.equals("ru.yandex.yandexmaps")) return;

        Log.i(TAG, "Yandex Maps loaded, trying to activate Fusion Sensor");

        new Thread(() -> {
            while (true) {
                try {
                    // Пробуем записать напрямую
                    java.io.FileOutputStream fos = new java.io.FileOutputStream(FUSION_PATH);
                    fos.write("1,1,1,1,1,1,1,1,1,1".getBytes());
                    fos.close();
                } catch (Exception e) {
                    Log.e(TAG, "Direct write failed, trying via root", e);
                    // Если не получилось, через su
                    try {
                        Process su = Runtime.getRuntime().exec("su");
                        DataOutputStream os = new DataOutputStream(su.getOutputStream());
                        os.writeBytes("echo 1,1,1,1,1,1,1,1,1,1 > " + FUSION_PATH + "\n");
                        os.writeBytes("exit\n");
                        os.flush();
                        su.waitFor();
                        os.close();
                    } catch (Exception ex) {
                        Log.e(TAG, "Root write failed", ex);
                    }
                }

                try {
                    Thread.sleep(2000); // каждые 2 секунды
                } catch (InterruptedException ie) {
                    break;
                }
            }
        }).start();
    }
}