package com.example.audiohook

import de.robv.android.xposed.XposedBridge

object Logger {
    fun d(msg: String) = XposedBridge.log("[AudioHook][DEBUG] $msg")
    fun e(msg: String, t: Throwable? = null) {
        XposedBridge.log("[AudioHook][ERROR] $msg")
        t?.let { XposedBridge.log(it) }
    }
}