package com.example.audiohook

object ClassEnumerator {
    fun getAllClasses(loader: ClassLoader): List<Class<*>> {
        val classes = mutableListOf<Class<*>>()
        try {
            val pathListField = loader.javaClass.getDeclaredField("pathList")
            pathListField.isAccessible = true
            val pathList = pathListField.get(loader)
            val dexElementsField = pathList.javaClass.getDeclaredField("dexElements")
            dexElementsField.isAccessible = true
            val dexElements = dexElementsField.get(pathList) as Array<*>
            dexElements.forEach { element ->
                val dexFileField = element!!.javaClass.getDeclaredField("dexFile")
                dexFileField.isAccessible = true
                val dexFile = dexFileField.get(element)
                val entries = dexFile.javaClass.getMethod("entries").invoke(dexFile) as java.util.Enumeration<String>
                while (entries.hasMoreElements()) {
                    try {
                        classes.add(Class.forName(entries.nextElement(), false, loader))
                    } catch (_: Throwable) {}
                }
            }
        } catch (_: Throwable) {}
        return classes
    }
}