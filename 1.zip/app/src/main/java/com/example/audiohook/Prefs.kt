package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val PREFS_NAME = "audiohook_prefs"

    private lateinit var sp: SharedPreferences
    var isInitialized = false
        private set

    var enabledApps: Set<String>
        get() = sp.getStringSet("enabledApps", emptySet()) ?: emptySet()
        set(value) = sp.edit().putStringSet("enabledApps", value).apply()

    var isAudioOnly: Boolean
        get() = sp.getBoolean("audioOnly", false)
        set(value) = sp.edit().putBoolean("audioOnly", value).apply()

    var isHideThumbnails: Boolean
        get() = sp.getBoolean("hideThumbnails", false)
        set(value) = sp.edit().putBoolean("hideThumbnails", value).apply()

    fun init(context: Context) {
        if (!this::sp.isInitialized) {
            sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            isInitialized = true
        }
    }

    fun isAppEnabled(packageName: String): Boolean = enabledApps.contains(packageName)
}