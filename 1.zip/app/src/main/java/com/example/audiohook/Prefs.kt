package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {

    private const val PREFS_NAME = "audiohook_prefs"
    private const val KEY_ENABLED_APPS = "enabled_apps"
    private const val KEY_AUDIO_ONLY = "audio_only"
    private const val KEY_HIDE_THUMBNAILS = "hide_thumbnails"

    private lateinit var prefs: SharedPreferences
    var isInitialized = false
        private set

    fun init(context: Context) {
        if (!isInitialized) {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            isInitialized = true
        }
    }

    fun setEnabledApps(apps: Set<String>) {
        checkInitialized()
        prefs.edit().putStringSet(KEY_ENABLED_APPS, apps).apply()
    }

    fun getEnabledApps(): Set<String> {
        checkInitialized()
        return prefs.getStringSet(KEY_ENABLED_APPS, emptySet()) ?: emptySet()
    }

    fun setAudioOnly(enabled: Boolean) {
        checkInitialized()
        prefs.edit().putBoolean(KEY_AUDIO_ONLY, enabled).apply()
    }

    fun isAudioOnly(): Boolean {
        checkInitialized()
        return prefs.getBoolean(KEY_AUDIO_ONLY, false)
    }

    fun setHideThumbnails(enabled: Boolean) {
        checkInitialized()
        prefs.edit().putBoolean(KEY_HIDE_THUMBNAILS, enabled).apply()
    }

    fun isHideThumbnails(): Boolean {
        checkInitialized()
        return prefs.getBoolean(KEY_HIDE_THUMBNAILS, false)
    }

    fun isAppEnabled(packageName: String): Boolean {
        return getEnabledApps().contains(packageName)
    }

    private fun checkInitialized() {
        if (!isInitialized) throw IllegalStateException("Prefs not initialized. Call Prefs.init(context) first.")
    }
}