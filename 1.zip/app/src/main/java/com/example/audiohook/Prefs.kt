package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val PREFS_NAME = "audiohook_prefs"
    private lateinit var sharedPreferences: SharedPreferences

    var audioOnly: Boolean
        get() = sharedPreferences.getBoolean("audio_only", true)
        set(value) = sharedPreferences.edit().putBoolean("audio_only", value).apply()

    var hideThumbnails: Boolean
        get() = sharedPreferences.getBoolean("hide_thumbnails", true)
        set(value) = sharedPreferences.edit().putBoolean("hide_thumbnails", value).apply()

    fun init(context: Context) {
        sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun isAppEnabled(packageName: String): Boolean {
        return true // Для универсального применения ко всем приложениям
    }
}