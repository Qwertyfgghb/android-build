package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {

    private const val PREFS_NAME = "audio_hook_prefs"
    private var prefs: SharedPreferences? = null

    /** Инициализация. Вызывать один раз с контекстом приложения */
    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    /** Audio-Only режим */
    fun isAudioOnly(): Boolean = prefs?.getBoolean("audio_only", true) ?: true
    fun setAudioOnly(enabled: Boolean) {
        prefs?.edit()?.putBoolean("audio_only", enabled)?.apply()
    }

    /** Скрывать превью/миниатюры */
    fun isHideThumbnails(): Boolean = prefs?.getBoolean("hide_thumbnails", false) ?: false
    fun setHideThumbnails(enabled: Boolean) {
        prefs?.edit()?.putBoolean("hide_thumbnails", enabled)?.apply()
    }

    /** Список приложений, для которых включён Audio-Only */
    fun getEnabledApps(): Set<String> = prefs?.getStringSet("enabled_apps", emptySet()) ?: emptySet()
    fun setEnabledApps(apps: Set<String>) {
        prefs?.edit()?.putStringSet("enabled_apps", apps)?.apply()
    }

    /** Проверка, включен ли Audio-Only для конкретного пакета */
    fun isAppEnabled(packageName: String): Boolean = getEnabledApps().contains(packageName)
}