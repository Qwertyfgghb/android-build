package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {

    private const val PREFS_NAME = "audiohook_prefs"

    private lateinit var prefs: SharedPreferences
    var isInitialized = false
        private set

    private var _enabledApps = mutableSetOf<String>()
    private var _audioOnly = false
    private var _hideThumbnails = false

    fun init(context: Context) {
        if (isInitialized) return
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        _enabledApps = prefs.getStringSet("enabledApps", emptySet())?.toMutableSet() ?: mutableSetOf()
        _audioOnly = prefs.getBoolean("audioOnly", false)
        _hideThumbnails = prefs.getBoolean("hideThumbnails", false)
        isInitialized = true
    }

    fun setEnabledApps(apps: Set<String>) {
        _enabledApps = apps.toMutableSet()
        prefs.edit().putStringSet("enabledApps", apps).apply()
    }

    fun setAudioOnly(enabled: Boolean) {
        _audioOnly = enabled
        prefs.edit().putBoolean("audioOnly", enabled).apply()
    }

    fun setHideThumbnails(enabled: Boolean) {
        _hideThumbnails = enabled
        prefs.edit().putBoolean("hideThumbnails", enabled).apply()
    }

    fun isAppEnabled(packageName: String): Boolean = _enabledApps.contains(packageName)
    fun isAudioOnly(): Boolean = _audioOnly
    fun isHideThumbnails(): Boolean = _hideThumbnails
}