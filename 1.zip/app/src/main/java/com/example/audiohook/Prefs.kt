package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val PREFS_NAME = "audiohook_prefs"
    private lateinit var prefs: SharedPreferences
    var isInitialized = false
        private set

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        isInitialized = true
    }

    var enabledApps: Set<String>
        get() = prefs.getStringSet("enabledApps", emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet("enabledApps", value).apply()

    var isAudioOnly: Boolean
        get() = prefs.getBoolean("isAudioOnly", true)
        set(value) = prefs.edit().putBoolean("isAudioOnly", value).apply()

    var isHideThumbnails: Boolean
        get() = prefs.getBoolean("isHideThumbnails", true)
        set(value) = prefs.edit().putBoolean("isHideThumbnails", value).apply()

    fun isAppEnabled(packageName: String): Boolean = enabledApps.contains(packageName)
}