package com.example.audiohook

import de.robv.android.xposed.XSharedPreferences

object Prefs {
    private const val PACKAGE = "com.example.audiohook"
    private const val PREFS_NAME = "audiohook_prefs"

    private val prefs = XSharedPreferences(PACKAGE, PREFS_NAME)

    val isAudioOnly: Boolean
        get() {
            prefs.reload()
            return prefs.getBoolean("audioOnly", true)
        }

    val isHideThumbnails: Boolean
        get() {
            prefs.reload()
            return prefs.getBoolean("hideThumbnails", true)
        }

    val enabledApps: Set<String>
        get() {
            prefs.reload()
            return prefs.getStringSet("enabledApps", emptySet()) ?: emptySet()
        }

    fun isAppEnabled(pkg: String): Boolean = enabledApps.contains(pkg)
}