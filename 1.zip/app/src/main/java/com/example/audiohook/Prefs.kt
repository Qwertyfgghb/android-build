package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {

    private const val PREFS_NAME = "audiohook_prefs"
    private const val KEY_AUDIO_ONLY = "audio_only"
    private const val KEY_HIDE_THUMBNAILS = "hide_thumbnails"
    private const val KEY_ENABLED_APPS = "enabled_apps"

    private lateinit var prefs: SharedPreferences
    var isInitialized = false
        private set

    // Сеттеры и геттеры
    var isAudioOnly: Boolean
        get() = prefs.getBoolean(KEY_AUDIO_ONLY, false)
        set(value) = prefs.edit().putBoolean(KEY_AUDIO_ONLY, value).apply()

    var isHideThumbnails: Boolean
        get() = prefs.getBoolean(KEY_HIDE_THUMBNAILS, false)
        set(value) = prefs.edit().putBoolean(KEY_HIDE_THUMBNAILS, value).apply()

    var enabledApps: Set<String>
        get() = prefs.getStringSet(KEY_ENABLED_APPS, emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_ENABLED_APPS, value).apply()

    /**
     * Инициализация Prefs. Нужно вызвать один раз при запуске модуля.
     */
    fun init(context: Context) {
        if (!isInitialized) {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            isInitialized = true
        }
    }

    /**
     * Установить значения по умолчанию для теста или при первом запуске
     */
    fun initDefaults(context: Context, audioOnly: Boolean = true, hideThumbnails: Boolean = true) {
        init(context)
        isAudioOnly = audioOnly
        isHideThumbnails = hideThumbnails
    }

    /**
     * Проверка, включено ли приложение для хуков
     */
    fun isAppEnabled(packageName: String): Boolean {
        return enabledApps.contains(packageName)
    }

    /**
     * Добавить приложение в список включенных
     */
    fun enableApp(packageName: String) {
        enabledApps = enabledApps + packageName
    }

    /**
     * Удалить приложение из списка включенных
     */
    fun disableApp(packageName: String) {
        enabledApps = enabledApps - packageName
    }
}