package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val PREF_NAME = "audio_hook_prefs"
    private const val KEY_ENABLED_APPS = "enabled_apps"
    private const val KEY_AUDIO_ONLY = "audio_only"
    private const val KEY_HIDE_THUMBNAILS = "hide_thumbnails"

    private lateinit var prefs: SharedPreferences
    var isInitialized = false
        private set

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        isInitialized = true
    }

    fun setEnabledApps(apps: Set<String>) {
        prefs.edit().putStringSet(KEY_ENABLED_APPS, apps).apply()
    }

    fun getEnabledApps(): Set<String> =
        prefs.getStringSet(KEY_ENABLED_APPS, emptySet()) ?: emptySet()

    fun isAppEnabled(packageName: String): Boolean =
        getEnabledApps().contains(packageName)

    fun setAudioOnly(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUDIO_ONLY, enabled).apply()
    }

    fun isAudioOnly(): Boolean =
        prefs.getBoolean(KEY_AUDIO_ONLY, false)

    fun setHideThumbnails(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_HIDE_THUMBNAILS, enabled).apply()
    }

    fun isHideThumbnails(): Boolean =
        prefs.getBoolean(KEY_HIDE_THUMBNAILS, false)
}