package com.example.audiohook

import de.robv.android.xposed.XSharedPreferences

object Prefs {
    private const val PREFS_NAME = "audio_hook_prefs"
    private lateinit var prefs: XSharedPreferences

    var audioOnly: Boolean = true
        private set

    var hideThumbnails: Boolean = true
        private set

    fun init(packageName: String) {
        prefs = XSharedPreferences(packageName)
        prefs.makeWorldReadable()
        audioOnly = prefs.getBoolean("audio_only", true)
        hideThumbnails = prefs.getBoolean("hide_thumbnails", true)
    }

    fun setAudioOnly(value: Boolean) {
        prefs.edit().putBoolean("audio_only", value).apply()
        audioOnly = value
    }

    fun setHideThumbnails(value: Boolean) {
        prefs.edit().putBoolean("hide_thumbnails", value).apply()
        hideThumbnails = value
    }
}