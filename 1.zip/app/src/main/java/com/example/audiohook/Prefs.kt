package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val PREFS_NAME = "audio_hook_prefs"
    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun isAudioOnly(): Boolean = prefs.getBoolean("audio_only", true)
    fun setAudioOnly(enabled: Boolean) = prefs.edit().putBoolean("audio_only", enabled).apply()

    fun isHideThumbnails(): Boolean = prefs.getBoolean("hide_thumbnails", false)
    fun setHideThumbnails(enabled: Boolean) = prefs.edit().putBoolean("hide_thumbnails", enabled).apply()

    fun getEnabledApps(): Set<String> = prefs.getStringSet("enabled_apps", emptySet()) ?: emptySet()
    fun setEnabledApps(apps: Set<String>) = prefs.edit().putStringSet("enabled_apps", apps).apply()
    fun isAppEnabled(packageName: String): Boolean = getEnabledApps().contains(packageName)
}
