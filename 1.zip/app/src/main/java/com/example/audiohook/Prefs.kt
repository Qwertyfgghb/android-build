package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

/**
 * Prefs — управляет настройками Audio‑Only для выбранных приложений.
 * Инициализация через Prefs.init(context)
 * Сразу включает Audio‑Only для примера.
 */
object Prefs {

    private const val PREFS_NAME = "audio_hook_prefs"
    private const val KEY_AUDIO_ONLY = "audio_only"
    private const val KEY_ENABLED_APPS = "enabled_apps"

    private lateinit var prefs: SharedPreferences

    /** Инициализация с контекстом приложения */
    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        // Пример: сразу включаем AudioOnly для этих пакетов, если еще не было задано
        if (!prefs.contains(KEY_ENABLED_APPS)) {
            setEnabledApps(setOf(
                "app.revanced.android.youtube",
                "app.revanced.android.gms"
            ))
        }

        // Включаем AudioOnly по умолчанию
        if (!prefs.contains(KEY_AUDIO_ONLY)) {
            setAudioOnly(true)
        }
    }

    /** Проверка включен ли AudioOnly */
    fun isAudioOnly(): Boolean {
        return prefs.getBoolean(KEY_AUDIO_ONLY, true)
    }

    /** Установить AudioOnly */
    fun setAudioOnly(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUDIO_ONLY, enabled).apply()
    }

    /** Получить список включенных приложений */
    fun getEnabledApps(): Set<String> {
        return prefs.getStringSet(KEY_ENABLED_APPS, emptySet()) ?: emptySet()
    }

    /** Установить список включенных приложений */
    fun setEnabledApps(apps: Set<String>) {
        prefs.edit().putStringSet(KEY_ENABLED_APPS, apps).apply()
    }

    /** Проверка, включено ли AudioOnly для конкретного приложения */
    fun isAppEnabled(packageName: String): Boolean {
        return getEnabledApps().contains(packageName)
    }
}