package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {

    private const val PREFS_NAME = "audiohook_prefs"
    private lateinit var prefs: SharedPreferences

    var isAudioOnly: Boolean = true
        private set

    var isHideThumbnails: Boolean = true
        private set

    fun init(context: Context) {
        if (!::prefs.isInitialized) {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            isAudioOnly = prefs.getBoolean("audio_only", true)
            isHideThumbnails = prefs.getBoolean("hide_thumbnails", true)
        }
    }

    fun setAudioOnly(enabled: Boolean) {
        isAudioOnly = enabled
        prefs.edit().putBoolean("audio_only", enabled).apply()
    }

    fun setHideThumbnails(enabled: Boolean) {
        isHideThumbnails = enabled
        prefs.edit().putBoolean("hide_thumbnails", enabled).apply()
    }
}