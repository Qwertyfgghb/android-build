package com.example.audiohook

object Prefs {
    var audioOnly: Boolean = true
        private set
    var hideThumbnails: Boolean = true
        private set

    fun init() {
        // Для простоты дефолтные значения всегда true
        audioOnly = true
        hideThumbnails = true
    }

    fun setAudioOnly(value: Boolean) {
        audioOnly = value
    }

    fun setHideThumbnails(value: Boolean) {
        hideThumbnails = value
    }
}