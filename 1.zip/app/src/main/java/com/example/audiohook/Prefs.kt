package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val PREFS_NAME = "audiohook_prefs"

    // ленивый SharedPreferences
    private var _sharedPreferences: SharedPreferences? = null
    private val sharedPreferences: SharedPreferences
        get() {
            if (_sharedPreferences == null) {
                throw IllegalStateException("Prefs not initialized. Call Prefs.init(context) first!")
            }
            return _sharedPreferences!!
        }

    var audioOnly: Boolean
        get() = sharedPreferences.getBoolean("audio_only", true)
        set(value) = sharedPreferences.edit().putBoolean("audio_only", value).apply()

    var hideThumbnails: Boolean
        get() = sharedPreferences.getBoolean("hide_thumbnails", true)
        set(value) = sharedPreferences.edit().putBoolean("hide_thumbnails", value).apply()

    fun init(context: Context) {
        if (_sharedPreferences == null) {
            _sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    fun isAppEnabled(packageName: String): Boolean {
        return true // применяем ко всем приложениям по умолчанию
    }
}