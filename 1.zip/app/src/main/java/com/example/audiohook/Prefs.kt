package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {

    private const val PREFS_NAME = "audiohook_prefs"
    private lateinit var prefs: SharedPreferences
    var isInitialized = false
        private set

    private const val KEY_ENABLED_APPS = "enabled_apps"
    private const val KEY_AUDIO_ONLY = "audio_only"
    private const val KEY_HIDE_THUMBNAILS = "hide_thumbnails"

    fun init(context: Context) {
        if (!isInitialized) {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            isInitialized = true
        }
    }

    var enabledApps: Set<String>
        get() = prefs.getStringSet(KEY_ENABLED_APPS, emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_ENABLED_APPS, value).apply()

    var isAudioOnly: Boolean
        get() = prefs.getBoolean(KEY_AUDIO_ONLY, true)
        set(value) = prefs.edit().putBoolean(KEY_AUDIO_ONLY, value).apply()

    var isHideThumbnails: Boolean
        get() = prefs.getBoolean(KEY_HIDE_THUMBNAILS, true)
        set(value) = prefs.edit().putBoolean(KEY_HIDE_THUMBNAILS, value).apply()

    fun isAppEnabled(packageName: String) = enabledApps.contains(packageName)
}