package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val PREFS_NAME = "audiohook_prefs"
    private lateinit var prefs: SharedPreferences
    var isInitialized = false
        private set

    var enabledApps: Set<String>
        get() = prefs.getStringSet("enabledApps", emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet("enabledApps", value).apply()

    var isAudioOnly: Boolean
        get() = prefs.getBoolean("audioOnly", true)
        set(value) = prefs.edit().putBoolean("audioOnly", value).apply()

    var isHideThumbnails: Boolean
        get() = prefs.getBoolean("hideThumbnails", true)
        set(value) = prefs.edit().putBoolean("hideThumbnails", value).apply()

    fun init(context: Context) {
        if (!isInitialized) {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            isInitialized = true
        }
    }

    fun isAppEnabled(pkg: String): Boolean = enabledApps.contains(pkg)
}