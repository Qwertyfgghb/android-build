package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val PREFS_NAME = "audiohook_prefs"
    private const val KEY_ENABLED_APPS = "enabled_apps"
    private const val KEY_AUDIO_ONLY = "audio_only"
    private const val KEY_HIDE_THUMBNAILS = "hide_thumbnails"

    private lateinit var prefs: SharedPreferences
    var isInitialized = false
        private set

    fun init(context: Context) {
        if (!isInitialized) {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            isInitialized = true
        }
    }

    var enabledApps: Set<String>
        get() = prefs.getStringSet(KEY_ENABLED_APPS, emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_ENABLED_APPS, value).apply()

    var isAudioOnly: Boolean
        get() = prefs.getBoolean(KEY_AUDIO_ONLY, false)
        set(value) = prefs.edit().putBoolean(KEY_AUDIO_ONLY, value).apply()

    var isHideThumbnails: Boolean
        get() = prefs.getBoolean(KEY_HIDE_THUMBNAILS, false)
        set(value) = prefs.edit().putBoolean(KEY_HIDE_THUMBNAILS, value).apply()

    fun isAppEnabled(packageName: String): Boolean = enabledApps.contains(packageName)

    // Удобные методы для включения
    fun setEnabledApps(apps: Set<String>) {
        enabledApps = apps
    }

    fun setAudioOnly(value: Boolean) {
        isAudioOnly = value
    }

    fun setHideThumbnails(value: Boolean) {
        isHideThumbnails = value
    }
}