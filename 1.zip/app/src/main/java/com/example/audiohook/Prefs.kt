package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val PREFS_NAME = "audio_hook_prefs"
    private lateinit var sharedPreferences: SharedPreferences

    var audioOnly: Boolean = true
        private set
    var hideThumbnails: Boolean = true
        private set

    fun init(context: Context) {
        sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        audioOnly = sharedPreferences.getBoolean("audio_only", true)
        hideThumbnails = sharedPreferences.getBoolean("hide_thumbnails", true)
    }

    fun setAudioOnly(value: Boolean) {
        audioOnly = value
        sharedPreferences.edit().putBoolean("audio_only", value).apply()
    }

    fun setHideThumbnails(value: Boolean) {
        hideThumbnails = value
        sharedPreferences.edit().putBoolean("hide_thumbnails", value).apply()
    }
}