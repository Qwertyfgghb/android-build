package com.example.audiohook

import de.robv.android.xposed.XSharedPreferences

object Prefs {
    private const val PACKAGE = "com.example.audiohook"
    private val prefs = XSharedPreferences(PACKAGE)

    fun isAudioOnly(): Boolean {
        prefs.reload()
        return prefs.getBoolean("audio_only", true)
    }

    fun isHideThumbnails(): Boolean {
        prefs.reload()
        return prefs.getBoolean("hide_thumbnails", false)
    }

    fun getEnabledApps(): Set<String> {
        prefs.reload()
        return prefs.getStringSet("enabled_apps", emptySet()) ?: emptySet()
    }

    fun isAppEnabled(packageName: String): Boolean {
        return getEnabledApps().contains(packageName)
    }
}