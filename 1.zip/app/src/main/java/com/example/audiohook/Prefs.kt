package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {

    private const val PREFS_NAME = "audio_hook_prefs"
    private const val KEY_AUDIO_ONLY = "audio_only"
    private const val KEY_HIDE_THUMBNAILS = "hide_thumbnails"
    private const val KEY_ENABLED_APPS = "enabled_apps"

    private lateinit var prefs: SharedPreferences

    /** Инициализация prefs, должна вызываться один раз в MainHook */
    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    // --- AudioOnly ---
    fun isAudioOnly(): Boolean {
        return prefs.getBoolean(KEY_AUDIO_ONLY, false)
    }

    fun setAudioOnly(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUDIO_ONLY, enabled).apply()
    }

    // --- Hide Thumbnails ---
    fun isHideThumbnails(): Boolean {
        return prefs.getBoolean(KEY_HIDE_THUMBNAILS, false)
    }

    fun setHideThumbnails(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_HIDE_THUMBNAILS, enabled).apply()
    }

    // --- Enabled Apps ---
    fun getEnabledApps(): Set<String> {
        return prefs.getStringSet(KEY_ENABLED_APPS, emptySet()) ?: emptySet()
    }

    fun setEnabledApps(apps: Set<String>) {
        prefs.edit().putStringSet(KEY_ENABLED_APPS, apps).apply()
    }

    fun isAppEnabled(packageName: String): Boolean {
        return getEnabledApps().contains(packageName)
    }
}