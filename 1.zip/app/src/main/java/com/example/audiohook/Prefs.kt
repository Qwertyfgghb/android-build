package com.example.audiohook

import de.robv.android.xposed.XSharedPreferences

object Prefs {
    private const val PREFS_NAME = "com.example.audiohook_preferences"
    private val prefs = XSharedPreferences("com.example.audiohook", PREFS_NAME).apply {
        makeWorldReadable()
    }

    fun isAudioOnly(): Boolean = prefs.getBoolean("audio_only", true)
    fun setAudioOnly(enabled: Boolean) {
        prefs.edit().putBoolean("audio_only", enabled).commit()
    }

    fun isHideThumbnails(): Boolean = prefs.getBoolean("hide_thumbnails", false)
    fun setHideThumbnails(enabled: Boolean) {
        prefs.edit().putBoolean("hide_thumbnails", enabled).commit()
    }

    fun getEnabledApps(): Set<String> = prefs.getStringSet("enabled_apps", emptySet()) ?: emptySet()
    fun setEnabledApps(apps: Set<String>) {
        prefs.edit().putStringSet("enabled_apps", apps).commit()
    }

    fun isAppEnabled(packageName: String): Boolean = getEnabledApps().contains(packageName)
}