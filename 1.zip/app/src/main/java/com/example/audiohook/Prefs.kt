package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val PREFS_NAME = "audio_hook_prefs"
    private var prefs: SharedPreferences? = null

    // Инициализация через контекст
    fun init(context: Context) {
        if (prefs == null) {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    private fun getPrefs(): SharedPreferences {
        return prefs ?: throw IllegalStateException("Prefs not initialized! Call Prefs.init(context) first.")
    }

    fun isAudioOnly(): Boolean = getPrefs().getBoolean("audio_only", true)
    fun setAudioOnly(enabled: Boolean) = getPrefs().edit().putBoolean("audio_only", enabled).apply()

    fun isHideThumbnails(): Boolean = getPrefs().getBoolean("hide_thumbnails", false)
    fun setHideThumbnails(enabled: Boolean) = getPrefs().edit().putBoolean("hide_thumbnails", enabled).apply()

    fun getEnabledApps(): Set<String> = getPrefs().getStringSet("enabled_apps", emptySet()) ?: emptySet()
    fun setEnabledApps(apps: Set<String>) = getPrefs().edit().putStringSet("enabled_apps", apps).apply()
    fun isAppEnabled(packageName: String): Boolean = getEnabledApps().contains(packageName)
}