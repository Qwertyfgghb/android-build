package com.example.audiohook

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val PREFS_NAME = "audio_hook_prefs"
    private lateinit var prefs: SharedPreferences
    var isInitialized = false
        private set

    var enabledApps: Set<String>
        get() = prefs.getStringSet("enabled_apps", emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet("enabled_apps", value).apply()

    var isAudioOnly: Boolean
        get() = prefs.getBoolean("audio_only", false)
        set(value) = prefs.edit().putBoolean("audio_only", value).apply()

    var isHideThumbnails: Boolean
        get() = prefs.getBoolean("hide_thumbnails", false)
        set(value) = prefs.edit().putBoolean("hide_thumbnails", value).apply()

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        isInitialized = true
    }

    fun isAppEnabled(packageName: String) = enabledApps.contains(packageName)
}