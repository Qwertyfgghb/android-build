package com.example.audiohook

import android.media.MediaPlayer
import android.webkit.WebView
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.ui.PlayerView
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isInitialized) return

        if (Prefs.isAudioOnly) {
            hookMediaPlayer(lpparam)
            hookExoPlayer(lpparam)
            hookWebView(lpparam)
        }
    }

    // Хук для MediaPlayer
    private fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                MediaPlayer::class.java,
                "setDisplay",
                android.view.SurfaceHolder::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly) {
                            param.args[0] = null  // убираем Surface, чтобы видео не показывалось
                        }
                    }
                }
            )
        } catch (_: Throwable) {}
    }

    // Хук для ExoPlayer
    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                PlayerView::class.java,
                "setPlayer",
                SimpleExoPlayer::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly) {
                            param.args[0] = null // убираем видео-плеер
                        }
                    }
                }
            )
        } catch (_: Throwable) {}
    }

    // Хук для WebView (YouTube, браузеры)
    private fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                WebView::class.java,
                "loadUrl",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly) {
                            val url = param.args[0] as? String
                            // Если URL ведет на видео, заменяем на аудио-only (например, через embed или mp3 поток)
                            if (url != null && url.contains("youtube.com/watch")) {
                                param.args[0] = url.replace("watch?v=", "embed/") + "?autoplay=1&mute=0"
                            }
                        }
                    }
                }
            )
        } catch (_: Throwable) {}
    }
}