package com.example.audiohook

import android.media.MediaPlayer
import android.webkit.WebView
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isAudioOnly) return

        XposedHelpers.findAndHookMethod(
            MediaPlayer::class.java,
            "setDataSource",
            String::class.java,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    param.result = null // блокируем воспроизведение видео/аудио
                }
            }
        )
    }

    fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isAudioOnly) return

        try {
            val exoPlayerClass = lpparam.classLoader.loadClass("com.google.android.exoplayer2.ExoPlayer")
            XposedHelpers.findAndHookMethod(
                exoPlayerClass,
                "setMediaItem",
                lpparam.classLoader.loadClass("com.google.android.exoplayer2.MediaItem"),
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.result = null
                    }
                }
            )
        } catch (_: Throwable) {
        }
    }

    fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isAudioOnly && !Prefs.isHideThumbnails) return

        try {
            val webViewClass = lpparam.classLoader.loadClass("android.webkit.WebView")
            XposedHelpers.findAndHookMethod(
                webViewClass,
                "loadUrl",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly) {
                            // Отключаем видео
                            param.result = null
                        }
                        if (Prefs.isHideThumbnails) {
                            // Можно добавить очистку изображений или скрыть thumbnails
                        }
                    }
                }
            )
        } catch (_: Throwable) {
        }
    }
}