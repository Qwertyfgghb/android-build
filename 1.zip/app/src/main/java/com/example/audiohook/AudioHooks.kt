package com.example.audiohook

import android.media.MediaPlayer
import android.view.Surface
import android.view.SurfaceHolder
import android.view.View
import android.webkit.WebView
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.lang.reflect.Modifier

object AudioHooks {

    fun hookAllDynamic(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            if (!Prefs.audioOnly) return

            // Базовые хуки
            hookMediaPlayer()
            hookWebView()
            hookExoPlayer(lpparam)

            // Динамический скан всех загруженных классов
            val classLoader = lpparam.classLoader
            val loadedClasses = mutableSetOf<Class<*>>()

            try {
                val vmClasses = Class.forName("dalvik.system.VMStack")
                    .getDeclaredMethod("getClasses")
                    .apply { isAccessible = true }
                    .invoke(null) as Array<Class<*>>
                loadedClasses.addAll(vmClasses)
            } catch (_: Throwable) {}

            // Повторный динамический поиск через ClassLoader
            loadedClasses.addAll(scanClassLoader(classLoader))

            for (clazz in loadedClasses) {
                try {
                    if (Modifier.isAbstract(clazz.modifiers)) continue
                    hookCustomVideoMethods(clazz)
                    hookViews(clazz)
                } catch (_: Throwable) {}
            }

            XposedBridge.log("AudioHooks: супер-универсальные хуки применены")

        } catch (t: Throwable) {
            XposedBridge.log("AudioHooks error: ${t.message}")
        }
    }

    private fun hookMediaPlayer() {
        try {
            XposedHelpers.findAndHookMethod(MediaPlayer::class.java, "setSurface", Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null
                    }
                })
            XposedBridge.log("MediaPlayer hook applied")
        } catch (_: Throwable) {}
    }

    private fun hookWebView() {
        try {
            XposedHelpers.findAndHookMethod(WebView::class.java, "loadUrl", String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val url = param.args[0] as String
                        if (url.contains("video") || url.endsWith(".mp4")) {
                            param.args[0] = "about:blank"
                        }
                    }
                })
            XposedBridge.log("WebView hook applied")
        } catch (_: Throwable) {}
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val exoClass = lpparam.classLoader.loadClass("com.google.android.exoplayer2.SimpleExoPlayer")
            XposedHelpers.findAndHookMethod(exoClass, "setVideoSurface", Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null
                    }
                })
            XposedBridge.log("ExoPlayer hook applied")
        } catch (_: Throwable) {
            XposedBridge.log("ExoPlayer class not found, skipping hook")
        }
    }

    private fun scanClassLoader(loader: ClassLoader): Set<Class<*>> {
        val classes = mutableSetOf<Class<*>>()
        try {
            val clazzField = ClassLoader::class.java.getDeclaredField("pathList")
            clazzField.isAccessible = true
            val pathList = clazzField.get(loader)
            val dexElementsField = pathList.javaClass.getDeclaredField("dexElements")
            dexElementsField.isAccessible = true
            val dexElements = dexElementsField.get(pathList) as Array<*>
            for (element in dexElements) {
                try {
                    val dexClass = element?.javaClass?.getDeclaredField("dexFile")?.get(element)
                    val entries = dexClass?.javaClass?.getDeclaredMethod("entries")?.invoke(dexClass) as? Enumeration<*>
                    entries?.forEach { clazzName ->
                        try {
                            val c = loader.loadClass(clazzName as String)
                            classes.add(c)
                        } catch (_: Throwable) {}
                    }
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
        return classes
    }

    private fun hookCustomVideoMethods(clazz: Class<*>) {
        clazz.methods.forEach { method ->
            val params = method.parameterTypes
            if (params.any { it == Surface::class.java || it == SurfaceHolder::class.java }) {
                XposedHelpers.findAndHookMethod(clazz, method.name, *params.toTypedArray(),
                    object : XC_MethodHook() {
                        override fun beforeHookedMethod(param: MethodHookParam) {
                            param.args = param.args.map { if (it is Surface || it is SurfaceHolder) null else it }.toTypedArray()
                        }
                    })
            }
        }
    }

    private fun hookViews(clazz: Class<*>) {
        if (View::class.java.isAssignableFrom(clazz)) {
            try {
                XposedHelpers.findAndHookMethod(clazz, "setVisibility", Int::class.javaPrimitiveType,
                    object : XC_MethodHook() {
                        override fun beforeHookedMethod(param: MethodHookParam) {
                            if (Prefs.audioOnly) {
                                param.args[0] = View.GONE
                            }
                        }
                    })
            } catch (_: Throwable) {}
        }
    }
}