package com.example.audiohook

import android.util.Log
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import android.view.Surface
import android.view.TextureView
import android.widget.VideoView
import android.media.MediaPlayer
import java.lang.reflect.Method

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            hookMediaPlayer()
            hookVideoView()
            hookWebView()
            hookExoPlayer(lpparam)
            hookCustomVideoMethods(lpparam)
        } catch (e: Exception) {
            Log.e("AudioHooks", "hookAll failed: $e")
        }
    }

    private fun hookMediaPlayer() {
        try {
            XposedHelpers.findAndHookMethod(MediaPlayer::class.java, "setSurface", Surface::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHook.MethodHookParam) {
                    if (Prefs.audioOnly) param.args[0] = null
                }
            })
            Log.i("AudioHooks", "MediaPlayer hook applied")
        } catch (e: Exception) {
            Log.e("AudioHooks", "MediaPlayer hook failed: $e")
        }
    }

    private fun hookVideoView() {
        try {
            XposedHelpers.findAndHookMethod(VideoView::class.java, "setVideoPath", String::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHook.MethodHookParam) {
                    if (Prefs.audioOnly) param.args[0] = null
                }
            })
            Log.i("AudioHooks", "VideoView hook applied")
        } catch (e: Exception) {
            Log.e("AudioHooks", "VideoView hook failed: $e")
        }
    }

    private fun hookWebView() {
        try {
            val clazz = Class.forName("android.webkit.WebView")
            XposedHelpers.findAndHookMethod(clazz, "loadUrl", String::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHook.MethodHookParam) {
                    if (Prefs.hideThumbnails) {
                        // можно подменить миниатюры или отключить их
                    }
                }
            })
            Log.i("AudioHooks", "WebView hook applied")
        } catch (e: Exception) {
            Log.e("AudioHooks", "WebView hook failed: $e")
        }
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val clazz = lpparam.classLoader.loadClass("com.google.android.exoplayer2.SimpleExoPlayer")
            XposedHelpers.findAndHookMethod(clazz, "setVideoSurface", Surface::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHook.MethodHookParam) {
                    if (Prefs.audioOnly) param.args[0] = null
                }
            })
            XposedHelpers.findAndHookMethod(clazz, "setVideoTextureView", TextureView::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHook.MethodHookParam) {
                    if (Prefs.audioOnly) param.args[0] = null
                }
            })
            Log