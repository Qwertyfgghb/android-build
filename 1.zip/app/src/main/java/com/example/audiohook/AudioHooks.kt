package com.example.audiohook

import android.view.Surface
import android.webkit.WebView
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (Prefs.isAudioOnly) {
            hookMediaPlayer(lpparam)
            hookExoPlayer(lpparam)
            hookWebView(lpparam)
        }
    }

    fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val clazz = XposedHelpers.findClass("android.media.MediaPlayer", lpparam.classLoader)
            XposedHelpers.findAndHookMethod(
                clazz,
                "setSurface",
                Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null // блокируем видео-сюрфейс
                    }
                }
            )
        } catch (ignored: Throwable) {}
    }

    fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val clazz = XposedHelpers.findClass("com.google.android.exoplayer2.SimpleExoPlayer", lpparam.classLoader)
            XposedHelpers.findAndHookMethod(
                clazz,
                "setVideoSurface",
                Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null
                    }
                }
            )
        } catch (ignored: Throwable) {}
    }

    fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val clazz = XposedHelpers.findClass(WebView::class.java.name, lpparam.classLoader)
            XposedHelpers.findAndHookMethod(
                clazz,
                "loadUrl",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val url = param.args[0] as String
                        // Здесь можно фильтровать видео
                        if (url.endsWith(".mp4") || url.contains("youtube")) {
                            param.args[0] = "about:blank"
                        }
                    }
                }
            )
        } catch (ignored: Throwable) {}
    }
}