package com.example.audiohook

import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isAudioOnly()) return

        try {
            // Пример перехвата метода MediaPlayer.setDataSource()
            val clazz = XposedHelpers.findClass(
                "android.media.MediaPlayer",
                lpparam.classLoader
            )
            XposedHelpers.findAndHookMethod(
                clazz,
                "setDataSource",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        Logger.d("AudioOnly: MediaPlayer.setDataSource called with ${param.args[0]}")
                        // Можно заменить источник на пустой или оставить для аудио
                    }
                }
            )
        } catch (e: Throwable) {
            Logger.e("hookMediaPlayer error: ${e.message}")
        }
    }

    fun hookThumbnails(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isHideThumbnails()) return

        try {
            // Пример перехвата метода загрузки превью
            val clazz = XposedHelpers.findClass(
                "com.example.youtube.ThumbnailLoader",
                lpparam.classLoader
            )
            XposedHelpers.findAndHookMethod(
                clazz,
                "loadThumbnail",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        Logger.d("HideThumbnails: Blocking thumbnail load for ${param.args[0]}")
                        // Прекращаем выполнение метода
                        param.result = null
                    }
                }
            )
        } catch (e: Throwable) {
            Logger.e("hookThumbnails error: ${e.message}")
        }
    }

    fun hookAnnotations(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Пример: отключение аннотаций/подсказок на видео
        try {
            val clazz = XposedHelpers.findClass(
                "com.example.youtube.AnnotationsManager",
                lpparam.classLoader
            )
            XposedHelpers.findAndHookMethod(
                clazz,
                "showAnnotation",
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        Logger.d("Annotations: Blocking annotation")
                        param.result = null
                    }
                }
            )
        } catch (e: Throwable) {
            Logger.e("hookAnnotations error: ${e.message}")
        }
    }
}