package com.example.audiohook

import android.media.MediaPlayer
import android.webkit.WebView
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (Prefs.audioOnly) {
            hookMediaPlayer(lpparam)
            hookExoPlayer(lpparam)
            hookWebView(lpparam)
        }
    }

    private fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val mediaPlayerClass = MediaPlayer::class.java
            XposedHelpers.findAndHookMethod(mediaPlayerClass, "setSurface", android.view.Surface::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHook.MethodHookParam) {
                    // Отменяем видео
                    param.args[0] = null
                }
            })
            XposedBridge.log("MediaPlayer hook applied")
        } catch (e: Throwable) {
            XposedBridge.log("MediaPlayer hook failed: $e")
        }
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val playerClass = Class.forName("com.google.android.exoplayer2.SimpleExoPlayer", false, lpparam.classLoader)
            XposedHelpers.findAndHookMethod(playerClass, "setVideoSurface", android.view.Surface::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHook.MethodHookParam) {
                    // Отменяем видео
                    param.args[0] = null
                }
            })
            XposedBridge.log("ExoPlayer hook applied")
        } catch (e: ClassNotFoundException) {
            XposedBridge.log("ExoPlayer class not found, skipping hook")
        } catch (e: Throwable) {
            XposedBridge.log("ExoPlayer hook failed: $e")
        }
    }

    private fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val webViewClass = WebView::class.java
            XposedHelpers.findAndHookMethod(webViewClass, "loadUrl", String::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHook.MethodHookParam) {
                    if (Prefs.audioOnly) {
                        // Можно блокировать видео URLs (например .mp4)
                        val url = param.args[0] as String
                        if (url.endsWith(".mp4")) param.args[0] = ""
                    }
                }
            })
            XposedBridge.log("WebView hook applied")
        } catch (e: Throwable) {
            XposedBridge.log("WebView hook failed: $e")
        }
    }
}