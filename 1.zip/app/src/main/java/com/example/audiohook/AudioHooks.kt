package com.example.audiohook

import android.media.MediaPlayer
import android.webkit.WebView
import com.google.android.exoplayer2.SimpleExoPlayer
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam

object AudioHooks {

    fun hookAll(lpparam: LoadPackageParam) {
        if (Prefs.isAudioOnly) {
            hookMediaPlayer(lpparam)
            hookExoPlayer(lpparam)
            hookWebView(lpparam)
        }

        if (Prefs.isHideThumbnails) {
            hookThumbnails(lpparam)
        }
    }

    fun hookMediaPlayer(lpparam: LoadPackageParam) {
        XposedHelpers.findAndHookMethod(
            MediaPlayer::class.java,
            "setDisplay",
            android.view.SurfaceHolder::class.java,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    param.args[0] = null // отключаем визуальный вывод
                }
            }
        )
    }

    fun hookExoPlayer(lpparam: LoadPackageParam) {
        XposedHelpers.findAndHookMethod(
            SimpleExoPlayer::class.java,
            "setVideoSurfaceView",
            android.view.SurfaceView::class.java,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    param.args[0] = null // отключаем вывод видео
                }
            }
        )
        XposedHelpers.findAndHookMethod(
            SimpleExoPlayer::class.java,
            "setVideoTextureView",
            android.view.TextureView::class.java,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    param.args[0] = null // отключаем вывод видео
                }
            }
        )
    }

    fun hookWebView(lpparam: LoadPackageParam) {
        XposedHelpers.findAndHookMethod(
            WebView::class.java,
            "loadUrl",
            String::class.java,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val url = param.args[0] as String
                    if (url.endsWith(".mp4") || url.endsWith(".m3u8")) {
                        param.args[0] = "" // блокируем видео URL
                    }
                }
            }
        )
    }

    fun hookThumbnails(lpparam: LoadPackageParam) {
        // Можно чистить ImageView или любой UI элемент с картинками
        XposedHelpers.findAndHookMethod(
            "android.widget.ImageView",
            lpparam.classLoader,
            "setImageBitmap",
            android.graphics.Bitmap::class.java,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    param.args[0] = null
                }
            }
        )
    }
}