package com.example.audiohook

import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.audioOnly) return

        hookMediaPlayer(lpparam)
        hookExoPlayer(lpparam)
        hookWebView(lpparam)
    }

    private fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.media.MediaPlayer",
                lpparam.classLoader,
                "setDisplay",
                android.view.SurfaceHolder::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null // отключаем видео
                    }
                }
            )
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "com.google.android.exoplayer2.SimpleExoPlayer",
                lpparam.classLoader,
                "setVideoSurface",
                android.view.Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null // отключаем видео
                    }
                }
            )
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.webkit.WebView",
                lpparam.classLoader,
                "loadUrl",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val url = param.args[0].toString()
                        if (Prefs.audioOnly && url.endsWith(".mp4")) {
                            param.result = null // блокируем видео
                        }
                    }
                }
            )
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }
}