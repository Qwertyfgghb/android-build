package com.example.audiohook

import android.graphics.Bitmap
import android.webkit.WebView
import android.widget.ImageView
import android.view.Surface
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodReplacement
import de.robv.android.xposed.XposedHelpers

object AudioHooks {

    fun hookAll(lpparam: IXposedHookLoadPackage.LoadPackageParam) {
        hookMediaPlayer(lpparam)
        hookExoPlayer(lpparam)

        if (Prefs.isHideThumbnails) {
            hookImageView()
            hookWebView()
        }
    }

    private fun hookMediaPlayer(lpparam: IXposedHookLoadPackage.LoadPackageParam) {
        // Аудио проигрывается как есть
    }

    private fun hookExoPlayer(lpparam: IXposedHookLoadPackage.LoadPackageParam) {
        try {
            val clazz = XposedHelpers.findClass(
                "com.google.android.exoplayer2.SimpleExoPlayer",
                lpparam.classLoader
            )
            XposedHelpers.findAndHookMethod(
                clazz,
                "setVideoSurface",
                Surface::class.java,
                object : XC_MethodReplacement() {
                    override fun replaceHookedMethod(param: MethodHookParam): Any? {
                        // Отключаем визуальное воспроизведение
                        return null
                    }
                }
            )
        } catch (_: Throwable) {}
    }

    private fun hookImageView() {
        try {
            XposedHelpers.findAndHookMethod(
                ImageView::class.java,
                "setImageBitmap",
                Bitmap::class.java,
                object : XC_MethodReplacement() {
                    override fun replaceHookedMethod(param: MethodHookParam): Any? {
                        return null // не показываем картинку
                    }
                }
            )
        } catch (_: Throwable) {}
    }

    private fun hookWebView() {
        try {
            XposedHelpers.findAndHookMethod(
                WebView::class.java,
                "loadUrl",
                String::class.java,
                object : XC_MethodReplacement() {
                    override fun replaceHookedMethod(param: MethodHookParam): Any? {
                        val url = param.args[0] as String
                        if (Prefs.isHideThumbnails &&
                            (url.endsWith(".mp4") || url.endsWith(".webm"))
                        ) {
                            return null
                        }
                        return XposedHelpers.callOriginalMethod(param.method, param.thisObject, *param.args)
                    }
                }
            )
        } catch (_: Throwable) {}
    }
}