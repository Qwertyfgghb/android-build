package com.example.audiohook

import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XC_MethodHook
import android.media.MediaPlayer
import android.webkit.WebView

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (Prefs.audioOnly) {
            hookMediaPlayer(lpparam)
            hookExoPlayer(lpparam)
            hookWebView(lpparam)
        }
    }

    private fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                MediaPlayer::class.java,
                "setSurface",
                android.view.Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null
                    }
                })
        } catch (t: Throwable) {
            de.robv.android.xposed.XposedBridge.log("MediaPlayer hook failed: ${t.message}")
        }
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val playerClass = XposedHelpers.findClass(
                "com.google.android.exoplayer2.SimpleExoPlayer",
                lpparam.classLoader
            )
            XposedHelpers.findAndHookMethod(
                playerClass,
                "setVideoSurfaceView",
                android.view.SurfaceView::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null
                    }
                }
            )
        } catch (t: Throwable) {
            de.robv.android.xposed.XposedBridge.log("ExoPlayer hook failed: ${t.message}")
        }
    }

    private fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val webViewClass = XposedHelpers.findClass("android.webkit.WebView", lpparam.classLoader)
            XposedHelpers.findAndHookMethod(
                webViewClass,
                "loadUrl",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.audioOnly) {
                            // Блокируем загрузку видео-ресурсов
                            val url = param.args[0] as String
                            if (url.contains(".mp4") || url.contains(".m3u8")) {
                                param.args[0] = "about:blank"
                            }
                        }
                    }
                }
            )
        } catch (t: Throwable) {
            de.robv.android.xposed.XposedBridge.log("WebView hook failed: ${t.message}")
        }
    }
}