package com.example.audiohook

import android.media.MediaPlayer
import android.view.Surface
import android.webkit.WebView
import com.google.android.exoplayer2.SimpleExoPlayer
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        hookMediaPlayer()
        hookExoPlayer()
        hookWebView()
    }

    private fun hookMediaPlayer() {
        try {
            XposedHelpers.findAndHookMethod(
                MediaPlayer::class.java,
                "start",
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly) {
                            (param.thisObject as? MediaPlayer)?.setSurface(null)
                        }
                    }
                })
        } catch (_: Throwable) {}
    }

    private fun hookExoPlayer() {
        try {
            XposedHelpers.findAndHookMethod(
                SimpleExoPlayer::class.java,
                "setVideoSurface",
                Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly) {
                            param.args[0] = null
                        }
                    }
                })
        } catch (_: Throwable) {}
    }

    private fun hookWebView() {
        try {
            XposedHelpers.findAndHookMethod(
                WebView::class.java,
                "loadUrl",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isHideThumbnails) {
                            val url = param.args[0] as? String
                            if (url != null && (url.endsWith(".mp4") || url.endsWith(".webm"))) {
                                param.args[0] = ""
                            }
                        }
                    }
                })
        } catch (_: Throwable) {}
    }
}