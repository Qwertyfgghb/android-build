package com.example.audiohook

import android.view.Surface
import android.webkit.WebView
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {
    fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.media.MediaPlayer",
                lpparam.classLoader,
                "setSurface",
                Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly()) {
                            param.args[0] = null
                            Logger.d("MediaPlayer surface blocked")
                        }
                    }
                })
        } catch (t: Throwable) { Logger.e("MediaPlayer hook failed", t) }
    }

    fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "com.google.android.exoplayer2.video.MediaCodecVideoRenderer",
                lpparam.classLoader,
                "render",
                Long::class.javaPrimitiveType,
                Long::class.javaPrimitiveType,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly()) {
                            param.result = null
                            Logger.d("ExoPlayer video render blocked")
                        }
                    }
                })
        } catch (t: Throwable) { Logger.e("ExoPlayer hook failed", t) }
    }

    fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.webkit.WebView",
                lpparam.classLoader,
                "loadUrl",
                String::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val webView = param.thisObject as WebView
                        if (Prefs.isAudioOnly()) {
                            webView.evaluateJavascript(
                                "document.querySelectorAll('video').forEach(v => v.style.display='none');",
                                null
                            )
                            Logger.d("WebView videos hidden")
                        }
                        if (Prefs.isHideThumbnails()) {
                            webView.evaluateJavascript(
                                "document.querySelectorAll('img, .thumbnail, .thumb').forEach(el => el.style.display='none');",
                                null
                            )
                            Logger.d("WebView thumbnails hidden")
                        }
                    }
                })
        } catch (t: Throwable) { Logger.e("WebView hook failed", t) }
    }
}