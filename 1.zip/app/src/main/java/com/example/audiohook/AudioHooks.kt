package com.example.audiohook

import android.webkit.WebView
import android.media.MediaPlayer
import com.google.android.exoplayer2.SimpleExoPlayer
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (Prefs.isAudioOnly) {
            hookMediaPlayer(lpparam)
            hookExoPlayer(lpparam)
            hookWebView(lpparam)
        }
    }

    fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                MediaPlayer::class.java,
                "setSurface",
                android.view.Surface::class.java,
                object : de.robv.android.xposed.XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null // Отключаем видео
                    }
                }
            )
        } catch (e: Throwable) {
            Logger.e("MediaPlayer hook failed: ${e.message}")
        }
    }

    fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val playerClass = XposedHelpers.findClass("com.google.android.exoplayer2.SimpleExoPlayer", lpparam.classLoader)
            XposedHelpers.findAndHookMethod(
                playerClass,
                "setVideoSurface",
                android.view.Surface::class.java,
                object : de.robv.android.xposed.XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null
                    }
                }
            )
        } catch (e: Throwable) {
            Logger.e("ExoPlayer hook failed: ${e.message}")
        }
    }

    fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                WebView::class.java,
                "loadUrl",
                String::class.java,
                object : de.robv.android.xposed.XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val url = param.args[0] as String
                        if (Prefs.isHideThumbnails && url.endsWith(".mp4")) {
                            param.args[0] = "" // Блокируем видео отображение
                        }
                    }
                }
            )
        } catch (e: Throwable) {
            Logger.e("WebView hook failed: ${e.message}")
        }
    }
}