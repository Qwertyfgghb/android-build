package com.example.audiohook

import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import android.media.MediaPlayer
import android.webkit.WebView

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (Prefs.audioOnly) {
            hookMediaPlayer(lpparam)
            hookExoPlayer(lpparam)
            hookWebView(lpparam)
        }
    }

    private fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                MediaPlayer::class.java,
                "setDisplay",
                android.view.SurfaceHolder::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null
                    }
                })
            XposedHelpers.findAndHookMethod(
                MediaPlayer::class.java,
                "setSurface",
                android.view.Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null
                    }
                })
            XposedBridge.log("MediaPlayer hook applied")
        } catch (t: Throwable) {
            XposedBridge.log("MediaPlayer hook failed: $t")
        }
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        val classesToTry = arrayOf(
            "com.google.android.exoplayer2.SimpleExoPlayer",
            "com.google.android.exoplayer2.ExoPlayerImpl"
        )
        for (clsName in classesToTry) {
            try {
                val cls = XposedHelpers.findClass(clsName, lpparam.classLoader)
                XposedHelpers.findAndHookMethod(
                    cls,
                    "setVideoSurfaceView",
                    android.view.SurfaceView::class.java,
                    object : XC_MethodHook() {
                        override fun beforeHookedMethod(param: MethodHookParam) {
                            param.args[0] = null
                        }
                    })
                XposedHelpers.findAndHookMethod(
                    cls,
                    "setVideoTextureView",
                    android.view.TextureView::class.java,
                    object : XC_MethodHook() {
                        override fun beforeHookedMethod(param: MethodHookParam) {
                            param.args[0] = null
                        }
                    })
                XposedBridge.log("$clsName hook applied")
            } catch (t: Throwable) {
                XposedBridge.log("$clsName hook failed: $t")
            }
        }
    }

    private fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                WebView::class.java,
                "loadUrl",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.audioOnly) {
                            // Можно блокировать видео url или заменять на пустую страницу
                            param.args[0] = ""
                        }
                    }
                })
            XposedBridge.log("WebView hook applied")
        } catch (t: Throwable) {
            XposedBridge.log("WebView hook failed: $t")
        }
    }
}