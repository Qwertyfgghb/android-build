package com.example.audiohook

import android.media.MediaPlayer
import android.webkit.WebView
import com.google.android.exoplayer2.SimpleExoPlayer
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (Prefs.isAudioOnly) {
            hookMediaPlayer(lpparam)
            hookExoPlayer(lpparam)
            hookWebView(lpparam)
        }
    }

    private fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        XposedHelpers.findAndHookMethod(MediaPlayer::class.java, "setDisplay", android.view.SurfaceHolder::class.java, object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (Prefs.isAudioOnly) {
                    param.args[0] = null
                }
            }
        })
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val playerClass = Class.forName("com.google.android.exoplayer2.SimpleExoPlayer", false, lpparam.classLoader)
            XposedHelpers.findAndHookMethod(playerClass, "setVideoSurface", android.view.Surface::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (Prefs.isAudioOnly) {
                        param.args[0] = null
                    }
                }
            })
        } catch (_: Exception) { }
    }

    private fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        XposedHelpers.findAndHookMethod(WebView::class.java, "loadUrl", String::class.java, object : XC_MethodHook() {
            override fun beforeHookedMethod(param: MethodHookParam) {
                if (Prefs.isHideThumbnails) {
                    val url = param.args[0] as String
                    if (url.contains(".jpg") || url.contains(".png") || url.contains(".gif")) {
                        param.result = null
                    }
                }
            }
        })
    }
}