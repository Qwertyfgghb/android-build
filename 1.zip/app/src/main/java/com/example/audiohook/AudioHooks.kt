package com.example.audiohook

import android.media.MediaPlayer
import android.view.Surface
import android.view.SurfaceHolder
import android.view.View
import android.webkit.WebView
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.util.*

object AudioHooks {

    fun hookAllDynamic(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.audioOnly) return

        hookMediaPlayer()
        hookWebView()
        hookExoPlayer(lpparam)

        try {
            val loadedClasses = mutableSetOf<Class<*>>()

            try {
                val vmClasses = Class.forName("dalvik.system.VMStack")
                    .getDeclaredMethod("getClasses")
                    .apply { isAccessible = true }
                    .invoke(null) as Array<Class<*>>
                loadedClasses.addAll(vmClasses)
            } catch (_: Throwable) {}

            loadedClasses.addAll(scanClassLoader(lpparam.classLoader))

            for (clazz in loadedClasses) {
                try {
                    if (clazz.modifiers and java.lang.reflect.Modifier.ABSTRACT != 0) continue
                    hookCustomVideoMethods(clazz)
                    hookViews(clazz)
                } catch (_: Throwable) {}
            }
        } catch (t: Throwable) {
            XposedBridge.log("AudioHooks error: ${t.message}")
        }
    }

    private fun hookMediaPlayer() {
        try {
            XposedHelpers.findAndHookMethod(MediaPlayer::class.java, "setSurface", Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null
                    }
                })
            XposedBridge.log("MediaPlayer hook applied")
        } catch (_: Throwable) {}
    }

    private fun hookWebView() {
        try {
            XposedHelpers.findAndHookMethod(WebView::class.java, "loadUrl", String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val url = param.args[0] as String
                        if (url.contains("video") || url.endsWith(".mp4")) {
                            param.args[0] = "about:blank"
                        }
                    }
                })
            XposedBridge.log("WebView hook applied")
        } catch (_: Throwable) {}
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val exoClass = lpparam.classLoader.loadClass("com.google.android.exoplayer2.SimpleExoPlayer")
            XposedHelpers.findAndHookMethod(exoClass, "setVideoSurface", Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.args[0] = null
                    }
                })
            XposedBridge.log("ExoPlayer hook applied")
        } catch (_: Throwable) {
            XposedBridge.log("ExoPlayer class not found, skipping hook")
        }
    }

    private fun scanClassLoader(loader: ClassLoader): Set<Class<*>> {
        val classes = mutableSetOf<Class<*>>()
        try {
            val pathListField = loader.javaClass.getDeclaredField("pathList")
            pathListField.isAccessible = true
            val pathList = pathListField.get(loader)
            val dexElementsField = pathList.javaClass.getDeclaredField("dexElements")
            dexElementsField.isAccessible = true
            val dexElements = dexElementsField.get(pathList) as Array<*>
            for (element in dexElements) {
                try {
                    val dexFileField = element?.javaClass?.getDeclaredField("dexFile")?.apply { isAccessible = true }
                    val dexFile = dexFileField?.get(element)
                    val entriesMethod = dexFile?.javaClass?.getDeclaredMethod("entries")?.apply { isAccessible = true }
                    val enumeration = entriesMethod?.invoke(dexFile) as? Enumeration<*>
                    if (enumeration != null) {
                        val list = mutableListOf<String>()
                        while (enumeration.hasMoreElements()) {
                            val name = enumeration.nextElement() as? String
                            if (name != null) list.add(name)
                        }
                        for (clazzName in list) {
                            try {
                                classes.add(loader.loadClass(clazzName))
                            } catch (_: Throwable) {}
                        }
                    }
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
        return classes
    }

    private fun hookCustomVideoMethods(clazz: Class<*>) {
        clazz.methods.forEach { method ->
            val params = method.parameterTypes
            if (params.any { it == Surface::class.java || it == SurfaceHolder::class.java }) {
                XposedHelpers.findAndHookMethod(clazz, method.name, *params,
                    object : XC_MethodHook() {
                        override fun beforeHookedMethod(param: MethodHookParam) {
                            param.args = param.args.map { if (it is Surface || it is SurfaceHolder) null else it }.toTypedArray()
                        }
                    })
            }
        }
    }

    private fun hookViews(clazz: Class<*>) {
        if (View::class.java.isAssignableFrom(clazz)) {
            try {
                XposedHelpers.findAndHookMethod(clazz, "setVisibility", Int::class.javaPrimitiveType,
                    object : XC_MethodHook() {
                        override fun beforeHookedMethod(param: MethodHookParam) {
                            if (Prefs.audioOnly) param.args[0] = View.GONE
                        }
                    })
            } catch (_: Throwable) {}
        }
    }
}