package com.example.audiohook

import android.media.MediaPlayer
import android.view.Surface
import android.view.SurfaceView
import android.view.TextureView
import android.webkit.WebView
import android.widget.ImageView
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            hookMediaPlayer()
            hookExoPlayer(lpparam)
            hookCustomVideoPlayers(lpparam)
            hookWebView()
            if (Prefs.hideThumbnails) hookImageView()
        } catch (e: Throwable) {
            XposedBridge.log("AudioHooks failed: ${e.message}")
        }
    }

    private fun hookMediaPlayer() {
        try {
            XposedHelpers.findAndHookMethod(
                MediaPlayer::class.java, "setSurface", Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.result = null
                    }
                })
            XposedBridge.log("MediaPlayer hook applied")
        } catch (e: Throwable) {
            XposedBridge.log("MediaPlayer hook failed: ${e.message}")
        }
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        val classLoader = lpparam.classLoader
        try {
            val exoClass = classLoader.loadClass("com.google.android.exoplayer2.SimpleExoPlayer")
            arrayOf(
                "setVideoSurface", "setVideoSurfaceView", "setVideoTextureView"
            ).forEach { methodName ->
                try {
                    val paramClass = when (methodName) {
                        "setVideoSurface" -> Surface::class.java
                        "setVideoSurfaceView" -> SurfaceView::class.java
                        else -> TextureView::class.java
                    }
                    XposedHelpers.findAndHookMethod(exoClass, methodName, paramClass,
                        object : XC_MethodHook() {
                            override fun beforeHookedMethod(param: MethodHookParam) {
                                param.result = null
                            }
                        })
                } catch (_: Throwable) {}
            }
            XposedBridge.log("ExoPlayer hook applied")
        } catch (_: ClassNotFoundException) {
            XposedBridge.log("ExoPlayer class not found, skipping hook")
        }
    }

    private fun hookCustomVideoPlayers(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val allClasses = ClassEnumerator.getAllClasses(lpparam.classLoader)
            allClasses.forEach { clazz ->
                clazz.declaredMethods.forEach { method ->
                    if (method.name.contains("setSurface") || method.name.contains("setVideo")) {
                        try {
                            XposedHelpers.findAndHookMethod(
                                clazz, method.name, *method.parameterTypes,
                                object : XC_MethodHook() {
                                    override fun beforeHookedMethod(param: MethodHookParam) {
                                        param.result = null
                                    }
                                })
                        } catch (_: Throwable) {}
                    }
                }
            }
            XposedBridge.log("Custom video players hook applied")
        } catch (e: Throwable) {
            XposedBridge.log("Custom video hook failed: ${e.message}")
        }
    }

    private fun hookWebView() {
        try {
            XposedHelpers.findAndHookMethod(
                WebView::class.java, "loadUrl", String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.result = null
                    }
                })
            XposedHelpers.findAndHookMethod(
                WebView::class.java, "loadData", String::class.java, String::class.java, String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.result = null
                    }
                })
            XposedBridge.log("WebView hook applied")
        } catch (_: Throwable) {}
    }

    private fun hookImageView() {
        try {
            XposedHelpers.findAndHookMethod(
                ImageView::class.java, "setImageBitmap", android.graphics.Bitmap::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.result = null
                    }
                })
            XposedHelpers.findAndHookMethod(
                ImageView::class.java, "setImageDrawable", android.graphics.drawable.Drawable::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        param.result = null
                    }
                })
            XposedBridge.log("ImageView hook applied")
        } catch (_: Throwable) {}
    }
}