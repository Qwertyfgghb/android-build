package com.example.audiohook

import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        Prefs.init()

        // MediaPlayer
        try {
            XposedHelpers.findAndHookMethod(
                "android.media.MediaPlayer",
                lpparam.classLoader,
                "setDataSource",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.audioOnly) {
                            // Блокируем видео только
                            XposedBridge.log("MediaPlayer hook applied (audioOnly)")
                        }
                    }
                }
            )
            XposedBridge.log("MediaPlayer hook applied")
        } catch (e: Throwable) {
            XposedBridge.log("MediaPlayer hook failed: ${e.message}")
        }

        // WebView
        try {
            XposedHelpers.findAndHookMethod(
                "android.webkit.WebView",
                lpparam.classLoader,
                "loadUrl",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.hideThumbnails) {
                            XposedBridge.log("WebView hook applied (hideThumbnails)")
                        }
                    }
                }
            )
            XposedBridge.log("WebView hook applied")
        } catch (e: Throwable) {
            XposedBridge.log("WebView hook failed: ${e.message}")
        }

        // ExoPlayer (если есть)
        try {
            val exoClass = XposedHelpers.findClassIfExists(
                "com.google.android.exoplayer2.SimpleExoPlayer",
                lpparam.classLoader
            )
            if (exoClass != null) {
                XposedHelpers.findAndHookMethod(
                    exoClass,
                    "setVideoSurface",
                    android.view.Surface::class.java,
                    object : XC_MethodHook() {
                        override fun beforeHookedMethod(param: MethodHookParam) {
                            if (Prefs.audioOnly) {
                                param.args[0] = null // Убираем Surface, оставляем аудио
                                XposedBridge.log("ExoPlayer video blocked (audioOnly)")
                            }
                        }
                    }
                )
                XposedBridge.log("ExoPlayer hook applied")
            } else {
                XposedBridge.log("ExoPlayer class not found, skipping hook")
            }
        } catch (e: Throwable) {
            XposedBridge.log("ExoPlayer hook failed: ${e.message}")
        }
    }
}