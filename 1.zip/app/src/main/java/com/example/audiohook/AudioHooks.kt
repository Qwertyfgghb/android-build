package com.example.audiohook

import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.audioOnly) return

        hookMediaPlayer(lpparam)
        hookExoPlayer(lpparam)
        hookWebView(lpparam)
    }

    private fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.media.MediaPlayer",
                lpparam.classLoader,
                "setDataSource",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        // Здесь можно блокировать видео или заменить поток
                    }
                }
            )
        } catch (_: Throwable) {}
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "com.google.android.exoplayer2.SimpleExoPlayer",
                lpparam.classLoader,
                "setMediaItem",
                Class.forName("com.google.android.exoplayer2.MediaItem"),
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        // Можно убрать картинки
                    }
                }
            )
        } catch (_: Throwable) {}
    }

    private fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.webkit.WebView",
                lpparam.classLoader,
                "loadUrl",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.audioOnly) {
                            // Можно заменить URL или блокировать картинки через JS
                        }
                    }
                }
            )
        } catch (_: Throwable) {}
    }
}