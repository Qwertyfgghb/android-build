package com.example.audiohook

import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedHelpers

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (Prefs.isAudioOnly) {
            hookMediaPlayer(lpparam)
            hookExoPlayer(lpparam)
            hookWebView(lpparam)
        }
    }

    fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Пример: можно замокать setVideoSurface на null
        try {
            val clazz = XposedHelpers.findClass(
                "android.media.MediaPlayer", lpparam.classLoader
            )
            XposedHelpers.findAndHookMethod(clazz, "setSurface",
                android.view.Surface::class.java) { param ->
                param.args[0] = null
            }
        } catch (_: Throwable) {}
    }

    fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val clazz = XposedHelpers.findClass(
                "com.google.android.exoplayer2.SimpleExoPlayer", lpparam.classLoader
            )
            XposedHelpers.findAndHookMethod(clazz, "setVideoSurface", android.view.Surface::class.java) { param ->
                param.args[0] = null
            }
        } catch (_: Throwable) {}
    }

    fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val clazz = XposedHelpers.findClass(
                "android.webkit.WebView", lpparam.classLoader
            )
            XposedHelpers.findAndHookMethod(clazz, "loadUrl", String::class.java) { param ->
                val url = param.args[0] as String
                // Можно фильтровать видео-контент
            }
        } catch (_: Throwable) {}
    }
}