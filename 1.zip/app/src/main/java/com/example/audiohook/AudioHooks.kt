package com.example.audiohook

import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (Prefs.isAudioOnly) {
            hookMediaPlayer(lpparam)
            hookExoPlayer(lpparam)
        }
        if (Prefs.isHideThumbnails) {
            hookWebViewThumbnails(lpparam)
        }
    }

    private fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.media.MediaPlayer",
                lpparam.classLoader,
                "setVideoSurface",
                android.view.Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly) {
                            param.args[0] = null // блокируем видео, оставляем аудио
                        }
                    }
                }
            )
        } catch (_: Throwable) {}
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "com.google.android.exoplayer2.SimpleExoPlayer",
                lpparam.classLoader,
                "setVideoSurface",
                android.view.Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly) {
                            param.args[0] = null
                        }
                    }
                }
            )
        } catch (_: Throwable) {}
    }

    private fun hookWebViewThumbnails(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.webkit.WebView",
                lpparam.classLoader,
                "capturePicture",
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isHideThumbnails) {
                            param.result = null // скрываем картинку
                        }
                    }
                }
            )
        } catch (_: Throwable) {}
    }
}