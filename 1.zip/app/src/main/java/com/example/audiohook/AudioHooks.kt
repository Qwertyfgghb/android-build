package com.example.audiohook

import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        hookMediaPlayer(lpparam)
        hookExoPlayer(lpparam)
        hookWebView(lpparam)
    }

    private fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isAudioOnly()) return

        try {
            val clazz = XposedHelpers.findClass("android.media.MediaPlayer", lpparam.classLoader)
            XposedHelpers.findAndHookMethod(clazz, "setSurface", android.view.Surface::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    // блокируем видео отображение
                    param.args[0] = null
                }
            })
        } catch (_: Throwable) { }
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isAudioOnly()) return

        try {
            val clazz = XposedHelpers.findClass("com.google.android.exoplayer2.SimpleExoPlayer", lpparam.classLoader)
            XposedHelpers.findAndHookMethod(clazz, "setVideoSurface", android.view.Surface::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    param.args[0] = null
                }
            })
        } catch (_: Throwable) { }
    }

    private fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isHideThumbnails()) return

        try {
            val clazz = XposedHelpers.findClass("android.webkit.WebView", lpparam.classLoader)
            XposedHelpers.findAndHookMethod(clazz, "loadUrl", String::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val url = param.args[0] as String
                    // если это картинка видео, подменяем на пустую
                    if (url.endsWith(".jpg") || url.endsWith(".png") || url.contains("thumbnail")) {
                        param.args[0] = "about:blank"
                    }
                }
            })
        } catch (_: Throwable) { }
    }
}