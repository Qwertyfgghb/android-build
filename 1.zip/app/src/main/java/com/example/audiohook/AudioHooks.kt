package com.example.audiohook

import android.graphics.Bitmap
import android.widget.ImageView
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

object AudioHooks {

    fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isAudioOnly()) return

        try {
            val mediaPlayerClass = XposedHelpers.findClass("android.media.MediaPlayer", lpparam.classLoader)
            XposedHelpers.findAndHookMethod(mediaPlayerClass, "setDataSource", String::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    Logger.d("AudioOnly: MediaPlayer setDataSource called for ${param.args[0]}")
                }
            })
        } catch (e: Throwable) {
            Logger.e("hookMediaPlayer failed", e)
        }
    }

    fun hookThumbnails(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isHideThumbnails()) return

        try {
            val imageViewClass = XposedHelpers.findClass(ImageView::class.java.name, lpparam.classLoader)
            XposedHelpers.findAndHookMethod(imageViewClass, "setImageBitmap", Bitmap::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    param.args[0] = null
                    Logger.d("HideThumbnails: ImageView setImageBitmap blocked")
                }
            })
        } catch (e: Throwable) {
            Logger.e("hookThumbnails failed", e)
        }
    }
}