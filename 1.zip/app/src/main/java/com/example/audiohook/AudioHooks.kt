package com.example.audiohook

import android.util.Log
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.lang.reflect.Method

object AudioHooks {

    fun hookAll(lpparam: XC_LoadPackage.LoadPackageParam) {
        hookMediaPlayer()
        hookWebView()
        hookDynamicVideoPlayers(lpparam)
    }

    private fun hookMediaPlayer() {
        try {
            val clazz = Class.forName("android.media.MediaPlayer")
            XposedHelpers.findAndHookMethod(clazz, "setSurface", android.view.Surface::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (Prefs.audioOnly) param.args[0] = null
                }
            })
            Log.i("AudioHooks", "MediaPlayer hook applied")
        } catch (e: Exception) {
            Log.e("AudioHooks", "MediaPlayer hook failed: $e")
        }
    }

    private fun hookWebView() {
        try {
            val clazz = Class.forName("android.webkit.WebView")
            XposedHelpers.findAndHookMethod(clazz, "loadUrl", String::class.java, object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    if (Prefs.hideThumbnails) {
                        // Можно подменить миниатюры или отключить их
                    }
                }
            })
            Log.i("AudioHooks", "WebView hook applied")
        } catch (e: Exception) {
            Log.e("AudioHooks", "WebView hook failed: $e")
        }
    }

    private fun hookDynamicVideoPlayers(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val classLoader = lpparam.classLoader

            // Пример перебора: можно использовать рефлексию DexFile или lpparam.classLoader.loadClass
            val classes = mutableListOf<Class<*>>()
            val dexFields = Class.forName("dalvik.system.BaseDexClassLoader")
            val pathListField = dexFields.getDeclaredField("pathList")
            pathListField.isAccessible = true

            val pathList = pathListField.get(classLoader)
            val dexElementsField = pathList.javaClass.getDeclaredField("dexElements")
            dexElementsField.isAccessible = true
            val dexElements = dexElementsField.get(pathList) as Array<*>

            for (element in dexElements) {
                try {
                    val dexFileField = element!!.javaClass.getDeclaredField("dexFile")
                    dexFileField.isAccessible = true
                    val dexFile = dexFileField.get(element)
                    val entriesMethod: Method = dexFile!!.javaClass.getMethod("entries")
                    val enumeration = entriesMethod.invoke(dexFile) as java.util.Enumeration<*>

                    while (enumeration.hasMoreElements()) {
                        val className = enumeration.nextElement() as String
                        try {
                            val clazz = classLoader.loadClass(className)
                            classes.add(clazz)
                        } catch (_: ClassNotFoundException) { }
                    }
                } catch (_: Exception) { }
            }

            // Хук всех методов с surface/video в найденных классах
            for (clazz in classes) {
                for (method in clazz.declaredMethods) {
                    val name = method.name.lowercase()
                    if (Prefs.audioOnly && (name.contains("setsurface") || name.contains("setvideo") || name.contains("settexture"))) {
                        try {
                            XposedHelpers.findAndHookMethod(clazz, method.name, *method.parameterTypes, object : XC_MethodHook() {
                                override fun beforeHookedMethod(param: MethodHookParam) {
                                    for (i in param.args.indices) {
                                        param.args[i] = null
                                    }
                                }
                            })
                        } catch (_: Exception) { }
                    }
                }
            }

            Log.i("AudioHooks", "Dynamic video players hook applied")
        } catch (e: Exception) {
            Log.e("AudioHooks", "Dynamic video players hook failed: $e")
        }
    }
}