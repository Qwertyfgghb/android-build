package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.helpers.AndroidAppHelper

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val app = AndroidAppHelper.currentApplication() ?: return
        Prefs.init(app)

        val pkg = lpparam.packageName
        if (!Prefs.isAppEnabled(pkg)) return

        Logger.d("AudioHook active for package: $pkg")

        // Хуки для аудио-only
        AudioHooks.hookAll(lpparam)
    }
}