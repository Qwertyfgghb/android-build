package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import org.lsposed.lsposed.api.AndroidAppHelper

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            Prefs.init(AndroidAppHelper.currentApplication()) // рабочий метод LSPosed
            AudioHooks.hookAllDynamic(lpparam)
        } catch (t: Throwable) {
            t.printStackTrace()
        }
    }
}