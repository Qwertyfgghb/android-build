package com.example.audiohook

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Безопасная инициализация prefs
        initPrefsSafe(lpparam.appContext)

        val packageName = lpparam.packageName
        if (!Prefs.isAppEnabled(packageName)) return

        Logger.d("AudioHook active for package: $packageName")

        // Здесь ваши хуки
        AudioHooks.hookMediaPlayer(lpparam)
        AudioHooks.hookExoPlayer(lpparam)
        AudioHooks.hookWebView(lpparam)
    }

    private fun initPrefsSafe(context: Context?) {
        context?.let {
            // prefs инициализируем только один раз
            if (!::Prefs.isInitialized) {
                Prefs.init(it)
            }
        } ?: run {
            Logger.e("Failed to get application context")
        }
    }
}