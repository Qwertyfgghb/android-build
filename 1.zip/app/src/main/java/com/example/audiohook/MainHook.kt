package com.example.audiohook

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val context: Context? = lpparam.appInfo?.loadLabel(lpparam.classLoader) as? Context
        if (context != null) {
            Prefs.init(context)
        }
        AudioHooks.hookAll(lpparam)
    }
}