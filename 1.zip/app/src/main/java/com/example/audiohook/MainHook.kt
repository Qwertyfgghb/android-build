package com.example.audiohook

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            // Получаем Context через рефлексию из LoadedApk
            val loadedApk = XposedHelpers.getObjectField(lpparam, "mLoadedApk") 
                ?: XposedHelpers.getObjectField(lpparam, "appInfo") 
            val context = loadedApk as? Context
            if (context != null) Prefs.init(context)
            
            // Запускаем универсальные хуки
            AudioHooks.hookAll(lpparam)
        } catch (e: Throwable) {
            de.robv.android.xposed.XposedBridge.log("MainHook error: ${e.message}")
        }
    }
}