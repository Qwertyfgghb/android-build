package com.example.audiohook

import android.content.Context
import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            // Инициализация Prefs
            val context = lpparam.appInfo.loadLabel(lpparam.classLoader.loadClass("android.content.pm.PackageManager")).toString()
            Prefs.init(lpparam.appInfo.sourceDir.let { /* контекст можно получить через ClassLoader */ throw NotImplementedError() })

        } catch (e: Exception) {
            Log.e("MainHook", "Prefs init failed: $e")
        }

        // Запуск хуков
        AudioHooks.hookAll(lpparam)
    }
}