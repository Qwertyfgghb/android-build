package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_LoadPackage
import de.robv.android.xposed.XposedHelpers
import android.content.Context

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val appContextField = XposedHelpers.findField(lpparam.appInfo.classLoader.loadClass("android.app.Application"), "mBase")
            val context = appContextField.get(null) as? Context ?: return
            Prefs.init(context)
        } catch (e: Exception) {
            // fallback: можно пропустить и использовать XSharedPreferences
        }

        AudioHooks.hookAll(lpparam)
    }
}