package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.helpers.AndroidAppHelper

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            Prefs.init(AndroidAppHelper.currentApplication()) // LSPosed должен быть подключен
            AudioHooks.hookAllDynamic(lpparam)
        } catch (t: Throwable) {
            t.printStackTrace()
        }
    }
}