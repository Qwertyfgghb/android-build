package com.example.audiohook

import android.app.Application
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val app = try {
                Class.forName("android.app.ActivityThread")
                    .getMethod("currentApplication")
                    .invoke(null) as? Application
            } catch (_: Exception) { null }

            app?.let { Prefs.init(it) }
        } catch (_: Exception) {}

        // Если всё ещё не инициализировано, используем безопасный fallback
        if (Prefs.isAppEnabled(lpparam.packageName)) {
            try {
                AudioHooks.hookAll(lpparam)
            } catch (_: Exception) {}
        }
    }
}