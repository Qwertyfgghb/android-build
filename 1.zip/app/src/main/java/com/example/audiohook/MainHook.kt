package com.example.audiohook

import android.app.Application
import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val context: Context = try {
            val app = lpparam.appInfo.loadLabel(lpparam.classLoader) // не бросает ошибку
            lpparam.appInfo.loadLabel(lpparam.classLoader) as? Context ?: return
        } catch (_: Exception) {
            return
        }

        if (!Prefs.isInitialized) {
            Prefs.init(context)
        }

        val packageName = lpparam.packageName
        if (!Prefs.isAppEnabled(packageName)) return

        // Подключаем все хуки
        AudioHooks.hookAll(lpparam)
    }
}