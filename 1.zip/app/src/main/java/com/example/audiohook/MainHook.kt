package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val context = lpparam.appInfo?.let { appInfo ->
            try {
                val loadedApp = lpparam.classLoader.loadClass("android.app.Application")
                val app = loadedApp.getDeclaredConstructor().newInstance()
                app as? android.content.Context
            } catch (e: Exception) {
                null
            }
        }

        if (context != null && !Prefs.isInitialized) {
            Prefs.init(context)
        }

        val pkgName = lpparam.packageName
        if (!Prefs.isAppEnabled(pkgName)) return

        AudioHooks.hookAll(lpparam)
    }
}