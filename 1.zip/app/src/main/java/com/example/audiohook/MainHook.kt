package com.example.audiohook

import android.view.Surface
import android.webkit.WebView
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val packageName = lpparam.packageName
        Logger.d("Loading package: $packageName")

        // Проверяем, включено ли модуль для этого приложения
        if (!Prefs.isAppEnabled(packageName)) {
            Logger.d("Package $packageName is not enabled in AudioOnly settings")
            return
        }

        // Prefs.init мы НЕ вызываем с Context в LSPosed
        // Можно оставить init для Activity модуля (UI), LSPosed hook работает через getEnabledApps()

        AudioHooks.hookMediaPlayer(lpparam)
        AudioHooks.hookExoPlayer(lpparam)
        AudioHooks.hookWebView(lpparam)

        Logger.d("AudioHooks applied for $packageName")
    }
}