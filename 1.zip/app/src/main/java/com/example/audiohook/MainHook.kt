package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val app = Class.forName("android.app.ActivityThread")
                .getMethod("currentApplication")
                .invoke(null) as? android.app.Application

            app?.let { Prefs.init(it) }
        } catch (_: Exception) {}

        if (Prefs.isAppEnabled(lpparam.packageName)) {
            AudioHooks.hookAll(lpparam)
        }
    }
}