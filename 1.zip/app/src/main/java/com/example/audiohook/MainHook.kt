package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            // Инициализация Prefs через Context приложения
            val appContext = lpparam.appInfo?.let {
                lpparam.classLoader.loadClass("android.app.Application")
                    .getDeclaredConstructor().newInstance() as? android.content.Context
            }
            if (appContext != null && !Prefs.isInitialized) {
                Prefs.init(appContext)
            }

            val packageName = lpparam.packageName
            if (!Prefs.isAppEnabled(packageName)) return

            // Применяем все хуки, если включено AudioOnly
            if (Prefs.isAudioOnly) {
                AudioHooks.hookAll(lpparam)
            }
        } catch (_: Exception) {
        }
    }
}