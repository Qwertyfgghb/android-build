package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val packageName = lpparam.packageName
            if (!Prefs.isAppEnabled(packageName)) return

            // Применяем все хуки
            AudioHooks.hookAll(lpparam)
        } catch (_: Throwable) {
        }
    }
}