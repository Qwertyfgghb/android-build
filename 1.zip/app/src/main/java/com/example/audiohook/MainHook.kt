package com.example.audiohook

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedBridge

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            // Получаем контекст приложения
            val context: Context = lpparam.appInfo.loadLabel(lpparam.classLoader) as? Context
                ?: lpparam.classLoader.loadClass("android.app.ActivityThread")
                    .getMethod("currentApplication")
                    .invoke(null) as Context

            Prefs.init(context)  // <--- Инициализация prefs!

            XposedBridge.log("[AudioHook][DEBUG] Loading package: ${lpparam.packageName}")

            if (!Prefs.isAppEnabled(lpparam.packageName)) {
                XposedBridge.log("[AudioHook][DEBUG] Package ${lpparam.packageName} is not enabled in AudioOnly settings")
                return
            }

            // Здесь можно вызывать свои хуки:
            AudioHooks.hookMediaPlayer(lpparam)
            AudioHooks.hookExoPlayer(lpparam)
            AudioHooks.hookWebView(lpparam)

        } catch (t: Throwable) {
            XposedBridge.log("[AudioHook][ERROR] Failed in handleLoadPackage: $t")
        }
    }
}