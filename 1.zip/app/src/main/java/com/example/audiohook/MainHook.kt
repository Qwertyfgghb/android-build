package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Инициализация Prefs через контекст приложения
        try {
            val appContext = lpparam.appInfo?.loadLabel(lpparam.classLoader) as? android.content.Context
            if (appContext != null) Prefs.init(appContext)
        } catch (_: Exception) { }

        val packageName = lpparam.packageName
        if (!Prefs.isAudioOnly && !Prefs.isHideThumbnails) return

        AudioHooks.hookAll(lpparam)
    }
}