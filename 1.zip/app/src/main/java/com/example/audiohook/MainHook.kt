package com.example.audiohook

import android.app.Application
import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedBridge
import com.android.tools.fd.runtime.AndroidAppHelper

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val app: Application? = AndroidAppHelper.currentApplication()
            if (app != null && !Prefs.isInitialized) {
                Prefs.init(app)
            }

            val pkgName = lpparam.packageName
            if (!Prefs.isAppEnabled(pkgName)) return

            AudioHooks.hookAll(lpparam)
        } catch (t: Throwable) {
            XposedBridge.log("[AudioHook][ERROR] Failed to load package: ${t.message}")
        }
    }
}