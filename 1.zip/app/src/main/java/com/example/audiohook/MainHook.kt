package com.example.audiohook

import de.robv.android.xposed.XC_LoadPackage
import de.robv.android.xposed.IXposedHookLoadPackage

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            if (!Prefs.isAppEnabled(lpparam.packageName)) return

            Logger.d("AudioHook loaded for package: ${lpparam.packageName}")

            AudioHooks.hookMediaPlayer(lpparam)
            AudioHooks.hookExoPlayer(lpparam)
            AudioHooks.hookWebView(lpparam)

        } catch (t: Throwable) {
            Logger.e("Error in MainHook.handleLoadPackage", t)
        }
    }
}