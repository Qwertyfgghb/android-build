package com.example.audiohook
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isAppEnabled(lpparam.packageName)) return

        Prefs.init(lpparam.appInfo.loadLabel(lpparam.classLoader as android.content.pm.PackageManager))
        AudioHooks.hookMediaPlayer(lpparam)
        AudioHooks.hookExoPlayer(lpparam)
        AudioHooks.hookWebView(lpparam)
    }
}
