package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedBridge

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            // Инициализация Prefs
            Prefs.init(lpparam.appInfo.sourceDir.let { path ->
                lpparam.appInfo.className?.let { context ->
                    XposedBridge.log("Prefs init: $path")
                    null // Используем null контекст в LSPosed, Prefs не зависит от Context для AudioOnly
                }
            })

            // Применяем аудио-хуки
            AudioHooks.hookAll(lpparam)
        } catch (t: Throwable) {
            XposedBridge.log("Error in MainHook: ${t.message}")
        }
    }
}