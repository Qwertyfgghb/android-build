package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isInitialized) {
            // Инициализируем Prefs без прямого Application context
            val context = lpparam.appInfo?.let {
                lpparam.classLoader.loadClass("android.app.Application")
            }
            // Prefs.init(context) здесь не нужен, SharedPreferences можно обойти через LSPosed Settings
        }

        val packageName = lpparam.packageName
        if (!Prefs.isAppEnabled(packageName)) return

        // Вызываем все хуки
        AudioHooks.hookMediaPlayer(lpparam)
        AudioHooks.hookExoPlayer(lpparam)
        AudioHooks.hookWebView(lpparam)
    }
}