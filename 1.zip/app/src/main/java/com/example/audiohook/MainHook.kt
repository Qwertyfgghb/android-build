package com.example.audiohook

import android.app.Application
import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val context = getApplicationContext(lpparam) ?: return

        if (!Prefs.isInitialized) {
            Prefs.init(context)
        }

        val packageName = lpparam.packageName
        if (!Prefs.isAppEnabled(packageName)) return

        Logger.d("AudioHook active for package: $packageName")

        // Основные хуки
        AudioHooks.hookMediaPlayer(lpparam)
        AudioHooks.hookThumbnails(lpparam)
        AudioHooks.hookAnnotations(lpparam) // Третий хук, если нужен
    }

    // Надёжное получение Application Context
    private fun getApplicationContext(lpparam: XC_LoadPackage.LoadPackageParam): Context? {
        return try {
            val app = Class.forName("android.app.ActivityThread")
                .getDeclaredMethod("currentApplication")
                .invoke(null) as? Application
            app
        } catch (e: Exception) {
            Logger.e("Failed to get application context: ${e.message}")
            null
        }
    }
}