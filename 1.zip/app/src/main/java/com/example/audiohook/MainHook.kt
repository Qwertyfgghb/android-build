package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val packageName = lpparam.packageName

        // Инициализация Prefs будет безопасно внутри AudioHooks
        if (!Prefs.isAppEnabled(packageName)) return

        AudioHooks.hookAll(lpparam)
    }
}