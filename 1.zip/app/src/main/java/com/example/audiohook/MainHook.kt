package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            AudioHooks.hookAll(lpparam)
        } catch (e: Throwable) {
            XposedBridge.log("MainHook error: ${e.message}")
        }
    }
}