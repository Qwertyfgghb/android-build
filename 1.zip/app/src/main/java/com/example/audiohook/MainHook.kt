package com.example.audiohook

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Получаем контекст приложения через appInfo
        val appContext: Context = lpparam.appInfo.loadLabel(lpparam.appInfo.packageName)?.let {
            // fallback если не можем получить контекст
            null
        } ?: return

        // Инициализация Prefs
        Prefs.init(appContext)

        // Проверка включено ли приложение
        if (!Prefs.isAppEnabled(lpparam.packageName)) return

        // Хуки
        AudioHooks.hookMediaPlayer(lpparam)
        AudioHooks.hookExoPlayer(lpparam)
        AudioHooks.hookWebView(lpparam)
    }
}