package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import android.content.Context

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val context: Context? = try {
            lpparam.appInfo?.let {
                // безопасный способ получить контекст приложения
                val app = lpparam.classLoader.loadClass("android.app.ActivityThread")
                    .getMethod("currentApplication").invoke(null) as? Context
                app
            }
        } catch (e: Exception) {
            null
        }

        if (context != null && !Prefs.isInitialized) {
            Prefs.initDefaults(context)
        }

        val packageName = lpparam.packageName
        if (!Prefs.isAppEnabled(packageName)) return

        // Применяем все хуки для аудио-only и скрытия превью
        AudioHooks.hookAll(lpparam)
    }
}