package com.example.audiohook

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XC_MethodHook

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            // Получаем рабочий Application context через XposedHelper
            val context: Context? = XposedHelpers.callStaticMethod(
                XposedHelpers.findClass(
                    "de.robv.android.xposed.XposedHelpers",
                    lpparam.classLoader
                ),
                "getObjectField",
                XposedBridge::class.java,
                "currentApplication"
            ) as? Context

            if (context != null && !Prefs.isInitialized) {
                Prefs.init(context)
            }

            val pkgName = lpparam.packageName
            if (!Prefs.isAppEnabled(pkgName)) return

            AudioHooks.hookAll(lpparam)
        } catch (t: Throwable) {
            XposedBridge.log("[AudioHook][ERROR] Failed to load package: ${t.message}")
        }
    }
}