package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Инициализация настроек
        Prefs.init(lpparam.appInfo.loadLabel(lpparam.classLoader) as android.content.Context)

        if (Prefs.audioOnly) {
            AudioHooks.hookAll(lpparam)
        }
    }
}