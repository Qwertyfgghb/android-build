package com.example.audiohook

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.helpers.AndroidAppHelper

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val context: Context = AndroidAppHelper.currentApplication()
            ?: return

        if (!Prefs.isInitialized) Prefs.init(context)

        val packageName = lpparam.packageName
        if (!Prefs.isAppEnabled(packageName)) return

        // Применяем все хуки, если включено AudioOnly и HideThumbnails
        AudioHooks.hookAll(lpparam)
    }
}