package com.example.audiohook

import android.view.Surface
import android.webkit.WebView
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val context = try {
            // Получаем Context приложения через ActivityThread
            val activityThread = Class.forName("android.app.ActivityThread")
            val app = activityThread.getMethod("currentApplication").invoke(null) as android.app.Application
            app
        } catch (t: Throwable) {
            Logger.e("Failed to get application context", t)
            return
        }

        Prefs.init(context)
        val packageName = lpparam.packageName
        Logger.d("Loading package: $packageName")

        if (!Prefs.isAppEnabled(packageName)) {
            Logger.d("Package $packageName is not enabled in AudioOnly settings")
            return
        }

        hookMediaPlayer(lpparam)
        hookExoPlayer(lpparam)
        hookWebView(lpparam)
    }

    private fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.media.MediaPlayer",
                lpparam.classLoader,
                "setSurface",
                Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly()) param.args[0] = null
                        Logger.d("MediaPlayer surface blocked")
                    }
                }
            )
        } catch (t: Throwable) {
            Logger.e("MediaPlayer hook failed", t)
        }
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "com.google.android.exoplayer2.video.MediaCodecVideoRenderer",
                lpparam.classLoader,
                "render",
                Long::class.javaPrimitiveType,
                Long::class.javaPrimitiveType,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly()) param.result = null
                        Logger.d("ExoPlayer video render blocked")
                    }
                }
            )
        } catch (t: Throwable) {
            Logger.e("ExoPlayer hook failed", t)
        }
    }

    private fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.webkit.WebView",
                lpparam.classLoader,
                "loadUrl",
                String::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val webView = param.thisObject as WebView
                        if (Prefs.isAudioOnly()) {
                            webView.evaluateJavascript(
                                "document.querySelectorAll('video').forEach(v => v.style.display='none');",
                                null
                            )
                            Logger.d("WebView videos hidden")
                        }
                    }
                }
            )
        } catch (t: Throwable) {
            Logger.e("WebView hook failed", t)
        }
    }
}