package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedBridge

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            // Используем XSharedPreferences вместо Context
            Prefs.init("com.example.audiohook")

            // Применяем аудио-хуки
            AudioHooks.hookAll(lpparam)
        } catch (t: Throwable) {
            XposedBridge.log("Error in MainHook: ${t.message}")
        }
    }
}