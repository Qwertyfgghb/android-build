package com.example.audiohook

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Проверяем включено ли приложение для данного пакета
        if (!Prefs.isAppEnabled(lpparam.packageName)) return

        // Инициализируем Prefs с Context
        val context: Context = lpparam.appInfo?.loadLabel(lpparam.appInfo.packageName.let { null }) as? Context
            ?: lpparam.appInfo.applicationInfo?.let { it as? Context } ?: return

        Prefs.init(context)

        // Хуки аудио
        AudioHooks.hookMediaPlayer(lpparam)
        AudioHooks.hookExoPlayer(lpparam)
        AudioHooks.hookWebView(lpparam)
    }
}