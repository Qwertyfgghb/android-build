package com.example.audiohook

import android.app.Application
import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedHelpers

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        try {
            // Получаем Application через ActivityThread
            val activityThreadClass = XposedHelpers.findClass("android.app.ActivityThread", lpparam.classLoader)
            val currentApplication = XposedHelpers.callStaticMethod(activityThreadClass, "currentApplication") as? Application

            currentApplication?.let {
                Prefs.init(it)
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        // Применяем хуки
        AudioHooks.hookAll(lpparam)
    }
}