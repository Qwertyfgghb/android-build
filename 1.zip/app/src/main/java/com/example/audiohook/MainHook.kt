package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.AndroidAppHelper

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val context = AndroidAppHelper.currentApplication()
        if (!Prefs.isInitialized && context != null) {
            Prefs.init(context)
        }

        val packageName = lpparam.packageName
        if (!Prefs.isAppEnabled(packageName)) return

        Logger.d("AudioHook active for package: $packageName")

        // Применяем все хуки
        AudioHooks.hookAll(lpparam)
    }
}