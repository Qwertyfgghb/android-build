package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import android.app.Application
import android.content.Context
import de.robv.android.xposed.XposedHelpers

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Получаем контекст приложения безопасно
        val context: Context? = try {
            val loadedApk = XposedHelpers.getObjectField(lpparam.appInfo, "mLoadedApk")
            val app = XposedHelpers.getObjectField(loadedApk, "mApplication") as? Application
            app ?: return
        } catch (e: Throwable) {
            Logger.e("Failed to get app context", e)
            return
        }

        if (!Prefs.isInitialized) {
            Prefs.init(context)
            // Пример включения целевых приложений
            Prefs.setEnabledApps(setOf("app.revanced.android.youtube", "app.revanced.android.gms"))
            Prefs.setAudioOnly(true)
            Prefs.setHideThumbnails(true)
        }

        val packageName = lpparam.packageName
        if (!Prefs.isAppEnabled(packageName)) return

        Logger.d("AudioHook active for package: $packageName")

        // Хуки
        AudioHooks.hookMediaPlayer(lpparam)
        AudioHooks.hookThumbnails(lpparam)
    }
}