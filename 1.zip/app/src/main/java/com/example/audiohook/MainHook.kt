package com.example.audiohook

import android.content.Context
import android.util.Log
import android.webkit.WebView
import android.view.Surface
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    private val TAG = "AudioHook"

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        val packageName = lpparam.packageName

        // Инициализация Prefs безопасно
        val context: Context? = try {
            lpparam.appInfo?.loadLabel(lpparam.classLoader)?.let {
                // loadLabel возвращает CharSequence, но для Prefs нужен Context — берём из lpparam.appInfo
                lpparam.appInfo.loadLabel(lpparam.classLoader) as? Context
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Cannot get Context for Prefs init", t)
            null
        }

        context?.let { Prefs.init(it) }

        // Проверка, включен ли Audio-Only для этого пакета
        if (!Prefs.isAppEnabled(packageName)) {
            Log.d(TAG, "AudioHook disabled for $packageName")
            return
        }

        Log.d(TAG, "AudioHook enabled for $packageName")

        // Хуки для всех 3 основных функций
        hookMediaPlayer(lpparam)
        hookExoPlayer(lpparam)
        hookWebView(lpparam)
    }

    private fun hookMediaPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.media.MediaPlayer",
                lpparam.classLoader,
                "setSurface",
                Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly()) {
                            param.args[0] = null
                            Log.d(TAG, "MediaPlayer surface blocked")
                        }
                    }
                })
        } catch (t: Throwable) {
            Log.e(TAG, "MediaPlayer hook failed", t)
        }
    }

    private fun hookExoPlayer(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "com.google.android.exoplayer2.video.MediaCodecVideoRenderer",
                lpparam.classLoader,
                "render",
                Long::class.javaPrimitiveType,
                Long::class.javaPrimitiveType,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        if (Prefs.isAudioOnly()) {
                            param.result = null
                            Log.d(TAG, "ExoPlayer video render blocked")
                        }
                    }
                })
        } catch (t: Throwable) {
            Log.e(TAG, "ExoPlayer hook failed", t)
        }
    }

    private fun hookWebView(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            XposedHelpers.findAndHookMethod(
                "android.webkit.WebView",
                lpparam.classLoader,
                "loadUrl",
                String::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val webView = param.thisObject as? WebView ?: return
                        if (Prefs.isAudioOnly()) {
                            webView.evaluateJavascript(
                                "document.querySelectorAll('video').forEach(v => v.style.display='none');",
                                null
                            )
                            Log.d(TAG, "WebView videos hidden")
                        }
                        if (Prefs.isHideThumbnails()) {
                            webView.evaluateJavascript(
                                "document.querySelectorAll('img, .thumbnail, .thumb').forEach(el => el.style.display='none');",
                                null
                            )
                            Log.d(TAG, "WebView thumbnails hidden")
                        }
                    }
                })
        } catch (t: Throwable) {
            Log.e(TAG, "WebView hook failed", t)
        }
    }
}