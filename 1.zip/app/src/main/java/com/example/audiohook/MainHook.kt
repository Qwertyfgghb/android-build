package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedBridge
import android.content.Context

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val context = lpparam.appInfo?.loadLabel(lpparam.classLoader)?.let { lpparam.appInfo }?.let { it.className }
            Prefs.init(context as Context)
        } catch (_: Throwable) {
            // Если Context получить не удалось, используем любой доступный через lpparam
        }

        AudioHooks.hookAll(lpparam)
    }
}