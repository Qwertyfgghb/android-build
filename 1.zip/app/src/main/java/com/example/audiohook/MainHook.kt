package com.example.audiohook

import android.app.Application
import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val packageName = lpparam.packageName

        // Инициализация Prefs один раз на процессе
        if (!Prefs.isInitialized) {
            val context = getApplicationContext(lpparam)
            if (context != null) {
                Prefs.init(context)
                Logger.d("Prefs initialized")
            } else {
                Logger.e("Failed to get application context")
                return
            }
        }

        // Проверка включено ли приложение в настройках
        if (!Prefs.isAppEnabled(packageName)) {
            Logger.d("Package $packageName is not enabled, skipping hooks")
            return
        }

        Logger.d("Applying AudioHooks for package: $packageName")
        AudioHooks.hookAll(lpparam)  // Все хуки включаются
    }

    private fun getApplicationContext(lpparam: XC_LoadPackage.LoadPackageParam): Context? {
        return try {
            val app = lpparam.appInfo.loadLabel(lpparam.classLoader)
            app as? Application
        } catch (t: Throwable) {
            null
        }
    }
}