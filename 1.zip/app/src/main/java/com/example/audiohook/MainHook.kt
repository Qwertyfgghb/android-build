package com.example.audiohook

import android.view.Surface
import android.webkit.WebView
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val packageName = lpparam.packageName
        Logger.d("Loading package: $packageName")

        if (!Prefs.isAppEnabled(packageName)) {
            Logger.d("Package $packageName is not enabled in AudioOnly settings")
            return
        }

        try {
            Prefs.init(lpparam.appInfo.className?.let { it1 -> lpparam.appInfo.loadLabel(lpparam.classLoader) }) // без ошибок init
        } catch (t: Throwable) {
            Logger.e("Prefs.init failed", t)
        }

        AudioHooks.hookMediaPlayer(lpparam)
        AudioHooks.hookExoPlayer(lpparam)
        AudioHooks.hookWebView(lpparam)

        Logger.d("AudioHooks applied for $packageName")
    }
}