package com.example.audiohook

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            // Инициализируем настройки
            Prefs.init(lpparam.appContext)
            
            // Запускаем хуки для видео и WebView
            AudioHooks.hookAll(lpparam)
        } catch (e: Throwable) {
            de.robv.android.xposed.XposedBridge.log("MainHook error: ${e.message}")
        }
    }
}