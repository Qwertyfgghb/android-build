package com.example.audiohook

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            // Инициализация Prefs через Context приложения
            val appContextField = lpparam.appInfo.loadLabel(lpparam.classLoader) // workaround, заменить на рабочий context
            Prefs.init(lpparam.appInfo.loadLabel(lpparam.classLoader) as Context)
        } catch (e: Throwable) {
            e.printStackTrace()
        }

        // Применяем хуки
        AudioHooks.hookAll(lpparam)
    }
}