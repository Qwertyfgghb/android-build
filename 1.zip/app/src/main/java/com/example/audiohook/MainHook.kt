package com.example.audiohook

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (!Prefs.isAppEnabled(lpparam.packageName)) return

        // Получаем Context приложения
        val context: Context = (lpparam.classLoader.loadClass("android.app.ActivityThread")
            .getMethod("currentApplication")
            .invoke(null) as android.app.Application).applicationContext

        // Инициализация SharedPreferences
        Prefs.init(context)

        // Хуки аудио
        AudioHooks.hookMediaPlayer(lpparam)
        AudioHooks.hookExoPlayer(lpparam)
        AudioHooks.hookWebView(lpparam)
    }
}