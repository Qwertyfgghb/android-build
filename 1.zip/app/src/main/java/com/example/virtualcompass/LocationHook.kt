package com.example.virtualcompass

import android.location.Location
import de.robv.android.xposed.*

object LocationHook {

    private var last = 0f

    fun start(gps: GPSProvider) {

        XposedHelpers.findAndHookMethod(
            Location::class.java,
            "getBearing",
            object : XC_MethodHook() {

                override fun afterHookedMethod(param: MethodHookParam) {

                    val az = gps.azimuth

                    if (az != 0f) {
                        last = az
                    }

                    param.result = last
                }
            }
        )
    }
}