package com.example.virtualcompass

class SmoothFilter {

    private var last = 0f

    fun update(value: Float): Float {
        val alpha = 0.15f
        last = last + alpha * (value - last)
        return last
    }
}