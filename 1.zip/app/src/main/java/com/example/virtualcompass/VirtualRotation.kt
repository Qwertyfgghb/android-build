package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import kotlin.math.*

object VirtualRotation {

    private var sensor: Sensor? = null

    fun setSensor(s: Sensor) {
        sensor = s
    }

    fun create(azimuth: Float): SensorEvent {

        val rad = Math.toRadians(azimuth.toDouble())
        val sin = sin(rad / 2)
        val cos = cos(rad / 2)

        val ctor = SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
        ctor.isAccessible = true
        val event = ctor.newInstance(4)

        val valuesField = SensorEvent::class.java.getDeclaredField("values")
        valuesField.isAccessible = true
        val values = valuesField.get(event) as FloatArray

        values[0] = 0f
        values[1] = 0f
        values[2] = sin.toFloat()
        values[3] = cos.toFloat()

        val sensorField = SensorEvent::class.java.getDeclaredField("sensor")
        sensorField.isAccessible = true
        sensorField.set(event, sensor)

        val tsField = SensorEvent::class.java.getDeclaredField("timestamp")
        tsField.isAccessible = true
        tsField.setLong(event, System.nanoTime())

        return event
    }
}