package com.example.virtualcompass

import android.content.Context
import android.location.*
import de.robv.android.xposed.XposedBridge
import kotlin.math.*

class GPSProvider(context: Context) : LocationListener {

    private val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    private var lastLocation: Location? = null
    var azimuth = 0f

    fun start() {
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 200, 0f, this)
            XposedBridge.log("GPS started")
        } catch (e: Exception) {
            XposedBridge.log("GPS error: $e")
        }
    }

    override fun onLocationChanged(loc: Location) {

        val prev = lastLocation

        if (prev != null) {
            val distance = prev.distanceTo(loc)

            if (distance > 0.3f) { // сверх чувствительность
                val bearing = prev.bearingTo(loc)
                azimuth = normalize(bearing)
                XposedBridge.log("AZIMUTH: $azimuth")
            }
        }

        lastLocation = loc
    }

    private fun normalize(b: Float): Float {
        var v = b
        if (v < 0) v += 360f
        return v
    }

    override fun onProviderEnabled(p: String) {}
    override fun onProviderDisabled(p: String) {}
    override fun onStatusChanged(p: String?, s: Int, b: android.os.Bundle?) {}
}