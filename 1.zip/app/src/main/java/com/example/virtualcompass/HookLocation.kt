package com.example.virtualcompass

import android.location.Location
import de.robv.android.xposed.*
import kotlin.math.*

object LocationHook {

    private var lastAzimuth = 0f

    fun start(gps: GPSProvider) {

        XposedBridge.log("HOOK: Location")

        XposedHelpers.findAndHookMethod(
            Location::class.java,
            "getBearing",
            object : XC_MethodHook() {

                override fun afterHookedMethod(param: MethodHookParam) {

                    val az = gps.azimuth

                    if (az != 0f) {
                        lastAzimuth = az
                    }

                    param.result = lastAzimuth
                }
            }
        )
    }
}