package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import de.robv.android.xposed.XposedBridge

object VirtualSensor {

    fun createEvent(azimuth: Float): SensorEvent {
        return try {
            val ctor = SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
            ctor.isAccessible = true
            val event = ctor.newInstance(3)

            val valuesField = SensorEvent::class.java.getDeclaredField("values")
            valuesField.isAccessible = true
            val values = valuesField.get(event) as FloatArray
            values[0] = azimuth
            values[1] = 0f
            values[2] = 0f

            event
        } catch (e: Throwable) {
            XposedBridge.log("VirtualSensor.createEvent error: $e")
            throw e
        }
    }
}