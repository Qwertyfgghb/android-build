package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.concurrent.fixedRateTimer

class VirtualSensor(private val gpsProvider: GPSAzimuthProvider) {

    private val listeners = mutableListOf<SensorEventListener>()

    fun registerListener(listener: SensorEventListener) {
        if (!listeners.contains(listener)) listeners.add(listener)
    }

    fun unregisterListener(listener: SensorEventListener) {
        listeners.remove(listener)
    }

    fun start() {
        fixedRateTimer("virtualSensorTimer", true, 0L, 50L) {
            val azimuth = gpsProvider.currentAzimuth.toFloat()
            val pitch = 0f
            val roll = 0f

            // Создаём псевдо SensorEvent
            val sensorEvent = createSensorEvent(azimuth, pitch, roll)

            // Отправляем всем зарегистрированным слушателям
            listeners.forEach { it.onSensorChanged(sensorEvent) }
        }
    }

    private fun createSensorEvent(azimuth: Float, pitch: Float, roll: Float): SensorEvent {
        val sensor = Sensor(TYPE_ORIENTATION, 0) // TYPE_ORIENTATION
        val event = SensorEvent(3)
        event.sensor = sensor
        event.values[0] = azimuth
        event.values[1] = pitch
        event.values[2] = roll
        return event
    }

    companion object {
        private const val TYPE_ORIENTATION = 1
    }
}