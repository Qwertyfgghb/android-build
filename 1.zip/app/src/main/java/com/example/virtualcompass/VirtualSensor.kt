package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import de.robv.android.xposed.XposedBridge
import java.lang.reflect.Constructor

object VirtualSensor {

    // Создаём "фиктивный" SensorEvent через Reflection
    fun pushAzimuth(listener: SensorEventListener, azimuth: Float, pitch: Float, roll: Float) {
        try {
            // SensorEvent constructor: SensorEvent(int valueArraySize)
            val ctor: Constructor<SensorEvent> = SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
            ctor.isAccessible = true
            val event = ctor.newInstance(3)

            // Sensor field
            val sensorField = SensorEvent::class.java.getDeclaredField("sensor")
            sensorField.isAccessible = true
            sensorField.set(event, Sensor(TYPE_ORIENTATION, 0))

            // Values field
            val valuesField = SensorEvent::class.java.getDeclaredField("values")
            valuesField.isAccessible = true
            val values = valuesField.get(event) as FloatArray
            values[0] = azimuth
            values[1] = pitch
            values[2] = roll

            // Отправляем событие
            listener.onSensorChanged(event)

        } catch (e: Exception) {
            XposedBridge.log("VirtualSensor error: $e")
        }
    }

    private const val TYPE_ORIENTATION = 1
}