package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import de.robv.android.xposed.XposedBridge
import kotlin.math.*

object VirtualSensor {

    /**
     * Создаёт псевдо SensorEvent для TYPE_ROTATION_VECTOR/TYPE_ORIENTATION
     */
    fun createEvent(azimuth: Float): SensorEvent {
        return try {
            // Конструктор SensorEvent через reflection
            val ctor = SensorEvent::class.java
                .getDeclaredConstructor(Int::class.javaPrimitiveType)
            ctor.isAccessible = true
            val event = ctor.newInstance(3) // 3 значения: azimuth, pitch, roll

            val valuesField = SensorEvent::class.java.getDeclaredField("values")
            valuesField.isAccessible = true
            val values = valuesField.get(event) as FloatArray

            values[0] = azimuth      // azimuth
            values[1] = 0f           // pitch
            values[2] = 0f           // roll

            // sensor поле НЕ трогаем, иначе на некоторых прошивках будет crash
            event
        } catch (e: Throwable) {
            XposedBridge.log("createEvent error: $e")
            throw e
        }
    }
}