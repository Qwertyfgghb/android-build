package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import de.robv.android.xposed.XposedBridge

object VirtualSensor {

    /**
     * Создаём виртуальный SensorEvent с azimuth, pitch и roll.
     */
    fun createEvent(azimuth: Float, pitch: Float = 0f, roll: Float = 0f): SensorEvent {
        try {
            // Конструктор SensorEvent защищён, создаём через Reflection
            val ctor = SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
            ctor.isAccessible = true
            val event = ctor.newInstance(3) // массив из 3 элементов: azimuth, pitch, roll

            // Устанавливаем значения
            val valuesField = SensorEvent::class.java.getDeclaredField("values")
            valuesField.isAccessible = true
            val values = valuesField.get(event) as FloatArray
            values[0] = azimuth
            values[1] = pitch
            values[2] = roll

            // Не трогаем поле sensor, иначе могут быть краши на некоторых прошивках
            return event

        } catch (e: Throwable) {
            XposedBridge.log("VirtualSensor createEvent error: $e")
            throw e
        }
    }
}