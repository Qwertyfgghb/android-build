package com.example.virtualcompass

import android.hardware.SensorEvent
import android.os.SystemClock
import de.robv.android.xposed.XposedBridge

object VirtualSensor {

    fun createEvent(azimuth: Float): SensorEvent {
        try {
            val ctor = SensorEvent::class.java
                .getDeclaredConstructor(Int::class.javaPrimitiveType)

            ctor.isAccessible = true
            val event = ctor.newInstance(3)

            // values
            val valuesField = SensorEvent::class.java.getDeclaredField("values")
            valuesField.isAccessible = true
            val values = valuesField.get(event) as FloatArray

            values[0] = azimuth
            values[1] = 0f
            values[2] = 0f

            // ✅ timestamp (очень важно!)
            val tsField = SensorEvent::class.java.getDeclaredField("timestamp")
            tsField.isAccessible = true
            tsField.setLong(event, SystemClock.elapsedRealtimeNanos())

            // ✅ accuracy (иногда требуется)
            val accField = SensorEvent::class.java.getDeclaredField("accuracy")
            accField.isAccessible = true
            accField.setInt(event, 3) // SENSOR_STATUS_ACCURACY_HIGH

            return event

        } catch (e: Throwable) {
            XposedBridge.log("createEvent error: $e")
            throw e
        }
    }
}