package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import de.robv.android.xposed.XposedBridge
import java.lang.reflect.Constructor
import java.lang.reflect.Field

object VirtualSensor {

    private val listeners = mutableListOf<SensorEventListener>()

    fun registerListener(listener: SensorEventListener) {
        if (!listeners.contains(listener)) listeners.add(listener)
    }

    fun unregisterListener(listener: SensorEventListener) {
        listeners.remove(listener)
    }

    fun pushAzimuth(azimuth: Float) {
        listeners.forEach { listener ->
            try {
                val sensorEvent = createSensorEvent(azimuth, 0f, 0f)
                listener.onSensorChanged(sensorEvent)
            } catch (e: Throwable) {
                XposedBridge.log("VirtualSensor push error: $e")
            }
        }
    }

    private fun createSensorEvent(azimuth: Float, pitch: Float, roll: Float): SensorEvent {
        val constructor: Constructor<SensorEvent> =
            SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
        constructor.isAccessible = true
        val event = constructor.newInstance(3)

        val sensorField: Field = SensorEvent::class.java.getDeclaredField("sensor")
        sensorField.isAccessible = true
        val sensorConstructor = Sensor::class.java.getDeclaredConstructor(Int::class.java)
        sensorConstructor.isAccessible = true
        sensorField.set(event, sensorConstructor.newInstance(TYPE_ORIENTATION))

        val valuesField: Field = SensorEvent::class.java.getDeclaredField("values")
        valuesField.isAccessible = true
        val values = valuesField.get(event) as FloatArray
        values[0] = azimuth
        values[1] = pitch
        values[2] = roll

        return event
    }

    private const val TYPE_ORIENTATION = 1
}