package com.example.virtualcompass

import android.hardware.SensorEvent
import android.hardware.Sensor
import de.robv.android.xposed.XposedBridge
import java.lang.reflect.Constructor
import java.lang.reflect.Field

object VirtualSensor {

    /**
     * Создаём псевдо SensorEvent с заданным азимутом
     */
    fun createEvent(azimuth: Float): SensorEvent {
        return try {
            // Конструктор SensorEvent(int) защищён, используем Reflection
            val ctor: Constructor<SensorEvent> =
                SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
            ctor.isAccessible = true
            val event = ctor.newInstance(3) // azimuth, pitch, roll

            // Заполняем значения
            val valuesField: Field = SensorEvent::class.java.getDeclaredField("values")
            valuesField.isAccessible = true
            val values = valuesField.get(event) as FloatArray
            values[0] = azimuth
            values[1] = 0f
            values[2] = 0f

            // Не трогаем поле sensor, иначе возможен crash
            event
        } catch (e: Throwable) {
            XposedBridge.log("VirtualSensor createEvent error: $e")
            throw e
        }
    }
}