package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.XposedBridge
import kotlin.reflect.full.declaredMemberProperties
import kotlin.reflect.jvm.isAccessible

object VirtualSensor {

    private val listeners = mutableListOf<SensorEventListener>()

    /**
     * Регистрирует виртуального слушателя
     */
    fun registerVirtualListener(listener: SensorEventListener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener)
            XposedBridge.log("VirtualSensor listener registered")
        }
    }

    /**
     * Убирает слушателя
     */
    fun unregisterVirtualListener(listener: SensorEventListener) {
        listeners.remove(listener)
        XposedBridge.log("VirtualSensor listener unregistered")
    }

    /**
     * Отправляет виртуальный SensorEvent со значением азимута
     */
    fun pushAzimuth(azimuth: Float) {
        listeners.forEach { listener ->
            val sensorEvent = createSensorEvent(azimuth, 0f, 0f)
            try {
                listener.onSensorChanged(sensorEvent)
            } catch (e: Throwable) {
                XposedBridge.log("VirtualSensor error pushing azimuth: $e")
            }
        }
    }

    /**
     * Создаём псевдо SensorEvent через Reflection (так как конструктор SensorEvent защищён)
     */
    private fun createSensorEvent(azimuth: Float, pitch: Float, roll: Float): SensorEvent {
        val sensorEvent = SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
            .newInstance(3) // 3 значения: azimuth, pitch, roll

        // Вставляем sensor через Reflection
        val sensorField = SensorEvent::class.java.getDeclaredField("sensor")
        sensorField.isAccessible = true
        sensorField.set(sensorEvent, Sensor(TYPE_ORIENTATION, 0))

        val valuesField = SensorEvent::class.java.getDeclaredField("values")
        valuesField.isAccessible = true
        val values = valuesField.get(sensorEvent) as FloatArray
        values[0] = azimuth
        values[1] = pitch
        values[2] = roll

        return sensorEvent
    }

    private const val TYPE_ORIENTATION = 1
}