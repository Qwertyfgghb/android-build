package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import de.robv.android.xposed.XposedBridge
import java.lang.reflect.Constructor
import java.lang.reflect.Field

object VirtualSensor {

    fun createSensorEvent(azimuth: Float, pitch: Float, roll: Float): SensorEvent {
        return try {
            // Создаём SensorEvent через Reflection
            val constructor: Constructor<SensorEvent> =
                SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
            constructor.isAccessible = true
            val event = constructor.newInstance(3) // azimuth, pitch, roll

            // Вставляем sensor
            val sensorField: Field = SensorEvent::class.java.getDeclaredField("sensor")
            sensorField.isAccessible = true
            val sensorConstructor = Sensor::class.java.getDeclaredConstructor()
            sensorConstructor.isAccessible = true
            sensorField.set(event, sensorConstructor.newInstance())

            // Заполняем значения
            val valuesField: Field = SensorEvent::class.java.getDeclaredField("values")
            valuesField.isAccessible = true
            val values = valuesField.get(event) as FloatArray
            values[0] = azimuth
            values[1] = pitch
            values[2] = roll

            event
        } catch (e: Throwable) {
            XposedBridge.log("Error creating SensorEvent: $e")
            throw e
        }
    }
}