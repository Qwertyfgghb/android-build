package com.example.virtualcompass

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.XposedBridge

class SensorLogger(private val context: Context) {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val listeners = mutableListOf<SensorEventListener>()

    fun start() {
        val sensors = sensorManager.getSensorList(Sensor.TYPE_ALL)
        XposedBridge.log("Device has ${sensors.size} sensors:")
        sensors.forEach { XposedBridge.log("Sensor: ${it.name} (type=${it.type})") }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                XposedBridge.log("SensorEvent: type=${event.sensor.type}, values=[${event.values.joinToString()}]")
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        sensors.forEach { sensor ->
            sensorManager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        }

        listeners.add(listener)
        XposedBridge.log("SensorLogger started")
    }
}