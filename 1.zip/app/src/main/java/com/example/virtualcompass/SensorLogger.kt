package com.example.virtualcompass

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.XposedBridge

class SensorLogger(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensors = sensorManager.getSensorList(Sensor.TYPE_ALL)

    fun start() {
        // 🔹 Лог всех сенсоров на устройстве
        sensors.forEach { sensor ->
            XposedBridge.log("Sensor detected: ${sensor.name} type=${sensor.type}")
        }

        // 🔹 Регистрируем сенсоры для логирования в реальном времени
        sensors.forEach { sensor ->
            sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        }

        XposedBridge.log("SensorLogger initialized")
    }

    override fun onSensorChanged(event: SensorEvent) {
        val valuesStr = event.values.joinToString(", ") { it.toString() }
        XposedBridge.log("SensorEvent: type=${event.sensor.type}, values=[$valuesStr]")
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        XposedBridge.log("Sensor accuracy changed: ${sensor?.name} accuracy=$accuracy")
    }
}