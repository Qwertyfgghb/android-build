package com.example.virtualcompass

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import de.robv.android.xposed.XposedBridge
import kotlin.math.*

class GPSAzimuthProvider(private val context: Context) : LocationListener {

    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private var lastLocation: Location? = null
    var currentAzimuth: Double = 0.0
        private set

    fun start() {
        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                50L, 0.1f, this
            )
            XposedBridge.log("GPSAzimuthProvider started")
        } catch (ex: SecurityException) {
            XposedBridge.log("GPS permission error: $ex")
        }
    }

    override fun onLocationChanged(location: Location) {
        val prev = lastLocation
        lastLocation = location

        if (prev != null) {
            val distance = location.distanceTo(prev)
            currentAzimuth = if (distance < 0.1f) {
                currentAzimuth  // минимальное движение, оставляем старый азимут
            } else {
                computeAzimuth(prev.latitude, prev.longitude, location.latitude, location.longitude)
            }
            XposedBridge.log("GPS update: azimuth=$currentAzimuth")
        }
    }

    private fun computeAzimuth(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dLon = Math.toRadians(lon2 - lon1)
        val y = sin(dLon) * cos(Math.toRadians(lat2))
        val x = cos(Math.toRadians(lat1)) * sin(Math.toRadians(lat2)) -
                sin(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * cos(dLon)
        var azimuth = Math.toDegrees(atan2(y, x))
        if (azimuth < 0) azimuth += 360.0
        return azimuth
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
}