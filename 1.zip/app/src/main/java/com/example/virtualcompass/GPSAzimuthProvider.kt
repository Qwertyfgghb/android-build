package com.example.virtualcompass

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import kotlin.math.*

class GPSAzimuthProvider(context: Context) : LocationListener {

    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val azimuthHistory = mutableListOf<Double>()
    var currentAzimuth: Double = 0.0
        private set

    private var lastLocation: Location? = null
    private var prevLocation: Location? = null

    fun start() {
        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                50L,    // минимальный интервал обновления 50мс
                0.1f,   // минимальное перемещение 0.1м
                this
            )
        } catch (ex: SecurityException) {
            ex.printStackTrace()
        }
    }

    override fun onLocationChanged(location: Location) {
        prevLocation = lastLocation
        lastLocation = location

        if (prevLocation != null) {
            val distance = location.distanceTo(prevLocation!!)
            currentAzimuth = if (distance < 0.1) {
                // минимальное движение → предсказание
                val lastAz = if (azimuthHistory.isNotEmpty()) azimuthHistory.last() else 0.0
                val prevAz = if (azimuthHistory.size > 1) azimuthHistory[azimuthHistory.size - 2] else lastAz
                lastAz + (lastAz - prevAz) * 0.5
            } else {
                computeAzimuth(prevLocation!!.latitude, prevLocation!!.longitude,
                               location.latitude, location.longitude)
            }

            azimuthHistory.add(currentAzimuth)
            if (azimuthHistory.size > 5) azimuthHistory.removeAt(0)

            // Скользящее среднее для сглаживания
            currentAzimuth = azimuthHistory.average()
        }
    }

    private fun computeAzimuth(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dLon = Math.toRadians(lon2 - lon1)
        val y = sin(dLon) * cos(Math.toRadians(lat2))
        val x = cos(Math.toRadians(lat1)) * sin(Math.toRadians(lat2)) -
                sin(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * cos(dLon)
        var azimuth = Math.toDegrees(atan2(y, x))
        if (azimuth < 0) azimuth += 360.0
        return azimuth
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
}