package com.example.virtualcompass

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import de.robv.android.xposed.XposedBridge
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class GPSAzimuthProvider(private val context: Context) {

    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private var lastLocation: Location? = null

    @Volatile
    var currentAzimuth: Float = 0f
        private set

    fun start() {
        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                100L,
                0f,
                listener
            )
            XposedBridge.log("GPS started")
        } catch (e: SecurityException) {
            XposedBridge.log("GPS permission error: $e")
        }
    }

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            val az = if (lastLocation != null) {
                computeAzimuth(lastLocation!!, location)
            } else {
                0f
            }

            lastLocation = location

            // Плавное сглаживание
            currentAzimuth = 0.2f * az + 0.8f * currentAzimuth

            XposedBridge.log("AZIMUTH: $currentAzimuth")
        }

        override fun onProviderDisabled(provider: String) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    private fun computeAzimuth(start: Location, end: Location): Float {
        val lat1 = Math.toRadians(start.latitude)
        val lon1 = Math.toRadians(start.longitude)
        val lat2 = Math.toRadians(end.latitude)
        val lon2 = Math.toRadians(end.longitude)

        val dLon = lon2 - lon1
        val y = sin(dLon) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        return ((Math.toDegrees(atan2(y, x)) + 360) % 360).toFloat()
    }
}