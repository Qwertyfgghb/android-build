package com.example.virtualcompass

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass Logger loaded (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Логируем все пакеты для анализа
        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        // Получаем context приложения через ActivityThread
        val context: Context? = try {
            val at = Class.forName("android.app.ActivityThread")
            at.getMethod("currentApplication").invoke(null) as? Context
        } catch (e: Throwable) {
            XposedBridge.log("Context error: $e")
            null
        }

        if (context == null) {
            XposedBridge.log("Context is null, cannot start GPS or Sensor logger")
            return
        }

        // Логируем GPS
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val gpsListener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                XposedBridge.log("GPS update: lat=${location.latitude}, lon=${location.longitude}, alt=${location.altitude}")
            }
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {
                XposedBridge.log("GPS provider enabled: $provider")
            }
            override fun onProviderDisabled(provider: String) {
                XposedBridge.log("GPS provider disabled: $provider")
            }
        }

        try {
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, gpsListener)
            XposedBridge.log("GPSAzimuthProvider started")
        } catch (ex: SecurityException) {
            XposedBridge.log("No GPS permission: $ex")
        }

        // Логируем сенсоры
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensors = sensorManager.getSensorList(Sensor.TYPE_ALL)
        sensors.forEach { sensor ->
            XposedBridge.log("Sensor found: ${sensor.name}, type=${sensor.type}, vendor=${sensor.vendor}")
        }

        // Логируем события сенсоров
        val sensorListener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                XposedBridge.log("SensorEvent: type=${event.sensor.type}, values=${event.values.joinToString()}")
            }
            override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {
                XposedBridge.log("Sensor accuracy changed: type=${sensor.type}, accuracy=$accuracy")
            }
        }

        sensors.forEach { sensor ->
            sensorManager.registerListener(sensorListener, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        }

        XposedBridge.log("Sensor logger initialized")
    }
}