package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    private var initialized = false

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VC FINAL START")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        val targetApps = listOf(
            "com.yandex.yandexmaps",
            "com.google.android.apps.maps"
        )

        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        if (initialized) return
        initialized = true

        // Получаем Context
        val context: Context? = try {
            val at = Class.forName("android.app.ActivityThread")
            at.getMethod("currentApplication").invoke(null) as? Context
        } catch (e: Throwable) {
            XposedBridge.log("Context error: $e")
            null
        }

        if (context == null) {
            XposedBridge.log("Context is null, cannot start GPS and sensors")
            return
        }

        XposedBridge.log("VC CONTEXT OK")

        val gpsProvider = GPSAzimuthProvider(context)
        gpsProvider.start()

        SensorHook(gpsProvider).hook(lpparam)
    }
}