package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass loaded (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Целевые приложения
        val targetApps = listOf("com.google.android.apps.maps", "ru.yandex.yandexmaps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded target: ${lpparam.packageName}")

        // Хук на attachBaseContext, чтобы безопасно получить Context
        XposedHelpers.findAndHookMethod(
            "android.app.Application",
            lpparam.classLoader,
            "attach",
            Context::class.java,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val context = param.args[0] as Context
                    XposedBridge.log("VirtualCompass got context: $context")

                    // Создаём GPS провайдер и запускаем
                    val gps = GPSAzimuthProvider(context)
                    gps.start()

                    // Хук SensorManager
                    SensorHook(gps).hook(lpparam)
                }
            }
        )
    }
}