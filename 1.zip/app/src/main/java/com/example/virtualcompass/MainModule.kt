package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass loaded (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        val targetApps = listOf("com.google.android.apps.maps", "ru.yandex.yandexmaps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        // Получаем Context безопасно
        val context: Context? = try {
            val at = Class.forName("android.app.ActivityThread")
            at.getMethod("currentApplication").invoke(null) as? Context
        } catch (e: Throwable) {
            XposedBridge.log("Context is NULL: $e")
            null
        }

        if (context == null) return

        val gpsProvider = GPSAzimuthProvider(context)
        gpsProvider.start()  // запускаем GPS

        SensorHook(gpsProvider).hook(lpparam)
    }
}