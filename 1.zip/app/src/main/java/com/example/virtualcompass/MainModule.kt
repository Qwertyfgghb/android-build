package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass LSPosed module loaded (zygote)")
        // GPSAzimuthProvider создаём позже, когда есть Context
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf("com.google.android.apps.maps", "com.yandex.maps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("VirtualCompass loaded in package: ${lpparam.packageName}")

        // Получаем Context через ActivityThread
        val context: Context? = try {
            val activityThreadClass = Class.forName("android.app.ActivityThread")
            val app = activityThreadClass.getMethod("currentApplication").invoke(null)
            app as? Context
        } catch (e: Exception) {
            XposedBridge.log("Error getting context: $e")
            null
        }

        if (context == null) return

        val gpsProvider = GPSAzimuthProvider(context)
        gpsProvider.start() // запуск GPS

        // Создаём и запускаем SensorHook
        val sensorHook = SensorHook(gpsProvider)
        sensorHook.handleLoadPackage(lpparam)
    }
}