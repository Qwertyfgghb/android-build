package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.*
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        if (lpparam.packageName != "ru.yandex.yandexmaps") return

        XposedBridge.log("VC STARTED")

        val at = Class.forName("android.app.ActivityThread")
        val context = at.getMethod("currentApplication").invoke(null) as? Context ?: return

        val gps = GPSProvider(context)
        gps.start()

        SensorHook.start(gps)
    }
}