package com.example.virtualcompass

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    private var lastAzimuth: Float = 0f

    companion object {
        const val UPDATE_INTERVAL_MS = 200L  // 0.2 секунды
        const val MIN_SPEED = 0.1f           // минимальная скорость, м/с
        const val SMOOTHING = 0.3f           // коэффициент сглаживания
    }

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VC FINAL START (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf(
            "ru.yandex.yandexmaps",
            "com.google.android.apps.maps"
        )
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        val context: Context? = try {
            val at = Class.forName("android.app.ActivityThread")
            at.getMethod("currentApplication").invoke(null) as? Context
        } catch (e: Throwable) {
            XposedBridge.log("Context hook error: $e")
            null
        }

        if (context == null) {
            XposedBridge.log("Context is null, cannot start GPS")
            return
        }

        XposedBridge.log("VC CONTEXT OK")
        startGPS(context)
    }

    private fun startGPS(context: Context) {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                val speed = location.speed
                if (speed < MIN_SPEED) return  // стоим — не меняем азимут

                val newBearing = location.bearing
                // плавное сглаживание
                lastAzimuth = lastAzimuth + SMOOTHING * ((newBearing - lastAzimuth + 540) % 360 - 180)

                XposedBridge.log("GPS Bearing: $lastAzimuth")
                // TODO: отправка в карту через хук или системный SensorManager
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }

        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                UPDATE_INTERVAL_MS,
                0f,
                listener
            )
            XposedBridge.log("GPS started")
        } catch (e: SecurityException) {
            XposedBridge.log("GPS permission error: $e")
        }
    }
}