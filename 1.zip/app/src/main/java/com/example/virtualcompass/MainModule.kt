package com.example.virtualcompass

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XC_MethodHook
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    private var lastLocation: Location? = null
    private var lastAzimuth: Float = 0f

    companion object {
        const val SPEED_THRESHOLD = 0.5f // м/с, ниже — стоим
    }

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VC FINAL START (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf(
            "ru.yandex.yandexmaps",
            "com.google.android.apps.maps"
        )
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        // Хук на onCreate приложения, чтобы получить реальный контекст
        XposedHelpers.findAndHookMethod(
            "android.app.Application",
            lpparam.classLoader,
            "onCreate",
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val context = param.thisObject as Context
                    XposedBridge.log("VC CONTEXT OK")
                    startGPS(context, lpparam)
                    hookSensorManager(lpparam)
                }
            }
        )
    }

    private fun startGPS(context: Context, lpparam: XC_LoadPackage.LoadPackageParam) {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                val azimuth = calculateAzimuth(lastLocation, location)
                lastLocation = location

                if (azimuth != null) {
                    lastAzimuth = azimuth
                    XposedBridge.log("AZIMUTH: $azimuth")
                }
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }

        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                500L, // обновление каждые 0.5 с
                0f,
                listener
            )
            XposedBridge.log("GPS started")
        } catch (e: SecurityException) {
            XposedBridge.log("GPS permission error: $e")
        }
    }

    private fun calculateAzimuth(last: Location?, current: Location): Float? {
        if (last == null) return null

        val distance = last.distanceTo(current)
        val time = (current.time - last.time) / 1000f
        val speed = if (time > 0) distance / time else 0f

        if (speed < SPEED_THRESHOLD) return lastAzimuth // стоим, не дергаем

        val deltaLat = Math.toRadians((current.latitude - last.latitude))
        val deltaLon = Math.toRadians((current.longitude - last.longitude))
        val y = sin(deltaLon) * cos(Math.toRadians(current.latitude))
        val x = cos(Math.toRadians(last.latitude)) * sin(Math.toRadians(current.latitude)) -
                sin(Math.toRadians(last.latitude)) * cos(Math.toRadians(current.latitude)) * cos(deltaLon)
        return ((Math.toDegrees(atan2(y, x)) + 360) % 360).toFloat()
    }

    // Хук SensorManager, чтобы Яндекс.Карты видели направление движения
    private fun hookSensorManager(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val sensorManagerClass = Class.forName("android.hardware.SystemSensorManager")
            XposedHelpers.findAndHookMethod(
                sensorManagerClass,
                "registerListener",
                SensorEventListener::class.java,
                Sensor::class.java,
                Int::class.javaPrimitiveType,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val listener = param.args[0] as SensorEventListener
                        val sensor = param.args[1] as Sensor
                        // Только для ориентации
                        if (sensor.type == Sensor.TYPE_ORIENTATION || sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
                            XposedBridge.log("Hooked SensorListener for orientation")
                            // Обновляем направление каждые GPS-обновления
                            Thread {
                                while (true) {
                                    Thread.sleep(200)
                                    listener.onSensorChanged(
                                        createFakeSensorEvent(lastAzimuth, sensor)
                                    )
                                }
                            }.start()
                        }
                    }
                }
            )
        } catch (t: Throwable) {
            XposedBridge.log("SensorHook error: $t")
        }
    }

    // Создаём SensorEvent вручную
    private fun createFakeSensorEvent(azimuth: Float, sensor: Sensor): SensorEvent {
        val values = FloatArray(3)
        values[0] = azimuth
        values[1] = 0f
        values[2] = 0f

        val event = java.lang.reflect.Proxy.newProxyInstance(
            SensorEvent::class.java.classLoader,
            arrayOf(SensorEvent::class.java)
        ) { _, method, _ ->
            when (method.name) {
                "getSensor" -> sensor
                "getValues" -> values
                else -> null
            }
        } as SensorEvent

        return event
    }
}