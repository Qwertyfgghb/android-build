package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.*
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        if (lpparam.packageName != "ru.yandex.yandexmaps") return

        XposedBridge.log("VC START (waiting context)")

        XposedHelpers.findAndHookMethod(
            "android.app.Application",
            lpparam.classLoader,
            "attach",
            Context::class.java,
            object : XC_MethodHook() {

                override fun afterHookedMethod(param: MethodHookParam) {

                    val context = param.args[0] as Context

                    XposedBridge.log("VC CONTEXT OK")

                    val gps = GPSProvider(context)
                    gps.start()

                    SensorHook.start(gps)
                    LocationHook.start(gps)
                }
            }
        )
    }
}