package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass loaded (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Только целевые приложения
        val targetApps = listOf("com.google.android.apps.maps", "ru.yandex.yandexmaps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        // Ждём, пока Application приложения создастся
        XposedHelpers.findAndHookMethod(
            "android.app.Application",
            lpparam.classLoader,
            "onCreate",
            object : XC_LoadPackage.MethodHook() {
                override fun afterHookedMethod(param: XC_LoadPackage.MethodHookParam) {
                    val appContext = param.thisObject as Context
                    XposedBridge.log("Application created, context available")

                    // Создаём GPSAzimuthProvider
                    val gpsProvider = GPSAzimuthProvider(appContext)
                    gpsProvider.start()

                    // Подключаем SensorHook для виртуального компаса
                    SensorHook(gpsProvider).hook(lpparam)
                }
            }
        )
    }
}