package com.example.virtualcompass

import android.content.Context
import android.hardware.Sensor
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook.MethodHookParam
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    private var lastLocation: Location? = null
    private var lastAzimuth: Float = 0f

    companion object {
        const val SPEED_THRESHOLD = 0.5f // м/с, ниже — стоим
    }

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VC FINAL START (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf(
            "ru.yandex.yandexmaps",
            "com.google.android.apps.maps"
        )
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        // Получаем реальный контекст
        val context: Context? = try {
            val at = Class.forName("android.app.ActivityThread")
            at.getMethod("currentApplication").invoke(null) as? Context
        } catch (e: Throwable) {
            XposedBridge.log("Context hook error: $e")
            null
        }

        if (context == null) {
            XposedBridge.log("Context is null, cannot start GPS")
            return
        }

        XposedBridge.log("VC CONTEXT OK")

        // Запускаем GPS-подписку
        startGPS(context, lpparam)

        // Хук сенсоров для подмены направления
        hookSensors(lpparam)
    }

    private fun startGPS(context: Context, lpparam: XC_LoadPackage.LoadPackageParam) {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                val azimuth = calculateAzimuth(lastLocation, location)
                lastLocation = location

                if (azimuth != null) {
                    lastAzimuth = azimuth
                    XposedBridge.log("AZIMUTH: $azimuth")
                }
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }

        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                500L, // обновление каждые 0.5 с
                0f,
                listener
            )
            XposedBridge.log("GPS started")
        } catch (e: SecurityException) {
            XposedBridge.log("GPS permission error: $e")
        }
    }

    private fun calculateAzimuth(last: Location?, current: Location): Float? {
        if (last == null) return null

        val distance = last.distanceTo(current)
        val time = (current.time - last.time) / 1000f
        val speed = if (time > 0) distance / time else 0f

        if (speed < SPEED_THRESHOLD) return lastAzimuth // стоим, не дергаем

        val deltaLat = Math.toRadians(current.latitude - last.latitude)
        val deltaLon = Math.toRadians(current.longitude - last.longitude)
        val y = sin(deltaLon) * cos(Math.toRadians(current.latitude))
        val x = cos(Math.toRadians(last.latitude)) * sin(Math.toRadians(current.latitude)) -
                sin(Math.toRadians(last.latitude)) * cos(Math.toRadians(current.latitude)) * cos(deltaLon)
        return ((Math.toDegrees(atan2(y, x)) + 360) % 360).toFloat()
    }

    private fun hookSensors(lpparam: XC_LoadPackage.LoadPackageParam) {
        try {
            val sensorManagerClass = Class.forName(
                "android.hardware.SystemSensorManager",
                false,
                lpparam.classLoader
            )

            XposedBridge.hookAllMethods(
                sensorManagerClass,
                "dispatchSensorEvent",
                object : de.robv.android.xposed.XC_MethodHook() {

                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val sensorType = param.args[1] as? Int ?: return
                        val values = param.args[0] as? FloatArray ?: return

                        // Подменяем TYPE_ORIENTATION
                        if (sensorType == Sensor.TYPE_ORIENTATION) {
                            values[0] = lastAzimuth
                        }

                        // Подменяем TYPE_ROTATION_VECTOR
                        if (sensorType == Sensor.TYPE_ROTATION_VECTOR) {
                            val rad = Math.toRadians(lastAzimuth.toDouble())
                            values[0] = Math.sin(rad / 2).toFloat()
                            values[1] = 0f
                            values[2] = 0f
                            values[3] = Math.cos(rad / 2).toFloat()
                        }
                    }
                }
            )

            XposedBridge.log("Sensor hook installed")

        } catch (e: Throwable) {
            XposedBridge.log("Sensor hook error: $e")
        }
    }
}