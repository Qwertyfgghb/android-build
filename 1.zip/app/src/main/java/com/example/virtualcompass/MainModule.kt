package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass LSPosed module loaded (zygote)")
        // Context здесь недоступен, GPSAzimuthProvider создаём в handleLoadPackage
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf("com.google.android.apps.maps", "com.yandex.maps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("VirtualCompass module loaded in package: ${lpparam.packageName}")

        val context: Context? = try {
            val activityThread = Class.forName("android.app.ActivityThread")
            val app = activityThread.getMethod("currentApplication").invoke(null) as Context
            app
        } catch (e: Exception) {
            XposedBridge.log("Error getting context: $e")
            null
        }

        if (context == null) return

        val gpsProvider = GPSAzimuthProvider(context)
        gpsProvider.start()

        SensorHook(gpsProvider).handleLoadPackage(lpparam)
    }
}