package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass loaded (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf("com.google.android.apps.maps", "ru.yandex.yandexmaps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        try {
            val appClass = Class.forName("android.app.Application")
            XposedHelpers.findAndHookConstructor(
                appClass,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHook.MethodHookParam) {
                        val context = param.thisObject as? Context
                        if (context != null) {
                            XposedBridge.log("Application created, starting GPS and sensor logger")
                            GPSLogger(context).start()
                            SensorLogger(context).start()
                        } else {
                            XposedBridge.log("Context is null after Application created")
                        }
                    }
                }
            )
        } catch (e: Throwable) {
            XposedBridge.log("Error hooking Application: $e")
        }
    }
}