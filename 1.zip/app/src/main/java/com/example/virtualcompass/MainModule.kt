package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorManager
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        XposedBridge.log("VirtualCompass module loaded in package: ${lpparam.packageName}")

        val gpsProvider = GPSAzimuthProvider()
        val sensorHook = SensorHook(gpsProvider)

        sensorHook.hookSensorManager(lpparam)
    }
}