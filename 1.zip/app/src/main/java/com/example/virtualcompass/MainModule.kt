package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass loaded (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        XposedBridge.log("HANDLE: ${lpparam.packageName}") // 🔥 важно для диагностики

        val targetApps = listOf(
            "com.google.android.apps.maps",
            "com.yandex.maps"
        )

        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in TARGET: ${lpparam.packageName}")

        val context: Context? = try {
            val at = Class.forName("android.app.ActivityThread")
            at.getMethod("currentApplication").invoke(null) as? Context
        } catch (e: Throwable) {
            XposedBridge.log("Context error: $e")
            null
        }

        if (context == null) {
            XposedBridge.log("Context NULL ❌")
            return
        }

        val gps = GPSAzimuthProvider(context)
        gps.start()

        // 🔥 ВАЖНО: вызываем ПРАВИЛЬНЫЙ метод
        SensorHook(gps).hook(lpparam)
    }
}