package com.example.virtualcompass

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    private var lastLocation: Location? = null
    private var lastAzimuth: Float = 0f

    companion object {
        const val SPEED_THRESHOLD = 0.5f // м/с, ниже — стоим
    }

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VC FINAL START (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf("ru.yandex.yandexmaps", "com.google.android.apps.maps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        try {
            val appClass = Class.forName("android.app.Application", false, lpparam.classLoader)
            val attachMethod = appClass.getMethod("attach", Context::class.java)

            XposedHelpers.findAndHookMethod(appClass, "attach", Context::class.java, object : de.robv.android.xposed.XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val context = param.args[0] as Context
                    XposedBridge.log("VC CONTEXT OK")
                    startGPS(context, lpparam)
                }
            })
        } catch (e: Throwable) {
            XposedBridge.log("Context hook error: $e")
        }
    }

    private fun startGPS(context: Context, lpparam: XC_LoadPackage.LoadPackageParam) {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                val azimuth = calculateAzimuth(lastLocation, location)
                lastLocation = location

                if (azimuth != null) {
                    lastAzimuth = azimuth
                    XposedBridge.log("AZIMUTH: $azimuth")
                    // Если есть SensorHook, можно отправить азимут туда
                    try {
                        val sensorHookClass = Class.forName("com.example.virtualcompass.SensorHook")
                        val sendAzimuth = sensorHookClass.getMethod("sendAzimuth", XC_LoadPackage.LoadPackageParam::class.java, Float::class.java)
                        sendAzimuth.invoke(null, lpparam, azimuth)
                    } catch (_: Throwable) { /* игнор */ }
                }
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }

        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                100L, // обновление каждые 0.1 с для мгновенного азимута
                0f,
                listener
            )
            XposedBridge.log("GPS started")
        } catch (e: SecurityException) {
            XposedBridge.log("GPS permission error: $e")
        }
    }

    private fun calculateAzimuth(last: Location?, current: Location): Float? {
        if (last == null) return null

        val distance = last.distanceTo(current)
        val time = (current.time - last.time) / 1000f // секунды
        val speed = if (time > 0) distance / time else 0f

        if (speed < SPEED_THRESHOLD) return lastAzimuth // стоим, не дергаем

        val deltaLat = Math.toRadians(current.latitude - last.latitude)
        val deltaLon = Math.toRadians(current.longitude - last.longitude)
        val y = sin(deltaLon) * cos(Math.toRadians(current.latitude))
        val x = cos(Math.toRadians(last.latitude)) * sin(Math.toRadians(current.latitude)) -
                sin(Math.toRadians(last.latitude)) * cos(Math.toRadians(current.latitude)) * cos(deltaLon)
        return ((Math.toDegrees(atan2(y, x)) + 360) % 360).toFloat()
    }
}