package com.example.virtualcompass

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass module loaded (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        // Получаем Context через Application
        try {
            val activityThread = Class.forName("android.app.ActivityThread")
            val app = activityThread.getMethod("currentApplication").invoke(null) as? Context

            if (app != null) {
                XposedBridge.log("Got real Context, starting loggers")

                GPSLogger(app).start()
                SensorLogger(app).start()
            } else {
                XposedBridge.log("Context is null, cannot start GPS and sensors")
            }
        } catch (e: Throwable) {
            XposedBridge.log("Error getting Context: $e")
        }
    }
}

// ---------------- GPS Logger ----------------
class GPSLogger(private val context: Context) : LocationListener {

    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    fun start() {
        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                1000L, // 1 сек
                0.1f,  // 0.1м
                this
            )
            XposedBridge.log("GPSLogger started")
        } catch (e: SecurityException) {
            XposedBridge.log("GPS permission missing: $e")
        }
    }

    override fun onLocationChanged(location: Location) {
        XposedBridge.log("GPS: lat=${location.latitude}, lon=${location.longitude}, alt=${location.altitude}")
    }

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
}

// ---------------- Sensor Logger ----------------
class SensorLogger(private val context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensors = sensorManager.getSensorList(Sensor.TYPE_ALL)

    fun start() {
        XposedBridge.log("Sensors on device: ${sensors.map { it.name }}")
        sensors.forEach { sensor ->
            sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
        XposedBridge.log("SensorLogger started")
    }

    override fun onSensorChanged(event: SensorEvent) {
        val valuesStr = event.values.joinToString(", ") { "%.2f".format(it) }
        XposedBridge.log("Sensor: ${event.sensor.name} [${event.sensor.type}] values=[$valuesStr]")
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}