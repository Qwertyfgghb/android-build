package com.example.virtualcompass

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass loaded (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // 🔹 Только для целевых приложений
        val targetApps = listOf("com.google.android.apps.maps", "ru.yandex.yandexmaps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        val context: Context? = try {
            val atClass = Class.forName("android.app.ActivityThread")
            atClass.getMethod("currentApplication").invoke(null) as? Context
        } catch (e: Throwable) {
            XposedBridge.log("Failed to get context: $e")
            null
        }

        if (context == null) {
            XposedBridge.log("Context is null, cannot start GPS and sensors")
            return
        }

        // 🔹 Инициализация GPS
        val gpsProvider = RealGPSProvider(context)
        gpsProvider.start()

        // 🔹 Инициализация сенсоров
        val sensorLogger = SensorLogger(context)
        sensorLogger.start()
    }
}