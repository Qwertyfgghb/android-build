package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass LSPosed module loaded (zygote)")
        // Здесь нельзя получить Context, поэтому GPSAzimuthProvider будет инициализирован в hookLoadPackage
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Только для целевых приложений
        val targetApps = listOf("com.google.android.apps.maps", "com.yandex.maps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("VirtualCompass module loaded in package: ${lpparam.packageName}")

        // Получаем context через ActivityThread или другой способ
        val context: Context? = try {
            val activityThreadClass = Class.forName("android.app.ActivityThread")
            val currentApplication = activityThreadClass.getMethod("currentApplication").invoke(null)
            currentApplication as? Context
        } catch (e: Exception) {
            XposedBridge.log("Error getting context: $e")
            null
        }

        if (context == null) return

        // Создаём провайдер азимута
        val gpsProvider = GPSAzimuthProvider(context)
        gpsProvider.start() // запускаем GPS

        // Регистрируем виртуальный сенсор
        SensorHook(gpsProvider).handleLoadPackage(lpparam)
    }
}