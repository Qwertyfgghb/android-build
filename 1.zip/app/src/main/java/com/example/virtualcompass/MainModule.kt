package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass loaded (zygote)")
        // Здесь контекст недоступен, провайдер GPS создаём в handleLoadPackage
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        val targetApps = listOf(
            "com.google.android.apps.maps",
            "ru.yandex.yandexmaps"
        )

        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        // Получаем Context через ActivityThread.currentApplication()
        val context: Context? = try {
            val atClass = Class.forName("android.app.ActivityThread")
            val app = atClass.getMethod("currentApplication").invoke(null) as? Context
            app
        } catch (e: Throwable) {
            XposedBridge.log("Error getting context: $e")
            null
        }

        if (context == null) {
            XposedBridge.log("Context is null, cannot start GPSAzimuthProvider")
            return
        }

        // Создаём и запускаем GPSAzimuthProvider
        val gpsProvider = GPSAzimuthProvider(context)
        gpsProvider.start()
        XposedBridge.log("GPSAzimuthProvider started")

        // Хук SensorManager для виртуального компаса
        SensorHook(gpsProvider).hook(lpparam)
        XposedBridge.log("SensorHook initialized for virtual compass")
    }
}