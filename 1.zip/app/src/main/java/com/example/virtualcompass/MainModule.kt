package com.example.virtualcompass

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.concurrent.fixedRateTimer
import kotlin.math.*

// Главный модуль
class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass loaded (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf("com.google.android.apps.maps", "ru.yandex.yandexmaps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        try {
            // Хук на конструктор Application
            val appClass = Class.forName("android.app.Application")
            XposedHelpers.findAndHookConstructor(
                appClass,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHook.Param) {
                        val context = param.thisObject as? Context
                        if (context != null) {
                            XposedBridge.log("Application created, starting GPS and sensor logger")

                            // Запуск GPS
                            val gpsProvider = GPSLogger(context)
                            gpsProvider.start()

                            // Логирование сенсоров
                            val sensorLogger = SensorLogger(context)
                            sensorLogger.start()
                        } else {
                            XposedBridge.log("Context is null after Application created")
                        }
                    }
                }
            )
        } catch (e: Throwable) {
            XposedBridge.log("Error hooking Application: $e")
        }
    }
}

// Класс для логирования GPS
class GPSLogger(private val context: Context) : LocationListener {
    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    fun start() {
        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                1000L, // 1 сек
                0.1f,
                this
            )
            XposedBridge.log("GPSLogger started")
        } catch (ex: SecurityException) {
            XposedBridge.log("GPS permission error: $ex")
        }
    }

    override fun onLocationChanged(location: Location) {
        XposedBridge.log("GPS update: lat=${location.latitude}, lon=${location.longitude}, alt=${location.altitude}")
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
}

// Класс для логирования всех сенсоров
class SensorLogger(private val context: Context) {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val listeners = mutableListOf<SensorEventListener>()

    fun start() {
        val sensors = sensorManager.getSensorList(Sensor.TYPE_ALL)
        XposedBridge.log("Device has ${sensors.size} sensors:")
        sensors.forEach { XposedBridge.log("Sensor: ${it.name} (type=${it.type})") }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                XposedBridge.log("SensorEvent: type=${event.sensor.type}, values=[${event.values.joinToString()}]")
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        sensors.forEach { sensor ->
            sensorManager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        }

        listeners.add(listener)
        XposedBridge.log("SensorLogger started")
    }
}