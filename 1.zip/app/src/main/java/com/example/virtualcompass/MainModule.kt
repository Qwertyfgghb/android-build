package com.example.virtualcompass

import android.content.Context
import android.os.Handler
import android.os.Looper
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass loaded (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        val targetApps = listOf(
            "com.google.android.apps.maps",
            "ru.yandex.yandexmaps"
        )

        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        // Хук Application.onCreate для безопасного получения Context
        XposedHelpers.findAndHookMethod(
            "android.app.Application",
            lpparam.classLoader,
            "onCreate",
            object : de.robv.android.xposed.XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {

                    val context = param.thisObject as? Context
                    if (context == null) {
                        XposedBridge.log("Context still null in onCreate")
                        return
                    }

                    Handler(Looper.getMainLooper()).post {
                        try {
                            val gpsProvider = GPSAzimuthProvider(context)
                            gpsProvider.start()
                            XposedBridge.log("GPSAzimuthProvider started")

                            SensorHook(gpsProvider).hook(lpparam)
                            XposedBridge.log("SensorHook initialized for virtual compass")

                        } catch (e: Throwable) {
                            XposedBridge.log("Error starting virtual compass: $e")
                        }
                    }
                }
            }
        )
    }
}