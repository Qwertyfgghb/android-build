package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.*
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        XposedBridge.log("LOAD: ${lpparam.packageName} | ${lpparam.processName}")

        // 🎯 Только Яндекс
        if (lpparam.packageName != "ru.yandex.yandexmaps") return

        // ❗ Только главный процесс
        if (lpparam.processName != "ru.yandex.yandexmaps") {
            XposedBridge.log("SKIP: not main process")
            return
        }

        XposedBridge.log("VC HOOK START")

        // 💥 Ждём реальный Context
        XposedHelpers.findAndHookMethod(
            "android.app.Application",
            lpparam.classLoader,
            "attach",
            Context::class.java,
            object : XC_MethodHook() {

                override fun afterHookedMethod(param: MethodHookParam) {

                    val context = param.args[0] as Context

                    XposedBridge.log("✅ CONTEXT OK")

                    try {
                        val gps = GPSAzimuthProvider(context)
                        gps.start()

                        XposedBridge.log("✅ GPS STARTED")

                        SensorHook(gps).hook(lpparam)

                        XposedBridge.log("✅ SENSOR HOOK STARTED")

                    } catch (e: Throwable) {
                        XposedBridge.log("❌ INIT ERROR: $e")
                    }
                }
            }
        )
    }
}