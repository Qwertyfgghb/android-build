package com.example.virtualcompass

import android.location.Location
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookLoadPackage {

    private var lastLat = 0.0
    private var lastLon = 0.0
    private var lastAzimuth = 0f

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        if (lpparam.packageName != "ru.yandex.yandexmaps") return

        XposedBridge.log("VC HOOK ACTIVE")

        XposedHelpers.findAndHookMethod(
            Location::class.java,
            "getBearing",
            object : de.robv.android.xposed.XC_MethodHook() {

                override fun afterHookedMethod(param: MethodHookParam) {

                    val loc = param.thisObject as Location

                    val lat = loc.latitude
                    val lon = loc.longitude

                    val azimuth = calculateAzimuth(lat, lon)

                    lastLat = lat
                    lastLon = lon

                    if (azimuth != null) {
                        lastAzimuth = smooth(azimuth)
                        param.result = lastAzimuth
                        XposedBridge.log("AZIMUTH: $lastAzimuth")
                    } else {
                        param.result = lastAzimuth
                    }
                }
            }
        )
    }

    private fun calculateAzimuth(lat: Double, lon: Double): Float? {

        if (lastLat == 0.0 && lastLon == 0.0) return null

        val dLon = Math.toRadians(lon - lastLon)

        val y = Math.sin(dLon) * Math.cos(Math.toRadians(lat))
        val x = Math.cos(Math.toRadians(lastLat)) * Math.sin(Math.toRadians(lat)) -
                Math.sin(Math.toRadians(lastLat)) * Math.cos(Math.toRadians(lat)) * Math.cos(dLon)

        return ((Math.toDegrees(Math.atan2(y, x)) + 360) % 360).toFloat()
    }

    private fun smooth(newAzimuth: Float): Float {
        return lastAzimuth + 0.4f * ((newAzimuth - lastAzimuth + 540) % 360 - 180)
    }
}