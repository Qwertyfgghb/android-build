package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, XC_LoadPackage.LoadPackageParam.Callback {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass LSPosed module loaded (zygote)")
        // Контекст недоступен здесь, GPSAzimuthProvider создаём при hookLoadPackage
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf("com.google.android.apps.maps", "com.yandex.maps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("VirtualCompass module loaded in package: ${lpparam.packageName}")

        // Получаем Context через ActivityThread
        val context: Context? = try {
            val activityThread = Class.forName("android.app.ActivityThread")
            val app = activityThread.getMethod("currentApplication").invoke(null)
            app as? Context
        } catch (e: Exception) {
            XposedBridge.log("Error getting context: $e")
            null
        }
        if (context == null) return

        // Создаём провайдер азимута
        val gpsProvider = GPSAzimuthProvider(context)
        gpsProvider.start()

        // Перехват SensorManager и запуск виртуального сенсора
        SensorHook(gpsProvider).hookSensorManager(lpparam)
    }
}