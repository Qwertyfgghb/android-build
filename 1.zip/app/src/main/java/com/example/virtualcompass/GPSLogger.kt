package com.example.virtualcompass

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import de.robv.android.xposed.XposedBridge

class GPSLogger(private val context: Context) : LocationListener {

    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    fun start() {
        try {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                1000L, // 1 сек
                0.1f,
                this
            )
            XposedBridge.log("GPSLogger started")
        } catch (ex: SecurityException) {
            XposedBridge.log("GPS permission error: $ex")
        }
    }

    override fun onLocationChanged(location: Location) {
        XposedBridge.log("GPS update: lat=${location.latitude}, lon=${location.longitude}, alt=${location.altitude}")
    }

    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
}