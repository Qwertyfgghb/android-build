package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.concurrent.fixedRateTimer

class SensorHook(private val gpsProvider: GPSAzimuthProvider) : IXposedHookLoadPackage {

    private val registeredListeners = mutableListOf<SensorEventListener>()

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf("com.google.android.apps.maps", "com.yandex.maps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("SensorHook for: ${lpparam.packageName}")

        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "getDefaultSensor",
            Int::class.javaPrimitiveType,
            object : XC_LoadPackage.MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val type = param.args[0] as Int
                    if (type == Sensor.TYPE_ORIENTATION || type == Sensor.TYPE_ROTATION_VECTOR) {
                        param.result = null
                    }
                }
            }
        )

        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : XC_LoadPackage.MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    if (!registeredListeners.contains(listener)) registeredListeners.add(listener)
                }
            }
        )

        fixedRateTimer("virtualSensorTimer", true, 0L, 50L) {
            val azimuth = gpsProvider.currentAzimuth.toFloat()
            val sensorEvent = VirtualSensor.createSensorEvent(azimuth, 0f, 0f)
            registeredListeners.forEach {
                try { it.onSensorChanged(sensorEvent) } catch (_: Throwable) {}
            }
        }
    }
}