package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.concurrent.fixedRateTimer

class SensorHook(private val gpsAzimuthProvider: GPSAzimuthProvider) {

    private val registeredListeners = mutableListOf<SensorEventListener>()

    fun hookSensorManager(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf("com.google.android.apps.maps", "com.yandex.maps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("VirtualCompass hooking SensorManager in ${lpparam.packageName}")

        // Перехват getDefaultSensor
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "getDefaultSensor",
            Int::class.javaPrimitiveType,
            object : XC_LoadPackage.MethodHook() {
                override fun afterHookedMethod(param: XC_LoadPackage.MethodHook.MethodHookParam) {
                    val sensorType = param.args[0] as Int
                    if (sensorType == Sensor.TYPE_ORIENTATION || sensorType == Sensor.TYPE_ROTATION_VECTOR) {
                        param.result = null
                    }
                }
            }
        )

        // Перехват registerListener
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : XC_LoadPackage.MethodHook() {
                override fun beforeHookedMethod(param: XC_LoadPackage.MethodHook.MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    if (!registeredListeners.contains(listener)) {
                        registeredListeners.add(listener)
                        XposedBridge.log("Registered listener: $listener")
                    }
                }
            }
        )

        // Таймер обновления виртуального сенсора каждые 50ms
        fixedRateTimer("virtualSensorTimer", true, 0L, 50L) {
            val azimuth = gpsAzimuthProvider.currentAzimuth.toFloat()
            val sensorEvent = VirtualSensor.createSensorEvent(azimuth, 0f, 0f)
            registeredListeners.forEach { listener ->
                try {
                    listener.onSensorChanged(sensorEvent)
                } catch (e: Throwable) {
                    XposedBridge.log("Error sending sensor event: $e")
                }
            }
        }
    }
}