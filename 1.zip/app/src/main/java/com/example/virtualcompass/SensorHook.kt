package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.concurrent.fixedRateTimer

object SensorHook {

    private val listeners = mutableListOf<SensorEventListener>()

    fun hook(lpparam: XC_LoadPackage.LoadPackageParam) {
        XposedBridge.log("Hooking SensorManager in ${lpparam.packageName}")

        // Хук registerListener
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : de.robv.android.xposed.XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    if (!listeners.contains(listener)) {
                        listeners.add(listener)
                        XposedBridge.log("Sensor listener added")
                    }
                }
            }
        )
    }

    // Функция для отправки азимута
    fun sendAzimuth(lpparam: XC_LoadPackage.LoadPackageParam, azimuth: Float) {
        fixedRateTimer("virtual-azimuth", true, 0L, 50L) {
            val event = createSensorEvent(azimuth)
            listeners.forEach {
                try {
                    it.onSensorChanged(event)
                } catch (e: Throwable) {
                    XposedBridge.log("Sensor send error: $e")
                }
            }
            this.cancel()
        }
    }

    private fun createSensorEvent(azimuth: Float): SensorEvent {
        return try {
            val ctor = SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
            ctor.isAccessible = true
            val event = ctor.newInstance(3)
            val valuesField = SensorEvent::class.java.getDeclaredField("values")
            valuesField.isAccessible = true
            val values = valuesField.get(event) as FloatArray
            values[0] = azimuth
            values[1] = 0f
            values[2] = 0f
            event
        } catch (e: Throwable) {
            XposedBridge.log("createSensorEvent error: $e")
            throw e
        }
    }
}