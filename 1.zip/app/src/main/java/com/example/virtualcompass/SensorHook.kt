package com.example.virtualcompass

import android.hardware.*
import de.robv.android.xposed.*
import kotlin.concurrent.fixedRateTimer

object SensorHook {

    private val listeners = mutableListOf<SensorEventListener>()
    private val filter = SmoothFilter()

    fun start(gps: GPSProvider) {

        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {

                override fun beforeHookedMethod(param: MethodHookParam) {

                    val listener = param.args[0] as SensorEventListener
                    val sensor = param.args[1] as Sensor

                    if (sensor.type == Sensor.TYPE_ROTATION_VECTOR) {

                        VirtualRotation.setSensor(sensor)

                        if (!listeners.contains(listener)) {
                            listeners.add(listener)
                        }

                        param.result = true
                    }
                }
            }
        )

        fixedRateTimer("vc", true, 0, 50) {

            val az = filter.update(gps.azimuth)
            val event = VirtualRotation.create(az)

            listeners.forEach {
                try {
                    it.onSensorChanged(event)
                } catch (_: Throwable) {}
            }
        }
    }
}