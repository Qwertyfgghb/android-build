package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.concurrent.fixedRateTimer

class SensorHook(private val gpsProvider: GPSAzimuthProvider) {

    private val listeners = mutableListOf<SensorEventListener>()

    fun hook(lpparam: XC_LoadPackage.LoadPackageParam) {

        XposedBridge.log("Hooking sensors in ${lpparam.packageName}")

        // 🔹 Перехват getDefaultSensor
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "getDefaultSensor",
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    val type = param.args[0] as Int
                    if (type == Sensor.TYPE_ORIENTATION || type == Sensor.TYPE_ROTATION_VECTOR) {
                        // Возвращаем null, чтобы приложения получали пустой сенсор
                        param.result = null
                        XposedBridge.log("getDefaultSensor hooked, type=$type -> null")
                    }
                }
            }
        )

        // 🔹 Перехват registerListener
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    if (!listeners.contains(listener)) {
                        listeners.add(listener)
                        XposedBridge.log("VirtualCompass listener added")
                    }
                }
            }
        )

        // 🔹 Генерация виртуального SensorEvent
        fixedRateTimer("VirtualCompassTimer", true, 0L, 50L) {
            val az = gpsProvider.currentAzimuth.toFloat()
            val event = VirtualSensor.createEvent(az)

            listeners.forEach { listener ->
                try {
                    listener.onSensorChanged(event)
                } catch (e: Throwable) {
                    XposedBridge.log("Error sending virtual sensor event: $e")
                }
            }
        }
    }
}