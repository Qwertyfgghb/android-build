package com.example.virtualcompass

import android.hardware.*
import de.robv.android.xposed.*
import kotlin.concurrent.fixedRateTimer
import kotlin.math.*

object SensorHook {

    private val listeners = mutableListOf<SensorEventListener>()

    fun start(gps: GPSProvider) {

        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {

                override fun beforeHookedMethod(param: MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    val sensor = param.args[1] as Sensor

                    if (sensor.type == Sensor.TYPE_ROTATION_VECTOR) {

                        if (!listeners.contains(listener)) {
                            listeners.add(listener)
                        }

                        param.result = true
                    }
                }
            }
        )

        fixedRateTimer("vc", true, 0, 50) {

            val az = gps.azimuth
            val event = createRotationEvent(az)

            listeners.forEach {
                try {
                    it.onSensorChanged(event)
                } catch (_: Throwable) {}
            }
        }
    }

    private fun createRotationEvent(azimuth: Float): SensorEvent {

        val rad = Math.toRadians(azimuth.toDouble())

        val sin = sin(rad / 2)
        val cos = cos(rad / 2)

        val ctor = SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
        ctor.isAccessible = true
        val event = ctor.newInstance(4)

        val valuesField = SensorEvent::class.java.getDeclaredField("values")
        valuesField.isAccessible = true
        val values = valuesField.get(event) as FloatArray

        values[0] = 0f
        values[1] = 0f
        values[2] = sin.toFloat()
        values[3] = cos.toFloat()

        return event
    }
}