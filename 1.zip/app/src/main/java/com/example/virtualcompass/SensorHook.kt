package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.concurrent.fixedRateTimer

class SensorHook(private val gpsAzimuthProvider: GPSAzimuthProvider) {
    fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

    private val registeredListeners = mutableListOf<SensorEventListener>()

    fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf("com.google.android.apps.maps", "com.yandex.maps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("VirtualCompass hooked: ${lpparam.packageName}")

        // Перехват getDefaultSensor
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "getDefaultSensor",
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    val type = param.args[0] as Int
                    if (type == Sensor.TYPE_ORIENTATION || type == Sensor.TYPE_ROTATION_VECTOR) {
                        param.result = null
                    }
                }
            }
        )

        // Перехват registerListener
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    if (!registeredListeners.contains(listener)) {
                        registeredListeners.add(listener)
                        XposedBridge.log("VirtualCompass listener registered: $listener")
                    }
                }
            }
        )

        // Таймер для виртуального SensorEvent
        fixedRateTimer("virtualSensorTimer", true, 0L, 50L) {
            val azimuth = gpsAzimuthProvider.currentAzimuth.toFloat()
            val pitch = 0f
            val roll = 0f
            val sensorEvent = createSensorEvent(azimuth, pitch, roll)

            registeredListeners.forEach { listener ->
                try {
                    listener.onSensorChanged(sensorEvent)
                } catch (e: Throwable) {
                    XposedBridge.log("Error sending sensor event: $e")
                }
            }
        }
    }

    // Создаём псевдо SensorEvent
    private fun createSensorEvent(azimuth: Float, pitch: Float, roll: Float): SensorEvent {
        // Создание Sensor через Reflection (Sensor конструктор защищён)
        val sensor = Sensor::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
            .apply { isAccessible = true }
            .newInstance(TYPE_ORIENTATION, 0)

        val sensorEvent = SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
            .apply { isAccessible = true }
            .newInstance(3)

        // Вставляем sensor через Reflection
        val sensorField = SensorEvent::class.java.getDeclaredField("sensor").apply { isAccessible = true }
        sensorField.set(sensorEvent, sensor)

        val valuesField = SensorEvent::class.java.getDeclaredField("values").apply { isAccessible = true }
        val values = valuesField.get(sensorEvent) as FloatArray
        values[0] = azimuth
        values[1] = pitch
        values[2] = roll

        return sensorEvent
    }

    companion object {
        private const val TYPE_ORIENTATION = 1
    }
}