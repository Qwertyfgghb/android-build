package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.concurrent.fixedRateTimer

class SensorHook(private val gps: GPSAzimuthProvider) {

    private val listeners = mutableListOf<SensorEventListener>()

    fun hook(lpparam: XC_LoadPackage.LoadPackageParam) {
        XposedBridge.log("Hooking sensors in ${lpparam.packageName}")

        // Перехватываем getDefaultSensor
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "getDefaultSensor",
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val type = param.args[0] as Int
                    if (type == Sensor.TYPE_ORIENTATION || type == Sensor.TYPE_ROTATION_VECTOR) {
                        param.result = null
                        XposedBridge.log("getDefaultSensor overridden for type=$type")
                    }
                }
            }
        )

        // Перехватываем registerListener
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    if (!listeners.contains(listener)) {
                        listeners.add(listener)
                        XposedBridge.log("Listener registered: $listener")
                    }
                }
            }
        )

        // Таймер генерации виртуального компаса
        fixedRateTimer("virtualCompass", true, 0L, 50L) {
            val azimuth = gps.currentAzimuth.toFloat()
            val event = createVirtualSensorEvent(azimuth)

            listeners.forEach { listener ->
                try {
                    listener.onSensorChanged(event)
                } catch (e: Throwable) {
                    XposedBridge.log("Error sending sensor event: $e")
                }
            }
        }

        XposedBridge.log("SensorHook initialized for virtual compass")
    }

    private fun createVirtualSensorEvent(azimuth: Float): SensorEvent {
        val ctor = SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
        ctor.isAccessible = true
        val event = ctor.newInstance(3) // azimuth, pitch, roll

        val valuesField = SensorEvent::class.java.getDeclaredField("values")
        valuesField.isAccessible = true
        val values = valuesField.get(event) as FloatArray
        values[0] = azimuth
        values[1] = 0f
        values[2] = 0f

        return event
    }
}