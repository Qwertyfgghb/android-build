package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.concurrent.fixedRateTimer

class SensorHook(private val gpsProvider: GPSAzimuthProvider) {

    fun hookSensors(lpparam: XC_LoadPackage.LoadPackageParam) {
        val targetApps = listOf("com.yandex.maps", "com.google.android.apps.maps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Hooking SensorManager in ${lpparam.packageName}")

        val registeredListeners = mutableListOf<SensorEventListener>()

        // Перехват getDefaultSensor
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "getDefaultSensor",
            Int::class.javaPrimitiveType,
            object : XC_LoadPackage.MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val type = param.args[0] as Int
                    if (type == Sensor.TYPE_ORIENTATION || type == Sensor.TYPE_ROTATION_VECTOR) {
                        param.result = null
                    }
                }
            }
        )

        // Перехват registerListener
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : XC_LoadPackage.MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    if (!registeredListeners.contains(listener)) {
                        registeredListeners.add(listener)
                        VirtualSensor.registerListener(listener)
                        XposedBridge.log("VirtualCompass listener registered")
                    }
                }
            }
        )

        // Таймер для обновления виртуального сенсора
        fixedRateTimer("VirtualCompassTimer", true, 0L, 50L) {
            val azimuth = gpsProvider.currentAzimuth.toFloat()
            VirtualSensor.pushAzimuth(azimuth)
        }
    }
}