package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import java.util.Timer
import java.util.TimerTask

class SensorHook(private val gps: GPSAzimuthProvider) {

    private val listeners = mutableListOf<SensorEventListener>()
    private var timerStarted = false

    fun hook(lpparam: XC_LoadPackage.LoadPackageParam) {

        XposedBridge.log("Hooking sensors in ${lpparam.packageName}")

        val classLoader = lpparam.classLoader

        // ✅ getDefaultSensor
        XposedHelpers.findAndHookMethod(
            "android.hardware.SensorManager",
            classLoader,
            "getDefaultSensor",
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {

                override fun afterHookedMethod(param: MethodHookParam) {
                    val type = param.args[0] as Int

                    if (type == Sensor.TYPE_ORIENTATION ||
                        type == Sensor.TYPE_ROTATION_VECTOR) {

                        XposedBridge.log("Fake sensor returned NULL")
                        param.result = null
                    }
                }
            }
        )

        // ✅ registerListener
        XposedHelpers.findAndHookMethod(
            "android.hardware.SensorManager",
            classLoader,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {

                override fun beforeHookedMethod(param: MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener

                    if (!listeners.contains(listener)) {
                        listeners.add(listener)
                        XposedBridge.log("Listener added: $listener")
                    }
                }
            }
        )

        // ✅ Запускаем генератор 1 раз
        if (!timerStarted) {
            timerStarted = true

            Timer().scheduleAtFixedRate(object : TimerTask() {
                override fun run() {

                    val az = gps.currentAzimuth.toFloat()
                    val event = VirtualSensor.createEvent(az)

                    listeners.forEach {
                        try {
                            it.onSensorChanged(event)
                        } catch (e: Throwable) {
                            XposedBridge.log("send error: $e")
                        }
                    }
                }
            }, 0, 50)
        }
    }
}