package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.concurrent.fixedRateTimer

class SensorHook(private val gps: GPSAzimuthProvider) {

    private val listeners = mutableListOf<SensorEventListener>()

    fun hook(lpparam: XC_LoadPackage.LoadPackageParam) {

        XposedBridge.log("Hooking sensors in ${lpparam.packageName}")

        // Hook getDefaultSensor
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "getDefaultSensor",
            Int::class.javaPrimitiveType,
            object : de.robv.android.xposed.XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val type = param.args[0] as Int
                    if (type == Sensor.TYPE_ORIENTATION || type == Sensor.TYPE_ROTATION_VECTOR) {
                        param.result = null
                    }
                }
            }
        )

        // Hook registerListener
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : de.robv.android.xposed.XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    if (!listeners.contains(listener)) {
                        listeners.add(listener)
                        XposedBridge.log("Listener added")
                    }
                }
            }
        )

        XposedBridge.log("SensorHook initialized for virtual compass")

        // Периодически отправляем текущий азимут в слушателей
        fixedRateTimer("compass", true, 0L, 50L) {
            val az = gps.currentAzimuth
            listeners.forEach {
                try {
                    val event = VirtualSensor.createEvent(az)
                    it.onSensorChanged(event)
                } catch (e: Throwable) {
                    XposedBridge.log("send error: $e")
                }
            }
        }
    }
}