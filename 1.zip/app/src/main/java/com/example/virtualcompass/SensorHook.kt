package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.XposedBridge

class SensorHook(private val virtualSensor: VirtualSensor) : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        val targetApps = listOf("com.yandex.maps", "com.google.android.apps.maps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("VirtualCompass hooked: ${lpparam.packageName}")

        // Перехватываем getDefaultSensor
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "getDefaultSensor",
            Int::class.javaPrimitiveType,
            object : de.robv.android.xposed.XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val sensorType = param.args[0] as Int
                    if (sensorType == Sensor.TYPE_ORIENTATION) {
                        param.result = null // Возвращаем null, потом виртуальный слушатель
                    }
                }
            }
        )

        // Перехватываем registerListener
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : de.robv.android.xposed.XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    virtualSensor.registerListener(listener)
                    param.result = true
                }
            }
        )

        // unregisterListener
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "unregisterListener",
            SensorEventListener::class.java,
            object : de.robv.android.xposed.XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    virtualSensor.unregisterListener(listener)
                    param.result = true
                }
            }
        )

        virtualSensor.start()
    }
}