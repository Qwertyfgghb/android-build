package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.concurrent.fixedRateTimer

class SensorHook(private val gpsAzimuthProvider: GPSAzimuthProvider) : IXposedHookLoadPackage {

    // Список слушателей, зарегистрированных через registerListener
    private val registeredListeners = mutableListOf<SensorEventListener>()

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        // Список приложений, для которых подменяем компас
        val targetApps = listOf("com.yandex.maps", "com.google.android.apps.maps")

        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("VirtualCompass hooked: ${lpparam.packageName}")

        // Перехватываем getDefaultSensor
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "getDefaultSensor",
            Int::class.javaPrimitiveType,
            object : de.robv.android.xposed.XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val sensorType = param.args[0] as Int
                    if (sensorType == Sensor.TYPE_ORIENTATION || sensorType == Sensor.TYPE_ROTATION_VECTOR) {
                        // Возвращаем null, чтобы потом вручную отдавать SensorEventListener
                        param.result = null
                    }
                }
            }
        )

        // Перехватываем registerListener, чтобы добавить наших слушателей в список
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : XC_LoadPackage.MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    if (!registeredListeners.contains(listener)) {
                        registeredListeners.add(listener)
                        XposedBridge.log("Registered VirtualCompass listener: $listener")
                    }
                }
            }
        )

        // Создаём таймер для виртуального SensorEvent
        fixedRateTimer("virtualSensorTimer", true, 0L, 50L) {
            val azimuth = gpsAzimuthProvider.currentAzimuth.toFloat()
            val pitch = 0f
            val roll = 0f

            val sensorEvent = createSensorEvent(azimuth, pitch, roll)

            // Отправляем всем зарегистрированным слушателям
            registeredListeners.forEach {
                try {
                    it.onSensorChanged(sensorEvent)
                } catch (e: Throwable) {
                    XposedBridge.log("Error sending sensor event: $e")
                }
            }
        }
    }

    // Создаём псевдо SensorEvent (имитация ориентационного сенсора)
    private fun createSensorEvent(azimuth: Float, pitch: Float, roll: Float): SensorEvent {
        val sensor = Sensor(TYPE_ORIENTATION, 0)
        val event = SensorEvent(3)
        event.sensor = sensor
        event.values[0] = azimuth
        event.values[1] = pitch
        event.values[2] = roll
        return event
    }

    companion object {
        private const val TYPE_ORIENTATION = 1
    }
}