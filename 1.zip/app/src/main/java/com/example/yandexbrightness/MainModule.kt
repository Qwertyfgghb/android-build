package com.example.yandexbrightness

import android.app.Activity
import android.content.Context
import android.location.Location
import android.provider.Settings
import android.view.WindowManager
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Проверяем пакет Яндекс.Карт
        if (lpparam.packageName != "ru.yandex.yandexmaps") return

        try {
            // Хук на метод getSpeed() класса Location
            XposedHelpers.findAndHookMethod(
                Location::class.java,
                "getSpeed",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: XC_MethodHook.MethodHookParam) {
                        val speedMps = param.result as Float
                        // Передаём объект Location, из него попытаемся достать Context
                        adjustBrightness(param.thisObject, speedMps)
                    }
                }
            )
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun adjustBrightness(obj: Any?, speedMps: Float) {
        // Получаем контекст из Activity если возможно
        val context: Context = when (obj) {
            is Activity -> obj
            is Context -> obj
            else -> return
        }

        // Не трогаем экран если он выключен
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val isScreenOn = try {
            val method = windowManager.javaClass.getMethod("getDefaultDisplay")
            val display = method.invoke(windowManager)
            val isOnMethod = display.javaClass.getMethod("isValid")
            isOnMethod.invoke(display) as Boolean
        } catch (_: Exception) {
            true // если не удалось проверить, допустим что экран включён
        }
        if (!isScreenOn) return

        // Выбираем яркость
        val newBrightness = if (speedMps > 8.33f) 150 else 220

        try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                newBrightness
            )
        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }
}