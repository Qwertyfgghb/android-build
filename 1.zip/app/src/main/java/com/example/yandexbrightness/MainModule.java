package com.example.yandexbrightness

import android.content.Context
import android.provider.Settings
import android.location.Location
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.XC_MethodHook

class MainModule : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if(lpparam.packageName == "ru.yandex.yandexmaps") { // Яндекс.Карты
            try {
                // Хук на метод getSpeed() класса Location
                XposedHelpers.findAndHookMethod(
                    Location::class.java,
                    "getSpeed",
                    object : XC_MethodHook() {
                        override fun afterHookedMethod(param: MethodHookParam) {
                            val speedMps = param.result as Float
                            adjustBrightness(lpparam.appContext, speedMps)
                        }
                    }
                )
            } catch(e: Throwable) {
                e.printStackTrace()
            }
        }
    }

    private fun adjustBrightness(context: Context?, speedMps: Float) {
        if(context == null) return

        val newBrightness = if(speedMps > 8.33f) 150 else 220 // 30 км/ч = 8.33 m/s

        try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                newBrightness
            )
        } catch(e: SecurityException) {
            e.printStackTrace()
        }
    }
}