package com.example.audioblocker

import de.robv.android.xposed.XposedBridge

fun logAudio(message: String) {
    XposedBridge.log("[AudioBlocker] $message")
}