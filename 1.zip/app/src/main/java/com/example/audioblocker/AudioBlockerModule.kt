package com.example.audioblocker

import android.media.AudioTrack
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class AudioBlockerModule : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam?) {
        if (lpparam?.packageName != "app.revanced.android.youtube") return

        XposedHelpers.findAndHookMethod(
            AudioTrack::class.java,
            "write",
            ByteArray::class.java,
            Int::class.javaPrimitiveType,
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    // Заблокировать аудио: обнуляем данные
                    val buffer = param.args[0] as ByteArray
                    for (i in buffer.indices) buffer[i] = 0
                }
            }
        )

        // Можно добавить логирование аудио потоков
        XposedHelpers.findAndHookMethod(
            AudioTrack::class.java,
            "play",
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    XposedHelpers.callMethod(param.thisObject, "setVolume", 0f)
                }
            }
        )
    }
}