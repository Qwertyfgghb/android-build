package com.example.audioonly

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_LoadPackage
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.XC_MethodHook

class AudioOnlyModule : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "com.google.android.youtube") return

        XposedBridge.log("AudioOnlyModule: Loaded YouTube package")

        try {
            // Пример: перехватываем конструктор ViewHolder в RecyclerView
            XposedHelpers.findAndHookConstructor(
                "androidx.recyclerview.widget.RecyclerView\$ViewHolder",
                lpparam.classLoader,
                View::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val viewHolder = param.thisObject as RecyclerView.ViewHolder
                        val itemView = viewHolder.itemView

                        // Простейшая проверка по тегу/типу контента (для примера)
                        val tag = itemView.tag?.toString() ?: ""
                        if (tag.contains("music", ignoreCase = true)) {
                            XposedBridge.log("AudioOnlyModule: Hiding music item")
                            itemView.visibility = View.GONE
                        }
                    }
                }
            )

            // Перехватываем метод setVisibility (если нужно)
            XposedHelpers.findAndHookMethod(
                RecyclerView::class.java,
                "setVisibility",
                Int::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val visibility = param.args[0] as Int
                        XposedBridge.log("AudioOnlyModule: RecyclerView setVisibility called: $visibility")
                    }
                }
            )

        } catch (t: Throwable) {
            XposedBridge.log("AudioOnlyModule ERROR: ${t.message}")
        }
    }
}