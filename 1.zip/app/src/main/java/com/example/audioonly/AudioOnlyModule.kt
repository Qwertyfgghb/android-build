package com.example.audioonly

import android.content.Context
import android.util.Log
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers

class AudioOnlyModule : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "AudioOnlyModule"
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "app.revanced.android.youtube") return

        // Хук SurfaceView
        try {
            XposedHelpers.findAndHookConstructor(
                SurfaceView::class.java,
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val view = param.thisObject as SurfaceView
                        view.visibility = View.GONE
                        Log.i(TAG, "SurfaceView hidden")
                    }
                }
            )
        } catch (e: Throwable) {
            Log.e(TAG, "SurfaceView hook failed: ${e.message}")
        }

        // Хук TextureView
        try {
            XposedHelpers.findAndHookConstructor(
                TextureView::class.java,
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val view = param.thisObject as TextureView
                        view.visibility = View.GONE
                        Log.i(TAG, "TextureView hidden")
                    }
                }
            )
        } catch (e: Throwable) {
            Log.e(TAG, "TextureView hook failed: ${e.message}")
        }

        Log.i(TAG, "Hooks installed successfully")
    }
}