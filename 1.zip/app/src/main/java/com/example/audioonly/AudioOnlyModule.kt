package com.example.audioonly

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import android.util.Log

class AudioOnlyModule : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "AudioOnlyModule"
        private const val TARGET_PACKAGE = "com.google.android.youtube"
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Проверяем, что это YouTube
        if (lpparam.packageName != TARGET_PACKAGE) return

        Log.i(TAG, "YouTube загружен, устанавливаем хуки...")

        try {
            // Пример: перехват метода воспроизведения видео
            val playerClass = XposedHelpers.findClass(
                "com.google.android.youtube.player.Player",
                lpparam.classLoader
            )

            XposedHelpers.findAndHookMethod(
                playerClass,
                "playVideo",
                String::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        val videoId = param.args[0] as String
                        // Пример фильтра: блокируем музыкальные видео
                        if (videoId.contains("music", ignoreCase = true)) {
                            Log.i(TAG, "Блокируем музыкальное видео: $videoId")
                            param.result = null // отменяем воспроизведение
                        }
                    }
                }
            )
        } catch (e: Throwable) {
            Log.e(TAG, "Ошибка установки хуков", e)
        }
    }
}