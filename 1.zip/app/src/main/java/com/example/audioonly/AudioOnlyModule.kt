package com.example.audioonly

import android.content.Context
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers

class AudioOnlyModule : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "app.revanced.android.youtube") return

        // Хук SurfaceView (конструктор с Context)
        try {
            XposedHelpers.findAndHookConstructor(
                SurfaceView::class.java,
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val view = param.thisObject as SurfaceView
                        view.visibility = View.GONE
                    }
                }
            )
        } catch (e: Throwable) {
            XposedHelpers.log("AudioOnlyModule: SurfaceView hook failed: ${e.message}")
        }

        // Хук TextureView (конструктор с Context)
        try {
            XposedHelpers.findAndHookConstructor(
                TextureView::class.java,
                Context::class.java,
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val view = param.thisObject as TextureView
                        view.visibility = View.GONE
                    }
                }
            )
        } catch (e: Throwable) {
            XposedHelpers.log("AudioOnlyModule: TextureView hook failed: ${e.message}")
        }

        XposedHelpers.log("AudioOnlyModule: Hooks installed successfully")
    }
}