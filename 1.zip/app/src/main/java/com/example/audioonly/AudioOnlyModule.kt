package com.example.nomusicstrict

import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class StrictNoMusicModule : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "StrictNoMusicFilter"
        private const val TARGET_PACKAGE = "com.google.android.youtube"

        // Слова для грубой проверки музыкального контента
        private val MUSIC_KEYWORDS = listOf(
            "Music", "Song", "Instrumental", "Track", "Remix", "AI Music"
        )
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET_PACKAGE) return

        Log.i(TAG, "YouTube загружен, включен строгий фильтр без музыки...")

        try {
            val videoClass = XposedHelpers.findClass(
                "com.google.android.youtube.model.Video",
                lpparam.classLoader
            )

            // Перехватываем метод, где создаётся аудио поток
            XposedHelpers.findAndHookMethod(
                videoClass,
                "getAudioStream",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val video = param.thisObject
                        val title = XposedHelpers.getObjectField(video, "title") as? String ?: ""
                        val category = XposedHelpers.getObjectField(video, "category") as? String ?: ""

                        // Блокируем видео, если категория или название содержат музыкальные слова
                        if (MUSIC_KEYWORDS.any { title.contains(it, ignoreCase = true) || category.contains(it, ignoreCase = true) }) {
                            Log.i(TAG, "Отключаем аудио для видео: $title [$category]")
                            param.result = null // блокируем аудио
                        }
                    }
                }
            )

            // Фильтрация видео в списках
            val listClass = XposedHelpers.findClass(
                "com.google.android.youtube.model.VideoList",
                lpparam.classLoader
            )

            XposedHelpers.findAndHookMethod(
                listClass,
                "getItems",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        val list = param.result as? MutableList<Any> ?: return
                        val filtered = list.filter { video ->
                            val title = XposedHelpers.getObjectField(video, "title") as? String ?: ""
                            val category = XposedHelpers.getObjectField(video, "category") as? String ?: ""
                            MUSIC_KEYWORDS.none { title.contains(it, ignoreCase = true) || category.contains(it, ignoreCase = true) }
                        }
                        param.result = filtered
                        Log.i(TAG, "Строгая фильтрация: музыкальные видео удалены, осталось: ${filtered.size}")
                    }
                }
            )

        } catch (e: Throwable) {
            Log.e(TAG, "Ошибка строгого фильтра", e)
        }
    }
}