package com.example.audioonly

import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class AudioOnlyModule : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "AudioOnly"
        private const val TARGET_PACKAGE = "app.revanced.android.youtube"
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET_PACKAGE) return

        Log.i(TAG, "YouTube ReVanced загружен, активируем AudioOnly...")

        try {
            // Хук на VideoClip.getVideoTracks() — возвращаем пустой массив, чтобы видео не создавалось
            val videoClipClass = XposedHelpers.findClass(
                "com.google.android.libraries.youtube.media.interfaces.VideoClip",
                lpparam.classLoader
            )

            XposedHelpers.findAndHookMethod(
                videoClipClass,
                "getVideoTracks",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        Log.i(TAG, "Видео потоки заблокированы (AudioOnly)")
                        param.result = emptyList<Any>() // возвращаем пустой список видео
                    }
                }
            )

            // Дополнительно хук на VideoStreamingData.getVideoStreams() (если используется)
            val videoDataClass = XposedHelpers.findClass(
                "com.google.android.libraries.youtube.media.interfaces.VideoStreamingData",
                lpparam.classLoader
            )

            XposedHelpers.findAndHookMethod(
                videoDataClass,
                "getVideoStreams",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        Log.i(TAG, "VideoStreamingData потоки видео заблокированы")
                        param.result = emptyList<Any>()
                    }
                }
            )

            Log.i(TAG, "AudioOnly хук успешно установлен")

        } catch (e: Throwable) {
            Log.e(TAG, "Ошибка при установке AudioOnly", e)
        }
    }
}