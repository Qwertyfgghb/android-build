package com.example.audioonly

import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class AudioOnlyModule : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam?) {
        if (lpparam?.packageName != "app.revanced.android.youtube") return

        // Перехватываем SurfaceView
        XposedHelpers.findAndHookConstructor(
            SurfaceView::class.java,
            lpparam.classLoader,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val view = param.thisObject as SurfaceView
                    view.visibility = View.GONE
                }
            }
        )

        // Перехватываем TextureView
        XposedHelpers.findAndHookConstructor(
            TextureView::class.java,
            lpparam.classLoader,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val view = param.thisObject as TextureView
                    view.visibility = View.GONE
                }
            }
        )
    }
}