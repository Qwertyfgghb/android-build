package com.example.audioonly

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_LoadPackage
import de.robv.android.xposed.XposedHelpers

class AudioOnlyModule : IXposedHookLoadPackage {

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam?) {
        if (lpparam?.packageName != "app.revanced.android.youtube") return

        // Перехватываем конструктор адаптера списка видео
        XposedHelpers.findAndHookConstructor(
            "com.youtube.adapter.VideoAdapter",
            lpparam.classLoader
        ) { param ->
            val adapter = param.thisObject

            // Перехватываем bindViewHolder
            XposedHelpers.findAndHookMethod(
                adapter.javaClass,
                "onBindViewHolder",
                RecyclerView.ViewHolder::class.java,
                Int::class.javaPrimitiveType
            ) { hookParam ->
                val holder = hookParam.args[0] as RecyclerView.ViewHolder
                val position = hookParam.args[1] as Int

                // Получаем объект видео
                val videoItem = XposedHelpers.callMethod(adapter, "getItem", position)

                // Проверяем категорию / ключевые слова
                val category = XposedHelpers.getObjectField(videoItem, "categoryId") as? Int
                val title = XposedHelpers.getObjectField(videoItem, "title") as? String

                if (category == 10 || title?.contains("Music", ignoreCase = true) == true) {
                    holder.itemView.visibility = View.GONE
                    holder.itemView.layoutParams = RecyclerView.LayoutParams(0, 0)
                }
            }
        }
    }
}