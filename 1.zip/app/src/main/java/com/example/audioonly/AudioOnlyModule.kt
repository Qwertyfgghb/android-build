package com.example.audioonly

import android.util.Log
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class AudioOnlyModule : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "AudioOnly"
        private const val TARGET_PACKAGE = "app.revanced.android.youtube"
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET_PACKAGE) return

        Log.i(TAG, "YouTube ReVanced загружен, активируем AudioOnly...")

        try {
            // Класс VideoClip
            val videoClipClass = XposedHelpers.findClass(
                "com.google.android.libraries.youtube.media.interfaces.VideoClip",
                lpparam.classLoader
            )

            // Хук метода getVideoTracks()
            XposedHelpers.findAndHookMethod(
                videoClipClass,
                "getVideoTracks",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        Log.i(TAG, "Видео треки заблокированы")
                        param.result = emptyList<Any>() // убираем видео
                    }
                }
            )

            // Хук метода getVideoStream() для полной блокировки видео
            XposedHelpers.findAndHookMethod(
                videoClipClass,
                "getVideoStream",
                object : XC_MethodHook() {
                    override fun afterHookedMethod(param: MethodHookParam) {
                        Log.i(TAG, "VideoStream заблокирован")
                        param.result = null
                    }
                }
            )

            Log.i(TAG, "AudioOnly хук применен успешно")

        } catch (e: Throwable) {
            Log.e(TAG, "Ошибка AudioOnly", e)
        }
    }
}