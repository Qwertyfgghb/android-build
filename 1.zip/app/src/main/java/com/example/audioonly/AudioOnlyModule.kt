package com.example.audioonly

import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class AudioOnlyModule : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam?) {
        if (lpparam?.packageName != "app.revanced.android.youtube") return

        // Перехватываем создание видео Surface
        XposedHelpers.findAndHookConstructor(
            "android.view.SurfaceView",
            lpparam.classLoader,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    param.thisObject.setVisibility(0) // INVISIBLE
                }
            }
        )

        XposedHelpers.findAndHookConstructor(
            "android.view.TextureView",
            lpparam.classLoader,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    param.thisObject.setVisibility(0) // INVISIBLE
                }
            }
        )

        // Аудио оставляем как есть
    }
}