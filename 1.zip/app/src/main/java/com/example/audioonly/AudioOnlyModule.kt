package com.example.audioonly

import android.util.Log
import android.view.Surface
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class AudioOnlyModule : IXposedHookLoadPackage {

    companion object {
        private const val TAG = "AudioOnly"
        private const val TARGET_PACKAGE = "app.revanced.android.youtube"
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != TARGET_PACKAGE) return

        Log.i(TAG, "YouTube ReVanced загружен, активируем AudioOnly режим")

        try {
            // --- 1. Блокировка ExoPlayer Surface (реальный рендер видео) ---
            val exoPlayerClass = XposedHelpers.findClass(
                "androidx.media3.exoplayer.ExoPlayer",
                lpparam.classLoader
            )
            XposedHelpers.findAndHookMethod(
                exoPlayerClass,
                "setVideoSurface",
                Surface::class.java,
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        Log.i(TAG, "ExoPlayer видео отключено")
                        param.args[0] = null
                    }
                }
            )

            // --- 2. Блокировка VideoClip.play() ---
            val videoClipClass = XposedHelpers.findClass(
                "com.google.android.libraries.youtube.media.interfaces.VideoClip",
                lpparam.classLoader
            )
            XposedHelpers.findAndHookMethod(
                videoClipClass,
                "play",
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        Log.i(TAG, "VideoClip play заблокировано")
                        param.result = null
                    }
                }
            )

            // --- 3. Блокировка SpoofVideoStreamsPatch.apply() ---
            val spoofPatchClass = XposedHelpers.findClass(
                "app.revanced.extension.shared.spoof.SpoofVideoStreamsPatch",
                lpparam.classLoader
            )
            XposedHelpers.findAndHookMethod(
                spoofPatchClass,
                "apply",
                object : XC_MethodHook() {
                    override fun beforeHookedMethod(param: MethodHookParam) {
                        Log.i(TAG, "SpoofVideoStreamsPatch видео заблокировано")
                        param.result = null
                    }
                }
            )

            // --- 4. Дополнительно: блокируем все внутренние методы рендеринга видео, если есть ---
            val internalVideoClasses = arrayOf(
                "app.revanced.extension.youtube.patches.VideoInformation",
                "app.revanced.extension.youtube.patches.MiniplayerPatch",
                "app.revanced.extension.youtube.patches.ForceOriginalAudioPatch"
            )
            for (clsName in internalVideoClasses) {
                try {
                    val cls = XposedHelpers.findClass(clsName, lpparam.classLoader)
                    XposedHelpers.findAndHookMethod(
                        cls,
                        "apply", // большинство патчей используют метод apply
                        object : XC_MethodHook() {
                            override fun beforeHookedMethod(param: MethodHookParam) {
                                Log.i(TAG, "$clsName видео отключено")
                                param.result = null
                            }
                        }
                    )
                } catch (_: Throwable) {
                    Log.w(TAG, "Класс $clsName не найден")
                }
            }

        } catch (t: Throwable) {
            Log.e(TAG, "Ошибка AudioOnly", t)
        }
    }
}