package com.example.ytmusiclogger;

import android.util.Log;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class LoggerModule implements IXposedHookLoadPackage {

    private static final String TAG = "YTLogger";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // Хук только на ReVanced
        if (!lpparam.packageName.equals("com.google.android.youtube")) return;

        Log.i(TAG, "YTLogger: пакет загружен, включаем динамический хук классов");

        // Используем XposedBridge для динамического хука всех новых классов
        XposedBridge.hookAllConstructors(ClassLoader.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                ClassLoader cl = (ClassLoader) param.thisObject;
                try {
                    // Динамически перехватываем класс при первой загрузке
                    XposedHelpers.findClassIfExists("com.google.android.apps.youtube.app.player.PlayerController", cl);
                    hookAllMethodsInLoadedClasses(cl);
                } catch (Throwable t) {
                    Log.e(TAG, "YTLogger: ошибка динамического перехвата классов", t);
                }
            }
        });

        // Попытка перехвата уже загруженных классов
        hookAllMethodsInLoadedClasses(lpparam.classLoader);
    }

    private void hookAllMethodsInLoadedClasses(ClassLoader cl) {
        String[] knownPackages = new String[]{
                "com.google.android.apps.youtube"
        };

        for (String pkg : knownPackages) {
            try {
                // Перебор классов в пакете
                for (String className : XposedHelpers.findClassIfExists(pkg + ".app.player.PlayerController", cl) != null ? new String[]{pkg + ".app.player.PlayerController"} : new String[]{}) {
                    try {
                        Class<?> clazz = XposedHelpers.findClassIfExists(className, cl);
                        if (clazz == null) continue;

                        for (Method method : clazz.getDeclaredMethods()) {
                            try {
                                XposedHelpers.findAndHookMethod(clazz, method.getName(), method.getParameterTypes(), new XC_MethodHook() {
                                    @Override
                                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                                        StringBuilder sb = new StringBuilder();
                                        sb.append("Метод вызван: ").append(clazz.getName()).append(".").append(method.getName()).append(" | args: ");
                                        for (Object arg : param.args) {
                                            sb.append(arg != null ? arg.getClass().getSimpleName() + "@" + arg.hashCode() : "null").append(", ");
                                        }
                                        Log.i(TAG, sb.toString());
                                    }
                                });
                            } catch (Throwable t) {
                                // игнорируем ошибки хука
                            }
                        }
                    } catch (Throwable t) {
                        // игнорируем ошибки загрузки класса
                    }
                }
            } catch (Throwable t) {
                // игнорируем ошибки перебора пакета
            }
        }
    }
}