package com.example.ytmusiclogger;

import android.util.Log;

import java.io.File;
import java.lang.reflect.Method;
import java.util.Enumeration;

import dalvik.system.DexClassLoader;
import dalvik.system.DexFile;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class LoggerModule implements IXposedHookLoadPackage {

    private static final String TAG = "YTLogger";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        if (!lpparam.packageName.equals("com.google.android.youtube")) return;

        Log.i(TAG, "YTLogger: пакет загружен - начинаем перебор классов через DexFile");

        try {
            String apkPath = lpparam.appInfo.sourceDir;
            File optimizedDexOutputPath = new File("/data/user/0/" + lpparam.packageName + "/files/dex");

            if (!optimizedDexOutputPath.exists()) {
                optimizedDexOutputPath.mkdirs();
            }

            DexClassLoader dexClassLoader = new DexClassLoader(
                    apkPath,
                    optimizedDexOutputPath.getAbsolutePath(),
                    null,
                    lpparam.classLoader
            );

            DexFile dexFile = new DexFile(apkPath);
            Enumeration<String> entries = dexFile.entries();

            while (entries.hasMoreElements()) {
                String className = entries.nextElement();
                try {
                    Class<?> clazz = dexClassLoader.loadClass(className);

                    for (Method method : clazz.getDeclaredMethods()) {
                        if (method.getParameterTypes().length == 1 && method.getParameterTypes()[0] == Object.class) {

                            XposedHelpers.findAndHookMethod(
                                    clazz,
                                    method.getName(),
                                    Object.class,
                                    new XC_MethodHook() {
                                        @Override
                                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                                            Log.i(TAG, "Метод вызван: " + clazz.getName() + "." + method.getName()
                                                    + " с аргументом: " + param.args[0]);
                                        }
                                    }
                            );
                        }
                    }

                } catch (Throwable t) {
                    // Класс может не загружаться, игнорируем
                }
            }

        } catch (Throwable t) {
            Log.e(TAG, "YTLogger: ошибка при переборе классов через DexFile", t);
        }
    }
}