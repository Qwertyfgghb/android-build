package com.example.ytmusiclogger;

import android.util.Log;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class LoggerModule implements IXposedHookLoadPackage {

    private static final String TAG = "YTLogger";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // Хук только на основной пакет ReVanced
        if (!lpparam.packageName.equals("com.google.android.youtube")) return;

        Log.i(TAG, "YTLogger: пакет загружен, начинаем перебор классов");

        ClassLoader cl = lpparam.classLoader;

        // Пример перебора известных пакетов/классов для ускорения
        String[] candidateClasses = new String[]{
                "com.google.android.apps.youtube.app.player.PlayerController",
                "com.google.android.apps.youtube.player.VideoPlayer",
                "com.google.android.apps.youtube.player.PlayerResponse"
        };

        for (String className : candidateClasses) {
            try {
                Class<?> clazz = XposedHelpers.findClass(className, cl);

                for (Method method : clazz.getDeclaredMethods()) {

                    XposedHelpers.findAndHookMethod(clazz, method.getName(), method.getParameterTypes(), new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            StringBuilder sb = new StringBuilder();
                            sb.append("Метод вызван: ").append(clazz.getName()).append(".").append(method.getName()).append(" | args: ");
                            for (Object arg : param.args) {
                                sb.append(arg != null ? arg.getClass().getSimpleName() + "@" + arg.hashCode() : "null").append(", ");
                            }
                            Log.i(TAG, sb.toString());
                        }
                    });

                }
            } catch (Throwable t) {
                Log.e(TAG, "YTLogger: не удалось хукнуть класс " + className, t);
            }
        }

        Log.i(TAG, "YTLogger: перебор классов завершен");
    }
}