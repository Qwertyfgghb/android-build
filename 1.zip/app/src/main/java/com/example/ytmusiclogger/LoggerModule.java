package com.example.ytmusiclogger;

import android.util.Log;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class LoggerModule implements IXposedHookLoadPackage {

    private static final String TAG = "YTLogger";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("com.google.android.youtube")) return;

        Log.i(TAG, "YTLogger: пакет загружен - начинаем перебор классов");

        ClassLoader cl = lpparam.classLoader;

        // Универсальный хук всех классов (можно оптимизировать по пакету)
        try {
            // Получаем все классы через известный пакет
            for (String className : DexFileUtils.getAllClasses(cl)) {
                try {
                    Class<?> clazz = Class.forName(className, false, cl);

                    for (Method m : clazz.getDeclaredMethods()) {
                        // Проверяем методы с одним параметром Object
                        if (m.getParameterTypes().length == 1 && m.getParameterTypes()[0] == Object.class) {
                            XposedHelpers.findAndHookMethod(clazz, m.getName(), Object.class, new XC_MethodHook() {
                                @Override
                                protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                                    Log.i(TAG, "Метод вызван: " + clazz.getName() + "." + m.getName() +
                                            " с аргументом: " + param.args[0]);
                                }
                            });
                        }
                    }
                } catch (Throwable t) {
                    Log.e(TAG, "Ошибка при обработке класса " + className, t);
                }
            }
        } catch (Throwable t) {
            Log.e(TAG, "YTLogger: ошибка при переборе классов", t);
        }
    }
}