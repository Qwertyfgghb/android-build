package com.example.whiteimagehook;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.VideoView;

import java.util.Random;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedHelpers;

public class WhiteImageHook implements IXposedHookLoadPackage {

    private final Random random = new Random();

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // Перехватываем все ImageView
        XposedHelpers.findAndHookMethod(ImageView.class, "setImageDrawable", Drawable.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = new ColorDrawable(randomColor());
            }
        });

        XposedHelpers.findAndHookMethod(ImageView.class, "setImageBitmap", android.graphics.Bitmap.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = null;
            }
        });

        XposedHelpers.findAndHookMethod(ImageView.class, "setImageResource", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = android.R.color.white; // можно заменить на randomColor() для разноцветных картинок
            }
        });

        // Перехватываем все VideoView (разные цвета вместо видео)
        XposedHelpers.findAndHookMethod(VideoView.class, "setVideoPath", String.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                ((VideoView)param.thisObject).setBackgroundColor(randomColor());
                param.setResult(null);
            }
        });

        XposedHelpers.findAndHookMethod(VideoView.class, "setVideoURI", android.net.Uri.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                ((VideoView)param.thisObject).setBackgroundColor(randomColor());
                param.setResult(null);
            }
        });

        // Перехватываем фоны всех View
        XposedHelpers.findAndHookMethod(View.class, "setBackground", Drawable.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = new ColorDrawable(randomColor());
            }
        });

        XposedHelpers.findAndHookMethod(View.class, "setBackgroundDrawable", Drawable.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = new ColorDrawable(randomColor());
            }
        });

        XposedHelpers.findAndHookMethod(View.class, "setBackgroundResource", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = android.R.color.white; // можно заменить на randomColor()
            }
        });

        // Рекурсивный обход всех ViewGroup
        XposedHelpers.findAndHookMethod(ViewGroup.class, "addView", View.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                View child = (View) param.args[0];
                removeImagesRecursive(child);
            }
        });
    }

    private void removeImagesRecursive(View view) {
        if (view instanceof ImageView) {
            ((ImageView)view).setImageDrawable(new ColorDrawable(randomColor()));
        } else if (view instanceof VideoView) {
            view.setBackgroundColor(randomColor());
        }

        view.setBackgroundColor(randomColor());

        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;
            for (int i = 0; i < vg.getChildCount(); i++) {
                removeImagesRecursive(vg.getChildAt(i));
            }
        }
    }

    private int randomColor() {
        return 0xFF000000 | random.nextInt(0x00FFFFFF); // случайный цвет с полной альфой
    }
}