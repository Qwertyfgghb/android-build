package com.example.whiteimagehook;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.VideoView;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedHelpers;

public class WhiteImageHook implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // Перехватываем все ImageView
        XposedHelpers.findAndHookMethod(ImageView.class, "setImageDrawable", Drawable.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = new ColorDrawable(Color.WHITE);
            }
        });

        XposedHelpers.findAndHookMethod(ImageView.class, "setImageBitmap", android.graphics.Bitmap.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = null;
            }
        });

        XposedHelpers.findAndHookMethod(ImageView.class, "setImageResource", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = android.R.color.white;
            }
        });

        // Перехватываем все VideoView (делаем фон белым и скрываем видео)
        XposedHelpers.findAndHookMethod(VideoView.class, "setVideoPath", String.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                ((VideoView)param.thisObject).setBackgroundColor(Color.WHITE);
                param.setResult(null); // предотвращаем загрузку видео
            }
        });

        XposedHelpers.findAndHookMethod(VideoView.class, "setVideoURI", android.net.Uri.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                ((VideoView)param.thisObject).setBackgroundColor(Color.WHITE);
                param.setResult(null);
            }
        });

        // Перехватываем фоны всех View
        XposedHelpers.findAndHookMethod(View.class, "setBackground", Drawable.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = new ColorDrawable(Color.WHITE);
            }
        });

        XposedHelpers.findAndHookMethod(View.class, "setBackgroundDrawable", Drawable.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = new ColorDrawable(Color.WHITE);
            }
        });

        XposedHelpers.findAndHookMethod(View.class, "setBackgroundResource", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = android.R.color.white;
            }
        });

        // Рекурсивный обход всех ViewGroup для принудительного белого фона
        XposedHelpers.findAndHookMethod(ViewGroup.class, "addView", View.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                View child = (View) param.args[0];
                removeImagesRecursive(child);
            }
        });
    }

    private void removeImagesRecursive(View view) {
        if (view instanceof ImageView) {
            ((ImageView)view).setImageDrawable(new ColorDrawable(Color.WHITE));
        } else if (view instanceof VideoView) {
            view.setBackgroundColor(Color.WHITE);
        }

        view.setBackgroundColor(Color.WHITE);

        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;
            for (int i = 0; i < vg.getChildCount(); i++) {
                removeImagesRecursive(vg.getChildAt(i));
            }
        }
    }
}