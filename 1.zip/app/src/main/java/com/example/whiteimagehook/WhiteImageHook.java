package com.example.whiteimagehook;

import android.view.TextureView;
import android.widget.ImageView;
import android.view.View;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.XC_MethodHook;

public class WhiteImageHook implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // LSPosed сам позволяет включить/отключить модуль для выбранных приложений
        // Поэтому проверка пакета не обязательна, но можно оставить для логов
        XposedHelpers.log("[*] WhiteImageHook загружен для: " + lpparam.packageName);

        // Замазываем TextureView (видео)
        XposedHelpers.findAndHookMethod(TextureView.class, "onDraw", Canvas.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                Canvas canvas = (Canvas) param.args[0];
                int w = ((TextureView) param.thisObject).getWidth();
                int h = ((TextureView) param.thisObject).getHeight();
                Paint paint = new Paint();
                paint.setColor(Color.WHITE);
                paint.setStyle(Paint.Style.FILL);
                canvas.drawRect(0, 0, w, h, paint);
            }
        });

        // Замазываем ImageView
        XposedHelpers.findAndHookMethod(ImageView.class, "setImageBitmap", Bitmap.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                Bitmap bmp = (Bitmap) param.args[0];
                if (bmp != null) {
                    int w = bmp.getWidth();
                    int h = bmp.getHeight();
                    Bitmap whiteBmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    Canvas c = new Canvas(whiteBmp);
                    Paint p = new Paint();
                    p.setColor(Color.WHITE);
                    p.setStyle(Paint.Style.FILL);
                    c.drawRect(0, 0, w, h, p);
                    param.args[0] = whiteBmp;
                }
            }
        });

        XposedHelpers.findAndHookMethod(ImageView.class, "setImageDrawable", Drawable.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                param.args[0] = null; // убираем drawable
            }
        });

        // Устанавливаем белый фон для всех View
        XposedHelpers.findAndHookMethod(View.class, "setBackground", Drawable.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                ((View) param.thisObject).setBackgroundColor(Color.WHITE);
                param.setResult(null);
            }
        });

        XposedHelpers.log("[*] WhiteImageHook активирован ✅ для " + lpparam.packageName);
    }
}