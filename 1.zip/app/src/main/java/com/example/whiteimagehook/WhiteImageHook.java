package com.example.whiteimagehook;

import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.ColorDrawable;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.VideoView;

import java.util.Random;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedHelpers;

public class WhiteImageHook implements IXposedHookLoadPackage {

    private Random random = new Random();

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // Перехватываем ImageView
        XposedHelpers.findAndHookMethod(ImageView.class, "setImageDrawable", android.graphics.drawable.Drawable.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = new ColorDrawable(randomColor());
            }
        });

        // Перехватываем VideoView
        XposedHelpers.findAndHookMethod(VideoView.class, "setVideoPath", String.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                ((VideoView)param.thisObject).setBackgroundColor(randomColor());
                param.setResult(null); // блокируем видео
            }
        });

        XposedHelpers.findAndHookMethod(VideoView.class, "setVideoURI", android.net.Uri.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                ((VideoView)param.thisObject).setBackgroundColor(randomColor());
                param.setResult(null); // блокируем видео
            }
        });

        // Перехватываем TextureView
        XposedHelpers.findAndHookMethod(TextureView.class, "setSurfaceTextureListener", TextureView.SurfaceTextureListener.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                param.args[0] = null; // убираем SurfaceTexture
            }
        });

        // Обход всех новых ViewGroup
        XposedHelpers.findAndHookMethod(ViewGroup.class, "addView", View.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                View child = (View) param.args[0];
                removeImagesRecursive(child);
            }
        });
    }

    private void removeImagesRecursive(View view) {
        if (view.getWidth() < 100 || view.getHeight() < 100) return; // мелкие элементы игнорируем

        if (view instanceof ImageView) {
            ((ImageView)view).setImageDrawable(new ColorDrawable(randomColor()));
        } else if (view instanceof VideoView || view instanceof TextureView) {
            view.setBackgroundColor(randomColor());
        } else if (!(view instanceof Button)) {
            view.setBackgroundColor(randomColor());
        }

        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;
            for (int i = 0; i < vg.getChildCount(); i++) {
                removeImagesRecursive(vg.getChildAt(i));
            }
        }
    }

    private int randomColor() {
        return Color.rgb(50 + random.nextInt(206),
                         50 + random.nextInt(206),
                         50 + random.nextInt(206));
    }
}