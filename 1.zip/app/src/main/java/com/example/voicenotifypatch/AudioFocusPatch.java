package com.example.voicenotifypatch;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.TextToSpeech;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class AudioFocusPatch implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // Только для пакета com.pilot51.voicenotify
        if (!lpparam.packageName.equals("com.pilot51.voicenotify")) return;

        // Хук на метод setOnUtteranceProgressListener
        XposedHelpers.findAndHookMethod(
                TextToSpeech.class,
                "setOnUtteranceProgressListener",
                UtteranceProgressListener.class,
                new XC_MethodHook() {

                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {

                        UtteranceProgressListener original = (UtteranceProgressListener) param.args[0];

                        TextToSpeech tts = (TextToSpeech) param.thisObject;
                        Context context = (Context) XposedHelpers.callMethod(tts, "getContext");

                        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);

                        AudioAttributes attrs = new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build();

                        AudioManager.OnAudioFocusChangeListener listener = focusChange -> {};

                        AudioFocusRequest request = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                                .setAudioAttributes(attrs)
                                .setOnAudioFocusChangeListener(listener)
                                .build();

                        // Прокси, который запрашивает и освобождает AudioFocus
                        UtteranceProgressListener proxy = new UtteranceProgressListener() {
                            @Override
                            public void onStart(String utteranceId) {
                                audioManager.requestAudioFocus(request);
                                if (original != null) original.onStart(utteranceId);
                            }

                            @Override
                            public void onDone(String utteranceId) {
                                audioManager.abandonAudioFocusRequest(request);
                                if (original != null) original.onDone(utteranceId);
                            }

                            @Override
                            public void onError(String utteranceId) {
                                audioManager.abandonAudioFocusRequest(request);
                                if (original != null) original.onError(utteranceId);
                            }
                        };

                        param.args[0] = proxy; // заменяем на прокси
                    }
                });
    }
}