package com.example.voicenotifypatch;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.speech.tts.TextToSpeech;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class AudioFocusHook implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        if (!lpparam.packageName.equals("com.pilot51.voicenotify")) return;

        // Хук на все методы speak(Text, QUEUE, Bundle, String)
        XposedHelpers.findAndHookMethod(
                TextToSpeech.class,
                "speak",
                CharSequence.class,
                int.class,
                android.os.Bundle.class,
                String.class,
                new XC_MethodHook() {

                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {

                        TextToSpeech tts = (TextToSpeech) param.thisObject;
                        Context context = (Context) XposedHelpers.callMethod(tts, "getContext");

                        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);

                        AudioAttributes attrs = new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build();

                        AudioManager.OnAudioFocusChangeListener listener = focusChange -> {};

                        AudioFocusRequest request = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                                .setAudioAttributes(attrs)
                                .setOnAudioFocusChangeListener(listener)
                                .build();

                        // Запрашиваем AudioFocus перед воспроизведением
                        audioManager.requestAudioFocus(request);

                        // Отдаём AudioFocus после окончания речи через UtteranceProgressListener
                        TextToSpeech.UtteranceProgressListener originalListener =
                                (TextToSpeech.UtteranceProgressListener) XposedHelpers.getObjectField(tts, "mUtteranceProgressListener");

                        TextToSpeech.UtteranceProgressListener proxyListener = new TextToSpeech.UtteranceProgressListener() {
                            @Override
                            public void onStart(String utteranceId) {
                                if (originalListener != null) originalListener.onStart(utteranceId);
                            }

                            @Override
                            public void onDone(String utteranceId) {
                                audioManager.abandonAudioFocusRequest(request);
                                if (originalListener != null) originalListener.onDone(utteranceId);
                            }

                            @Override
                            public void onError(String utteranceId) {
                                audioManager.abandonAudioFocusRequest(request);
                                if (originalListener != null) originalListener.onError(utteranceId);
                            }
                        };

                        XposedHelpers.setObjectField(tts, "mUtteranceProgressListener", proxyListener);
                    }
                });
    }
}