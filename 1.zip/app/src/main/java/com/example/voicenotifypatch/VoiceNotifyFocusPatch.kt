package com.example.voicenotifypatch

import android.content.Context
import android.media.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.callbacks.XC_LoadPackage
import de.robv.android.xposed.XposedHelpers

class VoiceNotifyFocusPatch : IXposedHookLoadPackage {

    private var focusRequest: AudioFocusRequest? = null
    private var audioManager: AudioManager? = null
    private var listenerAttached = false

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "com.pilot51.voicenotify") return

        XposedHelpers.findAndHookMethod(
            TextToSpeech::class.java,
            "speak",
            CharSequence::class.java,
            Int::class.javaPrimitiveType,
            android.os.Bundle::class.java,
            String::class.java,
            object : XC_MethodHook() {

                override fun beforeHookedMethod(param: MethodHookParam) {
                    val tts = param.thisObject as TextToSpeech

                    if (audioManager == null) {
                        val contextField =
                            TextToSpeech::class.java.getDeclaredField("mContext")
                        contextField.isAccessible = true
                        val context = contextField.get(tts) as Context
                        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    }

                    if (focusRequest == null) {
                        focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                            .setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                    .build()
                            )
                            .setAcceptsDelayedFocusGain(false)
                            .build()
                    }

                    audioManager?.requestAudioFocus(focusRequest!!)

                    if (!listenerAttached) {
                        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) {
                                audioManager?.abandonAudioFocusRequest(focusRequest!!)
                                try { Runtime.getRuntime().exec("input keyevent 127") } catch (_: Exception) {}
                            }
                            override fun onError(utteranceId: String?) {
                                audioManager?.abandonAudioFocusRequest(focusRequest!!)
                            }
                        })
                        listenerAttached = true
                    }
                }
            })
    }
}
