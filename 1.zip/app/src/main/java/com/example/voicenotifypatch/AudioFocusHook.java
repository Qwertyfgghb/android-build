package com.example.voicenotifypatch;

import android.content.Context;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class AudioFocusHook implements IXposedHookLoadPackage {

    private static final String TARGET_PACKAGE = "com.pilot51.voicenotify";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        if (!lpparam.packageName.equals(TARGET_PACKAGE)) return;

        final AudioManager audioManager = (AudioManager) XposedHelpers.callMethod(
                XposedHelpers.callStaticMethod(
                        XposedHelpers.findClass("android.app.ActivityThread", null),
                        "currentApplication"
                ),
                "getSystemService",
                Context.AUDIO_SERVICE
        );

        // ---------------- Android O+ ----------------
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            XposedHelpers.findAndHookMethod(
                    AudioManager.class,
                    "requestAudioFocus",
                    AudioFocusRequest.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            AudioFocusRequest request = (AudioFocusRequest) param.args[0];
                            String requestingPackage = (String) XposedHelpers.getObjectField(request, "mClientId");
                            if (!TARGET_PACKAGE.equals(requestingPackage)) {
                                // Глушим все кроме VoiceNotify
                                param.setResult(AudioManager.AUDIOFOCUS_REQUEST_FAILED);
                            }
                        }
                    }
            );
        }

        // ---------------- Старый метод (до O) ----------------
        else {
            XposedHelpers.findAndHookMethod(
                    AudioManager.class,
                    "requestAudioFocus",
                    AudioManager.OnAudioFocusChangeListener.class,
                    int.class,
                    int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            param.setResult(AudioManager.AUDIOFOCUS_REQUEST_FAILED); // Глушим всех кроме VoiceNotify
                        }
                    }
            );
        }

        // ---------------- Перехват speak() ----------------
        XposedHelpers.findAndHookMethod(
                TextToSpeech.class,
                "speak",
                String.class,
                int.class,
                Bundle.class,
                String.class,
                new XC_MethodHook() {

                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        // До начала речи — можно глушить другие приложения
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            // Для Android O+ можно подготовить AudioFocusRequest на VoiceNotify
                        }
                    }

                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        // После окончания речи — восстанавливаем аудиофокус
                        TextToSpeech tts = (TextToSpeech) param.thisObject;

                        // Старый метод
                        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
                            audioManager.abandonAudioFocus(null);
                        } else {
                            // Android O+ — можно попробовать получить текущий request и освободить
                            try {
                                AudioFocusRequest request = (AudioFocusRequest) XposedHelpers.getObjectField(tts, "mAudioFocusRequest");
                                if (request != null) {
                                    audioManager.abandonAudioFocusRequest(request);
                                }
                            } catch (NoSuchFieldError ignored) {}
                        }
                    }
                }
        );
    }
}