package com.example.voicenotifypatch;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.Build;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class AudioFocusHook implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // Только для конкретного пакета
        if (!lpparam.packageName.equals("com.pilot51.voicenotify")) return;

        // Хук на TextToSpeech.speak()
        XposedHelpers.findAndHookMethod(
                TextToSpeech.class,
                "speak",
                CharSequence.class,
                int.class,
                android.os.Bundle.class,
                String.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {

                        TextToSpeech tts = (TextToSpeech) param.thisObject;
                        Context context = (Context) XposedHelpers.callMethod(tts, "getContext");

                        // final переменные для использования в анонимном классе
                        final AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                        final AudioFocusRequest request;

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            AudioAttributes attrs = new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                    .build();

                            AudioManager.OnAudioFocusChangeListener listener = focusChange -> {};

                            request = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                                    .setAudioAttributes(attrs)
                                    .setOnAudioFocusChangeListener(listener)
                                    .build();

                            audioManager.requestAudioFocus(request);
                        } else {
                            request = null; // Для старых версий
                        }

                        // Получаем оригинальный listener, если установлен
                        UtteranceProgressListener originalListener =
                                (UtteranceProgressListener) XposedHelpers.getObjectField(tts, "mUtteranceProgressListener");

                        // Прокси listener для освобождения AudioFocus после речи
                        UtteranceProgressListener proxyListener = new UtteranceProgressListener() {
                            @Override
                            public void onStart(String utteranceId) {
                                if (originalListener != null) originalListener.onStart(utteranceId);
                            }

                            @Override
                            public void onDone(String utteranceId) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && request != null) {
                                    audioManager.abandonAudioFocusRequest(request);
                                }
                                if (originalListener != null) originalListener.onDone(utteranceId);
                            }

                            @Override
                            public void onError(String utteranceId) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && request != null) {
                                    audioManager.abandonAudioFocusRequest(request);
                                }
                                if (originalListener != null) originalListener.onError(utteranceId);
                            }
                        };

                        // Ставим наш прокси listener
                        XposedHelpers.setObjectField(tts, "mUtteranceProgressListener", proxyListener);
                    }
                });
    }
}