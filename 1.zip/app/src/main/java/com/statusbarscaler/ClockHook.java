package com.statusbarscaler;

import android.widget.TextView;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class ClockHook {
    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> clockClass = XposedHelpers.findClass(
                "com.android.systemui.statusbar.policy.Clock", lpparam.classLoader);

            // Хукаем метод onAttachedToWindow, чтобы изменить размер и масштаб для часов
            XposedHelpers.findAndHookMethod(clockClass, "onAttachedToWindow", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    TextView clock = (TextView) param.thisObject;
                    clock.setTextSize(18f);  // Увеличиваем размер шрифта для часов
                    clock.setScaleX(1.1f);   // Увеличиваем масштаб по горизонтали
                    clock.setScaleY(1.1f);   // Увеличиваем масштаб по вертикали
                }
            });
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}