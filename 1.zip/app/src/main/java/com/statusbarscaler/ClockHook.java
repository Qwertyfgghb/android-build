package com.statusbarscaler;

import android.widget.TextView;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class ClockHook {

    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {

        try {
            Class<?> clockClass = XposedHelpers.findClass(
                    "com.android.systemui.statusbar.policy.Clock",
                    lpparam.classLoader);

            XposedHelpers.findAndHookMethod(clockClass,
                    "onAttachedToWindow",
                    new XC_MethodHook() {

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {

                            TextView clock = (TextView) param.thisObject;

                            clock.setTextSize(24f);
                            clock.setScaleX(1.2f);
                            clock.setScaleY(1.2f);
                        }
                    });

        } catch (Throwable ignored) {}
    }
}
