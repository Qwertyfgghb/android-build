package com.statusbarscaler;

import android.widget.TextView;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import android.content.Context;
import android.content.SharedPreferences;
import de.robv.android.xposed.XposedBridge;

public class ClockHook {
    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> clockClass = XposedHelpers.findClass(
                "com.android.systemui.statusbar.policy.Clock", lpparam.classLoader);

            XposedHelpers.findAndHookMethod(clockClass, "onAttachedToWindow", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    TextView clock = (TextView) param.thisObject;
                    Context ctx = clock.getContext();
                    SharedPreferences prefs = ctx.getSharedPreferences("StatusBarScalerPrefs", Context.MODE_PRIVATE);

                    int textSize = prefs.getInt("clockTextSize", 36);      // размер текста по умолчанию
                    float scaleX = prefs.getFloat("clockScaleX", 1.8f);    // горизонтальный масштаб
                    float scaleY = prefs.getFloat("clockScaleY", 1.8f);    // вертикальный масштаб

                    clock.setTextSize(textSize);
                    clock.setScaleX(scaleX);
                    clock.setScaleY(scaleY);
                }
            });

        } catch (Throwable t) {
            XposedBridge.log("Error in ClockHook: " + t.getMessage());
        }
    }

    // Метод для динамического применения изменений без перезагрузки
    public static void applySettings(TextView clock, Context ctx) {
        try {
            SharedPreferences prefs = ctx.getSharedPreferences("StatusBarScalerPrefs", Context.MODE_PRIVATE);
            int textSize = prefs.getInt("clockTextSize", 36);
            float scaleX = prefs.getFloat("clockScaleX", 1.8f);
            float scaleY = prefs.getFloat("clockScaleY", 1.8f);

            clock.setTextSize(textSize);
            clock.setScaleX(scaleX);
            clock.setScaleY(scaleY);
        } catch (Throwable t) {
            XposedBridge.log("Error applying settings: " + t.getMessage());
        }
    }
}