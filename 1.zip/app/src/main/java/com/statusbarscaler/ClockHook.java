package com.statusbarscaler;

import android.widget.TextView;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class ClockHook {
    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> clockClass = XposedHelpers.findClass(
                "com.android.systemui.statusbar.policy.Clock", lpparam.classLoader);

            XposedHelpers.findAndHookMethod(clockClass, "onAttachedToWindow", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    TextView clock = (TextView) param.thisObject;
                    clock.setTextSize(36f);  // увеличиваем текст
                    clock.setScaleX(1.8f);   // масштаб по горизонтали
                    clock.setScaleY(1.8f);   // масштаб по вертикали
                }
            });
        } catch (Throwable t) {
            // ничего страшного, просто логируем
            de.robv.android.xposed.XposedBridge.log("Error in ClockHook: " + t.getMessage());
        }
    }
}