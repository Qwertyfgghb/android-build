package com.statusbarscaler;

import android.view.View;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;

public class StatusBarHook {
    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> statusBarClass = XposedHelpers.findClass(
                "com.android.systemui.statusbar.phone.StatusBar", lpparam.classLoader);

            XposedHelpers.findAndHookMethod(statusBarClass, "onLayout", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    View statusBar = (View) param.thisObject;
                    statusBar.setScaleX(1.5f);  // увеличиваем ширину статус-бара
                    statusBar.setScaleY(1.0f);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("Error in StatusBarHook: " + t.getMessage());
        }
    }
}