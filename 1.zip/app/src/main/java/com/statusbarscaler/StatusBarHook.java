package com.statusbarscaler;

import android.widget.TextView;
import android.view.View;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class StatusBarHook {
    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // Хук для контейнера статус-бара
            Class<?> statusBarClass = XposedHelpers.findClass(
                "com.android.systemui.statusbar.phone.StatusBar", lpparam.classLoader);

            // Хукаем метод для изменения ширины статус-бара
            XposedHelpers.findAndHookMethod(statusBarClass, "onLayout", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    // Увеличиваем ширину статус-бара
                    View statusBar = (View) param.thisObject;
                    statusBar.setScaleX(1.5f);  // Увеличиваем по горизонтали (ширина)
                    statusBar.setScaleY(1.0f);  // Оставляем высоту неизменной
                }
            });

            // Увеличиваем размер текста для часов
            Class<?> clockClass = XposedHelpers.findClass(
                "com.android.systemui.statusbar.policy.Clock", lpparam.classLoader);

            XposedHelpers.findAndHookMethod(clockClass, "onAttachedToWindow", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    TextView clock = (TextView) param.thisObject;
                    clock.setTextSize(36f);  // Увеличиваем размер текста для часов
                    clock.setScaleX(1.8f);   // Увеличиваем ширину
                    clock.setScaleY(1.8f);   // Увеличиваем высоту
                }
            });

            // Увеличиваем размер иконок сети и батареи
            Class<?> iconClass = XposedHelpers.findClass(
                "com.android.systemui.statusbar.StatusBarIconView", lpparam.classLoader);

            XposedHelpers.findAndHookMethod(iconClass, "onAttachedToWindow", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    View icon = (View) param.thisObject;
                    icon.setScaleX(1.5f);  // Увеличиваем иконки по горизонтали
                    icon.setScaleY(1.5f);  // Увеличиваем иконки по вертикали
                }
            });

        } catch (Throwable t) {
            // Логируем ошибку, если что-то пошло не так
            XposedBridge.log("Error in StatusBarHook: " + t.getMessage());
        }
    }
}