package com.statusbarscaler;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;

public class XposedInit implements IXposedHookLoadPackage {
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals("com.android.systemui"))
            return;
        try {
            ClockHook.init(lpparam);
        } catch (Throwable t) {
            XposedBridge.log("Error loading ClockHook: " + t.getMessage());
        }
    }
}