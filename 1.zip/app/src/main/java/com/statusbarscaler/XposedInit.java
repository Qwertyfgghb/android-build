package com.statusbarscaler;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedBridge;

public class XposedInit implements IXposedHookLoadPackage {
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        // Ограничиваем только com.android.systemui
        if (!lpparam.packageName.equals("com.android.systemui"))
            return;

        try {
            // Инициализируем все хуки (включая статус-бар)
            StatusBarHook.init(lpparam);
            ClockHook.init(lpparam);
        } catch (Throwable t) {
            // Логируем ошибку, чтобы понять, что пошло не так
            XposedBridge.log("Error loading hooks: " + t.getMessage());
        }
    }
}