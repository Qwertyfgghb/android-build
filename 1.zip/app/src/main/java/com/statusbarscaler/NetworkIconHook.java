package com.statusbarscaler;

import android.view.View;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class NetworkIconHook {

    public static void init(XC_LoadPackage.LoadPackageParam lpparam) {

        try {
            XposedHelpers.findAndHookMethod(
                    "com.android.systemui.statusbar.phone.StatusBarIconView",
                    lpparam.classLoader,
                    "onAttachedToWindow",
                    new XC_MethodHook() {

                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {

                            View icon = (View) param.thisObject;

                            icon.setScaleX(1.2f);
                            icon.setScaleY(1.2f);
                        }
                    });

        } catch (Throwable ignored) {}
    }
}
