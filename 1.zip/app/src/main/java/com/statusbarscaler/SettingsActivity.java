package com.statusbarscaler;

import android.app.Activity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.SharedPreferences;

public class SettingsActivity extends Activity {
    private SharedPreferences prefs;
    private static final String PREFS_NAME = "StatusBarScalerPrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        // Ползунок для размера текста
        TextView tvText = new TextView(this);
        tvText.setText("Размер текста часов");
        SeekBar seekText = new SeekBar(this);
        seekText.setMax(72);
        seekText.setProgress(prefs.getInt("clockTextSize", 36));
        seekText.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                prefs.edit().putInt("clockTextSize", progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Ползунок для ScaleX
        TextView tvScaleX = new TextView(this);
        tvScaleX.setText("Горизонтальный масштаб");
        SeekBar seekScaleX = new SeekBar(this);
        seekScaleX.setMax(300); // масштаб *100
        seekScaleX.setProgress((int)(prefs.getFloat("clockScaleX", 1.8f)*100));
        seekScaleX.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                prefs.edit().putFloat("clockScaleX", progress/100f).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        // Ползунок для ScaleY
        TextView tvScaleY = new TextView(this);
        tvScaleY.setText("Вертикальный масштаб");
        SeekBar seekScaleY = new SeekBar(this);
        seekScaleY.setMax(300);
        seekScaleY.setProgress((int)(prefs.getFloat("clockScaleY", 1.8f)*100));
        seekScaleY.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                prefs.edit().putFloat("clockScaleY", progress/100f).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        layout.addView(tvText);
        layout.addView(seekText);
        layout.addView(tvScaleX);
        layout.addView(seekScaleX);
        layout.addView(tvScaleY);
        layout.addView(seekScaleY);

        setContentView(layout);
    }
}