Fixed CloneSelectActivity lambda compilation error: appName is copied to finalAppName before use inside the lambda.
