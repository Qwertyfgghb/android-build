package com.example.voicenotifypatch;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.speech.tts.TextToSpeech;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.XC_MethodHook;

public class AudioFocusPatch implements IXposedHookLoadPackage {

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {

        // ✅ Работает только для одного приложения
        if (!lpparam.packageName.equals("com.pilot51.voicenotify")) return;

        // Хук на метод TextToSpeech.speak
        XposedHelpers.findAndHookMethod(
                TextToSpeech.class,
                "speak",
                String.class,
                int.class,
                android.os.Bundle.class,
                String.class,
                new XC_MethodHook() {

                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                        TextToSpeech tts = (TextToSpeech) param.thisObject;
                        Context context = tts.getContext();
                        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);

                        AudioAttributes attrs = new AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build();

                        AudioManager.OnAudioFocusChangeListener listener = focusChange -> {};

                        AudioFocusRequest request = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                                .setAudioAttributes(attrs)
                                .setOnAudioFocusChangeListener(listener)
                                .build();

                        // Запрос AudioFocus только для этого приложения
                        audioManager.requestAudioFocus(request);

                        // Сохраняем, чтобы потом отпустить
                        param.setObjectExtra("audioFocusRequest", request);
                        param.setObjectExtra("audioManager", audioManager);
                    }

                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        AudioFocusRequest request = (AudioFocusRequest) param.getObjectExtra("audioFocusRequest");
                        AudioManager audioManager = (AudioManager) param.getObjectExtra("audioManager");
                        if (request != null && audioManager != null) {
                            // Освобождаем AudioFocus после окончания TTS
                            audioManager.abandonAudioFocusRequest(request);
                        }
                    }
                });
    }
}