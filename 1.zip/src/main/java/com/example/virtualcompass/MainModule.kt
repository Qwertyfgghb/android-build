package com.example.virtualcompass

import android.content.Context
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.IXposedHookZygoteInit
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainModule : IXposedHookZygoteInit, IXposedHookLoadPackage {

    override fun initZygote(startupParam: IXposedHookZygoteInit.StartupParam?) {
        XposedBridge.log("VirtualCompass loaded (zygote)")
    }

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {

        // Список целевых приложений
        val targetApps = listOf("com.google.android.apps.maps", "ru.yandex.yandexmaps")
        if (!targetApps.contains(lpparam.packageName)) return

        XposedBridge.log("Loaded in target: ${lpparam.packageName}")

        // Получаем Context через ActivityThread
        val context: Context? = try {
            val activityThread = Class.forName("android.app.ActivityThread")
            val app = activityThread.getMethod("currentApplication").invoke(null) as? Context
            app
        } catch (e: Throwable) {
            XposedBridge.log("Error getting context: $e")
            null
        }

        if (context == null) {
            XposedBridge.log("Context is null, cannot start GPSAzimuthProvider")
            return
        }

        // Инициализируем GPSAzimuthProvider
        val gps = GPSAzimuthProvider(context)
        gps.start()
        XposedBridge.log("GPSAzimuthProvider started")

        // Запускаем SensorHook
        SensorHook(gps).hook(lpparam)
    }
}