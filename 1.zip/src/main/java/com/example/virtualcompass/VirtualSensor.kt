package com.example.virtualcompass

import android.hardware.SensorEvent
import android.util.Log
import de.robv.android.xposed.XposedBridge

object VirtualSensor {

    /**
     * Создаём псевдо SensorEvent с заданным азимутом
     */
    fun createEvent(azimuth: Float): SensorEvent {
        return try {
            // Создаём массив значений вручную
            val values = floatArrayOf(azimuth, 0f, 0f)

            // Создаём SensorEvent через рефлексию
            val ctor = SensorEvent::class.java.getDeclaredConstructor(Int::class.javaPrimitiveType)
            ctor.isAccessible = true
            val event = ctor.newInstance(3)

            val valuesField = SensorEvent::class.java.getDeclaredField("values")
            valuesField.isAccessible = true
            valuesField.set(event, values)

            event
        } catch (e: Throwable) {
            XposedBridge.log("VirtualSensor createEvent error: $e")
            throw e
        }
    }
}