package com.example.virtualcompass

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlin.concurrent.fixedRateTimer

class SensorHook(private val gps: GPSAzimuthProvider) {

    private val listeners = mutableListOf<SensorEventListener>()

    fun hook(lpparam: XC_LoadPackage.LoadPackageParam) {

        XposedBridge.log("Hooking sensors in ${lpparam.packageName}")

        // Перехват getDefaultSensor
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "getDefaultSensor",
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun afterHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    val type = param.args[0] as Int
                    if (type == Sensor.TYPE_ORIENTATION || type == Sensor.TYPE_ROTATION_VECTOR) {
                        param.result = null // возвращаем null, чтобы использовать виртуальный SensorEvent
                        XposedBridge.log("getDefaultSensor overridden for type $type")
                    }
                }
            }
        )

        // Перехват registerListener
        XposedHelpers.findAndHookMethod(
            SensorManager::class.java,
            "registerListener",
            SensorEventListener::class.java,
            Sensor::class.java,
            Int::class.javaPrimitiveType,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: XC_MethodHook.MethodHookParam) {
                    val listener = param.args[0] as SensorEventListener
                    if (!listeners.contains(listener)) {
                        listeners.add(listener)
                        XposedBridge.log("Listener added: $listener")
                    }
                }
            }
        )

        // Таймер для генерации виртуальных SensorEvent каждые 50ms
        fixedRateTimer("VirtualCompassTimer", true, 0L, 50L) {
            val azimuth = gps.currentAzimuth.toFloat()
            val event = VirtualSensor.createEvent(azimuth)

            listeners.forEach { listener ->
                try {
                    listener.onSensorChanged(event)
                } catch (e: Throwable) {
                    XposedBridge.log("Error sending virtual sensor event: $e")
                }
            }
        }

        XposedBridge.log("SensorHook initialized for virtual compass")
    }
}