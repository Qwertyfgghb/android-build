package com.virtual.app.proxy;

import android.app.Activity;
import android.os.Bundle;

/**
 * Manifest-declared Activity used as the Android entry point for a virtual app.
 * ProxyInstrumentation replaces this Activity instance with the target
 * Activity class before Activity.onCreate() is called.
 */
public class ProxyActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
