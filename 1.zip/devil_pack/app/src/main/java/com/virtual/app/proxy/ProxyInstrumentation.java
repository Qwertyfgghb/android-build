package com.virtual.app.proxy;

import android.app.Activity;
import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;

import com.virtual.core.VirtualCore;
import com.virtual.core.entity.VirtualApp;
import com.virtual.util.VirtualLog;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import dalvik.system.DexClassLoader;

/**
 * Lightweight in-process proxy runtime. Android launches ProxyActivity (which
 * is actually installed in the host APK); this Instrumentation then creates
 * the requested Activity class from the source APK. This is the foundation
 * for root-free virtual launching and is deliberately kept inside the host
 * process.
 */
public final class ProxyInstrumentation extends Instrumentation {
    public static final String EXTRA_TARGET_PACKAGE = "devil.target.package";
    public static final String EXTRA_TARGET_ACTIVITY = "devil.target.activity";
    public static final String EXTRA_USER_ID = "devil.target.user";

    private static final String TAG = "DevilProxyInstr";
    private final Instrumentation base;
    private final Context host;
    private final Map<String, ClassLoader> loaders = new ConcurrentHashMap<>();
    private final Map<String, Application> applications = new ConcurrentHashMap<>();

    public ProxyInstrumentation(Instrumentation base, Context host) {
        this.base = base;
        this.host = host.getApplicationContext();
    }

    public static boolean install(Context context) {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Method current = at.getDeclaredMethod("currentActivityThread");
            current.setAccessible(true);
            Object thread = current.invoke(null);
            if (thread == null) return false;

            Field f = at.getDeclaredField("mInstrumentation");
            f.setAccessible(true);
            Object existing = f.get(thread);
            if (existing instanceof ProxyInstrumentation) return true;

            f.set(thread, new ProxyInstrumentation((Instrumentation) existing, context));
            VirtualLog.i(TAG, "Proxy Instrumentation installed");
            return true;
        } catch (Throwable e) {
            VirtualLog.e(TAG, "Failed to install Proxy Instrumentation", e);
            return false;
        }
    }

    @Override
    public Activity newActivity(ClassLoader ignored, String className, Intent intent)
            throws InstantiationException, IllegalAccessException, ClassNotFoundException {
        if (intent != null && intent.hasExtra(EXTRA_TARGET_PACKAGE)) {
            String pkg = intent.getStringExtra(EXTRA_TARGET_PACKAGE);
            String activityName = intent.getStringExtra(EXTRA_TARGET_ACTIVITY);
            try {
                ClassLoader loader = getTargetClassLoader(pkg);
                Class<?> cls = Class.forName(activityName, true, loader);
                Object obj = cls.getDeclaredConstructor().newInstance();
                if (!(obj instanceof Activity)) {
                    throw new ClassNotFoundException("Target is not an Activity: " + activityName);
                }
                VirtualLog.i(TAG, "Created target Activity " + activityName + " for " + pkg);
                return (Activity) obj;
            } catch (Throwable e) {
                VirtualLog.e(TAG, "Failed to create target Activity: " + activityName, e);
                throw new InstantiationException(e.toString());
            }
        }
        return base.newActivity(ignored, className, intent);
    }

    @Override
    public void callActivityOnCreate(Activity activity, Bundle icicle) {
        prepareTargetActivity(activity);
        base.callActivityOnCreate(activity, icicle);
    }

    @Override
    public void callActivityOnCreate(Activity activity, Bundle icicle,
                                     android.os.PersistableBundle persistentState) {
        prepareTargetActivity(activity);
        base.callActivityOnCreate(activity, icicle, persistentState);
    }

    private void prepareTargetActivity(Activity activity) {
        try {
            Intent intent = activity.getIntent();
            if (intent == null) return;
            String pkg = intent.getStringExtra(EXTRA_TARGET_PACKAGE);
            if (pkg == null) return;

            Context targetContext = host.createPackageContext(
                    pkg, Context.CONTEXT_INCLUDE_CODE | Context.CONTEXT_IGNORE_SECURITY);

            Application targetApp = applications.get(pkg);
            if (targetApp == null) {
                ApplicationInfo ai = host.getPackageManager().getApplicationInfo(
                        pkg, PackageManager.GET_META_DATA);
                if (ai.className != null && !ai.className.equals("android.app.Application")) {
                    targetApp = newApplication(getTargetClassLoader(pkg), ai.className, targetContext);
                    targetApp.onCreate();
                    Application previous = applications.putIfAbsent(pkg, targetApp);
                    if (previous != null) targetApp = previous;
                }
            }

            setField(activity, Activity.class, "mBase", targetContext);
            if (targetApp != null) {
                setField(activity, Activity.class, "mApplication", targetApp);
            }
            VirtualCore core = VirtualCore.get();
            VirtualApp app = core.getVirtualAppByUserId(intent.getIntExtra(EXTRA_USER_ID, 0));
            if (app != null) {
                com.virtual.hook.ScreenPowerBinderHook.setActivePackage(app.packageName);
            } else {
                com.virtual.hook.ScreenPowerBinderHook.setActivePackage(pkg);
            }
        } catch (Throwable e) {
            VirtualLog.e(TAG, "Failed to prepare target Activity", e);
        }
    }

    private ClassLoader getTargetClassLoader(String packageName) throws Exception {
        ClassLoader cached = loaders.get(packageName);
        if (cached != null) return cached;

        ApplicationInfo ai = host.getPackageManager().getApplicationInfo(packageName, 0);
        File dexDir = new File(host.getCodeCacheDir(), "devil_dex/" + packageName);
        if (!dexDir.exists() && !dexDir.mkdirs()) {
            throw new IllegalStateException("Cannot create dex directory: " + dexDir);
        }
        File apk = new File(ai.sourceDir);
        ClassLoader loader = new DexClassLoader(
                apk.getAbsolutePath(), dexDir.getAbsolutePath(), ai.nativeLibraryDir,
                host.getClassLoader());
        ClassLoader previous = loaders.putIfAbsent(packageName, loader);
        return previous != null ? previous : loader;
    }

    private static void setField(Object object, Class<?> owner, String name, Object value) {
        try {
            Field f = owner.getDeclaredField(name);
            f.setAccessible(true);
            f.set(object, value);
        } catch (Throwable e) {
            VirtualLog.w(TAG, "Could not set " + name + ": " + e);
        }
    }
}
