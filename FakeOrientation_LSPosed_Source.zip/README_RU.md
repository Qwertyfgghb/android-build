# FakeOrientation — LSPosed source project

Проект собран как Android Studio/Gradle-проект и содержит исходники модуля.

## Важно про стрелку Google Maps
Этот модуль подменяет `Location.getBearing()` и `hasBearing()`, а также пытается подменять азимут `SensorManager.getOrientation()`.
**Он не может гарантировать, что стрелка/конус местоположения Google Maps исчезнет при любой скорости.** Отрисовка маркера — внутренняя логика Google Maps; она может использовать собственные сенсоры, fused location и внутренние классы. Подмена `getSpeed()` сама по себе не является надёжным способом скрыть графический маркер.

## Сборка
- Android Studio с JDK 17
- Gradle wrapper можно создать командой `gradle wrapper --gradle-version 8.2`
- Затем выполнить `gradle assembleDebug`
- APK будет в `app/build/outputs/apk/debug/app-debug.apk`

Зависимость Xposed API 82 подключается из `https://api.xposed.info/`; LSPosed обычно совместим с этим API.

## Установка
1. Соберите APK.
2. Установите его на устройство.
3. В LSPosed включите модуль и выберите только Google Maps (`com.google.android.apps.maps`).
4. Перезапустите Google Maps.

Модуль требует разрешения на местоположение у Google Maps. Если направление не меняется, проверьте Xposed-логи и наличие GPS-обновлений.
