package com.example.fakeorientation;

import android.location.Location;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Experimental Yandex Maps hook. Derives course from Location objects that the app itself
 * reads, rather than starting a separate GPS listener (which may lack location permission).
 * Course over ground is only meaningful after the device has moved.
 */
public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "YandexGpsDirection";
    private static volatile boolean hooked = false;
    private static volatile boolean courseValid = false;
    private static volatile float course = 0f;
    private static double anchorLat = Double.NaN;
    private static double anchorLon = Double.NaN;
    private static long anchorTime = -1L;
    private static double lastLat = Double.NaN;
    private static double lastLon = Double.NaN;
    private static long lastTime = -1L;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"ru.yandex.yandexmaps".equals(lpparam.packageName)) return;
        synchronized (MainHook.class) {
            if (hooked) return;
            hooked = true;
        }
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getBearing", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    Location loc = (Location) param.thisObject;
                    updateCourse(loc);
                    if (courseValid) param.setResult(course);
                }
            });
            XposedHelpers.findAndHookMethod(Location.class, "hasBearing", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    Location loc = (Location) param.thisObject;
                    updateCourse(loc);
                    if (courseValid) param.setResult(true);
                }
            });
            XposedBridge.log(TAG + ": hooks installed for Yandex Maps");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hook install failed: " + t);
        }
    }

    private static synchronized void updateCourse(Location loc) {
        if (loc == null) return;
        final double lat;
        final double lon;
        final long time;
        try {
            lat = loc.getLatitude();
            lon = loc.getLongitude();
            time = loc.getTime();
        } catch (Throwable ignored) {
            return;
        }
        if (!Double.isFinite(lat) || !Double.isFinite(lon)) return;
        // Do not process the same Location repeatedly: Yandex may call getBearing many times.
        if (time == lastTime && Math.abs(lat - lastLat) < 1e-8 && Math.abs(lon - lastLon) < 1e-8) return;
        lastTime = time;
        lastLat = lat;
        lastLon = lon;

        if (Double.isNaN(anchorLat)) {
            anchorLat = lat;
            anchorLon = lon;
            anchorTime = time;
            return;
        }

        float distance = distanceMeters(anchorLat, anchorLon, lat, lon);
        if (distance < 0.6f) return;

        double lat1 = Math.toRadians(anchorLat);
        double lat2 = Math.toRadians(lat);
        double dLon = Math.toRadians(lon - anchorLon);
        double y = Math.sin(dLon) * Math.cos(lat2);
        double x = Math.cos(lat1) * Math.sin(lat2)
                - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
        double deg = Math.toDegrees(Math.atan2(y, x));
        if (deg < 0) deg += 360.0;

        // Prefer fresh GPS course while moving. A short interval keeps turns responsive.
        course = (float) deg;
        courseValid = true;
        anchorLat = lat;
        anchorLon = lon;
        anchorTime = time;
    }

    private static float distanceMeters(double lat1, double lon1, double lat2, double lon2) {
        float[] result = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, result);
        return result[0];
    }
}
