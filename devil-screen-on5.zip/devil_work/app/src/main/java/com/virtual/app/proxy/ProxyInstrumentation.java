package com.virtual.app.proxy;

import android.app.Activity;
import android.app.Application;
import android.app.Instrumentation;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.IBinder;
import android.app.ActivityThread;
import android.app.IVoiceInteractor;
import android.view.Window;

import com.virtual.core.VirtualCore;
import com.virtual.core.entity.VirtualApp;
import com.virtual.util.VirtualLog;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.WeakHashMap;

import dalvik.system.DexClassLoader;

/**
 * In-process proxy runtime.
 *
 * Android creates only the manifest-declared ProxyActivity.  The target
 * Activity is then created separately and attached with Activity.attach(),
 * using a Context belonging to the target package.  This avoids the old
 * implementation's invalid pattern of returning the target Activity object
 * from Instrumentation.newActivity(), which caused target attachBaseContext()
 * to run against the host Activity state.
 */
public final class ProxyInstrumentation extends Instrumentation {
    public static final String EXTRA_TARGET_PACKAGE = "devil.target.package";
    public static final String EXTRA_TARGET_ACTIVITY = "devil.target.activity";
    public static final String EXTRA_USER_ID = "devil.target.user";

    private static final String TAG = "DevilProxyInstr";
    private static volatile ProxyInstrumentation sInstance;

    private final Instrumentation base;
    private final Context host;
    private final Map<String, ClassLoader> loaders = new ConcurrentHashMap<>();
    private final Map<String, Application> applications = new ConcurrentHashMap<>();
    private final Map<ProxyActivity, Activity> targets = new WeakHashMap<>();

    public ProxyInstrumentation(Instrumentation base, Context host) {
        this.base = base;
        this.host = host.getApplicationContext();
        sInstance = this;
    }

    public static boolean install(Context context) {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Method current = at.getDeclaredMethod("currentActivityThread");
            current.setAccessible(true);
            Object thread = current.invoke(null);
            if (thread == null) return false;

            Field f = at.getDeclaredField("mInstrumentation");
            f.setAccessible(true);
            Object existing = f.get(thread);
            if (existing instanceof ProxyInstrumentation) {
                sInstance = (ProxyInstrumentation) existing;
                return true;
            }

            ProxyInstrumentation proxy = new ProxyInstrumentation((Instrumentation) existing, context);
            f.set(thread, proxy);
            VirtualLog.i(TAG, "Proxy Instrumentation installed");
            return true;
        } catch (Throwable e) {
            VirtualLog.e(TAG, "Failed to install Proxy Instrumentation", e);
            return false;
        }
    }

    /** Called by ProxyActivity after Android has attached the proxy itself. */
    public static void dispatchCreate(ProxyActivity proxy, Bundle state) {
        ProxyInstrumentation instance = sInstance;
        if (instance == null) {
            VirtualLog.e(TAG, "Proxy instrumentation is not installed");
            return;
        }
        instance.createTarget(proxy, state);
    }

    public static void dispatchStart(ProxyActivity proxy) {
        ProxyInstrumentation instance = sInstance;
        if (instance != null) instance.invokeLifecycle(proxy, "onStart");
    }

    public static void dispatchResume(ProxyActivity proxy) {
        ProxyInstrumentation instance = sInstance;
        if (instance != null) instance.invokeLifecycle(proxy, "onResume");
    }

    public static void dispatchPause(ProxyActivity proxy) {
        ProxyInstrumentation instance = sInstance;
        if (instance != null) instance.invokeLifecycle(proxy, "onPause");
    }

    public static void dispatchStop(ProxyActivity proxy) {
        ProxyInstrumentation instance = sInstance;
        if (instance != null) instance.invokeLifecycle(proxy, "onStop");
    }

    public static void dispatchDestroy(ProxyActivity proxy) {
        ProxyInstrumentation instance = sInstance;
        if (instance != null) instance.destroyTarget(proxy);
    }

    public static void dispatchSaveInstanceState(ProxyActivity proxy, Bundle state) {
        ProxyInstrumentation instance = sInstance;
        if (instance != null) instance.invokeSaveInstanceState(proxy, state);
    }

    public static void dispatchNewIntent(ProxyActivity proxy, Intent intent) {
        ProxyInstrumentation instance = sInstance;
        if (instance != null) instance.invokeTarget(proxy, "onNewIntent", new Class<?>[]{Intent.class}, new Object[]{intent});
    }

    public static boolean dispatchBackPressed(ProxyActivity proxy) {
        ProxyInstrumentation instance = sInstance;
        if (instance == null) return false;
        Activity target = instance.getTarget(proxy);
        if (target == null) return false;
        try {
            Method m = findMethod(target.getClass(), "onBackPressed", new Class<?>[0]);
            if (m == null) return false;
            m.setAccessible(true);
            m.invoke(target);
            return true;
        } catch (Throwable e) {
            VirtualLog.w(TAG, "Target onBackPressed failed: " + e);
            return false;
        }
    }

    private synchronized Activity getTarget(ProxyActivity proxy) {
        return targets.get(proxy);
    }

    private void createTarget(ProxyActivity proxy, Bundle state) {
        Intent proxyIntent = proxy.getIntent();
        if (proxyIntent == null) return;

        String pkg = proxyIntent.getStringExtra(EXTRA_TARGET_PACKAGE);
        String activityName = proxyIntent.getStringExtra(EXTRA_TARGET_ACTIVITY);
        if (pkg == null || activityName == null) {
            VirtualLog.e(TAG, "Missing target package/activity");
            return;
        }

        try {
            VirtualCore core = VirtualCore.get();
            VirtualApp virtualApp = core.getVirtualAppByUserId(
                    proxyIntent.getIntExtra(EXTRA_USER_ID, 0));
            if (virtualApp != null) {
                com.virtual.hook.ScreenPowerBinderHook.setActivePackage(virtualApp.packageName);
            } else {
                com.virtual.hook.ScreenPowerBinderHook.setActivePackage(pkg);
            }

            ClassLoader loader = getTargetClassLoader(pkg);
            Class<?> cls = Class.forName(activityName, true, loader);
            Object object = cls.getDeclaredConstructor().newInstance();
            if (!(object instanceof Activity)) {
                throw new IllegalStateException("Target is not Activity: " + activityName);
            }
            Activity target = (Activity) object;

            Application application = getOrCreateApplication(pkg, loader);
            Context targetBase = host.createPackageContext(
                    pkg, Context.CONTEXT_INCLUDE_CODE | Context.CONTEXT_IGNORE_SECURITY);
            Context targetContext = new TargetContext(targetBase, loader, application);

            ActivityInfo info = getActivityInfo(pkg, activityName);
            attachTarget(proxy, target, application, targetContext, info, proxyIntent, loader);

            synchronized (this) {
                targets.put(proxy, target);
            }

            invokeCreate(target, state);
            VirtualLog.i(TAG, "Target Activity attached and created: " + activityName + " for " + pkg);
        } catch (Throwable e) {
            VirtualLog.e(TAG, "Failed to attach/create target Activity: " + activityName, e);
            throw new RuntimeException("Virtual target launch failed: " + activityName, e);
        }
    }

    private Application getOrCreateApplication(String pkg, ClassLoader loader) throws Exception {
        Application existing = applications.get(pkg);
        if (existing != null) return existing;

        ApplicationInfo ai = host.getPackageManager().getApplicationInfo(pkg, PackageManager.GET_META_DATA);
        String className = ai.className;
        if (className == null || className.length() == 0) className = "android.app.Application";

        Context baseContext = host.createPackageContext(
                pkg, Context.CONTEXT_INCLUDE_CODE | Context.CONTEXT_IGNORE_SECURITY);
        Context targetContext = new TargetContext(baseContext, loader, null);
        Application created = newApplication(loader, className, targetContext);
        created.onCreate();

        Application previous = applications.putIfAbsent(pkg, created);
        return previous != null ? previous : created;
    }

    private ActivityInfo getActivityInfo(String pkg, String activityName) throws Exception {
        PackageManager pm = host.getPackageManager();
        ActivityInfo[] infos = pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES).activities;
        if (infos != null) {
            for (ActivityInfo info : infos) {
                if (activityName.equals(info.name)) return info;
            }
        }
        ActivityInfo fallback = new ActivityInfo();
        fallback.packageName = pkg;
        fallback.name = activityName;
        fallback.applicationInfo = pm.getApplicationInfo(pkg, PackageManager.GET_META_DATA);
        return fallback;
    }

    /**
     * Invoke the hidden Activity.attach() method reflectively.  The proxy's
     * token/ActivityThread identity are reused, while the target gets its own
     * ActivityInfo, Application and target Context.
     */
    private void attachTarget(ProxyActivity proxy, Activity target, Application application,
                              Context targetContext, ActivityInfo info, Intent proxyIntent,
                              ClassLoader loader) throws Exception {
        Object activityThread = getFieldRecursive(proxy, "mMainThread");
        IBinder token = (IBinder) getFieldRecursive(proxy, "mToken");
        int ident = getIntFieldRecursive(proxy, "mIdent", 0);
        CharSequence title = (CharSequence) getFieldRecursive(proxy, "mTitle");
        Activity parent = (Activity) getFieldRecursive(proxy, "mParent");
        String embeddedId = (String) getFieldRecursive(proxy, "mEmbeddedID");
        Object lastNonConfig = getFieldRecursive(proxy, "mLastNonConfigurationInstances");
        Configuration config = (Configuration) getFieldRecursive(proxy, "mCurrentConfig");
        String referrer = (String) getFieldRecursive(proxy, "mReferrer");
        IVoiceInteractor voiceInteractor = (IVoiceInteractor) getFieldRecursive(proxy, "mVoiceInteractor");
        Object callback = getFieldRecursive(proxy, "mActivityConfigCallback");

        Method attach = findAttachMethod();
        Object[] args = new Object[]{
                targetContext,
                activityThread,
                this,
                token,
                ident,
                application,
                buildTargetIntent(proxyIntent, pkgOf(info), target.getClass().getName()),
                info,
                title,
                parent,
                embeddedId,
                lastNonConfig,
                config,
                referrer,
                voiceInteractor,
                null,
                callback
        };
        attach.setAccessible(true);
        attach.invoke(target, args);
    }

    private static String pkgOf(ActivityInfo info) {
        if (info != null && info.packageName != null) return info.packageName;
        return "";
    }

    private static Intent buildTargetIntent(Intent original, String pkg, String activityName) {
        Intent target = new Intent(original);
        target.setClassName(pkg, activityName);
        target.removeExtra(EXTRA_TARGET_PACKAGE);
        target.removeExtra(EXTRA_TARGET_ACTIVITY);
        target.removeExtra(EXTRA_USER_ID);
        return target;
    }

    private static Method findAttachMethod() throws Exception {
        for (Method method : Activity.class.getDeclaredMethods()) {
            if (!"attach".equals(method.getName())) continue;
            if (method.getParameterTypes().length == 17) return method;
        }
        throw new NoSuchMethodException("Activity.attach(17 args) not found");
    }

    private void invokeCreate(Activity target, Bundle state) throws Exception {
        Method method = findMethod(target.getClass(), "onCreate", new Class<?>[]{Bundle.class});
        if (method == null) throw new NoSuchMethodException("onCreate not found");
        method.setAccessible(true);
        method.invoke(target, state);
    }

    private void invokeLifecycle(ProxyActivity proxy, String name) {
        Activity target = getTarget(proxy);
        if (target == null) return;
        try {
            Method method = findMethod(target.getClass(), name, new Class<?>[0]);
            if (method != null) {
                method.setAccessible(true);
                method.invoke(target);
            }
        } catch (Throwable e) {
            VirtualLog.e(TAG, "Target " + name + " failed", e);
        }
    }

    private void invokeSaveInstanceState(ProxyActivity proxy, Bundle state) {
        Activity target = getTarget(proxy);
        if (target == null) return;
        try {
            Method method = findMethod(target.getClass(), "onSaveInstanceState", new Class<?>[]{Bundle.class});
            if (method != null) {
                method.setAccessible(true);
                method.invoke(target, state);
            }
        } catch (Throwable e) {
            VirtualLog.e(TAG, "Target onSaveInstanceState failed", e);
        }
    }

    private void invokeTarget(ProxyActivity proxy, String name, Class<?>[] types, Object[] args) {
        Activity target = getTarget(proxy);
        if (target == null) return;
        try {
            Method method = findMethod(target.getClass(), name, types);
            if (method != null) {
                method.setAccessible(true);
                method.invoke(target, args);
            }
        } catch (Throwable e) {
            VirtualLog.e(TAG, "Target " + name + " failed", e);
        }
    }

    private synchronized void destroyTarget(ProxyActivity proxy) {
        Activity target = targets.remove(proxy);
        if (target == null) return;
        try {
            Method method = findMethod(target.getClass(), "onDestroy", new Class<?>[0]);
            if (method != null) {
                method.setAccessible(true);
                method.invoke(target);
            }
        } catch (Throwable e) {
            VirtualLog.e(TAG, "Target onDestroy failed", e);
        }
    }

    private static Method findMethod(Class<?> cls, String name, Class<?>[] params) {
        Class<?> current = cls;
        while (current != null) {
            try {
                return current.getDeclaredMethod(name, params);
            } catch (NoSuchMethodException ignored) {
                current = current.getSuperclass();
            }
        }
        return null;
    }

    private ClassLoader getTargetClassLoader(String packageName) throws Exception {
        ClassLoader cached = loaders.get(packageName);
        if (cached != null) return cached;

        ApplicationInfo ai = host.getPackageManager().getApplicationInfo(packageName, 0);
        File dexDir = new File(host.getCodeCacheDir(), "devil_dex/" + packageName);
        if (!dexDir.exists() && !dexDir.mkdirs()) {
            throw new IllegalStateException("Cannot create dex directory: " + dexDir);
        }
        File apk = new File(ai.sourceDir);
        ClassLoader parent = host.getClassLoader();
        ClassLoader loader = new ChildFirstDexClassLoader(
                apk.getAbsolutePath(), dexDir.getAbsolutePath(), ai.nativeLibraryDir, parent);
        ClassLoader previous = loaders.putIfAbsent(packageName, loader);
        return previous != null ? previous : loader;
    }

    private static Object getFieldRecursive(Object object, String name) {
        if (object == null) return null;
        Class<?> cls = object.getClass();
        while (cls != null) {
            try {
                Field field = cls.getDeclaredField(name);
                field.setAccessible(true);
                return field.get(object);
            } catch (Throwable ignored) {
                cls = cls.getSuperclass();
            }
        }
        return null;
    }

    private static int getIntFieldRecursive(Object object, String name, int fallback) {
        Object value = getFieldRecursive(object, name);
        return value instanceof Integer ? (Integer) value : fallback;
    }

    /** Context wrapper that keeps target resources/package identity while using the target loader. */
    private static final class TargetContext extends ContextWrapper {
        private final ClassLoader targetLoader;
        private final Application targetApplication;

        TargetContext(Context base, ClassLoader targetLoader, Application targetApplication) {
            super(base);
            this.targetLoader = targetLoader;
            this.targetApplication = targetApplication;
        }

        @Override
        public ClassLoader getClassLoader() {
            return targetLoader;
        }

        @Override
        public Context getApplicationContext() {
            return targetApplication != null ? targetApplication : super.getApplicationContext();
        }
    }

    /** Target APK classes first; Android framework classes remain shared. */
    private static final class ChildFirstDexClassLoader extends DexClassLoader {
        private static final String[] PARENT_FIRST = {
                "java.", "javax.", "android.", "dalvik.", "libcore.", "kotlin.jvm."
        };

        ChildFirstDexClassLoader(String dexPath, String optimizedDirectory,
                                 String librarySearchPath, ClassLoader parent) {
            super(dexPath, optimizedDirectory, librarySearchPath, parent);
        }

        @Override
        protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
            for (String prefix : PARENT_FIRST) {
                if (name.startsWith(prefix)) return super.loadClass(name, resolve);
            }
            try {
                Class<?> c = findClass(name);
                if (resolve) resolveClass(c);
                return c;
            } catch (ClassNotFoundException ignored) {
                return super.loadClass(name, resolve);
            }
        }
    }
}
