package com.example.screenoffbike;

import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "ScreenOffBike";

    private static final int SCREEN_ON = 1;
    private static final int SCREEN_OFF = 0;

    private static final long KEEP_SCREEN_ON_MS = 60000L; // 1 минута
    private static final long THROTTLE_MS = 3000L;

    private static volatile long lastTriggerTime = 0L;
    private static volatile Handler handler = null;
    
    private static Process rootProcess = null;
    private static BufferedWriter rootWriter = null;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps") && !lpparam.packageName.contains("yandexnavi")) return;
        if (lpparam.processName != null && lpparam.processName.contains(":")) return;

        XposedBridge.log(TAG + ": hooked in " + lpparam.processName);
        
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        
        hookOldAudioFocus(lpparam);
        hookNewAudioFocus(lpparam);
        hookMediaPlayer(lpparam);
    }

    // 1. Старый API (Android 7 и ниже, на всякий случай)
    private static void hookOldAudioFocus(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> amClass = XposedHelpers.findClass("android.media.AudioManager", lpparam.classLoader);
            XposedHelpers.findAndHookMethod(amClass, "requestAudioFocus",
                    AudioManager.OnAudioFocusChangeListener.class, int.class, int.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam param) {
                            int durationHint = (int) param.args[2];
                            if (durationHint == 2 || durationHint == 3) {
                                onSoundTriggered("OldAudioFocus");
                            }
                        }
                    });
            XposedBridge.log(TAG + ": Old AudioFocus hooked");
        } catch (Throwable ignored) {}
    }

    // 2. Новый API (Android 8+, AudioFocusRequest)
    private static void hookNewAudioFocus(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> amClass = XposedHelpers.findClass("android.media.AudioManager", lpparam.classLoader);
            XposedHelpers.findAndHookMethod(amClass, "requestAudioFocus",
                    AudioFocusRequest.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam param) {
                            // Вызываем событие при любом запросе аудиофокуса
                            onSoundTriggered("NewAudioFocus");
                        }
                    });
            XposedBridge.log(TAG + ": New AudioFocus hooked");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": New AudioFocus hook fail: " + t);
        }
    }

    // 3. MediaPlayer (прямой перехват воспроизведения звука)
    private static void hookMediaPlayer(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> mpClass = XposedHelpers.findClass("android.media.MediaPlayer", lpparam.classLoader);
            XposedHelpers.findAndHookMethod(mpClass, "start", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    // Проверяем, что вызов идет из пакетов Яндекса
                    String callerClass = param.method.getDeclaringClass().getName();
                    // Фильтр, чтобы не реагировать на фоновую музыку
                    if (callerClass.contains("yandex") || callerClass.contains("runtime")) {
                        onSoundTriggered("MediaPlayer");
                    }
                }
            });
            XposedBridge.log(TAG + ": MediaPlayer hooked");
        } catch (Throwable ignored) {}
    }

    // ==================================================================
    // Логика
    // ==================================================================
    private static void onSoundTriggered(String source) {
        long now = System.currentTimeMillis();
        if (now - lastTriggerTime < THROTTLE_MS) return; 
        lastTriggerTime = now;

        XposedBridge.log(TAG + ": Звук (" + source + ") -> экран ВКЛ. Таймер сброшен (1 мин)");
        sendAmCommand(SCREEN_ON);

        if (handler != null) {
            handler.removeCallbacks(screenOffRunnable);
            handler.postDelayed(screenOffRunnable, KEEP_SCREEN_ON_MS);
        }
    }

    private static final Runnable screenOffRunnable = new Runnable() {
        @Override
        public void run() {
            XposedBridge.log(TAG + ": Прошла 1 минута тишины -> экран ВЫКЛ");
            sendAmCommand(SCREEN_OFF);
        }
    };

    private static void sendAmCommand(int screenValue) {
        String cmd = "am startservice -n own.moderpach.extinguish/.service.ExtinguishService --ei screen " + screenValue;
        try {
            if (rootProcess == null || !rootProcess.isAlive()) {
                rootProcess = Runtime.getRuntime().exec("su");
                rootWriter = new BufferedWriter(new OutputStreamWriter(rootProcess.getOutputStream()));
            }
            rootWriter.write(cmd + "\n");
            rootWriter.flush();
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": am fail: " + t);
            rootProcess = null;
            rootWriter = null;
        }
    }
}