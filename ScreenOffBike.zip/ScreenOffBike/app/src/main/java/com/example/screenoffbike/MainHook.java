package com.example.screenoffbike;

import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "ScreenOffBike";

    // Extinguish: 0 = ВКЛ, 1 = ВЫКЛ
    private static final int SCREEN_ON = 0;
    private static final int SCREEN_OFF = 1;

    // Сколько экран горит после звука
    private static final long KEEP_SCREEN_ON_MS = 60000L;
    // Пауза между диммингом и выключением
    private static final long DIM_TO_OFF_DELAY_MS = 1000L;
    // Защита от спама звуками
    private static final long THROTTLE_MS = 3000L;

    private static volatile long lastTriggerTime = 0L;
    private static volatile Handler handler = null;

    // Сохранённая яркость (до димминга)
    private static volatile int savedBrightness = -1;
    private static volatile int savedBrightnessMode = -1;

    // Постоянная Root-сессия для Extinguish-команд
    private static Process rootProcess = null;
    private static BufferedWriter rootWriter = null;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps") && !lpparam.packageName.contains("yandexnavi")) return;
        if (lpparam.processName != null && lpparam.processName.contains(":")) return;

        XposedBridge.log(TAG + ": hooked in " + lpparam.processName);

        if (handler == null) handler = new Handler(Looper.getMainLooper());

        hookOldAudioFocus(lpparam);
        hookNewAudioFocus(lpparam);
        hookMediaPlayer(lpparam);
    }

    // ==================================================================
    // Хуки на звук
    // ==================================================================

    private static void hookOldAudioFocus(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> amClass = XposedHelpers.findClass("android.media.AudioManager", lpparam.classLoader);
            XposedHelpers.findAndHookMethod(amClass, "requestAudioFocus",
                    AudioManager.OnAudioFocusChangeListener.class, int.class, int.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam param) {
                            int durationHint = (int) param.args[2];
                            if (durationHint == 2 || durationHint == 3) {
                                onSoundTriggered("OldAudioFocus");
                            }
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookNewAudioFocus(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> amClass = XposedHelpers.findClass("android.media.AudioManager", lpparam.classLoader);
            XposedHelpers.findAndHookMethod(amClass, "requestAudioFocus",
                    AudioFocusRequest.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam param) {
                            onSoundTriggered("NewAudioFocus");
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookMediaPlayer(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> mpClass = XposedHelpers.findClass("android.media.MediaPlayer", lpparam.classLoader);
            XposedHelpers.findAndHookMethod(mpClass, "start", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    String callerClass = param.method.getDeclaringClass().getName();
                    if (callerClass.contains("yandex") || callerClass.contains("runtime")) {
                        onSoundTriggered("MediaPlayer");
                    }
                }
            });
        } catch (Throwable ignored) {}
    }

    // ==================================================================
    // Логика включения
    // ==================================================================

    private static void onSoundTriggered(String source) {
        long now = System.currentTimeMillis();
        if (now - lastTriggerTime < THROTTLE_MS) return;
        lastTriggerTime = now;

        XposedBridge.log(TAG + ": Звук (" + source + ") -> экран ВКЛ. Яркость восстановлена");

        // Отменяем запланированный димминг и выключение
        if (handler != null) {
            handler.removeCallbacks(dimRunnable);
            handler.removeCallbacks(turnOffRunnable);
        }

        // Восстанавливаем яркость ДО включения экрана
        restoreBrightness();

        // Включаем экран
        sendAmCommand(SCREEN_ON);

        // Планируем затухание через 60 секунд тишины
        if (handler != null) {
            handler.postDelayed(dimRunnable, KEEP_SCREEN_ON_MS);
        }
    }

    // ==================================================================
    // Логика выключения (димминг → пауза → выкл)
    // ==================================================================

    private static final Runnable dimRunnable = new Runnable() {
        @Override
        public void run() {
            XposedBridge.log(TAG + ": Тишина 1 мин -> яркость в 2 раза ниже");
            saveAndDimBrightness();

            if (handler != null) {
                handler.postDelayed(turnOffRunnable, DIM_TO_OFF_DELAY_MS);
            }
        }
    };

    private static final Runnable turnOffRunnable = new Runnable() {
        @Override
        public void run() {
            XposedBridge.log(TAG + ": Прошла 1 сек после димминга -> экран ВЫКЛ");
            sendAmCommand(SCREEN_OFF);
        }
    };

    // ==================================================================
    // Управление яркостью через su
    // ==================================================================

    private static void saveAndDimBrightness() {
        try {
            // Сохраняем текущие значения, только если ещё не сохраняли в этом цикле
            if (savedBrightness < 0) {
                savedBrightness = readSettingInt("screen_brightness", 128);
                savedBrightnessMode = readSettingInt("screen_brightness_mode", 0);
            }

            // Отключаем авто-яркость, чтобы управлять вручную
            if (savedBrightnessMode == 1) {
                writeShell("settings put system screen_brightness_mode 0");
            }

            // Ставим 50 % от сохранённой яркости (но не ниже 1)
            int half = Math.max(1, savedBrightness / 2);
            writeShell("settings put system screen_brightness " + half);

            XposedBridge.log(TAG + ": Яркость " + savedBrightness + " -> " + half);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": dim fail: " + t);
        }
    }

    private static void restoreBrightness() {
        if (savedBrightness < 0) return;
        try {
            writeShell("settings put system screen_brightness " + savedBrightness);
            if (savedBrightnessMode >= 0) {
                writeShell("settings put system screen_brightness_mode " + savedBrightnessMode);
            }
            XposedBridge.log(TAG + ": Яркость восстановлена -> " + savedBrightness);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": restore fail: " + t);
        } finally {
            savedBrightness = -1;
            savedBrightnessMode = -1;
        }
    }

    private static int readSettingInt(String key, int fallback) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{
                    "su", "-c", "settings get system " + key});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = r.readLine();
            p.waitFor();
            if (line == null) return fallback;
            return Integer.parseInt(line.trim());
        } catch (Throwable t) {
            return fallback;
        }
    }

    private static void writeShell(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
            p.waitFor();
        } catch (Throwable ignored) {}
    }

    // ==================================================================
    // Команда для Extinguish
    // ==================================================================

    private static void sendAmCommand(int screenValue) {
        String cmd = "am startservice -n own.moderpach.extinguish/.service.ExtinguishService "
                + "--ei screen " + screenValue;
        try {
            if (rootProcess == null || !rootProcess.isAlive()) {
                rootProcess = Runtime.getRuntime().exec("su");
                rootWriter = new BufferedWriter(new OutputStreamWriter(rootProcess.getOutputStream()));
            }
            rootWriter.write(cmd + "\n");
            rootWriter.flush();
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": am fail: " + t);
            rootProcess = null;
            rootWriter = null;
        }
    }
}