package com.example.screenoffbike;

import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "ScreenOffBike";

    // Extinguish: 0 = ВКЛ, 1 = ВЫКЛ
    private static final int SCREEN_ON = 0;
    private static final int SCREEN_OFF = 1;

    // Тайминги
    private static final long KEEP_SCREEN_ON_MS = 60000L; // 1 минута
    private static final long DIM_TO_OFF_DELAY_MS = 1000L; // 1 секунда (задержка между нулевой яркостью и выключением)
    private static final long THROTTLE_MS = 3000L; // Защита от спама звуками

    private static volatile long lastTriggerTime = 0L;
    private static volatile Handler handler = null;

    // Постоянная Root-сессия для команд
    private static Process rootProcess = null;
    private static BufferedWriter rootWriter = null;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps") && !lpparam.packageName.contains("yandexnavi")) return;
        if (lpparam.processName != null && lpparam.processName.contains(":")) return;

        XposedBridge.log(TAG + ": hooked in " + lpparam.processName);

        if (handler == null) handler = new Handler(Looper.getMainLooper());

        hookOldAudioFocus(lpparam);
        hookNewAudioFocus(lpparam);
        hookMediaPlayer(lpparam);
    }

    // ==================================================================
    // Хуки на звук
    // ==================================================================

    private static void hookOldAudioFocus(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> amClass = XposedHelpers.findClass("android.media.AudioManager", lpparam.classLoader);
            XposedHelpers.findAndHookMethod(amClass, "requestAudioFocus",
                    AudioManager.OnAudioFocusChangeListener.class, int.class, int.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam param) {
                            int durationHint = (int) param.args[2];
                            if (durationHint == 2 || durationHint == 3) {
                                onSoundTriggered("OldAudioFocus");
                            }
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookNewAudioFocus(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> amClass = XposedHelpers.findClass("android.media.AudioManager", lpparam.classLoader);
            XposedHelpers.findAndHookMethod(amClass, "requestAudioFocus",
                    AudioFocusRequest.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam param) {
                            onSoundTriggered("NewAudioFocus");
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookMediaPlayer(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> mpClass = XposedHelpers.findClass("android.media.MediaPlayer", lpparam.classLoader);
            XposedHelpers.findAndHookMethod(mpClass, "start", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    String callerClass = param.method.getDeclaringClass().getName();
                    if (callerClass.contains("yandex") || callerClass.contains("runtime")) {
                        onSoundTriggered("MediaPlayer");
                    }
                }
            });
        } catch (Throwable ignored) {}
    }

    // ==================================================================
    // Логика включения
    // ==================================================================

    private static void onSoundTriggered(String source) {
        long now = System.currentTimeMillis();
        if (now - lastTriggerTime < THROTTLE_MS) return;
        lastTriggerTime = now;

        XposedBridge.log(TAG + ": Звук (" + source + ") -> экран ВКЛ. Яркость МАКСИМУМ");

        // Отменяем запланированное затухание и выключение
        if (handler != null) {
            handler.removeCallbacks(dimRunnable);
            handler.removeCallbacks(turnOffRunnable);
        }

        // 1. Ставим максимальную яркость и отключаем авто-режим
        sendShellCommand("settings put system screen_brightness_mode 0");
        sendShellCommand("settings put system screen_brightness 255");

        // 2. Включаем экран через Extinguish
        sendAmCommand(SCREEN_ON);

        // 3. Планируем затухание через 60 секунд тишины
        if (handler != null) {
            handler.postDelayed(dimRunnable, KEEP_SCREEN_ON_MS);
        }
    }

    // ==================================================================
    // Логика выключения (яркость в 0 → пауза → выкл)
    // ==================================================================

    private static final Runnable dimRunnable = new Runnable() {
        @Override
        public void run() {
            XposedBridge.log(TAG + ": Тишина 1 мин -> яркость в НОЛЬ");
            sendShellCommand("settings put system screen_brightness 0");

            if (handler != null) {
                handler.postDelayed(turnOffRunnable, DIM_TO_OFF_DELAY_MS);
            }
        }
    };

    private static final Runnable turnOffRunnable = new Runnable() {
        @Override
        public void run() {
            XposedBridge.log(TAG + ": Прошла 1 сек после нулевой яркости -> экран ВЫКЛ");
            sendAmCommand(SCREEN_OFF);
        }
    };

    // ==================================================================
    // Выполнение команд через Root
    // ==================================================================

    // Команда для Extinguish
    private static void sendAmCommand(int screenValue) {
        String cmd = "am startservice -n own.moderpach.extinguish/.service.ExtinguishService "
                + "--ei screen " + screenValue;
        sendShellCommand(cmd);
    }

    // Отправка любой команды в открытую Root-сессию (чтобы не спамить запросами su)
    private static synchronized void sendShellCommand(String cmd) {
        try {
            if (rootProcess == null || !rootProcess.isAlive()) {
                rootProcess = Runtime.getRuntime().exec("su");
                rootWriter = new BufferedWriter(new OutputStreamWriter(rootProcess.getOutputStream()));
            }
            rootWriter.write(cmd + "\n");
            rootWriter.flush();
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": shell fail: " + t);
            rootProcess = null;
            rootWriter = null;
        }
    }
}