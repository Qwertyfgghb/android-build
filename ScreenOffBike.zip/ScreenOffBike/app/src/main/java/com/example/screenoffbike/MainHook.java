package com.example.screenoffbike;

import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "ScreenOffBike";

    private static final int SCREEN_ON = 1;
    private static final int SCREEN_OFF = 0;

    private static final long KEEP_SCREEN_ON_MS = 60000L; // 1 минута
    private static final long THROTTLE_MS = 3000L; // защита от спама (не чаще раза в 3 сек)

    private static volatile long lastTriggerTime = 0L;
    private static volatile Handler handler = null;
    
    private static Process rootProcess = null;
    private static BufferedWriter rootWriter = null;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps") && !lpparam.packageName.contains("yandexnavi")) return;
        if (lpparam.processName != null && lpparam.processName.contains(":")) return;

        XposedBridge.log(TAG + ": hooked in " + lpparam.processName);
        
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        
        hookAudioFocus(lpparam); // Ловим звук через Аудиофокус
    }

    // ==================================================================
    // Перехват Аудиофокуса (срабатывает перед любой озвучкой)
    // ==================================================================
    private static void hookAudioFocus(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> audioManagerClass = XposedHelpers.findClass("android.media.AudioManager", lpparam.classLoader);

            XposedHelpers.findAndHookMethod(
                    audioManagerClass,
                    "requestAudioFocus",
                    AudioManager.OnAudioFocusChangeListener.class,
                    int.class,
                    int.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            int streamType = (int) param.args[1];
                            int durationHint = (int) param.args[2];

                            // AUDIOFOCUS_GAIN_TRANSIENT = 2 (временный фокус, обычно для навигации)
                            // AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK = 3 (приглушить музыку)
                            if (durationHint == 2 || durationHint == 3) {
                                onSoundTriggered();
                            }
                        }
                    }
            );

            XposedBridge.log(TAG + ": AudioFocus перехват установлен");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": AudioFocus hook fail: " + t);
        }
    }

    // ==================================================================
    // Логика экрана
    // ==================================================================
    private static void onSoundTriggered() {
        long now = System.currentTimeMillis();
        if (now - lastTriggerTime < THROTTLE_MS) return; 
        lastTriggerTime = now;

        XposedBridge.log(TAG + ": Звук -> экран ВКЛ. Таймер сброшен (1 мин)");
        sendAmCommand(SCREEN_ON);

        if (handler != null) {
            handler.removeCallbacks(screenOffRunnable);
            handler.postDelayed(screenOffRunnable, KEEP_SCREEN_ON_MS);
        }
    }

    private static final Runnable screenOffRunnable = new Runnable() {
        @Override
        public void run() {
            XposedBridge.log(TAG + ": Прошла 1 минута тишины -> экран ВЫКЛ");
            sendAmCommand(SCREEN_OFF);
        }
    };

    private static void sendAmCommand(int screenValue) {
        String cmd = "am startservice -n own.moderpach.extinguish/.service.ExtinguishService --ei screen " + screenValue;
        try {
            if (rootProcess == null || !rootProcess.isAlive()) {
                rootProcess = Runtime.getRuntime().exec("su");
                rootWriter = new BufferedWriter(new OutputStreamWriter(rootProcess.getOutputStream()));
            }
            rootWriter.write(cmd + "\n");
            rootWriter.flush();
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": am fail: " + t);
            rootProcess = null;
            rootWriter = null;
        }
    }
}