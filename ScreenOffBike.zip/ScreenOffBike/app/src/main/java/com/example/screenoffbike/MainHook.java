package com.example.screenoffbike;

import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;

import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.util.HashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "ScreenOffBike";

    // 1 = Экран ВКЛ, 0 = Экран ВЫКЛ (если у тебя наоборот - поменяй местами)
    private static final int SCREEN_ON = 1;
    private static final int SCREEN_OFF = 0;

    // Время, сколько экран горит после голосовой подсказки (1 минута = 60000 мс)
    private static final long KEEP_SCREEN_ON_MS = 60000L;
    
    // Защита, чтобы навигатор не спамил командами включения
    private static final long TTS_THROTTLE_MS = 2000L;

    private static volatile long lastTtsTime = 0L;
    private static volatile Handler handler = null;
    
    // Постоянная Root-сессия
    private static Process rootProcess = null;
    private static BufferedWriter rootWriter = null;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps")
                && !lpparam.packageName.contains("yandexnavi")) return;

        // Работаем только в основном процессе
        if (lpparam.processName != null && lpparam.processName.contains(":")) {
            return;
        }

        XposedBridge.log(TAG + ": hooked in " + lpparam.processName);
        
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        hookTts(lpparam);
    }

    // ==================================================================
    // Перехват голоса (TTS)
    // ==================================================================

    private static void hookTts(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> ttsClass = XposedHelpers.findClass(
                    "android.speech.tts.TextToSpeech", lpparam.classLoader);

            // Современный метод speak (API 21+)
            XposedHelpers.findAndHookMethod(ttsClass, "speak",
                    CharSequence.class, int.class, android.os.Bundle.class, String.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam param) {
                            onTtsSpeak();
                        }
                    });

            // Устаревший метод speak (для совместимости)
            XposedHelpers.findAndHookMethod(ttsClass, "speak",
                    String.class, int.class, HashMap.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam param) {
                            onTtsSpeak();
                        }
                    });

            XposedBridge.log(TAG + ": TTS перехват установлен");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": TTS hook fail: " + t);
        }
    }

    private static void onTtsSpeak() {
        long now = System.currentTimeMillis();
        
        // Защита от спама (если навигатор шлет куски одной фразы)
        if (now - lastTtsTime < TTS_THROTTLE_MS) return; 
        lastTtsTime = now;

        XposedBridge.log(TAG + ": Голос -> экран ВКЛ. Таймер сброшен (1 мин)");

        // 1. Включаем экран
        sendAmCommand(SCREEN_ON);

        // 2. Отменяем предыдущий таймер выключения (если был)
        if (handler != null) {
            handler.removeCallbacks(screenOffRunnable);
            // 3. Запускаем новый таймер на 60 секунд
            handler.postDelayed(screenOffRunnable, KEEP_SCREEN_ON_MS);
        }
    }

    // ==================================================================
    // Таймер выключения экрана
    // ==================================================================

    private static final Runnable screenOffRunnable = new Runnable() {
        @Override
        public void run() {
            XposedBridge.log(TAG + ": Прошла 1 минута тишины -> экран ВЫКЛ");
            sendAmCommand(SCREEN_OFF);
        }
    };

    // ==================================================================
    // am-вызов через постоянную Root-сессию
    // ==================================================================

    private static void sendAmCommand(int screenValue) {
        String cmd = "am startservice -n own.moderpach.extinguish/.service.ExtinguishService "
                + "--ei screen " + screenValue;
        try {
            if (rootProcess == null || !rootProcess.isAlive()) {
                rootProcess = Runtime.getRuntime().exec("su");
                rootWriter = new BufferedWriter(new OutputStreamWriter(rootProcess.getOutputStream()));
            }
            rootWriter.write(cmd + "\n");
            rootWriter.flush();
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": am fail: " + t);
            rootProcess = null;
            rootWriter = null;
        }
    }
}
