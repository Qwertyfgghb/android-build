# ImageBlocker API 102

Проект для сборки Android APK через GitHub Actions на современном libxposed API 102.

## Сборка
1. Загрузите содержимое ZIP в корень GitHub-репозитория.
2. Откройте Actions → Build ImageBlocker API 102 → Run workflow.
3. После успешной сборки скачайте artifact `ImageBlocker-API102-debug`.

## Исправления
Используются `hook(method).intercept(...)` и `log(priority, tag, message)`, доступные в современном API, вместо несуществующих `getXposedInterface()` и `log(String)`.

## Ограничения
Это начальный прототип: он перехватывает распространённые вызовы `ImageView.setImageBitmap`, `setImageDrawable` и `setImageURI`. Он блокирует выполнение этих setter-методов, но не гарантирует отмену сетевой загрузки/кэша и не покрывает Compose, WebView, SurfaceView или собственные рендереры. Glide/Picasso могут использовать другие пути вывода изображения. Scope LSPosed ограничивайте приложениями, которые вы имеете право тестировать.
