package com.example.imageblocker;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.ImageView;

import java.lang.reflect.Method;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedInterface;
import io.github.libxposed.api.XposedInterface.Hooker;

/**
 * Modern libxposed API module targeting API 102.
 *
 * This prototype blocks common ImageView image assignments. It does not
 * guarantee that the underlying network/cache request is cancelled.
 */
public final class ImageBlockerModule extends XposedModule {
    private static final Set<String> HOOKED = ConcurrentHashMap.newKeySet();

    public ImageBlockerModule() {
        super();
    }

    @Override
    public void onModuleLoaded(ModuleLoadedParam param) {
        log("ImageBlocker API 102 initialized");
    }

    @Override
    public void onPackageLoaded(PackageLoadedParam param) {
        String pkg = param.getPackageName();
        if (pkg == null || pkg.equals("com.example.imageblocker")) {
            return;
        }

        hookImageViewSetter("setImageBitmap", Bitmap.class);
        hookImageViewSetter("setImageDrawable", Drawable.class);
        hookImageViewSetter("setImageURI", Uri.class);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private void hookImageViewSetter(String name, Class<?> argType) {
        try {
            Method method = ImageView.class.getDeclaredMethod(name, argType);
            String key = ImageView.class.getName() + "#" + name;
            if (!HOOKED.add(key)) return;

            getXposedInterface().hook(method).intercept(new Hooker() {
                @Override
                public Object intercept(XposedInterface.Chain chain) throws Throwable {
                    // Do not call chain.proceed(): this suppresses the original
                    // ImageView setter. Return null for its void result.
                    log("Blocked image display: " + key);
                    return null;
                }
            });

            log("Hooked " + key);
        } catch (Throwable t) {
            log("Failed to hook " + name + ": " + t);
        }
    }
}
