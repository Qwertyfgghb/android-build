package com.example.imageblocker;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.Log;
import android.widget.ImageView;

import java.lang.reflect.Method;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import io.github.libxposed.api.XposedModule;
import io.github.libxposed.api.XposedInterface;

/**
 * Minimal modern libxposed module targeting API 102.
 *
 * This prototype blocks common ImageView image assignments. It does not
 * guarantee cancellation of the underlying network/cache request.
 */
public final class ImageBlockerModule extends XposedModule {
    private static final String TAG = "ImageBlocker";
    private static final Set<String> HOOKED = ConcurrentHashMap.newKeySet();

    public ImageBlockerModule() {
        super();
    }

    @Override
    public void onModuleLoaded(ModuleLoadedParam param) {
        log(Log.INFO, TAG, "ImageBlocker API 102 initialized");
    }

    @Override
    public void onPackageLoaded(PackageLoadedParam param) {
        String pkg = param.getPackageName();
        if (pkg == null || pkg.equals("com.example.imageblocker")) {
            return;
        }

        hookImageViewSetter("setImageBitmap", Bitmap.class);
        hookImageViewSetter("setImageDrawable", Drawable.class);
        hookImageViewSetter("setImageURI", Uri.class);
    }

    private void hookImageViewSetter(String name, Class<?> argType) {
        try {
            Method method = ImageView.class.getDeclaredMethod(name, argType);
            String key = ImageView.class.getName() + "#" + name;
            if (!HOOKED.add(key)) {
                return;
            }

            hook(method).intercept(chain -> {
                // Skip the original setter so the provided image is not displayed.
                // This does not stop Glide/Picasso from downloading or decoding it.
                log(Log.INFO, TAG, "Blocked image display: " + key);
                return null;
            });

            log(Log.INFO, TAG, "Hook installed: " + key);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook " + name, t);
        }
    }
}
