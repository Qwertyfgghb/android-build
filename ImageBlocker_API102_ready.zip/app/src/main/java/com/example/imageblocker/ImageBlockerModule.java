package com.example.imageblocker;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import io.github.libxposed.api.XposedModule;

/**
 * Image display blocker for modern libxposed API 102.
 * Covers common ImageView paths used by Glide/Picasso/Coil, WebView network
 * images, and common Compose BitmapPainter/VectorPainter paths.
 * Library internals vary by version, so this is broad coverage, not a guarantee
 * that every custom renderer or network request is blocked.
 */
public final class ImageBlockerModule extends XposedModule {
    private static final String TAG = "ImageBlocker";
    private static final Set<String> HOOKED = ConcurrentHashMap.newKeySet();

    public ImageBlockerModule() { super(); }

    @Override
    public void onModuleLoaded(ModuleLoadedParam param) {
        log(Log.INFO, TAG, "ImageBlocker API 102 initialized");
    }

    @Override
    public void onPackageLoaded(PackageLoadedParam param) {
        String pkg = param.getPackageName();
        if (pkg == null || pkg.equals("com.example.imageblocker")) return;

        hookImageViewSetter("setImageBitmap", Bitmap.class);
        hookImageViewSetter("setImageDrawable", Drawable.class);
        hookImageViewSetter("setImageURI", Uri.class);
        hookImageViewSetter("setImageResource", int.class);
        hookWebView();
        hookComposePainters(param.getDefaultClassLoader());
        log(Log.INFO, TAG, "Image hooks initialized for package: " + pkg);
    }

    private void hookImageViewSetter(String name, Class<?> argType) {
        try {
            Method method = ImageView.class.getDeclaredMethod(name, argType);
            installSkipHook(method, "ImageView#" + name);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook ImageView." + name, t);
        }
    }

    private void hookWebView() {
        try {
            Method getSettings = WebView.class.getDeclaredMethod("getSettings");
            String key = "WebView#getSettings";
            if (HOOKED.add(key)) {
                hook(getSettings).intercept(chain -> {
                    Object result = chain.proceed();
                    if (result instanceof WebSettings) {
                        try {
                            ((WebSettings) result).setBlockNetworkImage(true);
                            log(Log.INFO, TAG, "WebView network images blocked");
                        } catch (Throwable t) {
                            log(Log.ERROR, TAG, "Could not block WebView images", t);
                        }
                    }
                    return result;
                });
                log(Log.INFO, TAG, "Hook installed: " + key);
            }

            Method setBlock = WebSettings.class.getDeclaredMethod("setBlockNetworkImage", boolean.class);
            String setKey = "WebSettings#setBlockNetworkImage";
            if (HOOKED.add(setKey)) {
                hook(setBlock).intercept(chain -> {
                    Object arg = chain.getArg(0);
                    if (Boolean.FALSE.equals(arg)) {
                        log(Log.INFO, TAG, "Ignored attempt to enable WebView network images");
                        return null;
                    }
                    return chain.proceed();
                });
                log(Log.INFO, TAG, "Hook installed: " + setKey);
            }
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to install WebView hooks", t);
        }
    }

    private void hookComposePainters(ClassLoader classLoader) {
        if (classLoader == null) return;
        hookComposePainter(classLoader, "androidx.compose.ui.graphics.painter.BitmapPainter");
        hookComposePainter(classLoader, "androidx.compose.ui.graphics.painter.VectorPainter");
    }

    private void hookComposePainter(ClassLoader classLoader, String className) {
        try {
            Class<?> painterClass = Class.forName(className, false, classLoader);
            int count = 0;
            for (Method method : painterClass.getDeclaredMethods()) {
                if (method.getName().equals("onDraw") && !Modifier.isAbstract(method.getModifiers())) {
                    installSkipHook(method, className + "#onDraw");
                    count++;
                }
            }
            if (count == 0) log(Log.INFO, TAG, "No onDraw method found: " + className);
        } catch (ClassNotFoundException e) {
            log(Log.DEBUG, TAG, "Compose painter not present: " + className);
        } catch (Throwable t) {
            log(Log.ERROR, TAG, "Failed to hook Compose painter: " + className, t);
        }
    }

    private void installSkipHook(Method method, String key) {
        if (!HOOKED.add(key)) return;
        try {
            hook(method).intercept(chain -> {
                log(Log.DEBUG, TAG, "Blocked image display: " + key);
                return null;
            });
            log(Log.INFO, TAG, "Hook installed: " + key);
        } catch (Throwable t) {
            HOOKED.remove(key);
            log(Log.ERROR, TAG, "Failed to hook: " + key, t);
        }
    }
}
