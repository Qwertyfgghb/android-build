# FakeOrientation — исправленный исходный проект LSPosed

Исправлена ошибка сборки AAPT: `android:description` удалён из `<application>`, а описание Xposed перенесено в строковый ресурс, на который указывает `@string/xposed_description`.

## Сборка
Нужен JDK 17 и Android SDK с платформой 34. В корне проекта:
`gradle :app:assembleDebug`

APK при успешной сборке:
`app/build/outputs/apk/debug/app-debug.apk`

## Установка
Установите APK, включите модуль в LSPosed и выберите Google Maps (`com.google.android.apps.maps`), затем перезапустите приложение.

## Ограничение
Модуль подменяет bearing и пытается синхронизировать азимут с `SensorManager.getOrientation()`. Он не может гарантировать исчезновение маркера/стрелки Google Maps: визуальная логика приложения может использовать внутренние API, сенсоры или fused location. Сборка этого архива здесь не запускалась.
