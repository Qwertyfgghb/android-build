package com.example.fakeorientation;

import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.os.Handler;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook установлен на " + lpparam.packageName);

        // ============================================================
        // 1. Смотрим какие датчики запрашивает Яндекс
        // ============================================================
        hookRegisterListener(lpparam);

        // ============================================================
        // 2. Логируем ВСЕ события датчиков, чтобы найти нужный handle
        // ============================================================
        hookDispatch(lpparam);

        // ============================================================
        // 3. Логируем getBearing + отдаём наше значение
        // ============================================================
        XposedHelpers.findAndHookMethod(
                Location.class, "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        Location loc = (Location) param.thisObject;
                        if (loc != null && loc.hasBearing()) {
                            float b = loc.getBearing();
                            XposedBridge.log(TAG + ": getBearing -> " + b
                                    + " (из " + loc.getProvider() + ")");
                        }
                    }
                }
        );
    }

    // ------------------------------------------------------------------
    // Хук: когда Яндекс регистрирует listener на датчик
    // ------------------------------------------------------------------

    private static void hookRegisterListener(XC_LoadPackage.LoadPackageParam lpparam) {
        XC_MethodHook hook = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                try {
                    Sensor sensor = null;
                    for (Object arg : param.args) {
                        if (arg instanceof Sensor) {
                            sensor = (Sensor) arg;
                            break;
                        }
                    }
                    if (sensor == null) return;

                    XposedBridge.log(TAG + ": >>> registerListener type="
                            + sensor.getStringType()
                            + " name=" + sensor.getName());
                } catch (Throwable t) {}
            }
        };

        // Сигнатуры: (SensorEventListener, Sensor, int)
        try {
            XposedHelpers.findAndHookMethod(
                    SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class,
                    hook);
            XposedBridge.log(TAG + ": registerListener(S,E,I) захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": sig1 fail: " + t);
        }

        // (SensorEventListener, Sensor, int, int)
        try {
            XposedHelpers.findAndHookMethod(
                    SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, int.class,
                    hook);
            XposedBridge.log(TAG + ": registerListener(S,E,I,I) захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": sig2 fail: " + t);
        }

        // (SensorEventListener, Sensor, int, Handler)
        try {
            XposedHelpers.findAndHookMethod(
                    SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, Handler.class,
                    hook);
            XposedBridge.log(TAG + ": registerListener(S,E,I,H) захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": sig3 fail: " + t);
        }
    }

    // ------------------------------------------------------------------
    // Логируем КАЖДОЕ dispatchSensorEvent (без throttle) чтобы понять
    // какие handle реально живы
    // ------------------------------------------------------------------

    private static void hookDispatch(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                    "android.hardware.SystemSensorManager$SensorEventQueue",
                    lpparam.classLoader,
                    "dispatchSensorEvent",
                    int.class, float[].class, int.class, long.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                int handle = (int) param.args[0];
                                float[] v = (float[]) param.args[1];
                                if (v == null) return;

                                // Логируем только "интересные" handle,
                                // чтобы не спамить (handle=1 — акселерометр, пропускаем)
                                if (handle == 1) return;

                                StringBuilder sb = new StringBuilder();
                                sb.append(TAG).append(": dispatch h=").append(handle)
                                  .append(" len=").append(v.length)
                                  .append(" v=[");
                                int n = Math.min(v.length, 5);
                                for (int i = 0; i < n; i++) {
                                    if (i > 0) sb.append(", ");
                                    sb.append(String.format("%.3f", v[i]));
                                }
                                sb.append("]");
                                XposedBridge.log(sb.toString());
                            } catch (Throwable ignored) {}
                        }
                    }
            );
            XposedBridge.log(TAG + ": dispatchSensorEvent захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": dispatch hook fail: " + t);
        }
    }
}