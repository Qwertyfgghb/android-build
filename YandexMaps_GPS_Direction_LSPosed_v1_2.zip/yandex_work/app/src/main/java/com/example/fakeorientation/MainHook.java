package com.example.fakeorientation;

import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    // ==== Тайминги ====
    private static final long TICK_INTERVAL_MS   = 100L;
    private static final long MOVE_HYSTERESIS_MS = 600L;

    // ==== Пороги скорости (м/с) ====
    private static final float STAND_STILL_MAX    = 0.10f;
    private static final float SNAP_MIN_SPEED     = 0.10f;
    private static final float MIN_SPEED_FOR_CONE = 1.0f;

    // ==== GPS-история ====
    private static final long   RAW_WINDOW_MS   = 2000L;
    private static final double RAW_MIN_DELTA_M = 0.3;
    private static final double GLITCH_JUMP_M   = 30.0;
    private static final int    GPS_BUF_SIZE    = 32;

    // ==== Сглаживание ====
    private static final float SMOOTH_FAST = 0.90f;
    private static final float SMOOTH_SLOW = 0.55f;

    private static final double SHIFT_METERS = 6.0;

    private static final boolean VERBOSE = true;

    // ==== Состояние ====
    private static volatile Location baseLocation     = null;
    private static volatile boolean isInjecting       = false;

    private static volatile float smoothedBearing     = 0f;
    private static volatile float lastInjectedBearing = 0f;

    private static volatile long    lastMoveTime      = 0L;
    private static volatile boolean wasMoving         = false;
    private static volatile boolean everMoved         = false;
    private static volatile boolean justStartedMoving = false;

    // ==== GPS history ====
    private static final Location[] gpsBuf = new Location[GPS_BUF_SIZE];
    private static volatile int gpsHead  = 0;
    private static volatile int gpsCount = 0;

    // ==== Компас (реальный азимут из rotation_vector) ====
    private static volatile float realCompassAzimuth = Float.NaN;
    private static volatile long  realCompassTime    = 0L;

    private static volatile boolean bypassSpeedHook = false;

    private static final List<LocationListener> listeners     = new CopyOnWriteArrayList<>();
    private static final Set<String>            hookedClasses = new HashSet<>();

    private static volatile Handler handler = null;

    private static volatile int rotationVectorHandle = -1;

    // ==================================================================
    // Entry
    // ==================================================================

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook на " + lpparam.packageName
                + " proc=" + lpparam.processName);

        hookHasBearing();
        hookHasSpeed();
        hookGetSpeed();
        hookGetBearing();
        hookLocationManager();
        hookYandexLocationSubscription(lpparam);
        hookRegisterListener(lpparam);
        hookSensorDispatch(lpparam);
    }

    // ==================================================================
    // Location хуки
    // ==================================================================

    private static void hookHasBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasBearing",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(true);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookHasSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasSpeed",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(true);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookGetSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getSpeed",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            if (bypassSpeedHook) return;
                            Object r = p.getResult();
                            float s = (r instanceof Float) ? (Float) r : 0f;
                            if (s < MIN_SPEED_FOR_CONE) p.setResult(MIN_SPEED_FOR_CONE);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookGetBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getBearing",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            if (isInjecting) return;
                            Object res = p.getResult();
                            float real = (res instanceof Float) ? (Float) res : 0f;
                            if (real != 0f) return;
                            p.setResult(lastInjectedBearing);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static float readRawSpeed(Location loc) {
        if (loc == null) return 0f;
        bypassSpeedHook = true;
        try {
            return loc.getSpeed();
        } catch (Throwable t) {
            return 0f;
        } finally {
            bypassSpeedHook = false;
        }
    }

    // ==================================================================
    // LocationManager / listener capture
    // ==================================================================

    private static void hookLocationManager() {
        XC_MethodHook capture = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    for (Object a : p.args) {
                        if (a instanceof LocationListener) {
                            LocationListener ll = (LocationListener) a;
                            if (!listeners.contains(ll)) {
                                listeners.add(ll);
                                XposedBridge.log(TAG + ": listener захвачен: "
                                        + ll.getClass().getName());
                                hookListenerInstance(ll);
                            }
                            break;
                        }
                    }
                } catch (Throwable ignored) {}
            }
        };
        try {
            XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                    String.class, long.class, float.class, LocationListener.class, capture);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                    long.class, float.class, android.location.Criteria.class,
                    LocationListener.class, Looper.class, capture);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                    String.class, long.class, float.class, LocationListener.class,
                    Looper.class, capture);
        } catch (Throwable ignored) {}

        XposedBridge.log(TAG + ": LocationManager захукан");
    }

    private static void hookYandexLocationSubscription(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> cls = XposedHelpers.findClass(
                    "com.yandex.runtime.sensors.internal.LocationSubscription",
                    lpparam.classLoader);

            XposedBridge.hookAllMethods(cls, "onLocationChanged", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    if (!VERBOSE) return;
                    if (p.args.length > 0 && p.args[0] instanceof Location) {
                        Location l = (Location) p.args[0];
                        XposedBridge.log(TAG + ": YandexLocSub ← lat="
                                + String.format("%.6f", l.getLatitude())
                                + " lon=" + String.format("%.6f", l.getLongitude())
                                + " brg=" + l.getBearing()
                                + " spd=" + l.getSpeed());
                    }
                }
            });
            XposedBridge.log(TAG + ": YandexLocationSubscription захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": LocSub hook fail: " + t);
        }
    }

    private static void hookListenerInstance(LocationListener ll) {
        Class<?> cls  = ll.getClass();
        String   name = cls.getName();
        if (hookedClasses.contains(name)) return;
        hookedClasses.add(name);

        try {
            XposedBridge.hookAllMethods(cls, "onLocationChanged", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (isInjecting) return;
                    if (p.args.length == 0) return;
                    if (!(p.args[0] instanceof Location)) return;

                    Location incoming = (Location) p.args[0];
                    pushGpsHistory(incoming);
                    baseLocation = new Location(incoming);
                    ensureTicker();

                    float raw = readRawSpeed(incoming);
                    if (raw >= SNAP_MIN_SPEED) {
                        lastMoveTime = System.currentTimeMillis();
                        if (!wasMoving) {
                            wasMoving = true;
                            justStartedMoving = true;
                            if (VERBOSE) XposedBridge.log(TAG
                                    + ": → движение поймано (raw=" + raw + ")");
                        }
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hook onLocationChanged fail " + name + ": " + t);
        }
    }

    // ==================================================================
    // GPS history
    // ==================================================================

    private static void pushGpsHistory(Location loc) {
        if (loc == null) return;

        if (gpsCount > 0) {
            int lastIdx = (gpsHead - 1 + GPS_BUF_SIZE) % GPS_BUF_SIZE;
            Location last = gpsBuf[lastIdx];
            if (last != null) {
                // Точная копия — игнор
                if (last.getLatitude()  == loc.getLatitude()
                        && last.getLongitude() == loc.getLongitude()) {
                    return;
                }
                double d = distanceMeters(last, loc);
                if (d > GLITCH_JUMP_M) {
                    // Не глитч — телепорт (мок-локация → реал GPS).
                    // Заменяем последнюю точку новой, чтобы не блокировать всё.
                    if (VERBOSE) XposedBridge.log(TAG
                            + ": GPS-телепорт " + String.format("%.0f", d)
                            + " м — переустанавливаем base");
                    gpsBuf[lastIdx] = new Location(loc);
                    return;
                }
            }
        }
        gpsBuf[gpsHead] = new Location(loc);
        gpsHead = (gpsHead + 1) % GPS_BUF_SIZE;
        if (gpsCount < GPS_BUF_SIZE) gpsCount++;
    }

    /** Идём от новых к старым: первая точка с дельтой >= RAW_MIN_DELTA_M. */
    private static float rawGpsBearing() {
        if (gpsCount < 2) return Float.NaN;
        Location cur = gpsBuf[(gpsHead - 1 + GPS_BUF_SIZE) % GPS_BUF_SIZE];
        if (cur == null) return Float.NaN;
        long now = cur.getTime();

        for (int i = 1; i < gpsCount; i++) {
            int idx = (gpsHead - 1 - i + GPS_BUF_SIZE * 2) % GPS_BUF_SIZE;
            Location h = gpsBuf[idx];
            if (h == null) continue;
            long age = now - h.getTime();
            if (age > RAW_WINDOW_MS) break;

            double d = distanceMeters(h, cur);
            if (d < RAW_MIN_DELTA_M) continue;

            return bearingFrom(h, cur);
        }
        return Float.NaN;
    }

    private static double distanceMeters(Location a, Location b) {
        double dLat = (b.getLatitude()  - a.getLatitude())  * 111320.0;
        double dLon = (b.getLongitude() - a.getLongitude()) * 111320.0
                * Math.cos(Math.toRadians(b.getLatitude()));
        return Math.hypot(dLat, dLon);
    }

    private static float bearingFrom(Location from, Location to) {
        double dLat = to.getLatitude()  - from.getLatitude();
        double dLon = to.getLongitude() - from.getLongitude();
        double latM = dLat * 111320.0;
        double lonM = dLon * 111320.0 * Math.cos(Math.toRadians(to.getLatitude()));
        float b = (float) Math.toDegrees(Math.atan2(lonM, latM));
        return (b + 360f) % 360f;
    }

    // ==================================================================
    // Компас через стандартный Android API
    // ==================================================================

    /** Возвращает азимут (0–360) из rotation_vector, либо NaN при ошибке. */
    private static float azimuthFromRotationVector(float[] q) {
        try {
            float[] R = new float[9];
            SensorManager.getRotationMatrixFromVector(R, q);
            float[] orientation = new float[3];
            SensorManager.getOrientation(R, orientation);
            float az = (float) Math.toDegrees(orientation[0]);
            return (az + 360f) % 360f;
        } catch (Throwable t) {
            return Float.NaN;
        }
    }

    // ==================================================================
    // Сглаживание
    // ==================================================================

    private static float angleDiff(float a, float b) {
        return ((b - a + 540f) % 360f) - 180f;
    }

    private static float smoothAngle(float from, float to, float alpha) {
        return (from + alpha * angleDiff(from, to) + 360f) % 360f;
    }

    // ==================================================================
    // Тикер
    // ==================================================================

    private static synchronized void ensureTicker() {
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        if (handler.hasCallbacks(tickerRunnable)) return;

        XposedBridge.log(TAG + ": тикер запущен, base lat="
                + (baseLocation != null ? baseLocation.getLatitude() : "null"));
        handler.postDelayed(tickerRunnable, TICK_INTERVAL_MS);
    }

    private static final Runnable tickerRunnable = new Runnable() {
        @Override public void run() {
            try { tick(); } catch (Throwable t) {
                XposedBridge.log(TAG + ": tick error: " + t);
            }
            if (handler != null) handler.postDelayed(this, TICK_INTERVAL_MS);
        }
    };

    private static void tick() {
        Location base = baseLocation;
        if (base == null) return;

        long  now      = System.currentTimeMillis();
        float rawSpeed = readRawSpeed(base);

        boolean moving;
        if (rawSpeed >= STAND_STILL_MAX) {
            lastMoveTime = now;
            moving = true;
            wasMoving = true;
        } else {
            moving = (now - lastMoveTime) < MOVE_HYSTERESIS_MS;
            if (!moving && (now - lastMoveTime) >= MOVE_HYSTERESIS_MS) {
                wasMoving = false;
            }
        }

        // 1) GPS-bearing
        float raw = rawGpsBearing();
        String src = "gps";

        // 2) Если нет — компас (не старше 1 с)
        if (Float.isNaN(raw)
                && !Float.isNaN(realCompassAzimuth)
                && (now - realCompassTime) < 1000L) {
            raw = realCompassAzimuth;
            src = "compass";
        }

        if (Float.isNaN(raw)) {
            if (everMoved) injectLocation(base, lastInjectedBearing);
            return;
        }

        if (justStartedMoving || !everMoved) {
            smoothedBearing   = raw;
            justStartedMoving = false;
            everMoved         = true;
            if (VERBOSE) XposedBridge.log(TAG + ": ★ SNAP[" + src + "] → "
                    + String.format("%.1f", smoothedBearing) + "°");
        } else {
            float alpha = moving ? SMOOTH_FAST : SMOOTH_SLOW;
            smoothedBearing = smoothAngle(smoothedBearing, raw, alpha);
        }

        lastInjectedBearing = smoothedBearing;

        if (VERBOSE) {
            String state = moving ? "move" : "still";
            XposedBridge.log(TAG + ": " + state + "[" + src + "]"
                    + " rawSpeed=" + rawSpeed
                    + " raw=" + String.format("%.1f", raw)
                    + " → inject " + String.format("%.1f", smoothedBearing) + "°");
        }

        injectLocation(base, smoothedBearing);
    }

    private static void injectLocation(Location base, float bearingDeg) {
        Location inject = buildShifted(base, bearingDeg);
        isInjecting = true;
        try {
            for (LocationListener ll : listeners) {
                try { ll.onLocationChanged(inject); } catch (Throwable ignored) {}
            }
        } finally {
            isInjecting = false;
        }
    }

    private static Location buildShifted(Location base, float bearingDeg) {
        Location inj = new Location(base);

        double R   = 6371000.0;
        double rad = Math.toRadians(bearingDeg);
        double dLatDeg = Math.toDegrees(SHIFT_METERS * Math.cos(rad) / R);
        double dLonDeg = Math.toDegrees(SHIFT_METERS * Math.sin(rad)
                / (R * Math.cos(Math.toRadians(base.getLatitude()))));

        inj.setLatitude(base.getLatitude() + dLatDeg);
        inj.setLongitude(base.getLongitude() + dLonDeg);
        inj.setBearing(bearingDeg);
        inj.setSpeed(MIN_SPEED_FOR_CONE);
        inj.setTime(System.currentTimeMillis());
        inj.setElapsedRealtimeNanos(System.nanoTime());

        if (Build.VERSION.SDK_INT >= 26) {
            inj.setBearingAccuracyDegrees(10f);
            inj.setSpeedAccuracyMetersPerSecond(0.5f);
        }
        return inj;
    }

    // ==================================================================
    // Sensor
    // ==================================================================

    private static void hookRegisterListener(XC_LoadPackage.LoadPackageParam lpparam) {
        XC_MethodHook hook = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    for (Object a : p.args) {
                        if (a instanceof Sensor) {
                            Sensor s = (Sensor) a;
                            if (s.getType() == Sensor.TYPE_ROTATION_VECTOR) {
                                int h = XposedHelpers.getIntField(s, "mHandle");
                                if (rotationVectorHandle != h) {
                                    rotationVectorHandle = h;
                                    XposedBridge.log(TAG + ": rotation_vector handle = " + h);
                                }
                            }
                            break;
                        }
                    }
                } catch (Throwable ignored) {}
            }
        };
        try {
            XposedHelpers.findAndHookMethod(SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, hook);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, int.class, hook);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, Handler.class, hook);
        } catch (Throwable ignored) {}
    }

    private static void hookSensorDispatch(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                    "android.hardware.SystemSensorManager$SensorEventQueue",
                    lpparam.classLoader,
                    "dispatchSensorEvent",
                    int.class, float[].class, int.class, long.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam p) {
                            try {
                                int handle = (int) p.args[0];
                                if (handle != rotationVectorHandle) return;

                                float[] v = (float[]) p.args[1];
                                if (v == null || v.length < 4) return;

                                // 1) Сохраняем РЕАЛЬНЫЙ азимут ДО подмены
                                float az = azimuthFromRotationVector(v);
                                if (!Float.isNaN(az)) {
                                    realCompassAzimuth = az;
                                    realCompassTime    = System.currentTimeMillis();
                                }

                                // 2) Подменяем сенсор только после первого движения
                                if (!everMoved) return;
                                applyFakeRotation(v, lastInjectedBearing);
                            } catch (Throwable ignored) {}
                        }
                    });
            XposedBridge.log(TAG + ": dispatchSensorEvent захукан (rotation_vector)");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": dispatch hook fail: " + t);
        }
    }

    private static void applyFakeRotation(float[] v, float headingDeg) {
        double half = Math.toRadians(headingDeg) / 2.0;
        v[0] = 0f;
        v[1] = 0f;
        v[2] = (float) Math.sin(half);
        v[3] = (float) Math.cos(half);
        if (v.length >= 5) v[4] = 0f;
    }
}