package com.example.fakeorientation;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    private static final float MIN_DISTANCE_M = 1.0f;
    private static final float SMOOTHING = 0.4f;

    // Азимут, который инжектим в датчик
    private static volatile float bearing = 0f;
    private static volatile boolean hasBearing = false;

    private static Location anchorLocation = null;
    private static long lastLog = 0L;
    private static boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook установлен на " + lpparam.packageName);

        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (started) return;
                        started = true;
                        Context ctx = (Context) param.thisObject;
                        startLocation(ctx);
                    }
                }
        );

        // Скорость = 0 → карты рисуют КОНУС, а не стрелку
        XposedHelpers.findAndHookMethod(
                Location.class, "getSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(0f);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // getBearing НЕ хукаем — читаем оригинал в listener.

        hookRotationVector(lpparam);
    }

    // ------------------------------------------------------------------
    // Инжектим bearing в датчик вращения (handle=11)
    // ------------------------------------------------------------------

    private static void hookRotationVector(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                    "android.hardware.SystemSensorManager$SensorEventQueue",
                    lpparam.classLoader,
                    "dispatchSensorEvent",
                    int.class, float[].class, int.class, long.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                int handle = (int) param.args[0];
                                float[] values = (float[]) param.args[1];

                                if (handle != 11 || values.length < 4) return;
                                if (!hasBearing) return;

                                float half = (float) Math.toRadians(bearing) / 2f;
                                float s = (float) Math.sin(half);
                                float c = (float) Math.cos(half);

                                values[0] = 0f;
                                values[1] = 0f;
                                values[2] = s;
                                values[3] = c;

                                log("inject rot-vec: bearing=" + (int) bearing);
                            } catch (Throwable ignored) {}
                        }
                    }
            );
            XposedBridge.log(TAG + ": dispatchSensorEvent захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": dispatch hook fail: " + t);
        }
    }

    // ------------------------------------------------------------------
    // GPS
    // ------------------------------------------------------------------

    private static void startLocation(Context context) {
        LocationManager lm = (LocationManager)
                context.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) {
            XposedBridge.log(TAG + ": LocationManager == null");
            return;
        }

        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if (location == null) return;

                // СРАЗУ обновляем bearing, если GPS дал направление
                if (location.hasBearing() && location.getBearing() != 0f) {
                    float gpsBearing = location.getBearing();
                    if (!hasBearing) {
                        bearing = gpsBearing;
                        hasBearing = true;
                    } else {
                        float diff = gpsBearing - bearing;
                        while (diff > 180f) diff -= 360f;
                        while (diff < -180f) diff += 360f;
                        bearing += diff * SMOOTHING;
                        if (bearing < 0) bearing += 360f;
                        if (bearing >= 360f) bearing -= 360f;
                    }
                    log("GPS bearing (нативный) = " + (int) gpsBearing
                            + "°, итог=" + (int) bearing);
                    return;
                }

                // Если GPS bearing нет — считаем по двум точкам
                if (!location.hasAccuracy()) return;

                if (anchorLocation == null) {
                    anchorLocation = new Location(location);
                    log("первая точка");
                    return;
                }

                float dist = location.distanceTo(anchorLocation);
                if (dist < MIN_DISTANCE_M) return;

                float raw = anchorLocation.bearingTo(location);
                if (raw < 0) raw += 360f;

                if (!hasBearing) {
                    bearing = raw;
                    hasBearing = true;
                } else {
                    float diff = raw - bearing;
                    while (diff > 180f) diff -= 360f;
                    while (diff < -180f) diff += 360f;
                    bearing += diff * SMOOTHING;
                    if (bearing < 0) bearing += 360f;
                    if (bearing >= 360f) bearing -= 360f;
                }

                log("GPS two-point: dist=" + (int) dist + " м, bearing="
                        + (int) bearing + "°");
                anchorLocation = new Location(location);
            }

            @Override public void onStatusChanged(String s, int i, Bundle b) {}
            @Override public void onProviderEnabled(String s) {}
            @Override public void onProviderDisabled(String s) {}
        };

        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                    1000L, 0f, listener);
            XposedBridge.log(TAG + ": GPS listener запущен");
            try {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                        1000L, 0f, listener);
                XposedBridge.log(TAG + ": Network listener запущен");
            } catch (Exception ignored) {}
        } catch (Exception e) {
            XposedBridge.log(TAG + ": GPS error: " + e);
        }
    }

    private static void log(String msg) {
        long now = System.currentTimeMillis();
        if (now - lastLog > 500) {
            lastLog = now;
            XposedBridge.log(TAG + ": " + msg);
        }
    }
}