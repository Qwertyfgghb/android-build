package com.example.fakeorientation;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import java.util.List;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    private static volatile float baseHeading = 0f;
    private static volatile boolean baseHeadingSet = false;

    private static volatile float yaw = 0f;
    private static volatile boolean hasYaw = false;

    private static long lastYawLog = 0L;
    private static long lastBearingLog = 0L;
    private static long lastSensorLog = 0L;

    private static boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook установлен на " + lpparam.packageName);

        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (started) return;
                        started = true;
                        Context ctx = (Context) param.thisObject;
                        logAllSensors(ctx);   // ← диагностика
                        startAllSensors(ctx); // ← слушаем ВСЁ сразу
                        startLocation(ctx);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        long now = System.currentTimeMillis();
                        if (now - lastBearingLog > 2000) {
                            lastBearingLog = now;
                            XposedBridge.log(TAG + ": getBearing вызван (yaw="
                                    + yaw + ", base=" + baseHeading + ")");
                        }
                        if (!hasYaw) return;
                        float bearing = baseHeading + yaw;
                        bearing = ((bearing % 360f) + 360f) % 360f;
                        param.setResult(bearing);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "getSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(0f);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        hookSensorDispatch(lpparam);
    }

    // ------------------------------------------------------------------
    // Диагностика: перечисляем ВСЕ доступные датчики устройства
    // ------------------------------------------------------------------

    private static void logAllSensors(Context context) {
        SensorManager sm = (SensorManager)
                context.getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) {
            XposedBridge.log(TAG + ": SensorManager == null!");
            return;
        }

        List<Sensor> sensors = sm.getSensorList(Sensor.TYPE_ALL);
        XposedBridge.log(TAG + ": === Список всех датчиков (" + sensors.size() + ") ===");
        for (Sensor s : sensors) {
            XposedBridge.log(TAG + ": sensor name=" + s.getName()
                    + " type=" + s.getStringType()
                    + " vendor=" + s.getVendor());
        }
        XposedBridge.log(TAG + ": === Конец списка датчиков ===");
    }

    // ------------------------------------------------------------------
    // Слушаем сразу несколько датчиков для проверки, какой живой
    // ------------------------------------------------------------------

    private static void startAllSensors(Context context) {
        SensorManager sm = (SensorManager)
                context.getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) return;

        // Слушаем ВСЕ интересные типы сразу
        int[] types = new int[]{
                Sensor.TYPE_GAME_ROTATION_VECTOR,
                Sensor.TYPE_ROTATION_VECTOR,
                Sensor.TYPE_GYROSCOPE,
                Sensor.TYPE_ACCELEROMETER
        };

        for (int type : types) {
            final Sensor s = sm.getDefaultSensor(type);
            if (s == null) {
                XposedBridge.log(TAG + ": датчик " + type + " отсутствует");
                continue;
            }

            SensorEventListener l = new SensorEventListener() {

                private final float[] rotationMatrix = new float[9];
                private final float[] orientation = new float[3];
                private float firstYaw = Float.NaN;

                private long lastGyroTime = 0L;
                private float accumulatedYaw = 0f;
                private long logCounter = 0L;

                @Override
                public void onSensorChanged(SensorEvent event) {
                    int t = event.sensor.getType();

                    // Логируем первые 5 событий каждого типа
                    if (logCounter < 5) {
                        StringBuilder sb = new StringBuilder();
                        sb.append(TAG).append(": ").append(event.sensor.getStringType())
                          .append(" values=[");
                        for (int i = 0; i < event.values.length; i++) {
                            if (i > 0) sb.append(", ");
                            sb.append(event.values[i]);
                        }
                        sb.append("]");
                        XposedBridge.log(sb.toString());
                        logCounter++;
                    }

                    if (t == Sensor.TYPE_GAME_ROTATION_VECTOR
                            || t == Sensor.TYPE_ROTATION_VECTOR) {

                        SensorManager.getRotationMatrixFromVector(
                                rotationMatrix, event.values);
                        SensorManager.getOrientation(rotationMatrix, orientation);

                        float currentYaw = (float) Math.toDegrees(orientation[0]);
                        if (Float.isNaN(firstYaw)) firstYaw = currentYaw;
                        yaw = currentYaw - firstYaw;
                        hasYaw = true;

                    } else if (t == Sensor.TYPE_GYROSCOPE) {
                        if (lastGyroTime != 0L) {
                            float dt = (event.timestamp - lastGyroTime) * 1e-9f;
                            accumulatedYaw +=
                                    (float) Math.toDegrees(event.values[2]) * dt;
                            yaw = -accumulatedYaw;
                            hasYaw = true;
                        }
                        lastGyroTime = event.timestamp;
                    }
                    // ACCELEROMETER — просто логируем, ничего не делаем

                    long now = System.currentTimeMillis();
                    if (now - lastYawLog > 500) {
                        lastYawLog = now;
                        XposedBridge.log(TAG + ": yaw=" + yaw + " (from "
                                + event.sensor.getStringType() + ")");
                    }
                }

                @Override
                public void onAccuracyChanged(Sensor sensor, int accuracy) {}
            };

            sm.registerListener(l, s, SensorManager.SENSOR_DELAY_GAME);
            XposedBridge.log(TAG + ": слушаю " + s.getStringType());
        }
    }

    // ------------------------------------------------------------------
    // Хук на dispatchSensorEvent
    // ------------------------------------------------------------------

    private static void hookSensorDispatch(XC_LoadPackage.LoadPackageParam lpparam) {
        XC_MethodHook hook = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                try {
                    Object[] args = param.args;
                    if (args == null || args.length < 2) return;
                    int handle = ((Number) args[0]).intValue();
                    float[] values = (float[]) args[1];
                    long now = System.currentTimeMillis();
                    if (now - lastSensorLog < 800) return;
                    lastSensorLog = now;
                    StringBuilder sb = new StringBuilder();
                    sb.append(TAG).append(": dispatch handle=").append(handle)
                      .append(" values=[");
                    for (int i = 0; i < values.length; i++) {
                        if (i > 0) sb.append(", ");
                        sb.append(values[i]);
                    }
                    sb.append("]");
                    XposedBridge.log(sb.toString());
                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": err: " + t);
                }
            }
        };

        try {
            XposedHelpers.findAndHookMethod(
                    "android.hardware.SystemSensorManager$SensorEventQueue",
                    lpparam.classLoader,
                    "dispatchSensorEvent",
                    int.class, float[].class, int.class, long.class,
                    hook
            );
            XposedBridge.log(TAG + ": dispatchSensorEvent захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": dispatch hook fail: " + t);
        }
    }

    // ------------------------------------------------------------------
    // GPS
    // ------------------------------------------------------------------

    private static void startLocation(Context context) {
        LocationManager lm = (LocationManager)
                context.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return;

        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if (location == null) return;
                if (!baseHeadingSet
                        && location.hasBearing()
                        && location.getBearing() != 0f) {
                    baseHeading = location.getBearing();
                    baseHeadingSet = true;
                    XposedBridge.log(TAG + ": baseHeading = " + baseHeading);
                }
            }
            @Override public void onStatusChanged(String s, int i, Bundle b) {}
            @Override public void onProviderEnabled(String s) {}
            @Override public void onProviderDisabled(String s) {}
        };

        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                    1000L, 0f, listener);
            XposedBridge.log(TAG + ": GPS listener запущен");
        } catch (Exception e) {
            XposedBridge.log(TAG + ": GPS error: " + e);
        }
    }
}