package com.example.fakeorientation;

import android.location.Location;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** Experimental GPS-only course hook for Yandex Maps. */
public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "YandexGpsDirection";
    private static volatile boolean hooked = false;
    private static volatile boolean courseValid = false;
    private static volatile float course = 0f;
    private static double anchorLat = Double.NaN;
    private static double anchorLon = Double.NaN;
    private static long lastTime = -1L;
    private static double lastLat = Double.NaN;
    private static double lastLon = Double.NaN;
    private static final ThreadLocal<Boolean> insideUpdate = new ThreadLocal<Boolean>() {
        @Override protected Boolean initialValue() { return false; }
    };

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"ru.yandex.yandexmaps".equals(lpparam.packageName)) return;
        synchronized (MainHook.class) {
            if (hooked) return;
            hooked = true;
        }
        try {
            // Observe coordinates as Yandex reads them. This does not depend on Yandex calling getBearing().
            XC_MethodHook coordinateHook = new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    if (Boolean.TRUE.equals(insideUpdate.get())) return;
                    if (param.thisObject instanceof Location) updateCourse((Location) param.thisObject);
                }
            };
            XposedHelpers.findAndHookMethod(Location.class, "getLatitude", coordinateHook);
            XposedHelpers.findAndHookMethod(Location.class, "getLongitude", coordinateHook);

            XposedHelpers.findAndHookMethod(Location.class, "getBearing", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    Location loc = (Location) param.thisObject;
                    updateCourse(loc);
                    if (courseValid) param.setResult(course);
                }
            });
            XposedHelpers.findAndHookMethod(Location.class, "hasBearing", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    Location loc = (Location) param.thisObject;
                    updateCourse(loc);
                    if (courseValid) param.setResult(true);
                }
            });
            XposedBridge.log(TAG + ": coordinate/bearing hooks installed for Yandex Maps");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hook install failed: " + t);
        }
    }

    private static synchronized void updateCourse(Location loc) {
        if (loc == null || Boolean.TRUE.equals(insideUpdate.get())) return;
        insideUpdate.set(true);
        try {
            double lat = loc.getLatitude();
            double lon = loc.getLongitude();
            long time = loc.getTime();
            if (!Double.isFinite(lat) || !Double.isFinite(lon)) return;
            if (time == lastTime && Math.abs(lat - lastLat) < 1e-8 && Math.abs(lon - lastLon) < 1e-8) return;
            lastTime = time;
            lastLat = lat;
            lastLon = lon;

            if (Double.isNaN(anchorLat)) {
                anchorLat = lat;
                anchorLon = lon;
                return;
            }

            float distance = distanceMeters(anchorLat, anchorLon, lat, lon);
            // Small threshold for quick response; very short GPS movements can be noisy.
            if (distance < 0.45f) return;

            double lat1 = Math.toRadians(anchorLat);
            double lat2 = Math.toRadians(lat);
            double dLon = Math.toRadians(lon - anchorLon);
            double y = Math.sin(dLon) * Math.cos(lat2);
            double x = Math.cos(lat1) * Math.sin(lat2)
                    - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
            double deg = Math.toDegrees(Math.atan2(y, x));
            if (deg < 0) deg += 360.0;

            // Circular smoothing reduces abrupt jumps caused by GPS noise.
            if (courseValid) {
                double oldRad = Math.toRadians(course);
                double newRad = Math.toRadians(deg);
                double sx = 0.35 * Math.cos(oldRad) + 0.65 * Math.cos(newRad);
                double sy = 0.35 * Math.sin(oldRad) + 0.65 * Math.sin(newRad);
                deg = Math.toDegrees(Math.atan2(sy, sx));
                if (deg < 0) deg += 360.0;
            }
            course = (float) deg;
            courseValid = true;
            anchorLat = lat;
            anchorLon = lon;
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": update failed: " + t);
        } finally {
            insideUpdate.set(false);
        }
    }

    private static float distanceMeters(double lat1, double lon1, double lat2, double lon2) {
        float[] result = new float[1];
        Location.distanceBetween(lat1, lon1, lat2, lon2, result);
        return result[0];
    }
}
