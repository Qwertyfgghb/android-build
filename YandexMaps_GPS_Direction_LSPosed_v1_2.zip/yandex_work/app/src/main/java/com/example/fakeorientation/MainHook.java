package com.example.fakeorientation;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    // Текущее подменяемое направление (азимут в градусах)
    private static float fakeAzimuth = 0f;

    // Есть ли уже валидное направление (получено хотя бы 2 GPS точки)
    private static boolean hasValidAzimuth = false;

    // Предыдущая GPS-точка
    private static Location lastLocation = null;

    // Защита от повторного запуска GPS в одном процессе
    private static boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        XposedBridge.log(TAG + ": handleLoadPackage -> " + lpparam.packageName);

        // Фильтр по имени пакета (карты)
        if (!lpparam.packageName.contains("maps")) {
            return;
        }

        XposedBridge.log(TAG + ": хук установлен на " + lpparam.packageName);

        // 1. Запускаем GPS при старте приложения
        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (started) return;
                        started = true;

                        Context context = (Context) param.thisObject;
                        startLocation(context);
                    }
                }
        );

        // 2. Подменяем getBearing() — возвращаем посчитанный азимут
        XposedHelpers.findAndHookMethod(
                Location.class,
                "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (hasValidAzimuth) {
                            param.setResult(fakeAzimuth);
                        }
                        // Если валидного азимута ещё нет — оставляем оригинал
                    }
                }
        );

        // 3. Говорим приложению, что bearing ЕСТЬ (иначе стрелка не рисуется)
        XposedHelpers.findAndHookMethod(
                Location.class,
                "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // 4. Говорим приложению, что speed ЕСТЬ (иначе стрелка скорости не рисуется)
        XposedHelpers.findAndHookMethod(
                Location.class,
                "hasSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // 5. Обнуляем скорость, чтобы приложение не строило стрелку по GPS-скорости
        XposedHelpers.findAndHookMethod(
                Location.class,
                "getSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(0f);
                    }
                }
        );
    }

    // ------------------------------------------------------------------
    // GPS
    // ------------------------------------------------------------------

    private static void startLocation(Context context) {
        LocationManager lm = (LocationManager)
                context.getSystemService(Context.LOCATION_SERVICE);

        if (lm == null) {
            XposedBridge.log(TAG + ": LocationManager == null");
            return;
        }

        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                updateDirection(location);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {}

            @Override
            public void onProviderEnabled(String provider) {}

            @Override
            public void onProviderDisabled(String provider) {}
        };

        try {
            lm.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    0,      // минимальное время между обновлениями (мс)
                    0f,     // минимальное расстояние (м)
                    listener
            );
            XposedBridge.log(TAG + ": GPS listener запущен");
        } catch (SecurityException e) {
            XposedBridge.log(TAG + ": нет разрешения на GPS: " + e);
        } catch (Exception e) {
            XposedBridge.log(TAG + ": ошибка запуска GPS: " + e);
        }
    }

    // ------------------------------------------------------------------
    // Расчёт азимута
    // ------------------------------------------------------------------

    private static void updateDirection(Location location) {
        if (location == null) return;

        if (lastLocation != null) {
            float distance = location.distanceTo(lastLocation);

            // Отсекаем GPS-шум: если смещение меньше 0.3 м — не обновляем
            if (distance < 0.3f) {
                return;
            }

            double lat1 = Math.toRadians(lastLocation.getLatitude());
            double lon1 = Math.toRadians(lastLocation.getLongitude());
            double lat2 = Math.toRadians(location.getLatitude());
            double lon2 = Math.toRadians(location.getLongitude());

            double dLon = lon2 - lon1;

            double y = Math.sin(dLon) * Math.cos(lat2);
            double x = Math.cos(lat1) * Math.sin(lat2)
                    - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);

            double bearing = Math.toDegrees(Math.atan2(y, x));
            if (bearing < 0) bearing += 360;

            fakeAzimuth = (float) bearing;
            hasValidAzimuth = true;

            XposedBridge.log(TAG + ": azimuth = " + fakeAzimuth
                    + " (dist=" + distance + " м)");
        }

        lastLocation = location;
    }
}