package com.example.fakeorientation;

import android.location.Location;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    // Порог движения — от 1 метра
    private static final float MIN_DISTANCE_M = 1.0f;
    // Сглаживание (0..1)
    private static final float SMOOTHING = 0.4f;

    private static volatile float bearing = 0f;
    private static volatile boolean hasBearing = false;

    // Опорная точка, от которой считаем азимут
    private static Location anchorLocation = null;

    private static long lastLog = 0L;
    private static boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook установлен на " + lpparam.packageName);

        // ============================================================
        // 1. Главный хук: перехватываем getBearing.
        //    Именно через него Yandex читает направление.
        //    Используем сам Location (thisObject) для накопления истории.
        // ============================================================
        XposedHelpers.findAndHookMethod(
                Location.class, "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        Location loc = (Location) param.thisObject;
                        if (loc != null) {
                            updateBearingFromLocation(loc);
                        }
                        if (hasBearing) {
                            param.setResult(bearing);
                        }
                    }
                }
        );

        // ============================================================
        // 2. hasBearing → true, чтобы Yandex считал, что данные есть
        // ============================================================
        XposedHelpers.findAndHookMethod(
                Location.class, "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // ============================================================
        // 3. Скорость = 0 → Yandex рисует КОНУС, а не стрелку
        // ============================================================
        XposedHelpers.findAndHookMethod(
                Location.class, "getSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(0f);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // ============================================================
        // 4. Инжект bearing в датчик вращения — чтобы конус повернулся
        //    в момент, когда Yandex опрашивает сенсор
        // ============================================================
        hookRotationVector(lpparam);

        if (!started) {
            started = true;
            XposedBridge.log(TAG + ": все хуки установлены");
        }
    }

    // ------------------------------------------------------------------
    // Накопление истории из Location, приходящих из Yandex
    // ------------------------------------------------------------------

    private static void updateBearingFromLocation(Location loc) {
        try {
            // Проверяем валидность координат
            double lat = loc.getLatitude();
            double lon = loc.getLongitude();
            if (lat == 0.0 && lon == 0.0) return;

            // Если у Location есть "родной" bearing и он не нулевой — берём его
            float nativeBearing = loc.getBearing();
            if (loc.hasBearing() && nativeBearing != 0f) {
                float diff = nativeBearing - bearing;
                while (diff > 180f) diff -= 360f;
                while (diff < -180f) diff += 360f;
                bearing = hasBearing
                        ? normalize(bearing + diff * SMOOTHING)
                        : nativeBearing;
                hasBearing = true;
                log("native bearing=" + (int) nativeBearing
                        + "° итог=" + (int) bearing + "°");
                return;
            }

            // Иначе — считаем по двум точкам
            if (anchorLocation == null) {
                anchorLocation = new Location(loc);
                log("anchor set lat=" + lat + " lon=" + lon);
                return;
            }

            float dist = loc.distanceTo(anchorLocation);
            if (dist < MIN_DISTANCE_M) return;

            float raw = anchorLocation.bearingTo(loc);
            if (raw < 0) raw += 360f;

            if (!hasBearing) {
                bearing = raw;
                hasBearing = true;
            } else {
                float diff = raw - bearing;
                while (diff > 180f) diff -= 360f;
                while (diff < -180f) diff += 360f;
                bearing = normalize(bearing + diff * SMOOTHING);
            }

            log("two-point dist=" + (int) dist + "м, bearing="
                    + (int) bearing + "°");

            anchorLocation = new Location(loc);

        } catch (Throwable t) {
            // Никогда не падаем внутри хука
        }
    }

    private static float normalize(float deg) {
        deg = deg % 360f;
        if (deg < 0) deg += 360f;
        return deg;
    }

    // ------------------------------------------------------------------
    // Инжект bearing в датчик вращения
    // ------------------------------------------------------------------

    private static void hookRotationVector(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                    "android.hardware.SystemSensorManager$SensorEventQueue",
                    lpparam.classLoader,
                    "dispatchSensorEvent",
                    int.class, float[].class, int.class, long.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                int handle = (int) param.args[0];
                                float[] values = (float[]) param.args[1];

                                if (handle != 11 || values.length < 4) return;
                                if (!hasBearing) return;

                                float half = (float) Math.toRadians(bearing) / 2f;
                                float s = (float) Math.sin(half);
                                float c = (float) Math.cos(half);

                                values[0] = 0f;   // x
                                values[1] = 0f;   // y
                                values[2] = s;    // z
                                values[3] = c;    // w

                                log("inject rot-vec bearing=" + (int) bearing);
                            } catch (Throwable ignored) {}
                        }
                    }
            );
            XposedBridge.log(TAG + ": dispatchSensorEvent захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": dispatch hook fail: " + t);
        }
    }

    // ------------------------------------------------------------------

    private static void log(String msg) {
        long now = System.currentTimeMillis();
        if (now - lastLog > 500) {
            lastLog = now;
            XposedBridge.log(TAG + ": " + msg);
        }
    }
}