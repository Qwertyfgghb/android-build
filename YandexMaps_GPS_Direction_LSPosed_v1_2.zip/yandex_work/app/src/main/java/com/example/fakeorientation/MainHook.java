package com.example.fakeorientation;

import android.location.Location;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    // Как часто менять сторону света, когда стоишь
    private static final long STEP_INTERVAL_MS = 1500L;

    // Минимальная скорость, которую видит Яндекс.
    // При 0 он ПРЯЧЕТ конус — поэтому поднимаем до 0.8 м/с.
    private static final float MIN_SPEED_FOR_CONE = 0.8f;

    private static final boolean VERBOSE = true;

    private static volatile int cardinalStep = 0;
    private static volatile long lastStepTime = 0L;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook на " + lpparam.packageName);

        hookHasBearing();
        hookHasSpeed();
        hookGetSpeed();     // ← ключевой фикс
        hookGetBearing();
    }

    private static void hookHasBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                });
        } catch (Throwable ignored) {}
    }

    private static void hookHasSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                });
        } catch (Throwable ignored) {}
    }

    // ==================================================================
    // Ключевой фикс: пока стоишь, GPS даёт speed=0, и Яндекс прячет конус.
    // Всегда возвращаем минимум, чтобы конус рисовался.
    // ==================================================================
    private static void hookGetSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        Object r = param.getResult();
                        float s = (r instanceof Float) ? (Float) r : 0f;
                        if (s < MIN_SPEED_FOR_CONE) {
                            param.setResult(MIN_SPEED_FOR_CONE);
                        }
                    }
                });
        } catch (Throwable ignored) {}
    }

    // ==================================================================
    // Признак "стою" — не getSpeed() (он теперь зафейкан),
    // а realBearing == 0 (GPS не дал направление).
    // ==================================================================
    private static void hookGetBearing() {
        XposedHelpers.findAndHookMethod(Location.class, "getBearing",
            new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    Object res = param.getResult();
                    float realBearing = (res instanceof Float) ? (Float) res : 0f;

                    // Идём — реальный GPS-bearing, не трогаем
                    if (realBearing != 0f) {
                        if (VERBOSE) {
                            XposedBridge.log(TAG + ": real " + realBearing + "°");
                        }
                        return;
                    }

                    // Стоим — крутим по 4 сторонам
                    long now = System.currentTimeMillis();
                    if (now - lastStepTime > STEP_INTERVAL_MS) {
                        cardinalStep = (cardinalStep + 1) % 4;
                        lastStepTime = now;
                    }
                    float fake = cardinalStep * 90f;
                    param.setResult(fake);

                    if (VERBOSE) {
                        XposedBridge.log(TAG + ": standing fake " + fake + "°");
                    }
                }
            });
        XposedBridge.log(TAG + ": getBearing захукан");
    }
}