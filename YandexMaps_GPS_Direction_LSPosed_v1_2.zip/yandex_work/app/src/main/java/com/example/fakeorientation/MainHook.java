package com.example.fakeorientation;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    // Абсолютный азимут (0..360), посчитанный из магнитометра + акселерометра
    private static volatile float heading = 0f;
    private static volatile boolean hasHeading = false;

    private static long lastBearingLog = 0L;
    private static long lastMagLog = 0L;

    private static boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook установлен на " + lpparam.packageName);

        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (started) return;
                        started = true;
                        Context ctx = (Context) param.thisObject;
                        startSensors(ctx);
                        startLocation(ctx);
                    }
                }
        );

        // getBearing → отдаём азимут
        XposedHelpers.findAndHookMethod(
                Location.class, "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        long now = System.currentTimeMillis();
                        if (now - lastBearingLog > 2000) {
                            lastBearingLog = now;
                            XposedBridge.log(TAG + ": getBearing (heading="
                                    + heading + ", hasHeading=" + hasHeading + ")");
                        }
                        if (hasHeading) {
                            param.setResult(heading);
                        }
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "getSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(0f);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );
    }

    // ------------------------------------------------------------------
    // Датчики: магнитометр + акселерометр → абсолютный азимут
    // ------------------------------------------------------------------

    private static void startSensors(Context context) {
        SensorManager sm = (SensorManager)
                context.getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) {
            XposedBridge.log(TAG + ": SensorManager == null");
            return;
        }

        // Пробуем сначала калиброванный магнитометр, потом сырой
        Sensor mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        boolean uncal = false;
        if (mag == null) {
            mag = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED);
            uncal = true;
        }
        Sensor accel = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        if (mag == null) {
            XposedBridge.log(TAG + ": магнитометр ОТСУТСТВУЕТ физически");
            return;
        }
        if (accel == null) {
            XposedBridge.log(TAG + ": акселерометр отсутствует");
            return;
        }

        XposedBridge.log(TAG + ": магнитометр=" + mag.getName()
                + " uncal=" + uncal);
        XposedBridge.log(TAG + ": акселерометр=" + accel.getName());

        final SensorEventListener listener = new MagAccelListener(uncal);
        sm.registerListener(listener, mag, SensorManager.SENSOR_DELAY_GAME);
        sm.registerListener(listener, accel, SensorManager.SENSOR_DELAY_GAME);
    }

    private static class MagAccelListener implements SensorEventListener {

        private final boolean magUncalibrated;
        private final float[] magVec = new float[3];
        private final float[] accelVec = new float[3];

        private boolean haveMag = false;
        private boolean haveAccel = false;

        private final float[] R = new float[9];
        private final float[] I = new float[9];
        private final float[] orient = new float[3];

        MagAccelListener(boolean magUncalibrated) {
            this.magUncalibrated = magUncalibrated;
        }

        @Override
        public void onSensorChanged(SensorEvent event) {
            int type = event.sensor.getType();

            if (type == Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED) {
                // values[0..2] — сырое поле, values[3..5] — bias
                magVec[0] = event.values[0] - event.values[3];
                magVec[1] = event.values[1] - event.values[4];
                magVec[2] = event.values[2] - event.values[5];
                haveMag = true;
            } else if (type == Sensor.TYPE_MAGNETIC_FIELD) {
                magVec[0] = event.values[0];
                magVec[1] = event.values[1];
                magVec[2] = event.values[2];
                haveMag = true;
            } else if (type == Sensor.TYPE_ACCELEROMETER) {
                accelVec[0] = event.values[0];
                accelVec[1] = event.values[1];
                accelVec[2] = event.values[2];
                haveAccel = true;
            }

            // Лог раз в 1 сек — что видим от магнитометра
            long now = System.currentTimeMillis();
            if (now - lastMagLog > 1000 && haveMag) {
                lastMagLog = now;
                XposedBridge.log(TAG + ": mag=[" + magVec[0] + ", "
                        + magVec[1] + ", " + magVec[2] + "]"
                        + " accel=[" + accelVec[0] + ", "
                        + accelVec[1] + ", " + accelVec[2] + "]");
            }

            if (!haveMag || !haveAccel) return;

            boolean ok = SensorManager.getRotationMatrix(R, I, accelVec, magVec);
            if (!ok) return;

            SensorManager.getOrientation(R, orient);
            float az = (float) Math.toDegrees(orient[0]);
            if (az < 0) az += 360f;
            heading = az;
            hasHeading = true;
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
            XposedBridge.log(TAG + ": accuracy changed for "
                    + sensor.getStringType() + " = " + accuracy);
        }
    }

    // ------------------------------------------------------------------
    // GPS
    // ------------------------------------------------------------------

    private static void startLocation(Context context) {
        LocationManager lm = (LocationManager)
                context.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return;

        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {}
            @Override public void onStatusChanged(String s, int i, Bundle b) {}
            @Override public void onProviderEnabled(String s) {}
            @Override public void onProviderDisabled(String s) {}
        };

        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                    1000L, 0f, listener);
            XposedBridge.log(TAG + ": GPS listener запущен");
        } catch (Exception e) {
            XposedBridge.log(TAG + ": GPS error: " + e);
        }
    }
}