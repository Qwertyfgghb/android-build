package com.example.fakeorientation;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    private static volatile float baseHeading = 0f;
    private static volatile boolean baseHeadingSet = false;

    // Текущий относительный поворот (yaw), рассчитанный из гироскопа
    private static volatile float yaw = 0f;
    private static volatile boolean hasYaw = false;

    private static long lastBearingLog = 0L;
    private static long lastYawLog = 0L;
    private static long lastGyroLog = 0L;

    private static boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook установлен на " + lpparam.packageName);

        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (started) return;
                        started = true;
                        Context ctx = (Context) param.thisObject;
                        startSensors(ctx);
                        startLocation(ctx);
                    }
                }
        );

        // getBearing → отдаём baseHeading + yaw
        XposedHelpers.findAndHookMethod(
                Location.class, "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        long now = System.currentTimeMillis();
                        if (now - lastBearingLog > 2000) {
                            lastBearingLog = now;
                            XposedBridge.log(TAG + ": getBearing (yaw="
                                    + yaw + ", base=" + baseHeading + ")");
                        }
                        if (!hasYaw) return;
                        float bearing = baseHeading + yaw;
                        bearing = ((bearing % 360f) + 360f) % 360f;
                        param.setResult(bearing);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // Скорость = 0 → карты рисуют конус
        XposedHelpers.findAndHookMethod(
                Location.class, "getSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(0f);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );
    }

    // ------------------------------------------------------------------
    // Датчики
    // ------------------------------------------------------------------

    private static void startSensors(Context context) {
        SensorManager sm = (SensorManager)
                context.getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) {
            XposedBridge.log(TAG + ": SensorManager == null");
            return;
        }

        // 1. Пытаемся работать через GYROSCOPE_UNCALIBRATED
        Sensor gyroUncal = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE_UNCALIBRATED);
        if (gyroUncal != null) {
            registerGyroListener(sm, gyroUncal);
        } else {
            XposedBridge.log(TAG + ": GYROSCOPE_UNCALIBRATED отсутствует");
        }

        // 2. Фолбэк — обычный GYROSCOPE (на случай, если первый не сработает)
        Sensor gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if (gyro != null && gyroUncal == null) {
            registerGyroListener(sm, gyro);
        }

        // 3. Логируем rotation_vector — но не используем, он у MTK фиктивный
        Sensor rv = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if (rv != null) {
            sm.registerListener(new SensorEventListener() {
                long cnt = 0;
                @Override
                public void onSensorChanged(SensorEvent event) {
                    if (cnt++ < 3) {
                        XposedBridge.log(TAG + ": ROT_VEC values=["
                                + event.values[0] + ", "
                                + event.values[1] + ", "
                                + event.values[2] + "]");
                    }
                }
                @Override public void onAccuracyChanged(Sensor s, int a) {}
            }, rv, SensorManager.SENSOR_DELAY_GAME);
        }
    }

    private static void registerGyroListener(SensorManager sm, Sensor sensor) {
        final int type = sensor.getType();

        SensorEventListener listener = new SensorEventListener() {

            private long lastTime = 0L;
            private float accumYaw = 0f;

            @Override
            public void onSensorChanged(SensorEvent event) {
                float zRad;
                if (type == Sensor.TYPE_GYROSCOPE_UNCALIBRATED) {
                    // values[2] = угловая скорость по оси Z (рад/с)
                    // values[5] = оценка дрейфа по оси Z
                    zRad = event.values[2] - event.values[5];
                } else {
                    // обычный GYROSCOPE: values[2] = угловая скорость по Z
                    zRad = event.values[2];
                }

                long now = event.timestamp;
                if (lastTime != 0L) {
                    float dt = (now - lastTime) * 1e-9f;

                    // Игнорируем большие скачки времени
                    if (dt > 0f && dt < 0.5f) {
                        // Рад → градусы. Знак минус — потому что при повороте
                        // телефона вправо по часовой стрелке, вокруг оси Z,
                        // система координат Android даёт отрицательную скорость
                        accumYaw += (float) Math.toDegrees(zRad) * dt;
                        yaw = -accumYaw;
                        hasYaw = true;
                    }
                }
                lastTime = now;

                // Логируем раз в 500 мс
                long ms = System.currentTimeMillis();
                if (ms - lastGyroLog > 500) {
                    lastGyroLog = ms;
                    XposedBridge.log(TAG + ": gyro z=" + zRad
                            + " rad/s, yaw=" + yaw);
                }
            }

            @Override
            public void onAccuracyChanged(Sensor s, int a) {}
        };

        sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME);
        XposedBridge.log(TAG + ": слушаю " + sensor.getStringType()
                + " (" + sensor.getName() + ")");
    }

    // ------------------------------------------------------------------
    // GPS
    // ------------------------------------------------------------------

    private static void startLocation(Context context) {
        LocationManager lm = (LocationManager)
                context.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return;

        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if (location == null) return;
                if (!baseHeadingSet
                        && location.hasBearing()
                        && location.getBearing() != 0f) {
                    baseHeading = location.getBearing();
                    baseHeadingSet = true;
                    XposedBridge.log(TAG + ": baseHeading = " + baseHeading);
                }
            }
            @Override public void onStatusChanged(String s, int i, Bundle b) {}
            @Override public void onProviderEnabled(String s) {}
            @Override public void onProviderDisabled(String s) {}
        };

        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                    1000L, 0f, listener);
            XposedBridge.log(TAG + ": GPS listener запущен");
        } catch (Exception e) {
            XposedBridge.log(TAG + ": GPS error: " + e);
        }
    }
}