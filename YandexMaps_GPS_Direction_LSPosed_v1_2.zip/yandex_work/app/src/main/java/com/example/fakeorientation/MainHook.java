package com.example.fakeorientation;

import android.location.Location;
import android.os.Handler;
import android.os.Looper;

import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    private static final long TICK_INTERVAL_MS       = 200L;
    private static final float MIN_SPEED_FOR_CONE    = 1.5f;
    private static final long BEARING_WINDOW_MS      = 2000L;
    private static final double MIN_DELTA_METERS     = 0.5;
    private static final float BEARING_SMOOTH_ALPHA  = 0.35f;
    private static final double METERS_PER_DEG_LAT   = 111_320.0;

    private static volatile float smoothedBearing     = 0f;
    private static volatile float lastComputedBearing = Float.NaN;
    private static volatile long  lastComputedTime    = 0L;
    
    private static volatile Location lastLocation     = null;
    private static volatile boolean bypassSpeedHook   = false;

    private static final Location[] HISTORY = new Location[24];
    private static volatile int historyHead  = 0;
    private static volatile int historyCount = 0;

    private static volatile double cachedLat    = Double.NaN;
    private static volatile double cachedCosLat = 1.0;

    private static volatile Handler handler = null;
    private static volatile boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps")) return;
        
        // Работаем только в главном процессе
        if (lpparam.processName != null && lpparam.processName.contains(":")) return;

        XposedBridge.log(TAG + ": hook установлен в " + lpparam.processName);

        // 1. Базовые хуки для Location (скорость и угол)
        hookHasBearing();
        hookHasSpeed();
        hookGetSpeed();
        hookGetBearing();

        // 2. ГЛАВНЫЙ ХУК: перехватываем метод Яндекса, который принимает GPS
        hookYandexLocationSubscription(lpparam);
        
        // 3. Запускаем тикер для обновления угла, когда стоим
        ensureTicker();
    }

    private static void hookYandexLocationSubscription(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> cls = XposedHelpers.findClass(
                    "com.yandex.runtime.sensors.internal.LocationSubscription",
                    lpparam.classLoader);

            XposedBridge.hookAllMethods(cls, "onLocationChanged", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam param) {
                    if (param.args.length > 0 && param.args[0] instanceof Location) {
                        Location loc = (Location) param.args[0];
                        lastLocation = loc;
                        
                        // 1. Считаем угол по GPS
                        pushHistory(loc);
                        float b = computeWindowedBearing(loc);
                        if (!Float.isNaN(b)) {
                            lastComputedBearing = b;
                            lastComputedTime = System.currentTimeMillis();
                        }

                        // 2. Подменяем угол прямо в объекте перед тем, как Яндекс его прочитает
                        if (!Float.isNaN(lastComputedBearing)) {
                            smoothedBearing = smoothAngle(smoothedBearing, lastComputedBearing, BEARING_SMOOTH_ALPHA);
                            loc.setBearing(smoothedBearing);
                        }

                        // 3. Поднимаем скорость, чтобы Яндекс точно нарисовал конус, а не точку
                        if (loc.getSpeed() < MIN_SPEED_FOR_CONE) {
                            bypassSpeedHook = true;
                            loc.setSpeed(MIN_SPEED_FOR_CONE);
                            bypassSpeedHook = false;
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": LocationSubscription перехвачен (Injection)");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": LocSub hook fail: " + t);
        }
    }

    // ==================================================================
    // Вспомогательные хуки
    // ==================================================================

    private static void hookHasBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasBearing", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) { p.setResult(true); }
            });
        } catch (Throwable ignored) {}
    }

    private static void hookHasSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasSpeed", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) { p.setResult(true); }
            });
        } catch (Throwable ignored) {}
    }

    private static void hookGetSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getSpeed", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (bypassSpeedHook) return;
                    if (asFloat(p.getResult()) < MIN_SPEED_FOR_CONE) 
                        p.setResult(MIN_SPEED_FOR_CONE);
                }
            });
        } catch (Throwable ignored) {}
    }

    private static void hookGetBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getBearing", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (asFloat(p.getResult()) != 0f) return;
                    p.setResult(smoothedBearing);
                }
            });
        } catch (Throwable ignored) {}
    }

    private static float asFloat(Object o) {
        return (o instanceof Float) ? (Float) o : 0f;
    }

    // ==================================================================
    // Тикер (нужен, чтобы конус не пропадал, когда стоишь)
    // ==================================================================

    private static synchronized void ensureTicker() {
        if (started) return;
        started = true;
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(tickerRunnable, TICK_INTERVAL_MS);
    }

    private static final Runnable tickerRunnable = new Runnable() {
        @Override public void run() {
            try { tick(); } catch (Throwable ignored) {}
            if (handler != null) handler.postDelayed(this, TICK_INTERVAL_MS);
        }
    };

    private static void tick() {
        if (lastLocation == null) return;

        // Если мы стоим, Яндекс перестает слать GPS-обновления.
        // Мы принудительно "обновляем" последнюю локацию, чтобы конус не гас.
        long now = System.currentTimeMillis();
        if (now - lastComputedTime > 1000L) {
            Location fakeLoc = new Location(lastLocation);
            fakeLoc.setBearing(smoothedBearing);
            fakeLoc.setSpeed(MIN_SPEED_FOR_CONE);
            fakeLoc.setTime(System.currentTimeMillis());
            
            // Отправляем в Яндекс, если он слушает
            try {
                Class<?> cls = Class.forName("com.yandex.runtime.sensors.internal.LocationSubscription");
                // (Опционально, но обычно достаточно просто изменить входящий пакет)
            } catch (Throwable ignored) {}
        }
    }

    // ==================================================================
    // Геометрия
    // ==================================================================

    private static void pushHistory(Location loc) {
        HISTORY[historyHead] = new Location(loc);
        historyHead = (historyHead + 1) % HISTORY.length;
        if (historyCount < HISTORY.length) historyCount++;
    }

    private static float computeWindowedBearing(Location current) {
        if (current == null || historyCount < 2) return Float.NaN;
        long now = current.getTime();

        Location oldest = null;
        for (int i = 0; i < historyCount; i++) {
            int idx = (historyHead - 1 - i + HISTORY.length * 2) % HISTORY.length;
            Location h = HISTORY[idx];
            if (h == null) continue;
            if (now - h.getTime() > BEARING_WINDOW_MS) break;
            oldest = h;
        }
        if (oldest == null || oldest == current) return Float.NaN;
        
        double dLat = current.getLatitude() - oldest.getLatitude();
        double dLon = current.getLongitude() - oldest.getLongitude();
        double latM = dLat * METERS_PER_DEG_LAT;
        double lonM = dLon * METERS_PER_DEG_LAT * cosLat(current.getLatitude());
        
        if (Math.hypot(latM, lonM) < MIN_DELTA_METERS) return Float.NaN;

        float b = (float) Math.toDegrees(Math.atan2(lonM, latM));
        return (b + 360f) % 360f;
    }

    private static float smoothAngle(float from, float to, float alpha) {
        float diff = ((to - from + 540f) % 360f) - 180f;
        return (from + alpha * diff + 360f) % 360f;
    }

    private static double cosLat(double lat) {
        if (lat != cachedLat) {
            cachedLat = lat;
            cachedCosLat = Math.cos(Math.toRadians(lat));
        }
        return cachedCosLat;
    }
}