package com.example.fakeorientation;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    private static final long STEP_INTERVAL_MS = 1500L;
    private static final float MIN_SPEED_FOR_CONE = 0.8f;

    // Сдвиг координат в метрах — чтобы прошёл фильтр "по расстоянию" у Яндекса
    private static final double SHIFT_METERS = 8.0;

    private static final boolean VERBOSE = true;

    private static volatile int cardinalStep = 0;
    private static volatile long lastStepTime = 0L;
    private static volatile Location baseLocation = null;
    private static volatile boolean isInjecting = false;

    private static final List<LocationListener> listeners = new CopyOnWriteArrayList<>();
    private static final Set<String> hookedClasses = new HashSet<>();

    private static volatile Handler handler = null;
    private static volatile boolean tickerStarted = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook на " + lpparam.packageName
                + " proc=" + lpparam.processName);

        hookHasBearing();
        hookHasSpeed();
        hookGetSpeed();
        hookGetBearing();
        hookLocationManager();
        hookYandexLocationSubscription(lpparam);
    }

    private static void hookHasBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasBearing",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        p.setResult(true);
                    }
                });
        } catch (Throwable ignored) {}
    }

    private static void hookHasSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasSpeed",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        p.setResult(true);
                    }
                });
        } catch (Throwable ignored) {}
    }

    private static void hookGetSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getSpeed",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        Object r = p.getResult();
                        float s = (r instanceof Float) ? (Float) r : 0f;
                        if (s < MIN_SPEED_FOR_CONE) p.setResult(MIN_SPEED_FOR_CONE);
                    }
                });
        } catch (Throwable ignored) {}
    }

    private static void hookGetBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getBearing",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        Object res = p.getResult();
                        float real = (res instanceof Float) ? (Float) res : 0f;
                        if (real != 0f) return;  // реальный GPS — не трогаем
                        long now = System.currentTimeMillis();
                        if (now - lastStepTime > STEP_INTERVAL_MS) {
                            cardinalStep = (cardinalStep + 1) % 4;
                            lastStepTime = now;
                        }
                        p.setResult(cardinalStep * 90f);
                    }
                });
        } catch (Throwable ignored) {}
    }

    private static void hookLocationManager() {
        XC_MethodHook capture = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    for (Object a : p.args) {
                        if (a instanceof LocationListener) {
                            LocationListener ll = (LocationListener) a;
                            if (!listeners.contains(ll)) {
                                listeners.add(ll);
                                XposedBridge.log(TAG + ": listener захвачен: "
                                        + ll.getClass().getName());
                                hookListenerInstance(ll);
                            }
                            break;
                        }
                    }
                } catch (Throwable ignored) {}
            }
        };
        try { XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                String.class, long.class, float.class, LocationListener.class, capture); } catch (Throwable ignored) {}
        try { XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                long.class, float.class, android.location.Criteria.class,
                LocationListener.class, Looper.class, capture); } catch (Throwable ignored) {}
        try { XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                String.class, long.class, float.class, LocationListener.class,
                Looper.class, capture); } catch (Throwable ignored) {}

        XposedBridge.log(TAG + ": LocationManager захукан");
    }

    // Логируем, что Yandex-овский LocationSubscription реально получает наши inject'ы
    private static void hookYandexLocationSubscription(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> cls = XposedHelpers.findClass(
                "com.yandex.runtime.sensors.internal.LocationSubscription",
                lpparam.classLoader);

            XposedBridge.hookAllMethods(cls, "onLocationChanged", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    if (p.args.length > 0 && p.args[0] instanceof Location) {
                        Location l = (Location) p.args[0];
                        if (VERBOSE) {
                            XposedBridge.log(TAG + ": YandexLocSub ← lat="
                                + String.format("%.6f", l.getLatitude())
                                + " lon=" + String.format("%.6f", l.getLongitude())
                                + " brg=" + l.getBearing()
                                + " spd=" + l.getSpeed());
                        }
                    }
                }
            });
            XposedBridge.log(TAG + ": YandexLocationSubscription захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": LocSub hook fail: " + t);
        }
    }

    private static void hookListenerInstance(LocationListener ll) {
        Class<?> cls = ll.getClass();
        String name = cls.getName();
        if (hookedClasses.contains(name)) return;
        hookedClasses.add(name);

        try {
            XposedBridge.hookAllMethods(cls, "onLocationChanged", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (isInjecting) return;   // не обновляем базу от своих же inject'ов
                    if (p.args.length == 0) return;
                    if (!(p.args[0] instanceof Location)) return;
                    baseLocation = new Location((Location) p.args[0]);
                    if (!tickerStarted) {
                        tickerStarted = true;
                        startTicker();
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hook onLocationChanged fail " + name + ": " + t);
        }
    }

    private static void startTicker() {
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        XposedBridge.log(TAG + ": тикер запущен, base lat="
                + (baseLocation != null ? baseLocation.getLatitude() : "null"));
        handler.postDelayed(tickerRunnable, STEP_INTERVAL_MS);
    }

    private static final Runnable tickerRunnable = new Runnable() {
        @Override public void run() {
            try { tick(); } catch (Throwable t) {
                XposedBridge.log(TAG + ": tick error: " + t);
            }
            if (handler != null) handler.postDelayed(this, STEP_INTERVAL_MS);
        }
    };

    private static void tick() {
        Location base = baseLocation;
        if (base == null) return;

        long now = System.currentTimeMillis();
        if (now - lastStepTime > STEP_INTERVAL_MS) {
            cardinalStep = (cardinalStep + 1) % 4;
            lastStepTime = now;
        }
        float fake = cardinalStep * 90f;

        Location inject = buildShifted(base, fake);

        if (VERBOSE) {
            XposedBridge.log(TAG + ": inject " + fake + "° → "
                    + listeners.size() + " listener(s) lat="
                    + String.format("%.6f", inject.getLatitude())
                    + " lon=" + String.format("%.6f", inject.getLongitude()));
        }

        isInjecting = true;
        try {
            for (LocationListener ll : listeners) {
                try { ll.onLocationChanged(inject); } catch (Throwable ignored) {}
            }
        } finally {
            isInjecting = false;
        }
    }

    /** Сдвигает координаты на SHIFT_METERS в сторону bearingDeg. */
    private static Location buildShifted(Location base, float bearingDeg) {
        Location inj = new Location(base);

        double R = 6371000.0;
        double rad = Math.toRadians(bearingDeg);
        double dLatDeg = Math.toDegrees(SHIFT_METERS * Math.cos(rad) / R);
        double dLonDeg = Math.toDegrees(SHIFT_METERS * Math.sin(rad)
                / (R * Math.cos(Math.toRadians(base.getLatitude()))));

        inj.setLatitude(base.getLatitude() + dLatDeg);
        inj.setLongitude(base.getLongitude() + dLonDeg);
        inj.setBearing(bearingDeg);
        inj.setSpeed(MIN_SPEED_FOR_CONE);
        inj.setTime(System.currentTimeMillis());
        inj.setElapsedRealtimeNanos(System.nanoTime());
        return inj;
    }
}