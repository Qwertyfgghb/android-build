package com.example.fakeorientation;

import android.location.Location;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    // Порог скорости (м/с). Ниже — считаем что стоим.
    // 0.5 м/с ≈ 1.8 км/ч. Хочешь крутить даже при очень медленном шаге —
    // поставь 1.0f или 1.5f.
    private static final float MOVE_THRESHOLD_MS = 0.5f;

    // Как часто переключать сторону света, пока стоим (мс).
    private static final long STEP_INTERVAL_MS = 1500L;

    // Текущая «сторона света»: 0=С, 1=В, 2=Ю, 3=З
    private static volatile int cardinalStep = 0;
    private static volatile long lastStepTime = 0L;

    // Логи. Выключи, когда надоест — спам логов сам по себе тормозит.
    private static final boolean VERBOSE = true;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook на " + lpparam.packageName
                + ", threshold=" + MOVE_THRESHOLD_MS + " м/с, step="
                + STEP_INTERVAL_MS + " мс");

        hookHasBearing();
        hookGetBearing();
    }

    // ------------------------------------------------------------------
    // hasBearing() = true. Иначе Яндекс может вообще не рисовать конус,
    // даже если getBearing() что-то вернул.
    // ------------------------------------------------------------------
    private static void hookHasBearing() {
        try {
            XposedHelpers.findAndHookMethod(
                    Location.class, "hasBearing",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            param.setResult(true);
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hasBearing hook fail: " + t);
        }
    }

    // ------------------------------------------------------------------
    // Главный хук: движение — реальный bearing, стоянка — крутим по 4 сторонам
    // ------------------------------------------------------------------
    private static void hookGetBearing() {
        XposedHelpers.findAndHookMethod(
                Location.class, "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        Location loc = (Location) param.thisObject;
                        if (loc == null) return;

                        Object res = param.getResult();
                        float realBearing = (res instanceof Float) ? (Float) res : 0f;

                        // getSpeed() НЕ захукан — вызов безопасен, рекурсии нет.
                        float speed = loc.getSpeed();

                        // --- Двигаемся: оставляем как есть ---
                        if (speed >= MOVE_THRESHOLD_MS && realBearing != 0f) {
                            if (VERBOSE) {
                                XposedBridge.log(TAG + ": moving → реальный "
                                        + realBearing + "° speed=" + speed);
                            }
                            return;
                        }

                        // --- Стоим: крутим конус по 4 сторонам ---
                        long now = System.currentTimeMillis();
                        if (now - lastStepTime > STEP_INTERVAL_MS) {
                            cardinalStep = (cardinalStep + 1) % 4;
                            lastStepTime = now;
                        }
                        float fake = cardinalStep * 90f; // 0, 90, 180, 270
                        param.setResult(fake);

                        if (VERBOSE) {
                            XposedBridge.log(TAG + ": standing → fake "
                                    + fake + "° speed=" + speed);
                        }
                    }
                }
        );
        XposedBridge.log(TAG + ": getBearing захукан");
    }
}