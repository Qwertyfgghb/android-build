package com.example.fakeorientation;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;

import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    private static final long STEP_INTERVAL_MS = 1500L;
    private static final float MIN_SPEED_FOR_CONE = 0.8f;
    private static final boolean VERBOSE = true;

    private static volatile int cardinalStep = 0;
    private static volatile long lastStepTime = 0L;
    private static volatile Location lastLoc = null;

    private static final List<LocationListener> listeners = new CopyOnWriteArrayList<>();
    private static volatile Object yandexWrapper = null;
    private static volatile Method yandexOnLocationReceived = null;

    private static volatile Handler handler = null;
    private static volatile boolean tickerStarted = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook на " + lpparam.packageName);

        hookHasBearing();
        hookHasSpeed();
        hookGetSpeed();
        hookGetBearing();
        hookLocationManager();
        hookYandexWrapper(lpparam);
    }

    private static void hookHasBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasBearing",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        p.setResult(true);
                    }
                });
        } catch (Throwable ignored) {}
    }

    private static void hookHasSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasSpeed",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        p.setResult(true);
                    }
                });
        } catch (Throwable ignored) {}
    }

    private static void hookGetSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getSpeed",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        Object r = p.getResult();
                        float s = (r instanceof Float) ? (Float) r : 0f;
                        if (s < MIN_SPEED_FOR_CONE) p.setResult(MIN_SPEED_FOR_CONE);
                    }
                });
        } catch (Throwable ignored) {}
    }

    private static void hookGetBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getBearing",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        Object res = p.getResult();
                        float real = (res instanceof Float) ? (Float) res : 0f;
                        if (real != 0f) return;  // идём — реальный GPS, не трогаем
                        long now = System.currentTimeMillis();
                        if (now - lastStepTime > STEP_INTERVAL_MS) {
                            cardinalStep = (cardinalStep + 1) % 4;
                            lastStepTime = now;
                        }
                        p.setResult(cardinalStep * 90f);
                    }
                });
        } catch (Throwable ignored) {}
    }

    // Ловим LocationListener'ы, которые регистрирует Яндекс через LocationManager
    private static void hookLocationManager() {
        XC_MethodHook capture = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    for (Object a : p.args) {
                        if (a instanceof LocationListener) {
                            LocationListener ll = (LocationListener) a;
                            if (!listeners.contains(ll)) {
                                listeners.add(ll);
                                if (VERBOSE) XposedBridge.log(TAG + ": listener захвачен");
                            }
                            return;
                        }
                    }
                } catch (Throwable ignored) {}
            }
        };
        try { XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                String.class, long.class, float.class, LocationListener.class, capture); } catch (Throwable ignored) {}
        try { XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                long.class, float.class, android.location.Criteria.class,
                LocationListener.class, Looper.class, capture); } catch (Throwable ignored) {}
        try { XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                String.class, long.class, float.class, LocationListener.class,
                Looper.class, capture); } catch (Throwable ignored) {}
    }

    // Главное: ловим нативный callback Яндекс.Карт и запоминаем
    // последний Location + сам объект wrapper'а, чтобы потом injectить свой
    private static void hookYandexWrapper(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> cls = XposedHelpers.findClass(
                "com.yandex.runtime.sensors.internal.NativeLocationSubscriptionWrapper",
                lpparam.classLoader);

            XposedBridge.hookAllMethods(cls, "onLocationReceived", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        if (p.args.length == 0) return;
                        Object first = p.args[0];
                        if (!(first instanceof Location)) return;
                        Location loc = (Location) first;
                        lastLoc = new Location(loc);

                        if (yandexWrapper == null) {
                            yandexWrapper = p.thisObject;
                            try {
                                yandexOnLocationReceived = (Method) p.method;
                                yandexOnLocationReceived.setAccessible(true);
                            } catch (Throwable ignored) {}
                            XposedBridge.log(TAG + ": yandex wrapper захвачен");
                            startTicker();
                        }
                    } catch (Throwable ignored) {}
                }
            });
            XposedBridge.log(TAG + ": NativeLocationSubscriptionWrapper захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": wrapper hook fail: " + t);
        }
    }

    // Тикер: каждые STEP_INTERVAL_MS шлём фейковый Location с новым bearing
    private static void startTicker() {
        if (tickerStarted) return;
        tickerStarted = true;
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        XposedBridge.log(TAG + ": тикер запущен");

        handler.postDelayed(new Runnable() {
            @Override public void run() {
                try { tick(); } catch (Throwable t) {
                    XposedBridge.log(TAG + ": tick error: " + t);
                }
                handler.postDelayed(this, STEP_INTERVAL_MS);
            }
        }, STEP_INTERVAL_MS);
    }

    private static void tick() {
        Location base = lastLoc;
        if (base == null) return;

        long now = System.currentTimeMillis();
        if (now - lastStepTime > STEP_INTERVAL_MS) {
            cardinalStep = (cardinalStep + 1) % 4;
            lastStepTime = now;
        }
        float fake = cardinalStep * 90f;

        Location inject = new Location(base);
        inject.setBearing(fake);
        inject.setSpeed(MIN_SPEED_FOR_CONE);

        if (VERBOSE) XposedBridge.log(TAG + ": inject " + fake + "°");

        // Способ 1: нативный callback Яндекс.Карт
        if (yandexWrapper != null && yandexOnLocationReceived != null) {
            try {
                // если у метода >1 аргумента — заполним остальные значениями из base
                Class<?>[] types = yandexOnLocationReceived.getParameterTypes();
                Object[] args = new Object[types.length];
                args[0] = inject;
                for (int i = 1; i < types.length; i++) {
                    Class<?> t = types[i];
                    if (t == int.class) args[i] = 0;
                    else if (t == long.class) args[i] = 0L;
                    else if (t == float.class) args[i] = 0f;
                    else if (t == double.class) args[i] = 0d;
                    else if (t == boolean.class) args[i] = false;
                    else args[i] = null;
                }
                yandexOnLocationReceived.invoke(yandexWrapper, args);
                return;
            } catch (Throwable t) {
                if (VERBOSE) XposedBridge.log(TAG + ": wrapper invoke fail: " + t);
            }
        }

        // Способ 2 (fallback): обычные LocationListener'ы
        for (LocationListener ll : listeners) {
            try { ll.onLocationChanged(inject); } catch (Throwable ignored) {}
        }
    }
}