package com.example.fakeorientation;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    // Направление "старта" (взятое из GPS)
    private static volatile float baseHeading = 0f;
    private static volatile boolean baseHeadingSet = false;

    // Текущий yaw от GAME_ROTATION_VECTOR
    private static volatile float yaw = 0f;
    private static volatile boolean hasYaw = false;

    // Чтобы не спамить логи
    private static long lastYawLog = 0L;
    private static long lastBearingLog = 0L;
    private static long lastSensorLog = 0L;

    private static boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook установлен на " + lpparam.packageName);

        // 1. Стартуем сенсоры и GPS
        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (started) return;
                        started = true;
                        Context ctx = (Context) param.thisObject;
                        startSensors(ctx);
                        startLocation(ctx);
                    }
                }
        );

        // 2. Подменяем getBearing() + логируем, что его вызвали
        XposedHelpers.findAndHookMethod(
                Location.class, "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        long now = System.currentTimeMillis();
                        if (now - lastBearingLog > 2000) {
                            lastBearingLog = now;
                            XposedBridge.log(TAG + ": getBearing ВЫЗВАН (hasYaw="
                                    + hasYaw + ", yaw=" + yaw
                                    + ", base=" + baseHeading + ")");
                        }

                        if (!hasYaw) return;
                        float bearing = baseHeading + yaw;
                        bearing = ((bearing % 360f) + 360f) % 360f;
                        param.setResult(bearing);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // Скорость = 0 → карты рисуют конус
        XposedHelpers.findAndHookMethod(
                Location.class, "getSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(0f);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // 3. ДИАГНОСТИКА: перехватываем доставку сенсорных событий,
        //    чтобы понять, читает ли Яндекс датчики напрямую.
        hookSensorDispatch(lpparam);
    }

    // ------------------------------------------------------------------
    // Хук на SystemSensorManager$SensorEventQueue.dispatchSensorEvent
    // ------------------------------------------------------------------

    private static void hookSensorDispatch(XC_LoadPackage.LoadPackageParam lpparam) {

        // Разные версии Android — разные сигнатуры. Пробуем по очереди.
        // Самая распространённая: (int handle, float[] values, int accuracy, long timestamp)
        Class<?>[] sig1 = new Class<?>[]{int.class, float[].class, int.class, long.class};
        // Некоторые сборки: (int handle, float[] values, int accuracy, long timestamp, int sensorType)
        Class<?>[] sig2 = new Class<?>[]{int.class, float[].class, int.class, long.class, int.class};

        XC_MethodHook hook = new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                try {
                    Object[] args = param.args;
                    if (args == null || args.length < 2) return;

                    int handle = ((Number) args[0]).intValue();
                    float[] values = (float[]) args[1];

                    long now = System.currentTimeMillis();
                    if (now - lastSensorLog < 500) return; // троттлинг
                    lastSensorLog = now;

                    StringBuilder sb = new StringBuilder();
                    sb.append(TAG).append(": dispatch handle=").append(handle)
                      .append(" values=[");
                    for (int i = 0; i < values.length; i++) {
                        if (i > 0) sb.append(", ");
                        sb.append(values[i]);
                    }
                    sb.append("]");
                    XposedBridge.log(sb.toString());

                } catch (Throwable t) {
                    XposedBridge.log(TAG + ": ошибка в dispatch hook: " + t);
                }
            }
        };

        // Пробуем сигнатуру 1
        try {
            XposedHelpers.findAndHookMethod(
                    "android.hardware.SystemSensorManager$SensorEventQueue",
                    lpparam.classLoader,
                    "dispatchSensorEvent",
                    sig1[0], sig1[1], sig1[2], sig1[3],
                    hook
            );
            XposedBridge.log(TAG + ": dispatchSensorEvent захукан (sig1)");
            return;
        } catch (Throwable t1) {
            XposedBridge.log(TAG + ": sig1 не подошла: " + t1.getMessage());
        }

        // Пробуем сигнатуру 2
        try {
            XposedHelpers.findAndHookMethod(
                    "android.hardware.SystemSensorManager$SensorEventQueue",
                    lpparam.classLoader,
                    "dispatchSensorEvent",
                    sig2[0], sig2[1], sig2[2], sig2[3], sig2[4],
                    hook
            );
            XposedBridge.log(TAG + ": dispatchSensorEvent захукан (sig2)");
            return;
        } catch (Throwable t2) {
            XposedBridge.log(TAG + ": sig2 не подошла: " + t2.getMessage());
        }

        XposedBridge.log(TAG + ": не удалось захукать dispatchSensorEvent ни одной сигнатурой");
    }

    // ------------------------------------------------------------------
    // Сенсоры
    // ------------------------------------------------------------------

    private static void startSensors(Context context) {
        SensorManager sm = (SensorManager)
                context.getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) {
            XposedBridge.log(TAG + ": SensorManager == null");
            return;
        }

        Sensor sensor = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);
        if (sensor == null) {
            XposedBridge.log(TAG + ": GAME_ROTATION_VECTOR null, пробую ROTATION_VECTOR");
            sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        }
        if (sensor == null) {
            XposedBridge.log(TAG + ": rotation-датчиков нет, беру GYROSCOPE");
            sensor = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        }
        if (sensor == null) {
            XposedBridge.log(TAG + ": датчиков ориентации/гироскопа нет вообще!");
            return;
        }

        final int type = sensor.getType();

        SensorEventListener listener = new SensorEventListener() {

            private final float[] rotationMatrix = new float[9];
            private final float[] orientation = new float[3];
            private float firstYaw = Float.NaN;

            private long lastGyroTime = 0L;
            private float accumulatedYaw = 0f;

            @Override
            public void onSensorChanged(SensorEvent event) {
                if (type == Sensor.TYPE_GAME_ROTATION_VECTOR
                        || type == Sensor.TYPE_ROTATION_VECTOR) {

                    SensorManager.getRotationMatrixFromVector(
                            rotationMatrix, event.values);
                    SensorManager.getOrientation(rotationMatrix, orientation);

                    float currentYaw = (float) Math.toDegrees(orientation[0]);
                    if (Float.isNaN(firstYaw)) {
                        firstYaw = currentYaw;
                    }
                    yaw = currentYaw - firstYaw;
                    hasYaw = true;

                } else if (type == Sensor.TYPE_GYROSCOPE) {
                    if (lastGyroTime != 0L) {
                        float dt = (event.timestamp - lastGyroTime) * 1e-9f;
                        accumulatedYaw +=
                                (float) Math.toDegrees(event.values[2]) * dt;
                        yaw = -accumulatedYaw;
                        hasYaw = true;
                    }
                    lastGyroTime = event.timestamp;
                }

                // Логируем yaw раз в 500 мс
                long now = System.currentTimeMillis();
                if (now - lastYawLog > 500) {
                    lastYawLog = now;
                    XposedBridge.log(TAG + ": yaw=" + yaw + " (hasYaw=" + hasYaw + ")");
                }
            }

            @Override
            public void onAccuracyChanged(Sensor s, int accuracy) {}
        };

        sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME);
        XposedBridge.log(TAG + ": sensor listener запущен (" + sensor.getName()
                + ", type=" + sensor.getStringType() + ")");
    }

    // ------------------------------------------------------------------
    // GPS
    // ------------------------------------------------------------------

    private static void startLocation(Context context) {
        LocationManager lm = (LocationManager)
                context.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return;

        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if (location == null) return;

                if (!baseHeadingSet
                        && location.hasBearing()
                        && location.getBearing() != 0f) {
                    baseHeading = location.getBearing();
                    baseHeadingSet = true;
                    XposedBridge.log(TAG + ": baseHeading = " + baseHeading);
                }
            }
            @Override public void onStatusChanged(String s, int i, Bundle b) {}
            @Override public void onProviderEnabled(String s) {}
            @Override public void onProviderDisabled(String s) {}
        };

        try {
            lm.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    1000L,
                    0f,
                    listener
            );
            XposedBridge.log(TAG + ": GPS listener запущен");
        } catch (Exception e) {
            XposedBridge.log(TAG + ": GPS error: " + e);
        }
    }
}