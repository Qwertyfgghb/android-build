package com.example.fakeorientation;

import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    private static final long TICK_INTERVAL_MS       = 200L; // Немного реже тик (200 мс)
    private static final long MOVE_HYSTERESIS_MS     = 400L;
    private static final long DELTA_FRESH_MS         = 2000L;
    private static final long SENSOR_INJECT_INTERVAL_MS = 150L;

    private static final float STAND_STILL_MAX    = 0.10f;
    // 1.0 м/с (3.6 км/ч) — Яндекс стабильно рисует конус
    private static final float MIN_SPEED_FOR_CONE = 1.0f; 

    private static final int    HISTORY_SIZE      = 48;
    private static final long   BEARING_WINDOW_MS = 1500L; // Окно поменьше, чтобы угол был острее
    private static final double MIN_DELTA_METERS  = 0.5;
    private static final double MAX_JUMP_METERS   = 15.0;  // Защита от телепортов GPS

    private static final float  BEARING_SMOOTH_ALPHA = 0.35f;
    private static final double SHIFT_METERS         = 4.0; // Сдвиг 4 метра
    private static final double EARTH_RADIUS_M       = 6_371_000.0;
    private static final double METERS_PER_DEG_LAT   = 111_320.0;

    private static volatile Location baseLocation = null;
    private static volatile boolean  isInjecting  = false;

    private static volatile float smoothedBearing     = 0f;
    private static volatile float lastInjectedBearing = 0f;

    private static volatile float lastComputedDeltaBearing = Float.NaN;
    private static volatile long  lastDeltaBearingTime     = 0L;

    private static volatile long    lastMoveTime      = 0L;
    private static volatile boolean wasMoving         = false;
    private static volatile boolean justStartedMoving = false;
    private static volatile boolean everMoved         = false;

    private static volatile boolean bypassSpeedHook = false;

    private static volatile double cachedLat    = Double.NaN;
    private static volatile double cachedCosLat = 1.0;
    private static volatile long lastSensorInjectMs = 0L;

    private static final Location[] HISTORY = new Location[HISTORY_SIZE];
    private static volatile int historyHead  = 0;
    private static volatile int historyCount = 0;

    private static final List<LocationListener> LISTENERS    = new CopyOnWriteArrayList<>();
    private static final Set<String>            HOOKED_NAMES = new HashSet<>();

    private static volatile Handler handler = null;
    private static volatile int rotationVectorHandle = -1;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps")) return;

        // ФИЛЬТР ПРОЦЕССОВ: игнорируем :Metrica и :passport, работаем только в главном
        if (lpparam.processName != null && lpparam.processName.contains(":")) {
            return; 
        }

        XposedBridge.log(TAG + ": hook установлен в " + lpparam.processName);

        hookHasBearing();
        hookHasSpeed();
        hookGetSpeed();
        hookGetBearing();
        hookLocationManager();
        hookRegisterListener();
        hookSensorDispatch(lpparam);
    }

    private static void hookHasBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasBearing",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(true);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookHasSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasSpeed",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(true);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookGetSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getSpeed",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            if (bypassSpeedHook) return;
                            if (asFloat(p.getResult()) < MIN_SPEED_FOR_CONE)
                                p.setResult(MIN_SPEED_FOR_CONE);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookGetBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getBearing",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            if (isInjecting) return;
                            if (asFloat(p.getResult()) != 0f) return;
                            p.setResult(lastInjectedBearing);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static float asFloat(Object o) {
        return (o instanceof Float) ? (Float) o : 0f;
    }

    private static float readRawSpeed(Location loc) {
        if (loc == null) return 0f;
        bypassSpeedHook = true;
        try {
            return loc.getSpeed();
        } catch (Throwable t) {
            return 0f;
        } finally {
            bypassSpeedHook = false;
        }
    }

    private static void hookLocationManager() {
        XC_MethodHook capture = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                captureListener(p.args);
            }
        };
        try {
            XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                    String.class, long.class, float.class, LocationListener.class, capture);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                    long.class, float.class, android.location.Criteria.class,
                    LocationListener.class, Looper.class, capture);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                    String.class, long.class, float.class, LocationListener.class,
                    Looper.class, capture);
        } catch (Throwable ignored) {}
    }

    private static void captureListener(Object[] args) {
        if (args == null) return;
        for (Object a : args) {
            if (!(a instanceof LocationListener)) continue;
            LocationListener ll = (LocationListener) a;
            if (LISTENERS.contains(ll)) return;
            LISTENERS.add(ll);
            XposedBridge.log(TAG + ": захвачен LocationListener: " + ll.getClass().getSimpleName());
            hookListenerInstance(ll);
            return;
        }
    }

    private static void hookListenerInstance(LocationListener ll) {
        Class<?> cls  = ll.getClass();
        String   name = cls.getName();
        if (!HOOKED_NAMES.add(name)) return;

        try {
            XposedBridge.hookAllMethods(cls, "onLocationChanged", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (isInjecting) return;
                    if (p.args.length == 0) return;
                    if (!(p.args[0] instanceof Location)) return;

                    onRealLocation((Location) p.args[0]);
                }
            });
        } catch (Throwable ignored) {}
    }

    private static void onRealLocation(Location incoming) {
        // ФИЛЬТР ТЕЛЕПОРТАЦИИ: если точка прыгнула слишком далеко — игнорируем
        if (baseLocation != null) {
            double dist = distanceMeters(baseLocation, incoming);
            long dt = Math.abs(incoming.getTime() - baseLocation.getTime());
            if (dt > 0 && dt < 3000) {
                // Скорость пешехода максимум 3.5 м/с, велосипеда 15 м/с. 
                // Если скорость больше 15 м/с (54 км/ч) — это 100% глюк GPS.
                if ((dist / (dt / 1000.0)) > 15.0) {
                    return; 
                }
            }
        }

        long now = System.currentTimeMillis();

        pushHistory(incoming);

        float b = computeWindowedBearing(incoming);
        boolean hasNewBearing = !Float.isNaN(b);
        if (hasNewBearing) {
            lastComputedDeltaBearing = b;
            lastDeltaBearingTime     = now;
        }

        baseLocation = new Location(incoming);
        ensureTicker();

        float raw = readRawSpeed(incoming);
        boolean moving = raw >= STAND_STILL_MAX;

        if (moving) {
            lastMoveTime = now;
            if (!wasMoving) {
                wasMoving = true;
                justStartedMoving = true;
                XposedBridge.log(TAG + ": НАЧАЛО ДВИЖЕНИЯ. Скорость: " + raw);
                if (handler != null) {
                    handler.removeCallbacks(tickerRunnable);
                    handler.post(tickerRunnable);
                }
            }
        } else {
            if (now - lastMoveTime >= MOVE_HYSTERESIS_MS) {
                wasMoving = false;
            }
        }
    }

    private static void pushHistory(Location loc) {
        HISTORY[historyHead] = new Location(loc);
        historyHead = (historyHead + 1) % HISTORY_SIZE;
        if (historyCount < HISTORY_SIZE) historyCount++;
    }

    private static float computeWindowedBearing(Location current) {
        if (current == null || historyCount < 2) return Float.NaN;
        long now = current.getTime();

        Location oldest = null;
        for (int i = 0; i < historyCount; i++) {
            int idx = (historyHead - 1 - i + HISTORY_SIZE * 2) % HISTORY_SIZE;
            Location h = HISTORY[idx];
            if (h == null) continue;
            if (now - h.getTime() > BEARING_WINDOW_MS) break;
            oldest = h;
        }
        if (oldest == null || oldest == current) return Float.NaN;
        return bearingBetween(oldest, current);
    }

    private static float bearingBetween(Location from, Location to) {
        if (from == null || to == null) return Float.NaN;

        double dLat = to.getLatitude()  - from.getLatitude();
        double dLon = to.getLongitude() - from.getLongitude();

        double latM = dLat * METERS_PER_DEG_LAT;
        double lonM = dLon * METERS_PER_DEG_LAT * cosLat(to.getLatitude());

        if (Math.hypot(latM, lonM) < MIN_DELTA_METERS) return Float.NaN;

        float b = (float) Math.toDegrees(Math.atan2(lonM, latM));
        return (b + 360f) % 360f;
    }

    private static float smoothAngle(float from, float to, float alpha) {
        float diff = ((to - from + 540f) % 360f) - 180f;
        return (from + alpha * diff + 360f) % 360f;
    }

    private static double cosLat(double lat) {
        if (lat != cachedLat) {
            cachedLat    = lat;
            cachedCosLat = Math.cos(Math.toRadians(lat));
        }
        return cachedCosLat;
    }
    
    private static double distanceMeters(Location a, Location b) {
        double dLat = (b.getLatitude()  - a.getLatitude())  * METERS_PER_DEG_LAT;
        double dLon = (b.getLongitude() - a.getLongitude()) * METERS_PER_DEG_LAT * cosLat(b.getLatitude());
        return Math.hypot(dLat, dLon);
    }

    private static synchronized void ensureTicker() {
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        if (handler.hasCallbacks(tickerRunnable)) return;
        handler.postDelayed(tickerRunnable, TICK_INTERVAL_MS);
    }

    private static final Runnable tickerRunnable = new Runnable() {
        @Override public void run() {
            try { tick(); } catch (Throwable ignored) {}
            if (handler != null) handler.postDelayed(this, TICK_INTERVAL_MS);
        }
    };

    private static void tick() {
        Location base = baseLocation;
        if (base == null) return;
        if (LISTENERS.isEmpty()) return;

        long  now      = System.currentTimeMillis();
        float rawSpeed = readRawSpeed(base);

        boolean moving;
        if (rawSpeed >= STAND_STILL_MAX) {
            lastMoveTime = now;
            moving = true;
        } else {
            moving = (now - lastMoveTime) < MOVE_HYSTERESIS_MS;
        }
        wasMoving = moving;

        if (!moving) {
            if (!everMoved) return;
            injectToListeners(buildShifted(base, lastInjectedBearing));
            return;
        }

        boolean fresh = (now - lastDeltaBearingTime) < DELTA_FRESH_MS
                && !Float.isNaN(lastComputedDeltaBearing);

        if (justStartedMoving) {
            if (fresh) {
                smoothedBearing       = lastComputedDeltaBearing;
                justStartedMoving     = false;
                everMoved             = true;
                lastSensorInjectMs    = 0L;
                XposedBridge.log(TAG + ": СНАП! Угол: " + smoothedBearing);
            } else {
                return;
            }
        } else {
            float target = fresh ? lastComputedDeltaBearing : smoothedBearing;
            smoothedBearing = smoothAngle(smoothedBearing, target, BEARING_SMOOTH_ALPHA);
        }

        lastInjectedBearing = smoothedBearing;
        injectToListeners(buildShifted(base, smoothedBearing));
        
        if (fresh) {
            XposedBridge.log(TAG + ": ДВИЖЕНИЕ. Скорость GPS: " + rawSpeed + " | Угол: " + Math.round(smoothedBearing));
        }
    }

    private static void injectToListeners(Location inject) {
        isInjecting = true;
        try {
            for (LocationListener ll : LISTENERS) {
                try { ll.onLocationChanged(inject); } catch (Throwable ignored) {}
            }
        } finally {
            isInjecting = false;
        }
    }

    private static Location buildShifted(Location base, float bearingDeg) {
        Location inj = new Location(base);

        double rad     = Math.toRadians(bearingDeg);
        double dLatDeg = Math.toDegrees(SHIFT_METERS * Math.cos(rad) / EARTH_RADIUS_M);
        double dLonDeg = Math.toDegrees(SHIFT_METERS * Math.sin(rad)
                / (EARTH_RADIUS_M * cosLat(base.getLatitude())));

        inj.setLatitude(base.getLatitude() + dLatDeg);
        inj.setLongitude(base.getLongitude() + dLonDeg);
        inj.setBearing(bearingDeg);
        inj.setSpeed(MIN_SPEED_FOR_CONE); 
        inj.setTime(System.currentTimeMillis());
        inj.setElapsedRealtimeNanos(System.nanoTime());

        if (Build.VERSION.SDK_INT >= 26) {
            inj.setBearingAccuracyDegrees(10f);
            inj.setSpeedAccuracyMetersPerSecond(0.5f);
        }

        return inj;
    }

    private static void hookRegisterListener() {
        XC_MethodHook hook = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    for (Object a : p.args) {
                        if (a instanceof Sensor) {
                            Sensor s = (Sensor) a;
                            if (s.getType() == Sensor.TYPE_ROTATION_VECTOR) {
                                rotationVectorHandle = XposedHelpers.getIntField(s, "mHandle");
                            }
                            break;
                        }
                    }
                } catch (Throwable ignored) {}
            }
        };
        try {
            XposedHelpers.findAndHookMethod(SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, hook);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, int.class, hook);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, Handler.class, hook);
        } catch (Throwable ignored) {}
    }

    private static void hookSensorDispatch(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                    "android.hardware.SystemSensorManager$SensorEventQueue",
                    lpparam.classLoader,
                    "dispatchSensorEvent",
                    int.class, float[].class, int.class, long.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam p) {
                            try {
                                int handle = (int) p.args[0];
                                if (handle != rotationVectorHandle) return;
                                if (!everMoved) return;

                                long now = System.currentTimeMillis();
                                if (now - lastSensorInjectMs < SENSOR_INJECT_INTERVAL_MS) return;

                                float[] v = (float[]) p.args[1];
                                if (v == null || v.length < 4) return;

                                lastSensorInjectMs = now;
                                applyFakeRotation(v, lastInjectedBearing);
                            } catch (Throwable ignored) {}
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void applyFakeRotation(float[] v, float headingDeg) {
        double half = Math.toRadians(headingDeg) / 2.0;
        v[0] = 0f;
        v[1] = 0f;
        v[2] = (float) Math.sin(half);
        v[3] = (float) Math.cos(half);
        if (v.length >= 5) v[4] = 0f;
    }
}