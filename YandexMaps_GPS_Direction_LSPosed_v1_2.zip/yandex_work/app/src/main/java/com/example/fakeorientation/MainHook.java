package com.example.fakeorientation;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";
    private static final float MIN_DISTANCE_M = 1.0f;
    private static final float SMOOTHING = 0.4f;

    private static volatile float bearing = 0f;
    private static volatile boolean hasBearing = false;

    private static Location anchorLocation = null;
    private static long lastLog = 0L;
    private static long lastHeartbeat = 0L;
    private static boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook установлен на " + lpparam.packageName);

        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (started) return;
                        started = true;
                        Context ctx = (Context) param.thisObject;
                        startLocation(ctx);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "getSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(0f);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        hookRotationVector(lpparam);
    }

    private static void hookRotationVector(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                    "android.hardware.SystemSensorManager$SensorEventQueue",
                    lpparam.classLoader,
                    "dispatchSensorEvent",
                    int.class, float[].class, int.class, long.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            try {
                                int handle = (int) param.args[0];
                                float[] values = (float[]) param.args[1];

                                if (handle != 11 || values.length < 4) return;
                                if (!hasBearing) return;

                                float half = (float) Math.toRadians(bearing) / 2f;
                                float s = (float) Math.sin(half);
                                float c = (float) Math.cos(half);

                                values[0] = 0f;
                                values[1] = 0f;
                                values[2] = s;
                                values[3] = c;

                                log("inject rot-vec: bearing=" + (int) bearing);
                            } catch (Throwable ignored) {}
                        }
                    }
            );
            XposedBridge.log(TAG + ": dispatchSensorEvent захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": dispatch hook fail: " + t);
        }
    }

    // ------------------------------------------------------------------
    // GPS
    // ------------------------------------------------------------------

    private static void startLocation(Context context) {
        LocationManager lm = (LocationManager)
                context.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) {
            XposedBridge.log(TAG + ": LocationManager == null");
            return;
        }

        // Проверяем — включён ли GPS вообще
        try {
            boolean gpsEnabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
            boolean netEnabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            XposedBridge.log(TAG + ": gpsEnabled=" + gpsEnabled
                    + " netEnabled=" + netEnabled);
        } catch (Exception e) {
            XposedBridge.log(TAG + ": isProviderEnabled error: " + e);
        }

        // Последняя известная точка
        try {
            Location last = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (last == null) {
                last = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }
            if (last != null) {
                XposedBridge.log(TAG + ": lastKnown provider=" + last.getProvider()
                        + " lat=" + last.getLatitude()
                        + " lon=" + last.getLongitude()
                        + " acc=" + last.getAccuracy());
                anchorLocation = new Location(last);
            } else {
                XposedBridge.log(TAG + ": lastKnown = null");
            }
        } catch (Exception e) {
            XposedBridge.log(TAG + ": getLastKnownLocation error: " + e);
        }

        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                // ДИАГНОСТИКА: логируем КАЖДЫЙ приход без фильтров
                if (location != null) {
                    XposedBridge.log(TAG + ": LOCATION provider=" + location.getProvider()
                            + " lat=" + location.getLatitude()
                            + " lon=" + location.getLongitude()
                            + " acc=" + location.getAccuracy()
                            + " bearing=" + location.getBearing()
                            + " hasBearing=" + location.hasBearing()
                            + " speed=" + location.getSpeed());
                } else {
                    XposedBridge.log(TAG + ": LOCATION = null");
                }

                processLocation(location);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                XposedBridge.log(TAG + ": onStatusChanged provider=" + provider
                        + " status=" + status);
            }

            @Override
            public void onProviderEnabled(String provider) {
                XposedBridge.log(TAG + ": onProviderEnabled " + provider);
            }

            @Override
            public void onProviderDisabled(String provider) {
                XposedBridge.log(TAG + ": onProviderDisabled " + provider);
            }
        };

        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                    1000L, 0f, listener);
            XposedBridge.log(TAG + ": GPS listener запрошен");

            try {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                        1000L, 0f, listener);
                XposedBridge.log(TAG + ": Network listener запрошен");
            } catch (Exception e) {
                XposedBridge.log(TAG + ": Network listener fail: " + e);
            }
        } catch (SecurityException e) {
            XposedBridge.log(TAG + ": SecurityException — нет разрешения: " + e);
        } catch (Exception e) {
            XposedBridge.log(TAG + ": GPS error: " + e);
        }

        // Heartbeat — каждые 10 сек напомнит, что listener жив
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        Thread.sleep(10000L);
                    } catch (InterruptedException e) {
                        return;
                    }
                    XposedBridge.log(TAG + ": heartbeat, hasBearing=" + hasBearing
                            + ", bearing=" + bearing
                            + ", anchor=" + (anchorLocation != null));
                }
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private static void processLocation(Location location) {
        if (location == null) return;

        // Первое: если у локации есть свой bearing — берём его
        if (location.hasBearing() && location.getBearing() != 0f) {
            float gpsBearing = location.getBearing();
            if (!hasBearing) {
                bearing = gpsBearing;
                hasBearing = true;
            } else {
                float diff = gpsBearing - bearing;
                while (diff > 180f) diff -= 360f;
                while (diff < -180f) diff += 360f;
                bearing += diff * SMOOTHING;
                if (bearing < 0) bearing += 360f;
                if (bearing >= 360f) bearing -= 360f;
            }
            log("GPS native bearing=" + (int) gpsBearing
                    + "° итог=" + (int) bearing + "°");
            return;
        }

        // Второе: считаем по двум точкам
        if (anchorLocation == null) {
            anchorLocation = new Location(location);
            return;
        }

        float dist = location.distanceTo(anchorLocation);
        if (dist < MIN_DISTANCE_M) return;

        float raw = anchorLocation.bearingTo(location);
        if (raw < 0) raw += 360f;

        if (!hasBearing) {
            bearing = raw;
            hasBearing = true;
        } else {
            float diff = raw - bearing;
            while (diff > 180f) diff -= 360f;
            while (diff < -180f) diff += 360f;
            bearing += diff * SMOOTHING;
            if (bearing < 0) bearing += 360f;
            if (bearing >= 360f) bearing -= 360f;
        }

        log("GPS two-point dist=" + (int) dist + " м, bearing=" + (int) bearing + "°");
        anchorLocation = new Location(location);
    }

    private static void log(String msg) {
        long now = System.currentTimeMillis();
        if (now - lastLog > 500) {
            lastLog = now;
            XposedBridge.log(TAG + ": " + msg);
        }
    }
}