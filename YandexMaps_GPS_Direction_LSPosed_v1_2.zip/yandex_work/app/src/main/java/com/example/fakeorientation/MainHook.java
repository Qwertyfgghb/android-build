package com.example.fakeorientation;

import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    // ==== Тайминги (УСКОРЕНО) ====
    private static final long TICK_INTERVAL_MS   = 100L;  // Было 300L (обновляем 10 раз в секунду)
    private static final long MOVE_HYSTERESIS_MS = 500L;  // Было 1200L (быстро понимает, что ты остановился)
    private static final long DELTA_FRESH_MS     = 1500L; // Было 2500L

    // ==== Пороги (СНИЖЕНО) ====
    private static final float STAND_STILL_MAX    = 0.10f; // Было 0.35f (ловит самое слабое движение)
    private static final float MIN_SPEED_FOR_CONE = 1.0f;

    // ==== Окно истории для расчёта bearing (СУЖЕНО) ====
    private static final int    HISTORY_SIZE       = 32;    // Было 24
    private static final long   BEARING_WINDOW_MS  = 1000L; // Было 2500L (считает угол по свежим точкам)
    private static final double MIN_DELTA_METERS   = 0.3;   // Было 0.5 (хватает сдвига на 30 см)

    // ==== Сглаживание / геометрия (УСКОРЕНО И СМЯГЧЕНО) ====
    private static final float  BEARING_SMOOTH_ALPHA = 0.85f; // Было 0.5f (конус доворачивается моментально)
    private static final double SHIFT_METERS         = 4.0;   // Было 6.0 (чуть меньше сдвиг, чтобы не тормозила карта)

    private static final boolean VERBOSE = true;

    // ==== Состояние ====
    private static volatile Location baseLocation     = null;
    private static volatile boolean isInjecting       = false;

    private static volatile float smoothedBearing     = 0f;
    private static volatile float lastInjectedBearing = 0f;

    private static volatile float lastComputedDeltaBearing = Float.NaN;
    private static volatile long  lastDeltaBearingTime     = 0L;

    private static volatile long    lastMoveTime      = 0L;
    private static volatile boolean wasMoving         = false;
    private static volatile boolean justStartedMoving = false;
    private static volatile boolean everMoved         = false;

    private static volatile boolean bypassSpeedHook = false;

    // ---- Circular history ----
    private static final Location[] history = new Location[HISTORY_SIZE];
    private static volatile int historyHead  = 0;
    private static volatile int historyCount = 0;

    private static final List<LocationListener> listeners     = new CopyOnWriteArrayList<>();
    private static final Set<String>            hookedClasses = new HashSet<>();

    private static volatile Handler handler = null;

    private static volatile int rotationVectorHandle = -1;

    // ==================================================================
    // Entry
    // ==================================================================

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook на " + lpparam.packageName
                + " proc=" + lpparam.processName);

        hookHasBearing();
        hookHasSpeed();
        hookGetSpeed();
        hookGetBearing();
        hookLocationManager();
        hookYandexLocationSubscription(lpparam);
        hookRegisterListener(lpparam);
        hookSensorDispatch(lpparam);
    }

    // ==================================================================
    // Location хуки
    // ==================================================================

    private static void hookHasBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasBearing",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(true);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookHasSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasSpeed",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(true);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookGetSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getSpeed",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            if (bypassSpeedHook) return;
                            Object r = p.getResult();
                            float s = (r instanceof Float) ? (Float) r : 0f;
                            if (s < MIN_SPEED_FOR_CONE) p.setResult(MIN_SPEED_FOR_CONE);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookGetBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getBearing",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            if (isInjecting) return;
                            Object res = p.getResult();
                            float real = (res instanceof Float) ? (Float) res : 0f;
                            if (real != 0f) return;
                            p.setResult(lastInjectedBearing);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static float readRawSpeed(Location loc) {
        if (loc == null) return 0f;
        bypassSpeedHook = true;
        try {
            return loc.getSpeed();
        } catch (Throwable t) {
            return 0f;
        } finally {
            bypassSpeedHook = false;
        }
    }

    // ==================================================================
    // LocationManager / listener capture
    // ==================================================================

    private static void hookLocationManager() {
        XC_MethodHook capture = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    for (Object a : p.args) {
                        if (a instanceof LocationListener) {
                            LocationListener ll = (LocationListener) a;
                            if (!listeners.contains(ll)) {
                                listeners.add(ll);
                                XposedBridge.log(TAG + ": listener захвачен: "
                                        + ll.getClass().getName());
                                hookListenerInstance(ll);
                            }
                            break;
                        }
                    }
                } catch (Throwable ignored) {}
            }
        };
        try {
            XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                    String.class, long.class, float.class, LocationListener.class, capture);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                    long.class, float.class, android.location.Criteria.class,
                    LocationListener.class, Looper.class, capture);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                    String.class, long.class, float.class, LocationListener.class,
                    Looper.class, capture);
        } catch (Throwable ignored) {}

        XposedBridge.log(TAG + ": LocationManager захукан");
    }

    private static void hookYandexLocationSubscription(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> cls = XposedHelpers.findClass(
                    "com.yandex.runtime.sensors.internal.LocationSubscription",
                    lpparam.classLoader);

            XposedBridge.hookAllMethods(cls, "onLocationChanged", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    if (!VERBOSE) return;
                    if (p.args.length > 0 && p.args[0] instanceof Location) {
                        Location l = (Location) p.args[0];
                        XposedBridge.log(TAG + ": YandexLocSub ← lat="
                                + String.format("%.6f", l.getLatitude())
                                + " lon=" + String.format("%.6f", l.getLongitude())
                                + " brg=" + l.getBearing()
                                + " spd=" + l.getSpeed());
                    }
                }
            });
            XposedBridge.log(TAG + ": YandexLocationSubscription захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": LocSub hook fail: " + t);
        }
    }

    private static void hookListenerInstance(LocationListener ll) {
        Class<?> cls  = ll.getClass();
        String   name = cls.getName();
        if (hookedClasses.contains(name)) return;
        hookedClasses.add(name);

        try {
            XposedBridge.hookAllMethods(cls, "onLocationChanged", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (isInjecting) return;
                    if (p.args.length == 0) return;
                    if (!(p.args[0] instanceof Location)) return;

                    Location incoming = (Location) p.args[0];
                    long now = System.currentTimeMillis();

                    pushHistory(incoming);
                    float b = computeWindowedBearing(incoming);
                    if (!Float.isNaN(b)) {
                        lastComputedDeltaBearing = b;
                        lastDeltaBearingTime     = now;
                    }

                    baseLocation = new Location(incoming);

                    ensureTicker();

                    float raw = readRawSpeed(incoming);
                    boolean moving = raw >= STAND_STILL_MAX;
                    if (moving) lastMoveTime = now;

                    if (moving && !wasMoving) {
                        wasMoving = true;
                        justStartedMoving = true;

                        if (handler != null) {
                            handler.removeCallbacks(tickerRunnable);
                            handler.post(tickerRunnable);
                            if (VERBOSE) XposedBridge.log(TAG
                                    + ": → движение поймано, снап-тик");
                        }
                    } else if (!moving) {
                        long sinceMove = now - lastMoveTime;
                        if (sinceMove >= MOVE_HYSTERESIS_MS) {
                            wasMoving = false;
                        }
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hook onLocationChanged fail " + name + ": " + t);
        }
    }

    // ==================================================================
    // История / геометрия
    // ==================================================================

    private static void pushHistory(Location loc) {
        history[historyHead] = new Location(loc);
        historyHead = (historyHead + 1) % HISTORY_SIZE;
        if (historyCount < HISTORY_SIZE) historyCount++;
    }

    private static float computeWindowedBearing(Location current) {
        if (current == null || historyCount < 2) return Float.NaN;
        long now = current.getTime();

        Location oldest = null;
        for (int i = 0; i < historyCount; i++) {
            int idx = (historyHead - 1 - i + HISTORY_SIZE * 2) % HISTORY_SIZE;
            Location h = history[idx];
            if (h == null) continue;
            long age = now - h.getTime();
            if (age > BEARING_WINDOW_MS) break;
            oldest = h;
        }
        if (oldest == null) return Float.NaN;
        return bearingBetween(oldest, current);
    }

    private static float bearingBetween(Location from, Location to) {
        if (from == null || to == null) return Float.NaN;

        double dLat = to.getLatitude()  - from.getLatitude();
        double dLon = to.getLongitude() - from.getLongitude();

        double latM = dLat * 111320.0;
        double lonM = dLon * 111320.0 * Math.cos(Math.toRadians(to.getLatitude()));

        if (Math.hypot(latM, lonM) < MIN_DELTA_METERS) return Float.NaN;

        float b = (float) Math.toDegrees(Math.atan2(lonM, latM));
        return (b + 360f) % 360f;
    }

    private static float smoothAngle(float from, float to, float alpha) {
        float diff = ((to - from + 540f) % 360f) - 180f;
        return (from + alpha * diff + 360f) % 360f;
    }

    // ==================================================================
    // Тикер
    // ==================================================================

    private static synchronized void ensureTicker() {
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        if (handler.hasCallbacks(tickerRunnable)) return;

        XposedBridge.log(TAG + ": тикер запущен, base lat="
                + (baseLocation != null ? baseLocation.getLatitude() : "null"));
        handler.postDelayed(tickerRunnable, TICK_INTERVAL_MS);
    }

    private static final Runnable tickerRunnable = new Runnable() {
        @Override public void run() {
            try { tick(); } catch (Throwable t) {
                XposedBridge.log(TAG + ": tick error: " + t);
            }
            if (handler != null) handler.postDelayed(this, TICK_INTERVAL_MS);
        }
    };

    private static void tick() {
        Location base = baseLocation;
        if (base == null) return;

        long  now      = System.currentTimeMillis();
        float rawSpeed = readRawSpeed(base);

        // ---- Гистерезис ----
        boolean moving;
        if (rawSpeed >= STAND_STILL_MAX) {
            lastMoveTime = now;
            moving = true;
        } else {
            moving = (now - lastMoveTime) < MOVE_HYSTERESIS_MS;
        }
        wasMoving = moving;

        if (!moving) {
            // ================= СТОИМ =================
            if (!everMoved) {
                if (VERBOSE && (now % 5000) < TICK_INTERVAL_MS)
                    XposedBridge.log(TAG + ": idle (ещё не двигались)");
                return;
            }

            if (VERBOSE && (now % 5000) < TICK_INTERVAL_MS)
                XposedBridge.log(TAG + ": idle → держим " 
                        + String.format("%.1f", lastInjectedBearing) + "°");

            Location inject = buildShifted(base, lastInjectedBearing);
            isInjecting = true;
            try {
                for (LocationListener ll : listeners) {
                    try { ll.onLocationChanged(inject); } catch (Throwable ignored) {}
                }
            } finally {
                isInjecting = false;
            }
            return;
        }

        // ================= ЕДЕМ =================
        boolean fresh = (now - lastDeltaBearingTime) < DELTA_FRESH_MS
                && !Float.isNaN(lastComputedDeltaBearing);

        float target = fresh ? lastComputedDeltaBearing : smoothedBearing;

        if (justStartedMoving) {
            smoothedBearing   = target;
            justStartedMoving = false;
            everMoved         = true;
            if (VERBOSE) XposedBridge.log(TAG
                    + ": ★ snap → " + String.format("%.1f", smoothedBearing) + "°");
        } else {
            smoothedBearing = smoothAngle(smoothedBearing, target, BEARING_SMOOTH_ALPHA);
        }

        lastInjectedBearing = smoothedBearing;

        if (VERBOSE) {
            String state = (rawSpeed >= STAND_STILL_MAX) ? "move" : "move(hyst)";
            XposedBridge.log(TAG + ": " + state
                    + " raw=" + rawSpeed
                    + " window=" + String.format("%.1f", lastComputedDeltaBearing)
                    + " → inject " + String.format("%.1f", smoothedBearing) + "°");
        }

        Location inject = buildShifted(base, smoothedBearing);

        isInjecting = true;
        try {
            for (LocationListener ll : listeners) {
                try { ll.onLocationChanged(inject); } catch (Throwable ignored) {}
            }
        } finally {
            isInjecting = false;
        }
    }

    private static Location buildShifted(Location base, float bearingDeg) {
        Location inj = new Location(base);

        double R   = 6371000.0;
        double rad = Math.toRadians(bearingDeg);
        double dLatDeg = Math.toDegrees(SHIFT_METERS * Math.cos(rad) / R);
        double dLonDeg = Math.toDegrees(SHIFT_METERS * Math.sin(rad)
                / (R * Math.cos(Math.toRadians(base.getLatitude()))));

        inj.setLatitude(base.getLatitude() + dLatDeg);
        inj.setLongitude(base.getLongitude() + dLonDeg);
        inj.setBearing(bearingDeg);
        inj.setSpeed(MIN_SPEED_FOR_CONE);
        inj.setTime(System.currentTimeMillis());
        inj.setElapsedRealtimeNanos(System.nanoTime());

        if (Build.VERSION.SDK_INT >= 26) {
            inj.setBearingAccuracyDegrees(10f);
            inj.setSpeedAccuracyMetersPerSecond(0.5f);
        }

        return inj;
    }

    // ==================================================================
    // Sensor
    // ==================================================================

    private static void hookRegisterListener(XC_LoadPackage.LoadPackageParam lpparam) {
        XC_MethodHook hook = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    for (Object a : p.args) {
                        if (a instanceof Sensor) {
                            Sensor s = (Sensor) a;
                            if (s.getType() == Sensor.TYPE_ROTATION_VECTOR) {
                                int h = XposedHelpers.getIntField(s, "mHandle");
                                if (rotationVectorHandle != h) {
                                    rotationVectorHandle = h;
                                    XposedBridge.log(TAG + ": rotation_vector handle = " + h);
                                }
                            }
                            break;
                        }
                    }
                } catch (Throwable ignored) {}
            }
        };
        try {
            XposedHelpers.findAndHookMethod(SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, hook);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, int.class, hook);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, Handler.class, hook);
        } catch (Throwable ignored) {}
    }

    private static void hookSensorDispatch(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                    "android.hardware.SystemSensorManager$SensorEventQueue",
                    lpparam.classLoader,
                    "dispatchSensorEvent",
                    int.class, float[].class, int.class, long.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam p) {
                            try {
                                int handle = (int) p.args[0];
                                if (handle != rotationVectorHandle) return;

                                float[] v = (float[]) p.args[1];
                                if (v == null || v.length < 4) return;

                                if (!everMoved) return;

                                applyFakeRotation(v, lastInjectedBearing);
                            } catch (Throwable ignored) {}
                        }
                    });
            XposedBridge.log(TAG + ": dispatchSensorEvent захукан (rotation_vector)");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": dispatch hook fail: " + t);
        }
    }

    private static void applyFakeRotation(float[] v, float headingDeg) {
        double half = Math.toRadians(headingDeg) / 2.0;
        v[0] = 0f;
        v[1] = 0f;
        v[2] = (float) Math.sin(half);
        v[3] = (float) Math.cos(half);
        if (v.length >= 5) v[4] = 0f;
    }
}