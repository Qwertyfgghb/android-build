package com.example.fakeorientation;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.SystemClock;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    // Направление "старта" (взято из GPS) — к нему прибавляем повороты телефона
    private static volatile float baseHeading = 0f;
    private static volatile boolean baseHeadingSet = false;

    // Текущий yaw от GAME_ROTATION_VECTOR (угол поворота телефона от старта)
    private static volatile float yaw = 0f;
    private static volatile boolean hasYaw = false;

    private static boolean started = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook установлен на " + lpparam.packageName);

        XposedHelpers.findAndHookMethod(
                "android.app.Application",
                lpparam.classLoader,
                "onCreate",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (started) return;
                        started = true;
                        Context ctx = (Context) param.thisObject;
                        startSensors(ctx);
                        startLocation(ctx);
                    }
                }
        );

        // Отдаём итоговый bearing = baseHeading + yaw
        XposedHelpers.findAndHookMethod(
                Location.class, "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (!hasYaw) return;
                        float bearing = baseHeading + yaw;
                        // нормализуем к 0..360
                        bearing = ((bearing % 360f) + 360f) % 360f;
                        param.setResult(bearing);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );

        // Скорость = 0 → карты рисуют конус, а не стрелку
        XposedHelpers.findAndHookMethod(
                Location.class, "getSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(0f);
                    }
                }
        );

        XposedHelpers.findAndHookMethod(
                Location.class, "hasSpeed",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(true);
                    }
                }
        );
    }

    // ------------------------------------------------------------------
    // Датчики без магнитометра: используем GAME_ROTATION_VECTOR
    // ------------------------------------------------------------------

    private static void startSensors(Context context) {
        SensorManager sm = (SensorManager)
                context.getSystemService(Context.SENSOR_SERVICE);
        if (sm == null) {
            XposedBridge.log(TAG + ": SensorManager == null");
            return;
        }

        // Пробуем сначала GAME_ROTATION_VECTOR (не требует магнитометра)
        Sensor sensor = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);

        // Фолбэк: обычный ROTATION_VECTOR (если вдруг у устройства всё-таки есть магнитометр)
        if (sensor == null) {
            XposedBridge.log(TAG + ": GAME_ROTATION_VECTOR недоступен, пробую ROTATION_VECTOR");
            sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        }

        // Второй фолбэк: гироскоп напрямую (интегрируем сам)
        if (sensor == null) {
            XposedBridge.log(TAG + ": нет rotation-датчиков, беру гироскоп");
            sensor = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        }

        if (sensor == null) {
            XposedBridge.log(TAG + ": датчиков ориентации/гироскопа нет вообще!");
            return;
        }

        final int type = sensor.getType();

        SensorEventListener listener = new SensorEventListener() {

            private final float[] rotationMatrix = new float[9];
            private final float[] orientation = new float[3];
            private float firstYaw = Float.NaN;

            // для прямого гироскопа
            private long lastGyroTime = 0L;
            private float accumulatedYaw = 0f;

            @Override
            public void onSensorChanged(SensorEvent event) {
                if (type == Sensor.TYPE_GAME_ROTATION_VECTOR
                        || type == Sensor.TYPE_ROTATION_VECTOR) {

                    SensorManager.getRotationMatrixFromVector(
                            rotationMatrix, event.values);
                    SensorManager.getOrientation(rotationMatrix, orientation);
                    float currentYaw = (float) Math.toDegrees(orientation[0]);

                    if (Float.isNaN(firstYaw)) {
                        firstYaw = currentYaw;
                    }

                    // yaw — смещение относительно первого замера
                    yaw = currentYaw - firstYaw;
                    hasYaw = true;

                } else if (type == Sensor.TYPE_GYROSCOPE) {
                    // Интегрируем угловую скорость вокруг оси Z (вертикальная)
                    if (lastGyroTime != 0L) {
                        float dt = (event.timestamp - lastGyroTime) * 1e-9f;
                        // event.values[2] — угловая скорость по Z в рад/с
                        accumulatedYaw += (float) Math.toDegrees(event.values[2]) * dt;
                        yaw = -accumulatedYaw; // знак: подбирается эмпирически
                        hasYaw = true;
                    }
                    lastGyroTime = event.timestamp;
                }
            }

            @Override
            public void onAccuracyChanged(Sensor s, int accuracy) {}
        };

        sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME);
        XposedBridge.log(TAG + ": sensor listener запущен (" + sensor.getName()
                + ", type=" + sensor.getStringType() + ")");
    }

    // ------------------------------------------------------------------
    // GPS — нужен только чтобы задать базовое направление
    // ------------------------------------------------------------------

    private static void startLocation(Context context) {
        LocationManager lm = (LocationManager)
                context.getSystemService(Context.LOCATION_SERVICE);
        if (lm == null) return;

        LocationListener listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if (location == null) return;

                // Первое валидное GPS-направление используем как базовое
                if (!baseHeadingSet && location.hasBearing()
                        && location.getBearing() != 0f) {
                    baseHeading = location.getBearing();
                    baseHeadingSet = true;
                    XposedBridge.log(TAG + ": baseHeading = " + baseHeading);
                }
            }
            @Override public void onStatusChanged(String s, int i, Bundle b) {}
            @Override public void onProviderEnabled(String s) {}
            @Override public void onProviderDisabled(String s) {}
        };

        try {
            lm.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    1000L,
                    0f,
                    listener
            );
            XposedBridge.log(TAG + ": GPS listener запущен");
        } catch (Exception e) {
            XposedBridge.log(TAG + ": GPS error: " + e);
        }
    }
}