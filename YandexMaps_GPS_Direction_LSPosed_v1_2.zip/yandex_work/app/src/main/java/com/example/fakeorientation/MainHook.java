package com.example.fakeorientation;

import android.location.Location;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    // Куда должна смотреть стрелка (градусы):
    //   0 = север, 90 = восток, 180 = юг, 270 = запад
    private static final float FAKE_BEARING = 90f;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {

        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook на " + lpparam.packageName
                + ", fake bearing = " + FAKE_BEARING + "°");

        hookGetBearing();
        hookHasBearing();  // чтобы Яндекс не игнорировал значение
    }

    private static void hookGetBearing() {
        XposedHelpers.findAndHookMethod(
                Location.class, "getBearing",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        // ВАЖНО: никаких loc.getBearing() тут! Только param.setResult()
                        param.setResult(FAKE_BEARING);
                    }
                }
        );
        XposedBridge.log(TAG + ": Location.getBearing захукан");
    }

    // Многие приложения проверяют hasBearing() и игнорируют значение, если false.
    // Заставляем всегда возвращать true.
    private static void hookHasBearing() {
        try {
            XposedHelpers.findAndHookMethod(
                    Location.class, "hasBearing",
                    new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam param) {
                            param.setResult(true);
                        }
                    }
            );
            XposedBridge.log(TAG + ": Location.hasBearing захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hasBearing hook fail: " + t);
        }
    }
}