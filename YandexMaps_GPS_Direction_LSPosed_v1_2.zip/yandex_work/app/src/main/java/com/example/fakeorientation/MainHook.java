package com.example.fakeorientation;

import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    // Как часто менять сторону света на стоянке (мс)
    private static final long STEP_INTERVAL_MS = 1500L;

    // Минимальная скорость, чтобы Яндекс не прятал конус (м/с)
    private static final float MIN_SPEED_FOR_CONE = 0.8f;

    // Порог «я реально двигаюсь» — выше него inject отключается (м/с)
    private static final float MOVE_THRESHOLD_MS = 0.5f;

    // Сдвиг координат для inject (м)
    private static final double SHIFT_METERS = 8.0;

    private static final boolean VERBOSE = true;

    private static volatile int cardinalStep = 0;
    private static volatile long lastStepTime = 0L;
    private static volatile Location baseLocation = null;
    private static volatile boolean isInjecting = false;

    // Флаг: true — значит сейчас мы читаем РЕАЛЬНУЮ скорость,
    // хук getSpeed должен пропустить модификацию
    private static volatile boolean bypassSpeedHook = false;

    private static final List<LocationListener> listeners = new CopyOnWriteArrayList<>();
    private static final Set<String> hookedClasses = new HashSet<>();

    private static volatile Handler handler = null;
    private static volatile boolean tickerStarted = false;

    private static volatile int rotationVectorHandle = -1;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook на " + lpparam.packageName
                + " proc=" + lpparam.processName);

        hookHasBearing();
        hookHasSpeed();
        hookGetSpeed();
        hookGetBearing();
        hookLocationManager();
        hookYandexLocationSubscription(lpparam);
        hookRegisterListener(lpparam);
        hookSensorDispatch(lpparam);
    }

    // ==================================================================
    // Location
    // ==================================================================

    private static void hookHasBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasBearing",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(true);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookHasSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasSpeed",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            p.setResult(true);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookGetSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getSpeed",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            // Если мы сами читаем скорость — не трогаем
                            if (bypassSpeedHook) return;
                            Object r = p.getResult();
                            float s = (r instanceof Float) ? (Float) r : 0f;
                            if (s < MIN_SPEED_FOR_CONE) p.setResult(MIN_SPEED_FOR_CONE);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    private static void hookGetBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getBearing",
                    new XC_MethodHook() {
                        @Override protected void afterHookedMethod(MethodHookParam p) {
                            Object res = p.getResult();
                            float real = (res instanceof Float) ? (Float) res : 0f;
                            if (real != 0f) return; // реальный GPS — не трогаем

                            long now = System.currentTimeMillis();
                            if (now - lastStepTime > STEP_INTERVAL_MS) {
                                cardinalStep = (cardinalStep + 1) % 4;
                                lastStepTime = now;
                            }
                            p.setResult(cardinalStep * 90f);
                        }
                    });
        } catch (Throwable ignored) {}
    }

    /** Читает РЕАЛЬНУЮ скорость, минуя наш собственный хук getSpeed(). */
    private static float readRawSpeed(Location loc) {
        if (loc == null) return 0f;
        bypassSpeedHook = true;
        try {
            return loc.getSpeed();
        } catch (Throwable t) {
            return 0f;
        } finally {
            bypassSpeedHook = false;
        }
    }

    // ==================================================================
    // LocationManager / Listener
    // ==================================================================

    private static void hookLocationManager() {
        XC_MethodHook capture = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    for (Object a : p.args) {
                        if (a instanceof LocationListener) {
                            LocationListener ll = (LocationListener) a;
                            if (!listeners.contains(ll)) {
                                listeners.add(ll);
                                XposedBridge.log(TAG + ": listener захвачен: "
                                        + ll.getClass().getName());
                                hookListenerInstance(ll);
                            }
                            break;
                        }
                    }
                } catch (Throwable ignored) {}
            }
        };
        try {
            XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                    String.class, long.class, float.class, LocationListener.class, capture);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                    long.class, float.class, android.location.Criteria.class,
                    LocationListener.class, Looper.class, capture);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                    String.class, long.class, float.class, LocationListener.class,
                    Looper.class, capture);
        } catch (Throwable ignored) {}

        XposedBridge.log(TAG + ": LocationManager захукан");
    }

    private static void hookYandexLocationSubscription(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            Class<?> cls = XposedHelpers.findClass(
                    "com.yandex.runtime.sensors.internal.LocationSubscription",
                    lpparam.classLoader);

            XposedBridge.hookAllMethods(cls, "onLocationChanged", new XC_MethodHook() {
                @Override protected void beforeHookedMethod(MethodHookParam p) {
                    if (!VERBOSE) return;
                    if (p.args.length > 0 && p.args[0] instanceof Location) {
                        Location l = (Location) p.args[0];
                        XposedBridge.log(TAG + ": YandexLocSub ← lat="
                                + String.format("%.6f", l.getLatitude())
                                + " lon=" + String.format("%.6f", l.getLongitude())
                                + " brg=" + l.getBearing()
                                + " spd=" + l.getSpeed());
                    }
                }
            });
            XposedBridge.log(TAG + ": YandexLocationSubscription захукан");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": LocSub hook fail: " + t);
        }
    }

    private static void hookListenerInstance(LocationListener ll) {
        Class<?> cls = ll.getClass();
        String name = cls.getName();
        if (hookedClasses.contains(name)) return;
        hookedClasses.add(name);

        try {
            XposedBridge.hookAllMethods(cls, "onLocationChanged", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (isInjecting) return;
                    if (p.args.length == 0) return;
                    if (!(p.args[0] instanceof Location)) return;
                    baseLocation = new Location((Location) p.args[0]);
                    if (!tickerStarted) {
                        tickerStarted = true;
                        startTicker();
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": hook onLocationChanged fail " + name + ": " + t);
        }
    }

    // ==================================================================
    // Тикер
    // ==================================================================

    private static void startTicker() {
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        XposedBridge.log(TAG + ": тикер запущен, base lat="
                + (baseLocation != null ? baseLocation.getLatitude() : "null"));
        handler.postDelayed(tickerRunnable, STEP_INTERVAL_MS);
    }

    private static final Runnable tickerRunnable = new Runnable() {
        @Override public void run() {
            try { tick(); } catch (Throwable t) {
                XposedBridge.log(TAG + ": tick error: " + t);
            }
            if (handler != null) handler.postDelayed(this, STEP_INTERVAL_MS);
        }
    };

    private static void tick() {
        Location base = baseLocation;
        if (base == null) return;

        // ⬇️ Ключевой момент: если реально движемся — не inject'им
        float rawSpeed = readRawSpeed(base);
        if (rawSpeed >= MOVE_THRESHOLD_MS) {
            if (VERBOSE) XposedBridge.log(TAG + ": moving (raw=" + rawSpeed
                    + ") → inject пропущен, отдаём реальный GPS");
            return;
        }

        // ⬇️ Стоим — крутим по 4 сторонам
        long now = System.currentTimeMillis();
        if (now - lastStepTime > STEP_INTERVAL_MS) {
            cardinalStep = (cardinalStep + 1) % 4;
            lastStepTime = now;
        }
        float fake = cardinalStep * 90f;

        Location inject = buildShifted(base, fake);

        if (VERBOSE) {
            XposedBridge.log(TAG + ": standing → inject " + fake + "° → "
                    + listeners.size() + " listener(s)");
        }

        isInjecting = true;
        try {
            for (LocationListener ll : listeners) {
                try { ll.onLocationChanged(inject); } catch (Throwable ignored) {}
            }
        } finally {
            isInjecting = false;
        }
    }

    private static Location buildShifted(Location base, float bearingDeg) {
        Location inj = new Location(base);

        double R = 6371000.0;
        double rad = Math.toRadians(bearingDeg);
        double dLatDeg = Math.toDegrees(SHIFT_METERS * Math.cos(rad) / R);
        double dLonDeg = Math.toDegrees(SHIFT_METERS * Math.sin(rad)
                / (R * Math.cos(Math.toRadians(base.getLatitude()))));

        inj.setLatitude(base.getLatitude() + dLatDeg);
        inj.setLongitude(base.getLongitude() + dLonDeg);
        inj.setBearing(bearingDeg);
        inj.setSpeed(MIN_SPEED_FOR_CONE);
        inj.setTime(System.currentTimeMillis());
        inj.setElapsedRealtimeNanos(System.nanoTime());
        return inj;
    }

    // ==================================================================
    // Sensor
    // ==================================================================

    private static void hookRegisterListener(XC_LoadPackage.LoadPackageParam lpparam) {
        XC_MethodHook hook = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    for (Object a : p.args) {
                        if (a instanceof Sensor) {
                            Sensor s = (Sensor) a;
                            if (s.getType() == Sensor.TYPE_ROTATION_VECTOR) {
                                int h = XposedHelpers.getIntField(s, "mHandle");
                                if (rotationVectorHandle != h) {
                                    rotationVectorHandle = h;
                                    XposedBridge.log(TAG + ": rotation_vector handle = " + h);
                                }
                            }
                            break;
                        }
                    }
                } catch (Throwable ignored) {}
            }
        };
        try {
            XposedHelpers.findAndHookMethod(SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, hook);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, int.class, hook);
        } catch (Throwable ignored) {}
        try {
            XposedHelpers.findAndHookMethod(SensorManager.class, "registerListener",
                    SensorEventListener.class, Sensor.class, int.class, Handler.class, hook);
        } catch (Throwable ignored) {}
    }

    private static void hookSensorDispatch(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            XposedHelpers.findAndHookMethod(
                    "android.hardware.SystemSensorManager$SensorEventQueue",
                    lpparam.classLoader,
                    "dispatchSensorEvent",
                    int.class, float[].class, int.class, long.class,
                    new XC_MethodHook() {
                        @Override protected void beforeHookedMethod(MethodHookParam p) {
                            try {
                                int handle = (int) p.args[0];
                                if (handle != rotationVectorHandle) return;

                                // Если движемся — не подменяем датчик, пусть работает реально
                                Location base = baseLocation;
                                if (base != null && readRawSpeed(base) >= MOVE_THRESHOLD_MS) {
                                    return;
                                }

                                float[] v = (float[]) p.args[1];
                                if (v == null || v.length < 4) return;
                                float heading = cardinalStep * 90f;
                                applyFakeRotation(v, heading);
                            } catch (Throwable ignored) {}
                        }
                    });
            XposedBridge.log(TAG + ": dispatchSensorEvent захукан (rotation_vector)");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": dispatch hook fail: " + t);
        }
    }

    private static void applyFakeRotation(float[] v, float headingDeg) {
        double half = Math.toRadians(headingDeg) / 2.0;
        v[0] = 0f;
        v[1] = 0f;
        v[2] = (float) Math.sin(half);
        v[3] = (float) Math.cos(half);
        if (v.length >= 5) v[4] = 0f;
    }
}