package com.example.fakeorientation;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Handler;
import android.os.Looper;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "FakeOrientation";

    private static final long STEP_INTERVAL_MS = 1500L;
    private static final float MIN_SPEED_FOR_CONE = 0.8f;
    private static final boolean VERBOSE = true;

    private static volatile int cardinalStep = 0;
    private static volatile long lastStepTime = 0L;
    private static volatile Location lastLoc = null;

    private static final List<LocationListener> listeners = new CopyOnWriteArrayList<>();
    private static final Set<String> hookedListenerClasses = new HashSet<>();

    private static volatile Handler handler = null;
    private static volatile boolean tickerStarted = false;

    @Override
    public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.contains("maps")) return;

        XposedBridge.log(TAG + ": hook на " + lpparam.packageName);

        hookHasBearing();
        hookHasSpeed();
        hookGetSpeed();
        hookGetBearing();
        hookLocationManager();
    }

    private static void hookHasBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasBearing",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        p.setResult(true);
                    }
                });
        } catch (Throwable ignored) {}
    }

    private static void hookHasSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "hasSpeed",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        p.setResult(true);
                    }
                });
        } catch (Throwable ignored) {}
    }

    private static void hookGetSpeed() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getSpeed",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        Object r = p.getResult();
                        float s = (r instanceof Float) ? (Float) r : 0f;
                        if (s < MIN_SPEED_FOR_CONE) p.setResult(MIN_SPEED_FOR_CONE);
                    }
                });
        } catch (Throwable ignored) {}
    }

    private static void hookGetBearing() {
        try {
            XposedHelpers.findAndHookMethod(Location.class, "getBearing",
                new XC_MethodHook() {
                    @Override protected void afterHookedMethod(MethodHookParam p) {
                        Object res = p.getResult();
                        float real = (res instanceof Float) ? (Float) res : 0f;
                        if (real != 0f) return;
                        long now = System.currentTimeMillis();
                        if (now - lastStepTime > STEP_INTERVAL_MS) {
                            cardinalStep = (cardinalStep + 1) % 4;
                            lastStepTime = now;
                        }
                        p.setResult(cardinalStep * 90f);
                    }
                });
        } catch (Throwable ignored) {}
    }

    // ==================================================================
    // 1. Ловим listener'ы, которые Яндекс регистрирует в LocationManager
    // 2. Сразу же начинаем тикер (раньше этого не было — вот баг!)
    // ==================================================================
    private static void hookLocationManager() {
        XC_MethodHook capture = new XC_MethodHook() {
            @Override protected void beforeHookedMethod(MethodHookParam p) {
                try {
                    for (Object a : p.args) {
                        if (a instanceof LocationListener) {
                            LocationListener ll = (LocationListener) a;
                            if (!listeners.contains(ll)) {
                                listeners.add(ll);
                                XposedBridge.log(TAG + ": listener захвачен: "
                                        + ll.getClass().getName());
                                hookListenerInstance(ll);
                            }
                            break;
                        }
                    }
                } catch (Throwable ignored) {}
            }
        };

        try { XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                String.class, long.class, float.class, LocationListener.class, capture); } catch (Throwable ignored) {}
        try { XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                long.class, float.class, android.location.Criteria.class,
                LocationListener.class, Looper.class, capture); } catch (Throwable ignored) {}
        try { XposedHelpers.findAndHookMethod(LocationManager.class, "requestLocationUpdates",
                String.class, long.class, float.class, LocationListener.class,
                Looper.class, capture); } catch (Throwable ignored) {}

        XposedBridge.log(TAG + ": LocationManager захукан");
    }

    // ==================================================================
    // Хукаем onLocationChanged у класса listener'а — так мы узнаём
    // последний реальный Location (нужен как база для injection).
    // И заодно запускаем тикер, как только увидим первый fix.
    // ==================================================================
    private static void hookListenerInstance(LocationListener ll) {
        Class<?> cls = ll.getClass();
        String name = cls.getName();
        if (hookedListenerClasses.contains(name)) return;
        hookedListenerClasses.add(name);

        try {
            XposedBridge.hookAllMethods(cls, "onLocationChanged", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (p.args.length == 0) return;
                    if (!(p.args[0] instanceof Location)) return;
                    Location loc = (Location) p.args[0];
                    lastLoc = new Location(loc);
                    if (!tickerStarted) {
                        tickerStarted = true;
                        startTicker();
                    }
                }
            });
            XposedBridge.log(TAG + ": onLocationChanged захукан у " + name);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": onLocationChanged hook fail " + name + ": " + t);
        }
    }

    private static void startTicker() {
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        XposedBridge.log(TAG + ": тикер запущен, base lat="
                + (lastLoc != null ? lastLoc.getLatitude() : "null"));
        handler.postDelayed(tickerRunnable, STEP_INTERVAL_MS);
    }

    private static final Runnable tickerRunnable = new Runnable() {
        @Override public void run() {
            try { tick(); } catch (Throwable t) {
                XposedBridge.log(TAG + ": tick error: " + t);
            }
            if (handler != null) handler.postDelayed(this, STEP_INTERVAL_MS);
        }
    };

    private static void tick() {
        Location base = lastLoc;
        if (base == null) return;

        long now = System.currentTimeMillis();
        if (now - lastStepTime > STEP_INTERVAL_MS) {
            cardinalStep = (cardinalStep + 1) % 4;
            lastStepTime = now;
        }
        float fake = cardinalStep * 90f;

        Location inject = new Location(base);
        inject.setBearing(fake);
        inject.setSpeed(MIN_SPEED_FOR_CONE);
        inject.setTime(System.currentTimeMillis());

        if (VERBOSE) {
            XposedBridge.log(TAG + ": inject " + fake + "° → "
                    + listeners.size() + " listener(s)");
        }

        for (LocationListener ll : listeners) {
            try { ll.onLocationChanged(inject); } catch (Throwable t) {
                if (VERBOSE) XposedBridge.log(TAG + ": onLocationChanged fail: " + t);
            }
        }
    }
}